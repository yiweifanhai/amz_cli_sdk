"""Prepare supplied image inputs for multimodal requests without cropping."""

from __future__ import annotations

import base64
from dataclasses import dataclass
from io import BytesIO
import re
from urllib.parse import urlsplit

import httpx
from PIL import Image, ImageOps

MAX_IMAGE_BYTES = 20 * 1024 * 1024
MAX_IMAGE_PIXELS = 40_000_000
IMAGE_MAX_SIDE = 512
JPEG_QUALITY = 85


@dataclass(frozen=True)
class PreparedImage:
    data_url: str
    original_width: int
    original_height: int
    width: int
    height: int
    original_bytes: int
    image_bytes: int


def read_image(url: str) -> bytes:
    """Read an explicit HTTP(S) or base64 image input with a byte limit."""
    if url.startswith("data:image/"):
        header, separator, encoded = url.partition(",")
        if not separator or not header.endswith(";base64"):
            raise ValueError("Image data URL must use base64")
        if len(encoded) > ((MAX_IMAGE_BYTES + 2) // 3) * 4:
            raise ValueError("Image exceeds the 20 MiB limit")
        data = base64.b64decode(encoded, validate=True)
    else:
        if urlsplit(url).scheme not in {"http", "https"}:
            raise ValueError("Image must be an HTTP(S) URL or base64 image")
        data = bytearray()
        with httpx.stream("GET", url, timeout=30, follow_redirects=True) as response:
            response.raise_for_status()
            for chunk in response.iter_bytes():
                data.extend(chunk)
                if len(data) > MAX_IMAGE_BYTES:
                    raise ValueError("Image exceeds the 20 MiB limit")
        data = bytes(data)
    if not data or len(data) > MAX_IMAGE_BYTES:
        raise ValueError("Image is empty or exceeds the 20 MiB limit")
    return data


def prepare_image(url: str, max_side: int = IMAGE_MAX_SIDE) -> PreparedImage:
    """Scale the complete image to at most ``max_side`` px per side (512 by default); never enlarge it."""
    if not isinstance(max_side, int) or isinstance(max_side, bool) or not 64 <= max_side <= 2048:
        raise ValueError("max_side must be an integer between 64 and 2048")
    data = read_image(url)
    with Image.open(BytesIO(data)) as original:
        if original.width * original.height > MAX_IMAGE_PIXELS:
            raise ValueError("Image exceeds the 40 megapixel limit")
        if getattr(original, "n_frames", 1) != 1:
            raise ValueError("COSMO requires a single-frame image")
        picture = ImageOps.exif_transpose(original)
        original_width, original_height = picture.size
        picture.thumbnail((max_side, max_side), Image.Resampling.LANCZOS)
        # Flatten transparent images on white so text stays visible in JPEG.
        if "A" in picture.getbands() or "transparency" in picture.info:
            rgba = picture.convert("RGBA")
            picture = Image.new("RGB", rgba.size, "white")
            picture.paste(rgba, mask=rgba.getchannel("A"))
        else:
            picture = picture.convert("RGB")
        output = BytesIO()
        picture.save(output, format="JPEG", quality=JPEG_QUALITY, optimize=True)
        encoded = output.getvalue()
        return PreparedImage(
            data_url="data:image/jpeg;base64," + base64.b64encode(encoded).decode("ascii"),
            original_width=original_width, original_height=original_height,
            width=picture.width, height=picture.height,
            original_bytes=len(data), image_bytes=len(encoded),
        )


# ---------------------------------------------------------------------------
# Listing audit helpers: full-size URLs, A+ cleaning and pixel measurement.
# ---------------------------------------------------------------------------

# Groups: host, image id path, extension. The data source sometimes returns an
# ``/images/W/<experiment>/`` prefix before ``images/I``; it is dropped as well.
_AMAZON_IMAGE = re.compile(
    r"^(https?://[^/]*media-amazon\.com/)(?:images/W/[^/]+/)?(images/I/[^./]+)(?:\.[^/]*)?(\.[A-Za-z]{3,4})$"
)
_SIZE_TOKENS = (
    re.compile(r"_(?:SX|UX|SL|AC_SX|AC_UX|AC_SL)(\d+)"),
    re.compile(r"_(?:SR|AC_SR)(\d+),\d+"),
    re.compile(r"_US(\d+)_"),
)
_CROP_TOKEN = re.compile(r"_CR\d+,\d+,(\d+),\d+")
WHITE_LEVEL = 245
CONTENT_LEVEL = 240
MEASURE_SIDE = 600


def full_size_url(url: str) -> str:
    """Drop Amazon rendering modifiers (``._AC_US200_``) so the original upload is requested."""
    text = (url or "").strip()
    match = _AMAZON_IMAGE.match(text)
    return "".join(match.groups()) if match else text


def _rendered_width(url: str) -> int | None:
    for pattern in _SIZE_TOKENS:
        match = pattern.search(url)
        if match:
            return int(match.group(1))
    match = _CROP_TOKEN.search(url)
    return int(match.group(1)) if match else None


def select_aplus_images(urls: list[str], max_count: int = 6, min_width: int = 600) -> tuple[list[str], dict]:
    """Keep full-width A+ modules; drop thumbnails, other products' images and duplicates.

    A+ lists from the data source mix full-width modules (``SX970``) with brand
    story cards and comparison-table thumbnails (``SX362``/``SR166``) that often
    show other ASINs. Unknown widths are kept unless the URL is a catalogue
    product image (``/images/I/``), which inside A+ is almost always a
    comparison-table thumbnail.
    """
    kept: list[str] = []
    seen: set[str] = set()
    stats = {"raw": 0, "kept": 0, "dropped_small": 0, "dropped_product_thumbnail": 0,
             "dropped_duplicate": 0, "truncated": 0}
    for raw in urls or []:
        url = str(raw or "").strip()
        if not url:
            continue
        stats["raw"] += 1
        width = _rendered_width(url)
        # Catalogue images are checked first so comparison-table thumbnails
        # (``/images/I/..._SR166,182_``) are reported as product thumbnails.
        if "/images/I/" in url and (width is None or width < min_width):
            stats["dropped_product_thumbnail"] += 1
            continue
        if width is not None and width < min_width:
            stats["dropped_small"] += 1
            continue
        key = re.sub(r"\.__?[^/]*?(\.[A-Za-z]{3,4})$", r"\1", url.split("?")[0])
        if key in seen:
            stats["dropped_duplicate"] += 1
            continue
        seen.add(key)
        if len(kept) >= max_count:
            stats["truncated"] += 1
            continue
        kept.append(url)
    stats["kept"] = len(kept)
    return kept, stats


def measure_product_image(url: str, image_id: str = "main", reader=None) -> dict:
    """Measure the full-size image: original size, white border share and product fill.

    ``white_border_ratio`` is the share of near-white pixels on the outer 2 %
    ring; ``fill_ratio`` is the larger side of the non-white bounding box divided
    by the matching image side. Both are computed on a copy no larger than 600 px.
    """
    from PIL import ImageChops

    source = full_size_url(url)
    data = (reader or read_image)(source)
    with Image.open(BytesIO(data)) as original:
        if original.width * original.height > MAX_IMAGE_PIXELS:
            raise ValueError("Image exceeds the 40 megapixel limit")
        picture = ImageOps.exif_transpose(original)
        width, height = picture.size
        if "A" in picture.getbands() or "transparency" in picture.info:
            rgba = picture.convert("RGBA")
            flat = Image.new("RGB", rgba.size, "white")
            flat.paste(rgba, mask=rgba.getchannel("A"))
            picture = flat
        else:
            picture = picture.convert("RGB")
        picture.thumbnail((MEASURE_SIDE, MEASURE_SIDE), Image.Resampling.BILINEAR)
        # A 1 px side is a "no image" placeholder (or unmeasurable), not a low resolution upload.
        if min(picture.size) < 2:
            raise ValueError("Image is too small to measure")
        red, green, blue = picture.split()
        darkest = ImageChops.darker(ImageChops.darker(red, green), blue)
        w, h = darkest.size
        ring = max(1, round(min(w, h) * 0.02))
        border = [
            darkest.crop((0, 0, w, ring)), darkest.crop((0, h - ring, w, h)),
            darkest.crop((0, ring, ring, h - ring)), darkest.crop((w - ring, ring, w, h - ring)),
        ]
        total = white = 0
        for strip in border:
            values = strip.tobytes()  # mode "L": one byte per pixel (getdata is deprecated)
            total += len(values)
            white += sum(1 for value in values if value >= WHITE_LEVEL)
        patch = max(2, round(min(w, h) * 0.05))
        corners = 0
        for left, top in ((0, 0), (w - patch, 0), (0, h - patch), (w - patch, h - patch)):
            values = darkest.crop((left, top, left + patch, top + patch)).tobytes()
            if values and sum(1 for value in values if value >= WHITE_LEVEL) >= 0.9 * len(values):
                corners += 1
        box = darkest.point(lambda value: 255 if value < CONTENT_LEVEL else 0).getbbox()
        fill = max((box[2] - box[0]) / w, (box[3] - box[1]) / h) if box else 0.0
    return {
        "image_id": image_id, "url": source, "original_width": width, "original_height": height,
        "white_border_ratio": round(white / total, 4) if total else None, "fill_ratio": round(fill, 4), "white_corners": corners,
    }
