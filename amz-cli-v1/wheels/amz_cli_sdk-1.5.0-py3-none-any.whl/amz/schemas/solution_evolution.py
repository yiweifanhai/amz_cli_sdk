"""Contracts for the Market solution-evolution task.

One Amazon keyword sample is merged into product lines, classified along 2-4
dimensions (Amazon storefront filters first, model-added ones when filters are
missing), then a deterministic calculation describes each class: share, how the
same old lines are trending, how many new lines verified, and a program stage and
grade. A final model request explains which class is replacing which, constrained
by those program facts. Results are task output, never persisted Market fields.
"""
from __future__ import annotations

from datetime import date
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field

from amz.schemas.solution_directions import (
    DirectionsThresholds,
    FollowRow,
    Grade,
    Kind,
    MarketStructure,
    Nature,
    ProductLine,
    Relation,
)
from amz.schemas.solution_outlook import Asin, Confidence, Month, Text

Source = Literal["amazon_filter", "model"]
Stage = Literal["新兴上升", "单点新品", "稳定主流", "老品下滑", "停滞", "样本不足"]
EvolutionTier = Literal["下一代候选", "细分补充", "当前主流", "正被替代", "需求走弱", "微改进", "证据不足"]
OPPORTUNITY_TIERS = ("下一代候选", "细分补充")
INCUMBENT_STAGES = ("稳定主流", "老品下滑")
UNKNOWN = "未知"
OTHER = "其他"
BUCKETS = (UNKNOWN, OTHER)
MAX_LINES = 120


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class EvolutionThresholds(DirectionsThresholds):
    """Verified-line gates and grades reuse the directions calibration; the rest classify stages."""

    min_class_lines: int = Field(default=3, ge=1, description="主维度一类少于该商品线数且无已验证新品时为样本不足")
    mainstream_share: float = Field(default=0.25, ge=0, le=1, description="老品份额最高且不低于该值的类视为主流")
    decline_gap: float = Field(default=0.10, ge=0, le=1,
                               description="同批老品增长比全市场同批低该幅度以上视为下滑（近 3 月或同比）")
    min_growth_lines: int = Field(default=3, ge=1, description="计算一类同批增长所需的最少商品线数")
    price_cut: float = Field(default=0.15, ge=0, le=1, description="已验证新品中位价比同类老品低该比例以上视为降价起量")
    unknown_share: float = Field(default=0.3, ge=0, le=1, description="主维度未知/其他占比超过该值时提示分类不可靠")


# ---------------------------------------------------------------------------
# Step 2a: dimensions (analysis.market.evolution_axes)
# ---------------------------------------------------------------------------


class AxesItem(_Strict):
    item_id: Annotated[str, Field(min_length=1)]
    title: str | None = Field(default=None, max_length=2000)
    price: float | None = Field(default=None, ge=0)


class EvolutionAxesInput(_Strict):
    term: Text
    product_hint: str | None = Field(default=None, max_length=300)
    filters: dict[str, list[str]] = Field(default_factory=dict, description="已过滤的亚马逊前台产品属性筛选")
    items: list[AxesItem] = Field(min_length=1, max_length=MAX_LINES)
    model: str = "pro"


class AxisValue(_Strict):
    v: Annotated[str, Field(min_length=1, max_length=20)]
    desc: str = ""
    nature: Nature = "新方案"
    filter_options: list[str] = Field(default_factory=list, description="对应的亚马逊筛选选项原文")


class EvolutionAxis(_Strict):
    name: Text
    kind: Kind
    source: Source
    filter_group: str | None = Field(default=None, description="source=amazon_filter 时对应的筛选组名")
    primary: bool = False
    values: list[AxisValue] = Field(min_length=2, max_length=8)


class EvolutionAxes(_Strict):
    axes: list[EvolutionAxis] = Field(min_length=1, max_length=4)
    filters_offered: list[str] = Field(default_factory=list)
    limitations: list[Text]


# ---------------------------------------------------------------------------
# Step 2b: tagging with titles and main images (analysis.market.evolution_tags)
# ---------------------------------------------------------------------------


class TagItem(_Strict):
    item_id: Annotated[str, Field(min_length=1)]
    title: str | None = Field(default=None, max_length=2000)
    price: float | None = Field(default=None, ge=0)
    image_url: str | None = None
    verified: bool = Field(default=False, description="已验证新品线：主维度不允许落入未知")


class EvolutionTagsInput(_Strict):
    term: Text
    axes: list[EvolutionAxis] = Field(min_length=1, max_length=4)
    items: list[TagItem] = Field(min_length=1, max_length=MAX_LINES)
    use_images: bool = True
    batch_size: int = Field(default=20, ge=5, le=40)
    model: str = "pro"


class TaggedLine(_Strict):
    item_id: str
    rel: Relation
    values: list[str]
    image: bool = Field(description="打标时是否带了主图")


class EvolutionTags(_Strict):
    items: list[TaggedLine]
    coerced: int = 0
    image_failed: list[str] = Field(default_factory=list)
    verified_unknown: list[str] = Field(default_factory=list, description="纠错后主维度仍为未知的已验证新品线")
    batches: int = 0
    limitations: list[Text]


# ---------------------------------------------------------------------------
# Step 3: class dynamics (calc.market.solution_evolution)
# ---------------------------------------------------------------------------


class EvolutionCalcInput(_Strict):
    current_date: date
    lines: list[ProductLine]
    axes: list[EvolutionAxis] = Field(min_length=1, max_length=4)
    tags: list[TaggedLine]
    thresholds: EvolutionThresholds = Field(default_factory=EvolutionThresholds)


class ClassStats(_Strict):
    axis: str
    value: str
    desc: str
    nature: Nature
    bucket: bool = Field(description="未知/其他，不参与判断")
    lines: int
    sold: int
    share: float | None = Field(description="本类月销占本体商品月销")
    revenue_share: float | None
    recent_share: float | None = Field(description="在≤新品月数的有销量商品线中的份额")
    base_share: float | None = Field(description="在老商品线中的份额")
    shift: float | None
    new_units_share: float | None = Field(description="本类月销里新品线的占比")
    growth_3m: float | None = Field(description="本类同批商品线近 3 个完整月 vs 前 3 个月")
    growth_3m_lines: int
    growth_yoy: float | None = Field(description="本类同批商品线近 3 个完整月 vs 去年同期")
    growth_yoy_lines: int
    growth_gap_3m: float | None = Field(description="growth_3m 减全市场同口径增长")
    growth_gap_yoy: float | None
    share_start: float | None = Field(description="12 个月份额序列最早 3 个有数月均值")
    share_end: float | None = Field(description="最近 3 个完整月均值")
    series: list[tuple[Month, float | None]]
    verified: list[Asin]
    official_verified: int
    aba_verified: int
    suspected: int
    suspected_ids: list[Asin] = Field(default_factory=list, description="疑似老链接换新 ASIN 的商品线，不能作为证据")
    ramp_days_median: float | None = Field(default=None, description="已验证新品从上架到首次月销过线的天数中位数（上界）")
    ramp_count: int = 0
    follow: list[FollowRow]
    entries_6m: int
    ramped_6m: int
    price_median: float | None
    price_verified: float | None
    price_older: float | None
    rating_verified: float | None
    rating_older: float | None
    price_cut: bool = Field(description="已验证新品主要靠更低价格起量")
    launch_verified: tuple[date, date] | None
    top: list[Asin]
    mainstream: bool
    declining: bool
    stage: Stage
    grade: Grade | None
    notes: list[Text]


class AxisStats(_Strict):
    name: str
    kind: Kind
    source: Source
    primary: bool
    classes: list[ClassStats]


class ReplacementPair(_Strict):
    riser: str
    incumbent: str
    riser_share_change: float | None
    incumbent_share_change: float | None
    incumbent_growth_gap_3m: float | None
    price_ratio: float | None = Field(description="上升类已验证新品中位价 / 被比较类中位价")


class EvolutionDynamics(_Strict):
    primary_axis: str
    market_growth_3m: float | None
    market_growth_yoy: float | None
    on_topic: int
    accessory: int
    off_topic: int
    untagged: int
    axes: list[AxisStats]
    pairs: list[ReplacementPair]
    supplements: list[ClassStats] = Field(description="副维度 A/B 级新方案取值")
    limitations: list[Text]


# ---------------------------------------------------------------------------
# Step 4: judgement (analysis.market.evolution_judge)
# ---------------------------------------------------------------------------


class EvolutionJudgeInput(_Strict):
    term: Text
    product_hint: str | None = None
    structure: MarketStructure
    dynamics: EvolutionDynamics
    titles: dict[str, str] = Field(default_factory=dict, description="ASIN → 标题，用于证据与代表商品")
    model: str = "pro"


class ClassJudgement(_Strict):
    value: str
    tier: EvolutionTier
    replaces: str = Field(default="", description="被替代类的取值；无替代对象为空")
    why_better: list[Text] = Field(default_factory=list)
    barriers: list[Text] = Field(default_factory=list)
    counter_evidence: list[Text] = Field(default_factory=list)
    unknowns: list[Text] = Field(default_factory=list)
    evidence_ids: list[Asin] = Field(default_factory=list)
    confidence: Confidence
    program_notes: list[Text] = Field(default_factory=list, description="程序对模型判断的修正")


class SupplementJudgement(_Strict):
    axis: str
    value: str
    why: list[Text] = Field(default_factory=list)
    evidence_ids: list[Asin] = Field(default_factory=list)


class EvolutionJudgement(_Strict):
    summary: Text = Field(description="最终结论；程序修正过等级或替代链时由程序按最终等级改写")
    model_summary: str | None = Field(default=None, description="模型原结论")
    summary_source: Literal["model", "program"] = "model"
    classes: list[ClassJudgement]
    supplements: list[SupplementJudgement] = Field(default_factory=list)
    unknowns: list[Text] = Field(default_factory=list)
    limitations: list[Text]


# ---------------------------------------------------------------------------
# Task result (entity.market.solution_evolution)
# ---------------------------------------------------------------------------


class ChainLink(_Strict):
    incumbent: str
    riser: str
    tier: EvolutionTier
    grade: Grade | None
    confidence: Confidence
    evidence_ids: list[Asin]


class SolutionEvolutionResult(_Strict):
    term: Text
    current_date: date
    conclusion: str | None = Field(description="市场一句话结论；未出判断时为空")
    chain: list[ChainLink] = Field(default_factory=list, description="谁在替代谁")
    structure: MarketStructure
    filters: dict[str, list[str]] = Field(default_factory=dict, description="交给模型的前台筛选维度")
    axes: EvolutionAxes | None
    tags: EvolutionTags | None
    dynamics: EvolutionDynamics | None
    judgement: EvolutionJudgement | None
    lines: list[ProductLine]
    usage: dict = Field(default_factory=dict)
    limitations: list[Text]
