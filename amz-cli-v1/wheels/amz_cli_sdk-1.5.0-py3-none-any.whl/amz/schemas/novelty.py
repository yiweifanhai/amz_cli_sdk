"""Product novelty against earlier solutions in its Market samples and solution-term search.

An earlier ("legacy") product was first available at least ``min_lead_months``
before the target product; when the target has no listing date, at least
``min_age_months`` before the evaluation date.

The model grades six innovation dimensions per legacy group (level 0–3 with a
named innovation pattern), whether buyers would care (``buyer_value``) and
non-innovation flags. Product attributes come only from the supplied listing and
main image; category common sense may explain what a difference means. The score
answers "is this an innovation worth following": it starts from the strongest
dimension (not a weighted sum, so a pure scenario or audience innovation can score
high), adds a small bonus for further strong dimensions, then applies caps for low
buyer value, flags and an existing solution (default 60). A same-solution judgement
whose form, function, scenario or audience differs by level 2+ is an ``upgrade``
and does not count as existing.
"""
from __future__ import annotations

from datetime import date
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

Text = Annotated[str, Field(min_length=1)]
NoveltyDimension = Literal["form", "function", "scenario", "audience", "appearance", "emotion"]
NOVELTY_DIMENSIONS: tuple[str, ...] = ("form", "function", "scenario", "audience", "appearance", "emotion")
DIMENSION_LABELS: dict[str, str] = {
    "form": "原理/形态创新",
    "function": "功能创新",
    "scenario": "场景创新",
    "audience": "人群创新",
    "appearance": "外观/材质改进",
    "emotion": "情绪价值",
}
# Named patterns per dimension (merged from the 10-type benchmark comparison taxonomy).
INNOVATION_PATTERNS: dict[str, tuple[str, ...]] = {
    "form": ("新原理", "形态颠覆", "结构改良"),
    "function": ("功能叠加", "跨界混搭", "极致单点", "功能改良"),
    "scenario": ("场景细分", "场景迁移"),
    "audience": ("人群迁移", "身份标签"),
    "appearance": ("外观升级", "材质升级"),
    "emotion": ("情绪价值",),
}
PATTERN_DESCRIPTIONS: dict[str, str] = {
    "新原理": "换了解决问题的核心原理或机制",
    "形态颠覆": "把产品固有形状/结构彻底改变（平铺菜板→书本状；有叶风扇→无叶）",
    "结构改良": "核心原理不变，结构或使用方式有用户可感知的改进",
    "功能叠加": "集成多个功能（野营灯+充电宝+驱蚊）",
    "跨界混搭": "两个成熟品类融合（保温杯+蓝牙音箱）",
    "极致单点": "放弃其他，把一个关键参数做到远超同类（待机一年的录音笔）",
    "功能改良": "增减或改进个别功能、配置",
    "场景细分": "针对一个更具体的场景设计（房车专用防潮地毯）",
    "场景迁移": "把 A 场景的产品拿到 B 场景用",
    "人群迁移": "使用对象根本改变（婴儿硅胶餐具→宠物餐具）",
    "身份标签": "强绑定亚文化或身份（哥特风家居）",
    "外观升级": "功能不变，设计风格明显升级",
    "材质升级": "功能不变，材质明显升级（塑料→亚克力+黄铜）",
    "情绪价值": "卖解压、治愈、搞怪或炫耀，功能不是重点",
}
LEVEL_BASE: dict[int, int] = {0: 0, 1: 25, 2: 55, 3: 80}
LEVEL_TEXT: dict[int, str] = {0: "无差异", 1: "小改", 2: "明显不同", 3: "完全不同"}
BUYER_VALUE_TEXT: dict[int, str] = {0: "买家基本不在乎", 1: "买家有一点兴趣", 2: "买家明显愿意因此选它", 3: "强需求，买家会主动找"}
EXTRA_STRONG_BONUS = 8      # per additional dimension at level >= 2
MAX_EXTRA_BONUS = 16
TOP_BUYER_VALUE_BONUS = 4
BUYER_VALUE_CAPS: dict[int, int] = {0: 30, 1: 60}
NoveltyFlag = Literal["ip_derivative", "model_specific", "bundle_only", "downgrade", "seasonal"]
FLAG_CAPS: dict[str, int] = {
    "ip_derivative": 20, "bundle_only": 20, "downgrade": 30, "model_specific": 50, "seasonal": 50,
}
FLAG_LABELS: dict[str, str] = {
    "ip_derivative": "知名 IP/影视/球队周边",
    "model_specific": "通用款改成某个具体型号的专用款",
    "bundle_only": "主要差异只是加量、多送配件、凑套装",
    "downgrade": "主要差异是去掉功能或结构做简化降配",
    "seasonal": "主要为某个节日、季节或一次性场合设计",
}
MAX_LEVEL = 3
DEFAULT_EXISTING_CAP = 60
# A "same solution" may only differ by tweaks on these dimensions (level <= 1).
STRUCTURAL_DIMENSIONS: tuple[str, ...] = ("form", "function", "scenario", "audience")
UPGRADE_LEVEL = 2
MAX_COMPARISON_GROUPS = 13  # max_groups (<=12) plus the solution-search group
MAX_PRESCREEN_CANDIDATES = 200


class _Frozen(BaseModel):
    model_config = ConfigDict(frozen=True, str_strip_whitespace=True)


class _Output(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


def _upper(value):
    return value.strip().upper() if isinstance(value, str) else value


# ---------------------------------------------------------------------------
# calc.product.legacy_split
# ---------------------------------------------------------------------------


class DatedProduct(_Frozen):
    asin: Text
    listing_date: str | None = None
    monthly_sales: int | None = None

    _asin = field_validator("asin", mode="before")(_upper)


class LegacySplitInput(_Frozen):
    products: tuple[DatedProduct, ...]
    as_of: date
    min_age_months: int = Field(default=12, ge=1, le=120)
    exclude_asins: tuple[str, ...] = ()
    anchor_date: str | None = Field(default=None, description="本品上架日期；有效时按它往前 min_lead_months 取老品")
    min_lead_months: int = Field(default=6, ge=0, le=120)


class LegacySplitOutput(_Output):
    cutoff_date: date
    cutoff_basis: Literal["target_listing", "as_of"]
    anchor_date: date | None = None
    legacy_asins: list[str]
    recent_asins: list[str]
    missing_date_asins: list[str]
    listing_dates: dict[str, str] = Field(description="ASIN → 规范化后的上架日期 (ISO)")


# ---------------------------------------------------------------------------
# analysis.product.novelty
# ---------------------------------------------------------------------------


class NoveltyProductFacts(_Frozen):
    asin: Text
    title: str = ""
    bullet_points: tuple[str, ...] = ()
    image_url: str = ""
    listing_date: str | None = None
    monthly_sales: int | None = None

    _asin = field_validator("asin", mode="before")(_upper)


class NoveltyGroupInput(_Frozen):
    group_name: Text
    solution: Text
    legacy_count: int = Field(ge=1)
    members: tuple[NoveltyProductFacts, ...] = Field(min_length=1, max_length=5)


class NoveltyAnalysisInput(_Frozen):
    target: NoveltyProductFacts
    groups: tuple[NoveltyGroupInput, ...] = Field(min_length=1, max_length=MAX_COMPARISON_GROUPS)
    model: str = Field(default="pro", min_length=1)

    @model_validator(mode="after")
    def target_not_in_groups(self):
        names = [group.group_name for group in self.groups]
        if len(set(names)) != len(names):
            raise ValueError("group_name must be unique")
        seen = set()
        for group in self.groups:
            if len(group.members) > group.legacy_count:
                raise ValueError("representatives cannot outnumber the legacy products in the group")
            for member in group.members:
                if member.asin == self.target.asin:
                    raise ValueError("target product must not be its own legacy benchmark")
                if member.asin in seen:
                    raise ValueError(f"duplicate legacy benchmark: {member.asin}")
                seen.add(member.asin)
        return self


class DimensionGrade(_Output):
    dimension: NoveltyDimension
    level: int = Field(strict=True, ge=0, le=MAX_LEVEL, description="0 无差异，1 微调，2 明显创新，3 根本不同")
    pattern: str | None = Field(default=None, description="level ≥1 时必填，取自该维度的创新模式")
    evidence: Text = Field(description="依据标题、五点或主图写出的可见差异；无差异写“未见差异证据”")
    insight: str = Field(default="", description="结合品类常识说明这一差异对买家意味着什么；没有可留空")

    @model_validator(mode="after")
    def pattern_matches_level(self):
        allowed = INNOVATION_PATTERNS[self.dimension]
        if self.level == 0:
            if self.pattern:
                raise ValueError(f"{self.dimension}: pattern must be null when level is 0")
            self.pattern = None
        elif self.pattern not in allowed:
            raise ValueError(f"{self.dimension}: pattern must be one of {list(allowed)} when level >= 1")
        return self


class FlagJudgement(_Output):
    flag: NoveltyFlag
    reason: Text = Field(description="为什么打这个标记，引用标题、五点或主图")


class GroupJudgement(_Output):
    """Model output for one legacy solution group."""

    same_solution: bool = Field(strict=True, description="本品是否与该组老品属于同一解决方案（核心原理、形态和主要功能相同，可有改良）")
    matched_asins: list[Text] = Field(description="与本品方案相同的老品 ASIN")
    shared_points: list[Text]
    novel_points: list[Text]
    dimensions: list[DimensionGrade]
    buyer_value: int = Field(strict=True, ge=0, le=3, description="0 买家基本不在乎；1 有一点吸引；2 明显愿意选它；3 强需求、会主动找")
    buyer_value_reason: Text
    flags: list[FlagJudgement] = Field(default_factory=list)
    reason: Text

    @model_validator(mode="after")
    def complete_dimensions(self):
        seen = [grade.dimension for grade in self.dimensions]
        if sorted(seen) != sorted(NOVELTY_DIMENSIONS):
            raise ValueError(f"dimensions must grade each of {list(NOVELTY_DIMENSIONS)} exactly once")
        if len({item.flag for item in self.flags}) != len(self.flags):
            raise ValueError("flags must be unique")
        self.matched_asins = [_upper(asin) for asin in self.matched_asins]
        if len(set(self.matched_asins)) != len(self.matched_asins):
            raise ValueError("matched_asins must be unique")
        if self.same_solution and not self.matched_asins:
            raise ValueError("same_solution requires matched_asins")
        if not self.same_solution and self.matched_asins:
            raise ValueError("matched_asins must be empty when same_solution is false")
        return self


class NoveltyGroupJudgement(GroupJudgement):
    group_name: Text
    compared_asins: list[Text] = Field(min_length=1)
    images_used: list[str] = Field(default_factory=list, description="成功送入模型的主图所属 ASIN")

    @model_validator(mode="after")
    def matches_were_compared(self):
        unknown = set(self.matched_asins) - set(self.compared_asins)
        if unknown:
            raise ValueError(f"matched_asins not in the comparison: {sorted(unknown)}")
        return self


class SkippedGroup(_Output):
    group_name: Text
    reason: Text


class FailedRef(_Output):
    asin: Text
    reason: Text


class NoveltyAnalysisOutput(_Output):
    groups: list[NoveltyGroupJudgement]
    skipped_groups: list[SkippedGroup] = Field(default_factory=list)
    failed_refs: list[FailedRef] = Field(default_factory=list)
    limitations: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# analysis.product.solution_terms
# ---------------------------------------------------------------------------


class SolutionTermsInput(_Frozen):
    asin: Text
    title: Text
    brand: str | None = Field(default=None, description="品牌名，其中的词不得出现在方案词里")
    bullet_points: tuple[str, ...] = ()
    avoid_terms: tuple[str, ...] = Field(default=(), description="已用于市场取样的搜索词，方案词不得与之相同")
    model: str = Field(default="lite", min_length=1)


class SolutionTermsDraft(_Output):
    """Model output."""

    terms: list[Text] = Field(min_length=1, max_length=2)
    reason: Text


class SolutionTermsOutput(_Output):
    terms: list[str] = Field(min_length=1, max_length=2)
    reason: str


# ---------------------------------------------------------------------------
# analysis.product.solution_prescreen
# ---------------------------------------------------------------------------


class PrescreenCandidate(_Frozen):
    asin: Text
    title: Text

    _asin = field_validator("asin", mode="before")(_upper)


class PrescreenTarget(_Frozen):
    asin: Text
    title: Text
    bullet_points: tuple[str, ...] = ()


class SolutionPrescreenInput(_Frozen):
    target: PrescreenTarget
    candidates: tuple[PrescreenCandidate, ...] = Field(min_length=1, max_length=MAX_PRESCREEN_CANDIDATES)
    limit: int = Field(default=8, ge=1, le=20)
    model: str = Field(default="lite", min_length=1)

    @model_validator(mode="after")
    def unique_candidates(self):
        asins = [item.asin for item in self.candidates]
        if len(set(asins)) != len(asins):
            raise ValueError("candidates must have unique ASINs")
        if self.target.asin.strip().upper() in asins:
            raise ValueError("target must not be a prescreen candidate")
        return self


class PrescreenPick(_Output):
    id: Text
    reason: Text


class PrescreenDraft(_Output):
    """Model output; ids are the short local ids shown to the model."""

    matches: list[PrescreenPick]


class PrescreenSelection(_Output):
    asin: Text
    title: Text
    reason: Text


class SolutionPrescreenOutput(_Output):
    selected: list[PrescreenSelection] = Field(description="按可能性从高到低排序的疑似同方案候选")
    screened_count: int


# ---------------------------------------------------------------------------
# calc.product.novelty_score
# ---------------------------------------------------------------------------


class NoveltyScoreInput(_Frozen):
    groups: tuple[NoveltyGroupJudgement, ...] = Field(min_length=1)
    existing_cap: int = Field(default=DEFAULT_EXISTING_CAP, ge=0, le=100)


class BaseScore(_Output):
    points: int = Field(ge=0, le=100)
    dimension: NoveltyDimension | None = Field(default=None, description="最强创新维度；全为 0 级时为空")
    label: str | None = None
    pattern: str | None = None
    level: int = Field(ge=0, le=MAX_LEVEL)
    reason: Text = Field(description="为什么是这个基础分")
    evidence: str = Field(default="", description="该维度的图文依据")
    insight: str = Field(default="", description="该维度的常识解读")


class ScoreAdjustment(_Output):
    kind: Literal["extra_dimension", "buyer_value"]
    points: int = Field(ge=0, description="实际加的分；超出加分上限的项为 0")
    reason: Text
    evidence: str = ""


class ScoreCap(_Output):
    kind: Literal["buyer_value", "flag", "existing"]
    cap: int = Field(ge=0, le=100)
    reason: Text
    evidence: str = ""
    effective: bool = Field(description="该上限是否低于封顶前分数、实际压低了分数")


class GroupScore(_Output):
    group_name: Text
    same_solution: bool = Field(description="模型原始判定")
    match_type: Literal["same", "upgrade", "different"] = Field(
        description="same 计入 existing；upgrade 为模型判同方案但原理形态/功能/场景/人群有 ≥2 级差异的改良款")
    raised_dimensions: list[NoveltyDimension] = Field(default_factory=list, description="使 same_solution 降为 upgrade 的维度")
    base: BaseScore
    bonuses: list[ScoreAdjustment] = Field(default_factory=list)
    bonus: int = Field(ge=0, description="加分合计")
    uncapped_score: int = Field(ge=0, le=100, description="基础分 + 加分（不超过 100）")
    caps: list[ScoreCap] = Field(default_factory=list, description="买家价值和非创新标记带来的上限（同方案上限在总分层）")
    score: int = Field(ge=0, le=100, description="本组得分 = min(封顶前分数, 各上限)")


class ScoreExplanation(_Output):
    """Why the final score is what it is, step by step."""

    closest_group: Text
    selection_reason: Text = Field(description="为什么用这一组的分数")
    base: BaseScore
    bonuses: list[ScoreAdjustment]
    uncapped_score: int = Field(ge=0, le=100)
    caps: list[ScoreCap] = Field(description="本组上限加同方案上限")
    final_score: int = Field(ge=0, le=100)
    summary: Text = Field(description="一句话算式")


class InnovationPoint(_Output):
    dimension: NoveltyDimension
    label: Text
    pattern: Text
    level: int = Field(ge=1, le=MAX_LEVEL)
    evidence: Text
    insight: str = ""


class NoveltyScoreOutput(_Output):
    existing: bool
    innovation_score: int = Field(ge=0, le=100)
    raw_score: int = Field(ge=0, le=100, description="existing 封顶前分数：existing=true 时取匹配组得分，否则取最接近的老品方案组得分")
    score_capped: bool = Field(description="是否因 existing_cap 封顶")
    existing_cap: int
    closest_group: Text
    explanation: ScoreExplanation
    group_scores: list[GroupScore]


# ---------------------------------------------------------------------------
# entity.product.novelty
# ---------------------------------------------------------------------------


MatchSource = Literal["market_sample", "solution_search"]


class ExistingMatch(_Output):
    asin: Text
    group_name: Text
    listing_date: str | None = None
    monthly_sales: int | None = None
    source: MatchSource
    query: Text = Field(description="召回该商品的搜索词")
    match_type: Literal["existing_hot", "prior_attempt"] = Field(
        description="月销量 ≥ hot_sales_threshold 为 existing_hot，否则（含销量未知）为 prior_attempt")


class UpgradeMatch(_Output):
    asin: Text
    group_name: Text
    listing_date: str | None = None
    monthly_sales: int | None = None
    source: MatchSource
    query: Text
    raised_dimensions: list[NoveltyDimension]


class SearchCoverage(_Output):
    query: Text
    source: MatchSource
    pages: int
    total: int | None = Field(default=None, description="接口报告的结果总数，未知为空")
    fetched: int = Field(description="实际拉到的商品数")


class NoveltySample(_Output):
    market_term: Text
    market_terms: list[str] = Field(default_factory=list, description="用于市场取样的全部搜索词")
    term_source: Literal["input", "reverse_keyword"] = "reverse_keyword"
    cutoff_basis: Literal["target_listing", "as_of"] = "as_of"
    target_listing_date: date | None = None
    solution_terms: list[str] = Field(default_factory=list)
    solution_candidate_count: int = Field(default=0, description="方案词召回中早于截止日、送入标题预筛的商品数")
    solution_prescreened: list[str] = Field(default_factory=list, description="标题预筛判定可能同方案的 ASIN")
    coverage: list[SearchCoverage] = Field(default_factory=list)
    pages: int
    product_count: int
    legacy_count: int
    recent_count: int
    missing_date_asins: list[str]
    eligible_group_count: int | None = Field(default=None, ge=0, description="含符合年限老品的候选组总数，包括跳过的组，本品不计入老品")
    target_group: Text | None = Field(default=None, description="本品按标题归入的候选组名称，未归入候选组时为空")
    compared_group_count: int
    skipped_groups: list[SkippedGroup]
    failed_refs: list[FailedRef]


class ProductNoveltyOutput(_Output):
    asin: Text
    as_of: date
    cutoff_date: date
    cutoff_basis: Literal["target_listing", "as_of"]
    min_age_months: int
    min_lead_months: int
    hot_sales_threshold: int
    existing: bool
    existing_matches: list[ExistingMatch]
    upgrades: list[UpgradeMatch]
    innovation_score: int = Field(ge=0, le=100)
    raw_score: int = Field(ge=0, le=100)
    score_capped: bool
    existing_cap: int
    closest_group: Text
    explanation: ScoreExplanation = Field(description="打分理由：为什么用这一组、基础分、每项加分、每条上限和一句话算式")
    primary_innovation: str | None = Field(default=None, description="相对最接近老品组的最强创新，如“场景创新·场景迁移”")
    innovations: list[InnovationPoint] = Field(default_factory=list, description="相对最接近老品组的创新点，按等级从高到低")
    buyer_value: int = Field(ge=0, le=3)
    buyer_value_reason: str
    flags: list[FlagJudgement] = Field(default_factory=list)
    novel_points: list[str]
    groups: list[NoveltyGroupJudgement]
    group_scores: list[GroupScore]
    sample: NoveltySample
    limitations: list[str]
