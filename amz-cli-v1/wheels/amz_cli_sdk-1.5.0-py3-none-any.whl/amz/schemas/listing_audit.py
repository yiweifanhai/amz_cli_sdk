"""Listing audit contracts: inputs prepared by ``Product.listing_audit`` and the report.

The audit reviews one live Listing section by section (title, bullets, main
image, gallery, A+, description). Every finding states the current Listing
fact, the comparison facts (keyword data, competitor coverage, real buyer
demand) and the reasoning, so it can be checked by the person who wrote it.

Layers:
- ``analysis.product.listing_text`` / ``analysis.product.listing_visual`` read
  copy and images with a model and return structured observations + findings.
- ``calc.product.listing_audit`` applies deterministic rules, merges model
  findings, scores each section and renders the report.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

Section = Literal["title", "bullets", "main_image", "gallery", "aplus", "description"]
TextSection = Literal["title", "bullets", "description"]
VisualSection = Literal["main_image", "gallery", "aplus"]
Severity = Literal["hard", "advice"]
Owner = Literal["operator", "designer"]
CompetitorGroup = Literal["winner", "direct", "peer", "user"]
Relevance = Literal["perfect", "high", "partial", "low", "unknown"]

SECTION_LABELS: dict[str, str] = {
    "title": "标题",
    "bullets": "五点",
    "main_image": "主图",
    "gallery": "副图",
    "aplus": "A+",
    "description": "描述",
}
SECTION_OWNERS: dict[str, str] = {
    "title": "operator", "bullets": "operator", "description": "operator",
    "main_image": "designer", "gallery": "designer", "aplus": "designer",
}
HARD_PENALTY = 3
ADVICE_PENALTY = 1


class _Model(BaseModel):
    model_config = ConfigDict(extra="forbid")


# ---------------------------------------------------------------------------
# Prepared facts (Entity → Analysis / Calc)
# ---------------------------------------------------------------------------

class AuditListing(_Model):
    """The audited Listing as read from the Product."""

    asin: str
    title: str = ""
    brand: str | None = None
    bullet_points: list[str] = Field(default_factory=list)
    description: str = ""
    listing_date: str | None = None
    main_image: str = ""
    gallery_images: list[str] = Field(default_factory=list, description="Product images after the main image")
    aplus_images: list[str] = Field(default_factory=list, description="A+ images after cleaning")
    aplus_raw_count: int = 0
    brief: str = Field(default="", description="User supplied product intent, audience and advantages")


class CompetitorListing(_Model):
    asin: str
    group: CompetitorGroup
    reason: str = ""
    title: str = ""
    brand: str | None = None
    bullet_points: list[str] = Field(default_factory=list)
    listing_date: str | None = None
    main_image: str = ""
    image_count: int = 0
    aplus_count: int = 0


class Top3Share(_Model):
    asin: str
    click_share: float | None = None
    conversion_share: float | None = None
    title: str = ""


class KeywordFact(_Model):
    """One candidate keyword with its market data (percent values are 0–100)."""

    term: str
    search_volume: int | None = None
    clicks: int | None = None
    purchases: int | None = None
    purchase_rate: float | None = None
    ppc: float | None = None
    top3_click_share: float | None = None
    top3_conversion_share: float | None = None
    top3: list[Top3Share] = Field(default_factory=list)
    traffic_competitors: int = Field(default=0, description="Competitors whose reverse lookup lists this term")
    relevance: Relevance = "unknown"
    relevance_reason: str = ""
    own_traffic_pct: float | None = None
    own_natural_ratio: float | None = None
    own_rank: str = ""
    is_core: bool = Field(default=False, description="One of the audit's core terms")


class DemandSignal(_Model):
    kind: Literal["persona", "scenario", "motivation"]
    label: str
    detail: str = ""
    evidence: str = ""
    mentioned_by: int = 0
    source_asin: str


class DemandPortrait(_Model):
    """Who really buys and why: competitor reviews + search terms + user brief."""

    signals: list[DemandSignal] = Field(default_factory=list)
    review_asins: list[str] = Field(default_factory=list)
    keyword_signals: list[str] = Field(default_factory=list, description="High-value relevant search terms")
    brief: str = ""
    notes: list[str] = Field(default_factory=list)


class CosmoGroupFact(_Model):
    group_id: str
    term: str
    term_cn: str = ""
    cosmo_category: str = ""
    cosmo_field: str = ""
    asins: list[str] = Field(default_factory=list)
    members: list[str] = Field(default_factory=list, description="Member term texts")


class ImageMeasure(_Model):
    """Pixel facts measured from the full-size image."""

    image_id: str
    url: str
    original_width: int
    original_height: int
    white_border_ratio: float | None = Field(default=None, description="Share of near-white pixels on the outer border")
    fill_ratio: float | None = Field(default=None, description="Larger side of the non-white bounding box / image side")
    white_corners: int | None = Field(default=None, ge=0, le=4, description="Corner patches that are near-white (0–4)")


# ---------------------------------------------------------------------------
# Model observations (Analysis → Calc)
# ---------------------------------------------------------------------------

class ModelFinding(_Model):
    section: Section
    severity: Severity
    title: str = Field(min_length=1)
    current: str = Field(min_length=1, description="What the Listing does now; quote text or name image ids")
    evidence: list[str] = Field(min_length=1, description="Comparison facts copied from the inputs")
    judgement: str = Field(min_length=1)
    fix: str = Field(min_length=1)
    image_ids: list[str] = Field(default_factory=list)
    competitor_asins: list[str] = Field(default_factory=list)
    keywords: list[str] = Field(default_factory=list)


class AlignmentVerdict(_Model):
    status: Literal["aligned", "partial", "misaligned", "unknown"]
    summary: str


class ListingTextInput(_Model):
    listing: AuditListing
    competitors: list[CompetitorListing] = Field(default_factory=list)
    keywords: list[KeywordFact] = Field(default_factory=list)
    demand: DemandPortrait = Field(default_factory=DemandPortrait)
    model: str = "pro"


class ListingTextOutput(_Model):
    alignment: AlignmentVerdict
    strengths: dict[TextSection, list[str]] = Field(default_factory=dict)
    findings: list[ModelFinding] = Field(default_factory=list)


class ImageReading(_Model):
    image_id: str
    source: Literal["main", "gallery", "aplus"]
    role: str = Field(description="卖点图/场景图/尺寸图/对比图/细节图/包装清单/人群使用/品牌故事/其他")
    people: str = Field(description="Who appears, or 无人物")
    scene: str
    message: str = Field(description="What the image tries to tell the shopper")
    visible_text: list[str] = Field(default_factory=list)
    original_width: int | None = None
    original_height: int | None = None


class CompetitorMainReading(_Model):
    asin: str
    group: CompetitorGroup
    people: str
    scene: str
    message: str


class ListingVisualInput(_Model):
    listing: AuditListing
    competitors: list[CompetitorListing] = Field(default_factory=list)
    keywords: list[KeywordFact] = Field(default_factory=list)
    demand: DemandPortrait = Field(default_factory=DemandPortrait)
    model: str = "pro"
    max_side: int = Field(default=768, ge=256, le=1568)


class ListingVisualOutput(_Model):
    alignment: AlignmentVerdict
    images: list[ImageReading] = Field(default_factory=list)
    competitor_mains: list[CompetitorMainReading] = Field(default_factory=list)
    strengths: dict[VisualSection, list[str]] = Field(default_factory=dict)
    findings: list[ModelFinding] = Field(default_factory=list)
    failed_images: list[str] = Field(default_factory=list)
    limitations: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Deterministic audit (Calc) and report
# ---------------------------------------------------------------------------

class ListingAuditCalcInput(_Model):
    listing: AuditListing
    competitors: list[CompetitorListing] = Field(default_factory=list)
    keywords: list[KeywordFact] = Field(default_factory=list)
    core_terms: list[str] = Field(default_factory=list)
    cosmo_groups: list[CosmoGroupFact] = Field(default_factory=list)
    demand: DemandPortrait = Field(default_factory=DemandPortrait)
    main_measure: ImageMeasure | None = None
    text: ListingTextOutput | None = None
    visual: ListingVisualOutput | None = None
    not_checked: dict[str, str] = Field(default_factory=dict, description="section or check -> reason")
    limitations: list[str] = Field(default_factory=list)


class AuditFinding(_Model):
    id: str
    section: Section
    severity: Severity
    source: Literal["rule", "model"]
    title: str
    current: str
    evidence: list[str]
    judgement: str
    fix: str
    owner: Owner
    image_ids: list[str] = Field(default_factory=list)
    competitor_asins: list[str] = Field(default_factory=list)
    keywords: list[str] = Field(default_factory=list)


class Deduction(_Model):
    finding_id: str
    points: int


class SectionReview(_Model):
    section: Section
    label: str
    score: int | None = Field(default=None, ge=0, le=10)
    status: Literal["ok", "needs_work", "failed", "not_checked"]
    conclusion: str
    strengths: list[str] = Field(default_factory=list)
    findings: list[AuditFinding] = Field(default_factory=list)
    deductions: list[Deduction] = Field(default_factory=list)
    not_checked_reason: str | None = None


class KeywordRow(KeywordFact):
    competitor_title_count: int = 0
    competitor_bullet_count: int = 0
    competitor_total: int = 0
    target_locations: list[str] = Field(default_factory=list, description="title_front/title/bp1..bp5/description")
    title_index: int | None = None


class CosmoRow(_Model):
    group_id: str
    term: str
    term_cn: str = ""
    cosmo_field: str = ""
    competitor_count: int
    competitor_total: int
    target_has: bool


class ListingAuditOutput(_Model):
    asin: str
    verdict: Literal["red", "yellow", "green", "incomplete"]
    verdict_text: str
    alignment: AlignmentVerdict
    sections: list[SectionReview]
    top_fixes: list[str] = Field(default_factory=list, description="Finding ids, most important first")
    hard_count: int
    advice_count: int
    core_terms: list[str] = Field(default_factory=list)
    competitors: list[CompetitorListing] = Field(default_factory=list)
    demand: DemandPortrait = Field(default_factory=DemandPortrait)
    keyword_table: list[KeywordRow] = Field(default_factory=list)
    cosmo_table: list[CosmoRow] = Field(default_factory=list)
    image_readings: list[ImageReading] = Field(default_factory=list)
    competitor_mains: list[CompetitorMainReading] = Field(default_factory=list)
    not_checked: dict[str, str] = Field(default_factory=dict)
    limitations: list[str] = Field(default_factory=list)
    report_markdown: str = ""
