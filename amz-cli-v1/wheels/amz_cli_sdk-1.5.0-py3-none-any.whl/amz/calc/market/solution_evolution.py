"""Describe how each product class in a keyword market is evolving.

Deterministic. Classes come from the model's tags (titles + main images, no sales);
every number, stage and grade here comes from the sample's sales facts:

- share now, share among new vs old lines, 12-month share series;
- old demand: the *same* lines' last 3 complete months vs the 3 before and vs a
  year ago, compared with the whole market on the same basis (seasonality cancels);
- new supply: verified new lines, official 200+ marks, ABA, entrants and ramps;
- stage: 样本不足 / 老品下滑 / 新兴上升 / 稳定主流 / 单点新品 / 停滞;
- grade (verified new lines only): A = ≥2 verified + ≥1 official 200+ + share among new
  lines ≥ ``min_shift`` above share among old lines; B = ≥2; C = 1.
- replacement pairs on the primary dimension: a rising class gaining share while a
  mainstream or declining class loses share or weakens.
"""
from __future__ import annotations

from calendar import monthrange
from datetime import date
from statistics import median

from amz.calc.market.solution_lines import (
    follow_table,
    history_of,
    month_of,
    shift_month,
)
from amz.envelope import Code, Result, err, ok
from amz.registry import capability
from amz.schemas.solution_evolution import (
    BUCKETS,
    INCUMBENT_STAGES,
    OTHER,
    UNKNOWN,
    EvolutionCalcInput,
    EvolutionDynamics,
    EvolutionThresholds,
)

LIMITATIONS = [
    "份额、走势只基于搜索结果里的商品；已掉出搜索结果的老品不在样本中，下滑类别的真实降幅可能被低估（幸存者偏差）。",
    "份额序列会因新品上架而自然抬高新类别份额，替代判断以同批老品走势和新老份额对比为准。",
    "同批增长与全市场同口径比较以抵消季节性；同比需要至少 15 个月销量记录，缺失时只看近 3 个月。",
    "阶段与等级由程序按规则给出，阈值未经回测；A 级只说明证据硬，不代表创新程度高。",
]


def _med(values):
    values = [v for v in values if v is not None]
    return round(median(values), 4) if values else None


def _round(value):
    return round(value, 4) if isinstance(value, float) else value


def matched_change(lines: list[dict], as_of: date, offset: int) -> tuple[float | None, int]:
    """Same lines: last 3 complete months vs the same 3 months ``offset`` months earlier."""
    end = shift_month(month_of(as_of), -1)
    recent = [shift_month(end, -i) for i in (2, 1, 0)]
    base = [shift_month(m, -offset) for m in recent]
    need = set(recent) | set(base)
    recent_sum = base_sum = count = 0
    for line in lines:
        history = history_of(line)
        if not need <= history.keys():
            continue
        count += 1
        recent_sum += sum(history[m] for m in recent)
        base_sum += sum(history[m] for m in base)
    return (round(recent_sum / base_sum - 1, 4) if count and base_sum > 0 else None), count


def ramp_days(line: dict, as_of: date, gate: int) -> int | None:
    """Days from launch to the first month observed above the units gate (month end; current month = as_of)."""
    launch = line["launch"]
    if launch is None:
        return None
    current = month_of(as_of)
    months = [p["month"] for p in line["sales"] if p["month"] < current and p["units"] > gate]
    if months:
        first = date.fromisoformat(f"{min(months)}-01")
        observed = first.replace(day=monthrange(first.year, first.month)[1])
    elif (line["monthly_units"] or 0) > gate:
        observed = as_of
    else:
        return None
    return max((observed - launch).days, 0)


def _gap(value, market, count, t: EvolutionThresholds):
    if value is None or market is None or count < t.min_growth_lines:
        return None
    return round(value - market, 4)


def _ends(series: list[tuple[str, float | None]]) -> tuple[float | None, float | None]:
    known = [s for _, s in series if s is not None]
    if len(known) < 6:
        return None, None
    return round(sum(known[:3]) / 3, 4), round(sum(known[-3:]) / 3, 4)


def _stage(row: dict, t: EvolutionThresholds) -> str:
    verified = len(row["verified"])
    if row["lines"] < t.min_class_lines and not verified:
        return "样本不足"
    if row["declining"]:
        return "老品下滑"
    if row["mainstream"]:
        return "稳定主流"
    if verified >= 2:
        return "新兴上升"
    return "单点新品" if verified == 1 else "停滞"


def _grade(row: dict, t: EvolutionThresholds) -> str | None:
    n = len(row["verified"])
    if not n:
        return None
    if n >= 2 and row["official_verified"] and row["shift"] is not None and row["shift"] >= t.min_shift:
        return "A"
    return "B" if n >= 2 else "C"


def _notes(row: dict, has_base: bool) -> list[str]:
    notes = []
    if row["grade"] == "C":
        notes.append("只有 1 条新品线过线，可能是个别卖家运营强，不能证明这一类成立")
    if row["verified"] and not row["official_verified"]:
        notes.append("过线新品都没有官方 200+ 标记，销量只有第三方估算")
    if row["suspected"]:
        notes.append(f"另有 {row['suspected']} 条疑似老链接换新 ASIN，已排除在证据外")
    if row["verified"] and not has_base:
        notes.append("老品对照组太小，没法比较新老份额，等级最高 B")
    if row["mainstream"] and len(row["verified"]) >= 2:
        notes.append("主流类里仍有多条新品起量：新品在跟进主流，不是替代主流")
    newest = row["follow"][0]
    if newest["lines"] >= 5 and not newest["over_gate"]:
        notes.append(f"最近上架的 {newest['lines']} 条线还没有一条过线：可能窗口在收窄，也可能只是时间太短")
    if row["price_cut"]:
        notes.append(f"过线新品中位价 ${row['price_verified']:.2f}，比同类老品 ${row['price_older']:.2f} 低 15% 以上，靠降价起量")
    if row["rating_verified"] is not None and row["rating_older"] is not None and row["rating_verified"] < row["rating_older"] - 0.2:
        notes.append(f"过线新品评分中位 {row['rating_verified']:.1f}，低于同类老品 {row['rating_older']:.1f}")
    if row["declining"]:
        parts = []
        if row["growth_gap_3m"] is not None:
            parts.append(f"近 3 个月比全市场低 {-row['growth_gap_3m']:.0%}")
        if row["growth_gap_yoy"] is not None:
            parts.append(f"同比比全市场低 {-row['growth_gap_yoy']:.0%}")
        notes.append("同一批老商品线走弱：" + "，".join(parts))
    return notes


def _class_row(axis, index, value, group, ctx, t: EvolutionThresholds) -> dict:
    sold, recent, base, base_ids = ctx["sold"], ctx["recent"], ctx["base"], ctx["base_ids"]
    members = {l["asin"] for l in group}
    active = [l for l in group if (l["monthly_units"] or 0) > 0]

    def share(pool, key="monthly_units"):
        whole = sum(l[key] or 0 for l in pool)
        return sum(l[key] or 0 for l in pool if l["asin"] in members) / whole if whole else None

    verified = sorted((l for l in group if l["verified"]), key=lambda l: -(l["monthly_units"] or 0))
    older = [l for l in group if l["asin"] in base_ids]
    recent_share, base_share = share(recent), share(base)
    shift = recent_share - base_share if ctx["has_base"] and recent_share is not None and base_share is not None else None
    class_units = sum(l["monthly_units"] for l in active)
    new_units = sum(l["monthly_units"] for l in active if l["new"] and not l["suspect"])
    # Old-demand trend: only lines older than the new-product window, never recent launches.
    old_active = [l for l in active if l["asin"] in base_ids]
    growth_3m, n_3m = matched_change(old_active, ctx["as_of"], 3)
    growth_yoy, n_yoy = matched_change(old_active, ctx["as_of"], 12)
    ramps = [d for l in verified if (d := ramp_days(l, ctx["as_of"], t.min_monthly_units)) is not None]
    series = []
    for month in ctx["months"]:
        whole = sum(h[month] for h in ctx["histories"].values() if month in h)
        part = sum(ctx["histories"][a][month] for a in members if month in ctx["histories"][a])
        series.append((month, round(part / whole, 4) if whole else None))
    start, end = _ends(series)
    price_verified = _med([l["price_usd"] for l in verified])
    price_older = _med([l["price_usd"] for l in older])
    launches = sorted(l["launch"] for l in verified if l["launch"])
    follow = follow_table(group, t)
    return {
        "axis": axis.name, "value": value.v if not isinstance(value, str) else value,
        "desc": "" if isinstance(value, str) else value.desc,
        "nature": "新方案" if isinstance(value, str) else value.nature,
        "bucket": isinstance(value, str),
        "lines": len(group), "sold": len(active),
        "share": share(sold), "revenue_share": share(sold, "monthly_revenue"),
        "recent_share": recent_share, "base_share": base_share, "shift": shift,
        "new_units_share": new_units / class_units if class_units else None,
        "growth_3m": growth_3m, "growth_3m_lines": n_3m, "growth_yoy": growth_yoy, "growth_yoy_lines": n_yoy,
        "growth_gap_3m": _gap(growth_3m, ctx["market_3m"], n_3m, t),
        "growth_gap_yoy": _gap(growth_yoy, ctx["market_yoy"], n_yoy, t),
        "share_start": start, "share_end": end, "series": series,
        "verified": [l["asin"] for l in verified],
        "official_verified": sum(l["official_ok"] for l in verified),
        "aba_verified": sum(bool((l.get("aba") or {}).get("weeks_13")) for l in verified),
        "suspected": sum(bool(l["suspect"]) for l in group),
        "suspected_ids": [l["asin"] for l in group if l["suspect"]],
        "ramp_days_median": median(ramps) if ramps else None, "ramp_count": len(ramps),
        "follow": follow, "entries_6m": sum(f["lines"] for f in follow), "ramped_6m": sum(f["over_gate"] for f in follow),
        "price_median": _med([l["price_usd"] for l in active]),
        "price_verified": price_verified, "price_older": price_older,
        "rating_verified": _med([l["rating"] for l in verified]),
        "rating_older": _med([l["rating"] for l in older]),
        "price_cut": bool(price_verified and price_older and price_verified < price_older * (1 - t.price_cut)),
        "launch_verified": (launches[0], launches[-1]) if launches else None,
        "top": [l["asin"] for l in sorted(group, key=lambda l: -(l["monthly_units"] or 0))[:8]],
    }


def _finish_axis(rows: list[dict], has_base: bool, base_ok: bool, t: EvolutionThresholds) -> None:
    real = [r for r in rows if not r["bucket"]]
    key = "base_share" if base_ok else "share"
    leader = max(real, key=lambda r: r[key] or 0, default=None)
    for row in rows:
        row["mainstream"] = row is leader and (row[key] or 0) >= t.mainstream_share
        gaps = [g for g in (row["growth_gap_3m"], row["growth_gap_yoy"]) if g is not None]
        weak = not row["bucket"] and any(g <= -t.decline_gap for g in gaps)
        conflict = weak and any(g >= t.decline_gap for g in gaps)
        # New entrants still choosing this class more than old lines did: renewal inside the class, not abandonment.
        renewing = weak and not conflict and row["shift"] is not None and row["shift"] > 0
        row["declining"] = weak and not conflict and not renewing
        row["stage"] = _stage(row, t)
        row["grade"] = _grade(row, t)
        row["notes"] = _notes(row, has_base)
        if conflict:
            row["notes"].append("近 3 个月与同比走势相反，不判为走弱")
        if renewing:
            row["notes"].append("同批老品落后于全市场，但新品更集中在这一类：是类内换代，不是被别类替代")


def _change(row: dict) -> float | None:
    if row["share_start"] is None or row["share_end"] is None:
        return None
    return round(row["share_end"] - row["share_start"], 4)


def _pairs(rows: list[dict]) -> list[dict]:
    risers = [r for r in rows if not r["bucket"] and r["stage"] in ("新兴上升", "单点新品")]
    incumbents = [r for r in rows if not r["bucket"] and (r["stage"] in INCUMBENT_STAGES or r["mainstream"])]
    pairs = []
    for riser in risers:
        gain = _change(riser)
        for incumbent in incumbents:
            if incumbent is riser:
                continue
            loss = _change(incumbent)
            weakening = incumbent["declining"] or (loss is not None and loss < 0)
            if (gain is not None and gain > 0 or (riser["shift"] or 0) > 0) and weakening:
                ratio = (round(riser["price_verified"] / incumbent["price_median"], 4)
                         if riser["price_verified"] and incumbent["price_median"] else None)
                pairs.append({"riser": riser["value"], "incumbent": incumbent["value"],
                              "riser_share_change": gain, "incumbent_share_change": loss,
                              "incumbent_growth_gap_3m": incumbent["growth_gap_3m"], "price_ratio": ratio})
    return pairs


def evolution(lines: list[dict], axes: list, tags: list, as_of: date, t: EvolutionThresholds) -> dict:
    tag_map = {tag.item_id: tag for tag in tags}
    rel = {l["asin"]: (tag_map[l["asin"]].rel if l["asin"] in tag_map else None) for l in lines}
    on = [l for l in lines if rel[l["asin"]] == "T"]
    sold = [l for l in on if (l["monthly_units"] or 0) > 0]
    # Suspected relists are probably old products under a new ASIN: neither new nor a clean old baseline.
    recent = [l for l in sold if l["new"] and not l["suspect"]]
    base = [l for l in sold if l["age_months"] is not None and not l["new"]]
    ctx = {
        "as_of": as_of, "sold": sold, "recent": recent, "base": base, "base_ids": {l["asin"] for l in base},
        "has_base": len(base) >= t.min_base_lines and bool(recent),
        "base_ok": len(base) >= t.min_base_lines,
        "months": [shift_month(month_of(as_of), -i) for i in range(12, 0, -1)],
        "histories": {l["asin"]: history_of(l) for l in on},
    }
    ctx["market_3m"], _ = matched_change(base, as_of, 3)
    ctx["market_yoy"], _ = matched_change(base, as_of, 12)
    # Archived tags may carry values outside the declared dimension: count them as 其他, never drop the line.
    allowed = [{v.v for v in axis.values} | {OTHER, UNKNOWN} for axis in axes]
    values = {tag.item_id: [v if v in ok_values else OTHER for v, ok_values in zip(tag.values, allowed)]
              for tag in tags if tag.rel == "T"}
    out_axes, primary_rows, supplements = [], [], []
    for index, axis in enumerate(axes):
        rows = []
        for value in [*axis.values, OTHER, UNKNOWN]:
            name = value if isinstance(value, str) else value.v
            group = [l for l in on if values[l["asin"]][index] == name]
            if isinstance(value, str) and not group:
                continue
            rows.append(_class_row(axis, index, value, group, ctx, t))
        _finish_axis(rows, ctx["has_base"], ctx["base_ok"], t)
        rows = [{k: _round(v) for k, v in row.items()} for row in rows]
        out_axes.append({"name": axis.name, "kind": axis.kind, "source": axis.source, "primary": axis.primary,
                         "classes": rows})
        if axis.primary:
            primary_rows = rows
        else:
            supplements += [r for r in rows if not r["bucket"] and r["grade"] in ("A", "B") and r["nature"] == "新方案"]
    limitations = list(LIMITATIONS)
    primary = next(a for a in out_axes if a["primary"])
    on_lines = sum(r["lines"] for r in primary_rows)
    vague = sum(r["lines"] for r in primary_rows if r["value"] in BUCKETS)
    if on_lines and vague / on_lines > t.unknown_share:
        limitations.append(f"主维度上有 {vague}/{on_lines} 条本体商品线归为未知或其他，分类可能不可靠。")
    counts = {key: sum(1 for v in rel.values() if v == key) for key in ("T", "A", "X", None)}
    return {
        "primary_axis": primary["name"], "market_growth_3m": ctx["market_3m"], "market_growth_yoy": ctx["market_yoy"],
        "on_topic": counts["T"], "accessory": counts["A"], "off_topic": counts["X"], "untagged": counts[None],
        "axes": out_axes, "pairs": _pairs(primary_rows), "supplements": supplements, "limitations": limitations,
    }


@capability(
    "calc.market.solution_evolution",
    description="按分类计算每类份额、同批老品走势、新品起量和新老对比，由程序定阶段、证据等级和此消彼长候选对",
    input_model=EvolutionCalcInput, output_model=EvolutionDynamics,
)
def solution_evolution(current_date: date, lines: list[dict], axes: list[dict], tags: list[dict],
                       thresholds: dict | None = None) -> Result:
    data = EvolutionCalcInput(current_date=current_date, lines=lines, axes=axes, tags=tags,
                              thresholds=thresholds or {})
    if sum(a.primary for a in data.axes) != 1:
        return err(Code.ERROR_PARAM, "axes need exactly one primary dimension")
    bad = [t.item_id for t in data.tags if t.rel == "T" and len(t.values) != len(data.axes)]
    if bad:
        return err(Code.ERROR_PARAM, f"tagged lines need one value per dimension: {bad[:5]}")
    if not any(t.rel == "T" for t in data.tags):
        return err(Code.ERROR_MISSING_FIELDS, "no product line is tagged as the market's own product",
                   missing=["tags.rel=T"])
    result = evolution([l.model_dump() for l in data.lines], data.axes, data.tags, data.current_date, data.thresholds)
    return ok(data=EvolutionDynamics.model_validate(result).model_dump(mode="json"))
