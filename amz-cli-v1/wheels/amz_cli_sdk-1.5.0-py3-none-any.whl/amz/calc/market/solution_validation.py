"""Apply the launch age, monthly USD revenue and monthly units gates."""
from __future__ import annotations

from calendar import monthrange
from datetime import date

from amz.envelope import Code, Result, err, ok
from amz.registry import capability
from amz.schemas.solution_outlook import (
    OutlookProduct, SolutionValidationInput, SolutionValidationResult, SuspectProduct, Thresholds,
    VerifiedProduct,
)


def launch_age(row: OutlookProduct, current: date) -> int | None:
    if row.available_date is None or row.available_date > current:
        return None
    return (current - row.available_date).days


def _month_days(month: str) -> int:
    return monthrange(int(month[:4]), int(month[5:]))[1]


def relist_reasons(
    row: OutlookProduct, age: int, rows: list[OutlookProduct], current: date, limits: Thresholds,
) -> list[str]:
    """Signals that the ASIN inherits reviews or sales from an older product line."""
    reasons = []
    reviews, units = row.count_review, row.monthly_units
    if reviews is not None and units and reviews >= limits.min_reviews_for_rate:
        estimated = units * max(age, 1) / 30
        rate = reviews / estimated * 100
        if rate > limits.max_review_rate_pct:
            reasons.append(
                f"上架 {age} 天已有 {reviews} 条评论，约占上架以来估算销量的 {rate:.0f}%"
                f"（阈值 {limits.max_review_rate_pct:g}%），评论可能继承自老链接或同父变体。"
            )
    launch_month = row.available_date.isoformat()[:7]
    current_month = current.isoformat()[:7]
    history = {p.month: p.units for p in row.sales_trend}
    later = [history[m] / _month_days(m) for m in history if launch_month < m < current_month]
    if launch_month < current_month and launch_month in history and later and max(later) > 0:
        active = _month_days(launch_month) - row.available_date.day + 1
        ratio = round(history[launch_month] / active / max(later), 6)  # exact 3.0 must not trip "> 3"
        if ratio > limits.max_launch_rate_ratio:
            reasons.append(
                f"上架当月仅 {active} 天却记录 {history[launch_month]} 件，日均是之后最佳完整月的 {ratio:.1f} 倍"
                f"（阈值 {limits.max_launch_rate_ratio:g}），销量记录可能来自老链接。"
            )
    if row.parent_asin:
        older = sorted(
            other.asin for other in rows
            if other.asin != row.asin and other.parent_asin == row.parent_asin
            and (other_age := launch_age(other, current)) is not None and other_age > limits.new_days
        )
        if older:
            reasons.append(
                f"同父 ASIN {row.parent_asin} 下的 {'、'.join(older[:3])} 上架已超过 {limits.new_days} 天，"
                "本 ASIN 可能是老商品线的新变体。"
            )
    return reasons


def validate_products(
    rows: list[OutlookProduct], current: date, limits: Thresholds,
) -> tuple[list[VerifiedProduct], list[SuspectProduct]]:
    verified, suspected = [], []
    for row in rows:
        age = launch_age(row, current)
        if age is None or age > limits.new_days:
            continue
        if row.monthly_revenue is None or row.monthly_revenue <= limits.min_monthly_revenue:
            continue
        if row.monthly_units is None or row.monthly_units <= limits.min_monthly_units:
            continue
        facts = dict(
            asin=row.asin, parent_asin=row.parent_asin, title=row.title,
            days_since_launch=age, monthly_units=row.monthly_units,
            monthly_revenue=row.monthly_revenue, price_usd=row.price_usd,
            rating=row.rating, count_review=row.count_review,
        )
        reasons = relist_reasons(row, age, rows, current, limits)
        if reasons:
            suspected.append(SuspectProduct(**facts, reasons=reasons))
        else:
            verified.append(VerifiedProduct(**facts))
    order = lambda item: item.monthly_revenue  # noqa: E731
    return sorted(verified, key=order, reverse=True), sorted(suspected, key=order, reverse=True)


def verified_products(rows: list[OutlookProduct], current: date, limits: Thresholds) -> list[VerifiedProduct]:
    return validate_products(rows, current, limits)[0]


@capability(
    "calc.market.solution_validation",
    description="按上架天数、月营收（美元）和月销量筛出已验证新品，并把疑似老品换新 ASIN 的商品单列",
    input_model=SolutionValidationInput, output_model=SolutionValidationResult,
)
def solution_validation(current_date: date, products: list[dict], thresholds: dict | None = None) -> Result:
    inputs = SolutionValidationInput(current_date=current_date, products=products, thresholds=thresholds or {})
    dated = [p for p in inputs.products if launch_age(p, inputs.current_date) is not None]
    if not any(p.monthly_units is not None and p.monthly_revenue is not None for p in dated):
        missing = []
        if not dated:
            missing.append("products.available_date")
        if not any(p.monthly_revenue is not None for p in inputs.products):
            missing.append("products.totalAmount")
        if not any(p.monthly_units is not None for p in inputs.products):
            missing.append("products.monthly_sales")
        return err(Code.ERROR_MISSING_FIELDS, "no single Amazon product has a valid launch date, monthly USD revenue and monthly units",
                   missing=missing or ["products.available_date+monthly_revenue+monthly_units"])
    verified, suspected = validate_products(inputs.products, inputs.current_date, inputs.thresholds)
    result = SolutionValidationResult(verified_new=verified, suspected_new=suspected)
    return ok(data=result.model_dump(mode="json"))
