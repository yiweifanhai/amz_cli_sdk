"""Markdown rendering of a Listing audit result (pure, Chinese report text)."""

from __future__ import annotations

from amz.schemas.listing_audit import (
    SECTION_LABELS, AuditFinding, ListingAuditOutput, SectionReview,
)

VERDICT_EMOJI = {"red": "🔴", "yellow": "🟡", "green": "🟢", "incomplete": "⚪"}
ALIGNMENT_LABELS = {"aligned": "一致", "partial": "部分偏离", "misaligned": "整体偏离", "unknown": "未判断"}
OWNER_LABELS = {"operator": "运营", "designer": "美工"}
KIND_LABELS = {"persona": "人群", "scenario": "场景", "motivation": "诉求"}
GROUP_LABELS = {"winner": "流量赢家", "direct": "同方案竞品", "peer": "同期新品", "user": "指定竞品"}
RELEVANCE_LABELS = {"perfect": "完全对口", "high": "高度相关", "partial": "部分相关",
                    "low": "低相关", "unknown": "未判断"}
FIELD_LABELS = {
    "is_a_description": "产品描述", "used_as": "用作", "made_of": "材质", "used_to": "用途",
    "capable_of": "能力", "used_for_func": "功能用途", "used_for_eve": "场合", "used_on": "作用对象",
    "used_in_loc": "地点", "used_in_body": "身体部位", "used_for_aud": "目标人群", "used_by": "使用者",
    "xis_a": "用户身份", "xinterested_in": "兴趣", "xwant": "想要", "lifestyle_symbol_of": "生活方式",
    "used_with": "搭配使用",
}
CHECK_LABELS = {**SECTION_LABELS, "keywords": "关键词规则", "cosmo": "COSMO 语义", "core_terms": "核心词",
                "competitors": "竞品对照", "main_measure": "主图像素测量"}
IMAGE_SOURCES = {"main_image": "main", "gallery": "gallery", "aplus": "aplus"}
KEYWORD_ROWS = 30


def _flat(value: object) -> str:
    return " ".join(str(value).split())


def _table(headers: list[str], rows: list[list[object]]) -> list[str]:
    def line(cells) -> str:
        return "| " + " | ".join(_flat(cell).replace("|", "\\|") for cell in cells) + " |"

    return [line(headers), "|" + "---|" * len(headers), *(line(row) for row in rows)]


def _score(section: SectionReview) -> str:
    return "未检查" if section.score is None else f"{section.score}/10"


def _finding_block(finding: AuditFinding, points: int | None) -> list[str]:
    mark = "❌ [硬伤" if finding.severity == "hard" else "⚠️ [建议"
    mark += f" -{points}]" if points is not None else "，未计分]"
    current = _flat(finding.current)
    if finding.image_ids:
        current += f"（图片：{'、'.join(finding.image_ids)}）"
    return [
        f"### {mark} {_flat(finding.title)}", "",
        f"- 现状：{current}",
        "- 对照：",
        *(f"  - {_flat(item)}" for item in finding.evidence),
        f"- 判断：{_flat(finding.judgement)}",
        f"- 改法：{_flat(finding.fix)}",
        f"- 负责：{OWNER_LABELS[finding.owner]}", "",
    ]


def _image_notes(output: ListingAuditOutput, section: str) -> list[str]:
    source = IMAGE_SOURCES.get(section)
    lines = []
    readings = [r for r in output.image_readings if r.source == source]
    if readings:
        lines.append("逐张识别：")
        lines += [f"- {r.image_id}（{_flat(r.role)}）：{_flat(r.message)}；"
                  f"人物：{_flat(r.people)}；场景：{_flat(r.scene)}" for r in readings]
        lines.append("")
    if section == "main_image" and output.competitor_mains:
        lines.append("竞品主图对照：")
        lines += [f"- {r.asin}（{GROUP_LABELS[r.group]}）：{_flat(r.message)}；"
                  f"人物：{_flat(r.people)}；场景：{_flat(r.scene)}" for r in output.competitor_mains]
        lines.append("")
    return lines


def _section(output: ListingAuditOutput, number: int, section: SectionReview) -> list[str]:
    lines = [f"## {number}. {section.label}  {_score(section)}", ""]
    if section.status == "not_checked":
        lines += [f"结论：未检查（{_flat(section.not_checked_reason or '缺少数据')}）", ""]
    else:
        lines += [f"结论：{_flat(section.conclusion)}", ""]
    if section.strengths:
        lines += [f"做得好：{'；'.join(_flat(item) for item in section.strengths)}", ""]
    points = {item.finding_id: item.points for item in section.deductions}
    for finding in section.findings:
        lines += _finding_block(finding, points.get(finding.id))
    return lines + _image_notes(output, section.section)


def _demand(output: ListingAuditOutput) -> list[str]:
    demand = output.demand
    lines = ["### A. 真实需求画像", ""]
    signals = sorted(demand.signals, key=lambda s: s.mentioned_by, reverse=True)
    if signals:
        lines += _table(["类型", "内容", "提及人数", "来源 ASIN"], [
            [KIND_LABELS[s.kind], s.label, s.mentioned_by, s.source_asin] for s in signals])
    else:
        lines.append("没有可用的评论需求信号。")
    lines.append("")
    extra = []
    if demand.keyword_signals:
        extra.append(f"- 高价值搜索词：{'、'.join(demand.keyword_signals)}")
    if demand.brief:
        extra.append(f"- 提交人说明：{_flat(demand.brief)}")
    if demand.review_asins:
        extra.append(f"- 评论样本：{'、'.join(demand.review_asins)}")
    extra += [f"- 备注：{_flat(note)}" for note in demand.notes]
    return lines + (extra + [""] if extra else [])


def _appendix(output: ListingAuditOutput) -> list[str]:
    lines = ["## 附录", ""] + _demand(output)

    lines += ["### B. 竞品样本", ""]
    if output.competitors:
        lines += _table(["ASIN", "分组", "上架日", "入选原因"], [
            [c.asin, GROUP_LABELS[c.group], c.listing_date or "—", c.reason or "—"]
            for c in output.competitors])
    else:
        lines.append("没有竞品样本。")

    lines += ["", "### C. 关键词表", ""]
    if output.keyword_table:
        rows = []
        for row in output.keyword_table[:KEYWORD_ROWS]:
            places = [
                "标题前段" if place == "title_front" else "标题" if place == "title"
                else "描述" if place == "description" else f"五点{place[2:]}"
                for place in row.target_locations
                if not (place == "title" and "title_front" in row.target_locations)
            ]
            rows.append([
                row.term,
                "—" if row.search_volume is None else f"{row.search_volume:,}",
                "—" if row.purchases is None else f"{row.purchases:,}",
                "—" if row.purchase_rate is None else f"{round(row.purchase_rate, 2):g}%",
                RELEVANCE_LABELS[row.relevance],
                f"{row.competitor_title_count}/{row.competitor_total}",
                "、".join(places) or "未埋",
            ])
        lines += _table(["词", "月搜索", "月成交", "购买率", "相关性", "竞品标题覆盖", "本品位置"], rows)
    else:
        lines.append("没有关键词数据。")

    lines += ["", "### D. COSMO 语义覆盖", ""]
    if output.cosmo_table:
        lines += _table(["语义词", "字段", "竞品覆盖", "本品"], [
            [f"{row.term_cn}（{row.term}）" if row.term_cn else row.term,
             FIELD_LABELS.get(row.cosmo_field, row.cosmo_field),
             f"{row.competitor_count}/{row.competitor_total}",
             "有" if row.target_has else "缺"]
            for row in output.cosmo_table])
    else:
        lines.append("没有可对照的 COSMO 语义。")

    lines += ["", "### E. 未检查项与限制", ""]
    notes = [f"- {CHECK_LABELS.get(key, key)}：{_flat(reason)}"
             for key, reason in output.not_checked.items()]
    notes += [f"- {_flat(item)}" for item in output.limitations]
    return lines + (notes or ["无。"])


def render_report(output: ListingAuditOutput) -> str:
    alignment = output.alignment
    lines = [
        f"# Listing 审查报告：{output.asin}", "",
        f"## 总览 {VERDICT_EMOJI[output.verdict]} {output.verdict_text}", "",
        *_table(["部分", "分数", "结论"],
                [[s.label, _score(s), s.conclusion] for s in output.sections]),
        "",
        f"人群与诉求：{ALIGNMENT_LABELS[alignment.status]} {_flat(alignment.summary)}", "",
    ]
    by_id = {f.id: f for s in output.sections for f in s.findings}
    if output.top_fixes:
        lines += ["最该先改：", ""]
        lines += [f"{n}. {_flat(by_id[i].title)}（{SECTION_LABELS[by_id[i].section]}）"
                  for n, i in enumerate(output.top_fixes, 1)]
    else:
        lines.append("最该先改：无")
    lines.append("")
    for number, section in enumerate(output.sections, 1):
        lines += _section(output, number, section)
    lines += _appendix(output)
    return "\n".join(lines) + "\n"
