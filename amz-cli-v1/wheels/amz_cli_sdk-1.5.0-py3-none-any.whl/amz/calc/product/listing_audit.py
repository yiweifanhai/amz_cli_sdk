"""Deterministic Listing audit: rules, model finding merge, scoring and report.

Inputs are prepared by ``Product.listing_audit``. Rules only fire on facts that
are present: a missing data set (competitor copy, COSMO result, images) is
recorded as not checked or skipped, never reported as a Listing defect.

Title positions are 0-based internally and shown 1-based in findings.
"""

from __future__ import annotations

import re
from statistics import median

from pydantic import ValidationError

from amz.calc.product._listing_report import render_report
from amz.calc.product.keyword_gap import _keyword_matches
from amz.envelope import Code, Result, err, ok
from amz.registry import capability
from amz.schemas.listing_audit import (
    ADVICE_PENALTY, HARD_PENALTY, SECTION_LABELS, SECTION_OWNERS,
    AlignmentVerdict, AuditFinding, CompetitorListing, CosmoRow, Deduction,
    KeywordFact, KeywordRow, ListingAuditCalcInput, ListingAuditOutput,
    SectionReview,
)

SECTIONS = ("title", "bullets", "main_image", "gallery", "aplus", "description")
TEXT_SECTIONS = {"title", "bullets", "description"}
FIX_PRIORITY = ("main_image", "title", "bullets", "gallery", "aplus", "description")

TITLE_FRONT_CHARS = 80
CORE_EARLY_INDEX = 40
MIN_COMPETITORS = 3
POOL_SIZE = 15
POOL_TOP = 10
MISSING_KEYWORD_LIMIT = 6
COSMO_GAP_LIMIT = 5
KEYWORD_TABLE_LIMIT = 60
COSMO_TABLE_LIMIT = 40
MIN_MAIN_SIDE = 1000
MIN_WHITE_BORDER = 0.90
# A product touching the edges lowers the white-border share, but never below half of the border.
MIN_WHITE_BORDER_WITH_CORNERS = 0.50
MIN_IMAGES = 5
MODEL_HARD_MENTIONS = 30
MODEL_HARD_MIN_COMPETITORS = 5
MODEL_HARD_RATIO = 0.6
MODEL_ADVICE_CAP = 2
RED_MODEL_HARDS = 3
MISSING_HARD_RATIO = 0.6
COSMO_HARD_GAPS = 3
COSMO_HARD_RATIO = 0.7

FORBIDDEN_TITLE_CHARS = "!$?_{}^¬¦"
BRAND_STOPLIST = {"generic", "unbranded", "unknown", "none", "n/a"}
KEY_COSMO_FIELDS = {
    "used_for_aud", "used_by", "xis_a", "used_for_eve",
    "used_in_loc", "used_on", "used_in_body", "used_for_func",
}
RELEVANCE_LABELS = {"perfect": "完全对口", "high": "高度相关"}
ALIGNMENT_RANK = {"unknown": 0, "aligned": 1, "partial": 2, "misaligned": 3}
VERDICT_TEXT = {"red": "必须返工", "yellow": "限期整改", "green": "可以微调",
                "incomplete": "审查不完整，需重跑"}


# ---------------------------------------------------------------------------
# Term matching
# ---------------------------------------------------------------------------

def _variants(term: str) -> list[str]:
    base = " ".join(term.split()).lower()
    return [base, base + "s", base + "es"] if base else []


def term_index(term: str, text: str) -> int | None:
    """Character index of the first match (singular or plural), None if absent."""
    found = []
    for variant in _variants(term):
        if not _keyword_matches(variant, text):
            continue
        # Same boundary rules as the matcher: phrases are substrings, words are bounded.
        pattern = re.escape(variant) if " " in variant else rf"\b{re.escape(variant)}\b"
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if match:
            found.append(match.start())
    return min(found, default=None)


def term_matches(term: str, text: str) -> bool:
    return term_index(term, text) is not None


_STOPWORDS = {"for", "and", "with", "the", "of", "a", "an", "to", "in", "on", "by", "&"}


def missing_tokens(term: str, text: str) -> list[str]:
    """Content words of ``term`` that do not appear anywhere in ``text`` (plural tolerant)."""
    words = [w for w in re.findall(r"[a-z0-9]+", term.lower()) if w not in _STOPWORDS]
    return [w for w in dict.fromkeys(words)
            if not re.search(rf"\b{re.escape(w)}(?:s|es)?\b", text, flags=re.IGNORECASE)]


def _norm(term: str) -> str:
    return " ".join(term.split()).casefold()


def keyword_value(keyword: KeywordFact) -> float:
    if keyword.purchases is not None:
        return keyword.purchases
    if keyword.search_volume is not None and keyword.purchase_rate is not None:
        return keyword.search_volume * keyword.purchase_rate / 100
    return keyword.search_volume or 0


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------

def _num(value: float) -> str:
    if float(value).is_integer():
        return f"{int(value):,}"
    return f"{round(float(value), 2):,}"


def _percent(ratio: float) -> str:
    # Truncate so that a failing ratio such as 0.8996 is never shown as the 90% limit.
    return f"{int(ratio * 1000) / 10:g}%"


def _clip(text: str, limit: int = 200) -> str:
    flat = " ".join(text.split())
    return flat if len(flat) <= limit else flat[:limit] + "…"


def _unique(items) -> list[str]:
    return list(dict.fromkeys(item for item in items if item and item.strip()))


def _finding(finding_id: str, section: str, severity: str, title: str, current: str,
             evidence: list[str], judgement: str, fix: str, **extra) -> AuditFinding:
    return AuditFinding(
        id=finding_id, section=section, severity=severity, source="rule", title=title,
        current=current, evidence=evidence, judgement=judgement, fix=fix,
        owner=SECTION_OWNERS[section], **extra,
    )


# ---------------------------------------------------------------------------
# Prepared context
# ---------------------------------------------------------------------------

class _Audit:
    """Derived facts shared by the rules."""

    def __init__(self, data: ListingAuditCalcInput):
        self.data = data
        self.listing = data.listing
        self.title = data.listing.title.strip()
        self.bullets = [text for text in data.listing.bullet_points if text.strip()]
        self.description = data.listing.description.strip()
        self.has_text = bool(self.title or self.bullets or self.description)
        self.has_aplus = bool(data.listing.aplus_images) or data.listing.aplus_raw_count > 0

        own_asin = data.listing.asin.upper()
        peers: dict[str, CompetitorListing] = {}
        for item in data.competitors:
            if item.asin.upper() != own_asin:
                peers.setdefault(item.asin.upper(), item)
        self.peers = list(peers.values())
        self.titled = [item for item in self.peers if item.title.strip()]

        self.core_terms = list({_norm(t): t.strip() for t in data.core_terms if t.strip()}.values())
        core_keys = {_norm(t) for t in self.core_terms}
        facts: dict[str, KeywordFact] = {}
        for item in data.keywords:
            if item.term.strip():
                facts.setdefault(_norm(item.term), item)
        self.rows = {key: self._row(item) for key, item in facts.items()}
        self.table = sorted(self.rows.values(), key=keyword_value, reverse=True)
        self.core_keys = core_keys | {key for key, row in self.rows.items() if row.is_core}
        self.pool = [row for row in self.table
                     if row.relevance in RELEVANCE_LABELS or row.is_core][:POOL_SIZE]

        competitor_asins = set(peers)
        groups = {}
        for group in data.cosmo_groups:
            groups.setdefault(group.group_id, group)
        self.cosmo = [
            (group, {a.upper() for a in group.asins} & competitor_asins,
             own_asin in {a.upper() for a in group.asins})
            for group in groups.values()
        ]
        self.cosmo_total = len(set().union(*(found for _, found, _ in self.cosmo)))
        self.target_has_cosmo = any(has for _, _, has in self.cosmo)

    def _row(self, fact: KeywordFact) -> KeywordRow:
        index = term_index(fact.term, self.title)
        locations = []
        if index is not None:
            if index < TITLE_FRONT_CHARS:
                locations.append("title_front")
            locations.append("title")
        locations += [f"bp{i}" for i, text in enumerate(self.listing.bullet_points, 1)
                      if term_matches(fact.term, text)]
        if term_matches(fact.term, self.listing.description):
            locations.append("description")
        return KeywordRow(
            **fact.model_dump(),
            competitor_title_count=sum(term_matches(fact.term, c.title) for c in self.titled),
            competitor_bullet_count=sum(
                any(term_matches(fact.term, b) for b in c.bullet_points) for c in self.titled),
            competitor_total=len(self.titled),
            target_locations=locations,
            title_index=index,
        )

    def title_holders(self, term: str) -> list[tuple[CompetitorListing, int]]:
        pairs = ((c, term_index(term, c.title)) for c in self.titled)
        return [(c, index) for c, index in pairs if index is not None]

    def keyword_evidence(self, term: str) -> list[str]:
        """Market data lines for a term; only values present in the input."""
        row = self.rows.get(_norm(term))
        if row is None:
            return []
        lines = []
        metrics = [f"{label} {_num(value)}" for label, value in (
            ("月搜索", row.search_volume), ("月点击", row.clicks), ("月成交", row.purchases),
        ) if value is not None]
        if row.purchase_rate is not None:
            metrics.append(f"购买率 {_num(row.purchase_rate)}%")
        if metrics:
            lines.append(f"「{row.term}」" + "，".join(metrics))
        shares = [f"{_num(value)}% {label}" for label, value in (
            ("点击", row.top3_click_share), ("成交", row.top3_conversion_share),
        ) if value is not None]
        if shares:
            lines.append("点击前三共拿走 " + "、".join(shares))
        if row.own_traffic_pct is not None:
            own = f"本品该词流量占比 {_num(row.own_traffic_pct)}%"
            if row.own_rank:
                own += f"，排名 {row.own_rank}"
            lines.append(own)
        if row.traffic_competitors:
            lines.append(f"{row.traffic_competitors} 个竞品的流量词反查中有该词")
        return lines

    def relevance_note(self, term: str) -> str:
        row = self.rows.get(_norm(term))
        reason = row.relevance_reason.strip() if row else ""
        return f"相关性依据：{reason}" if reason else ""


# ---------------------------------------------------------------------------
# Title rules
# ---------------------------------------------------------------------------

def _core_rules(audit: _Audit) -> list[AuditFinding]:
    if not audit.core_terms:
        return []
    findings = []
    primary = audit.core_terms[0]
    index = term_index(primary, audit.title)
    holders = audit.title_holders(primary)
    total = len(audit.titled)
    coverage = (f"{len(holders)}/{total} 个竞品标题含该词" if total
                else "没有可对照的竞品标题")
    shown_title = f"标题：“{_clip(audit.title)}”" if audit.title else "标题为空"

    lacking = missing_tokens(primary, audit.title) if index is None else []
    words = [w for w in re.findall(r"[a-z0-9]+", primary.lower()) if w not in _STOPWORDS]
    if index is None and len(set(words)) >= 3 and len(lacking) <= 1:
        # Most words are there in another order or form: a phrase gap, not a missing core term.
        findings.append(_finding(
            "title.core_partial", "title", "advice", f"标题没有完整写出核心词「{primary}」",
            f"{shown_title}，" + (f"缺少其中的 {'、'.join(lacking)}" if lacking else "各个词都在，但不是连续短语"),
            [*audit.keyword_evidence(primary), coverage],
            "核心词的大部分词已在标题中，但没有完整短语；精确搜索这个短语时相关性会弱于完整写出的竞品。"
            + audit.relevance_note(primary),
            f"如果不影响可读性，把「{primary}」作为完整短语写进标题前段。",
            keywords=[primary],
        ))
    elif index is None:
        findings.append(_finding(
            "title.core_missing", "title", "hard", f"标题缺少第一核心词「{primary}」",
            f"{shown_title}，没有出现「{primary}」（缺少 {'、'.join(lacking) or '完整短语'}）",
            [*audit.keyword_evidence(primary), coverage,
             f"本品标题 {len(audit.title)} 个字符，全文未匹配到该词"],
            f"「{primary}」是本品第一核心词，标题里没有它，搜索匹配和点击都会受损。"
            + audit.relevance_note(primary),
            f"在标题前 {TITLE_FRONT_CHARS} 个字符内自然放入「{primary}」，删减空泛修饰词腾出位置。",
            keywords=[primary],
        ))
    elif index >= TITLE_FRONT_CHARS:
        evidence = [f"「{primary}」从本品标题第 {index + 1} 个字符才开始出现"]
        severity = "advice"
        asins = []
        if holders:
            position = median(i for _, i in holders)
            evidence.append(f"{coverage}，起始位置中位数是第 {_num(position + 1)} 个字符")
            asins = [c.asin for c, _ in holders]
            if len(holders) >= MIN_COMPETITORS and position <= CORE_EARLY_INDEX:
                severity = "hard"
        else:
            evidence.append(coverage)
        evidence += audit.keyword_evidence(primary)
        findings.append(_finding(
            "title.core_late", "title", severity, f"第一核心词「{primary}」位置靠后",
            f"{shown_title}，核心词起始于第 {index + 1} 个字符", evidence,
            f"核心词落在前 {TITLE_FRONT_CHARS} 个字符之外，搜索结果页截断后买家看不到。"
            + audit.relevance_note(primary),
            f"把「{primary}」前移到标题开头部分，修饰词和次要卖点后移。",
            keywords=[primary], competitor_asins=asins,
        ))

    missing = [t for t in audit.core_terms[1:] if not term_matches(t, audit.title)]
    if missing:
        evidence = []
        for term in missing:
            evidence.append(f"「{term}」：{len(audit.title_holders(term))}/{total} 个竞品标题含该词"
                            if total else f"「{term}」：没有可对照的竞品标题")
            evidence += audit.keyword_evidence(term)
        names = "、".join(f"「{t}」" for t in missing)
        findings.append(_finding(
            "title.core_missing_secondary", "title", "advice", "标题缺少其他核心词",
            f"{shown_title}，没有出现 {names}", evidence,
            "这些是指定的核心词，放进标题能扩大高权重位置的搜索匹配。",
            "在不堆砌、不超类目字符上限的前提下补入标题；放不下的放进靠前的五点。",
            keywords=missing,
        ))
    return findings


def _title_length(audit: _Audit) -> list[AuditFinding]:
    if len(audit.titled) < MIN_COMPETITORS:
        return []
    length = len(audit.title)
    middle = median(len(c.title.strip()) for c in audit.titled)
    if middle >= 100 and length < 0.6 * middle:
        severity = "hard"
    elif length < 0.8 * middle and middle - length >= 30:
        severity = "advice"
    else:
        return []
    return [_finding(
        "title.length_unused", "title", severity, "标题长度明显短于竞品",
        f"本品标题 {length} 个字符：“{_clip(audit.title)}”",
        [f"本品标题 {length} 字符；竞品中位 {_num(middle)} 字符（{len(audit.titled)} 个竞品）",
         f"比竞品中位少 {_num(middle - length)} 个字符"],
        "可用字符空着，可被搜索匹配的词和能打动买家的卖点都放得更少。",
        "补入高价值词和关键卖点（人群、场景、规格），同时遵守本类目标题字符上限。",
    )]


# ---------------------------------------------------------------------------
# Keyword pool rules
# ---------------------------------------------------------------------------

def _density(audit: _Audit, section: str) -> list[AuditFinding]:
    """High-value terms used in our title / bullets against the competitor median."""
    if section == "title":
        name, hard_floor, ours_text = "标题", 3, audit.title
        texts = [c.title for c in audit.titled]
    else:
        name, hard_floor, ours_text = "五点", 4, "\n".join(audit.bullets)
        texts = ["\n".join(c.bullet_points) for c in audit.peers
                 if any(b.strip() for b in c.bullet_points)]
    if not audit.pool or len(texts) < MIN_COMPETITORS:
        return []
    present = [row.term for row in audit.pool if term_matches(row.term, ours_text)]
    ours = len(present)
    middle = median(sum(term_matches(row.term, text) for row in audit.pool) for text in texts)
    if middle >= hard_floor and ours <= middle / 2:
        severity = "hard"
    elif middle - ours >= 2:
        severity = "advice"
    else:
        return []
    lacking = []
    for row in audit.pool:
        if row.term in present:
            continue
        count = sum(term_matches(row.term, text) for text in texts)
        if count:
            lacking.append((count, row.term))
    lacking.sort(key=lambda item: item[0], reverse=True)
    evidence = [f"本品{name}含高价值词 {ours} 个（词池 {len(audit.pool)} 个）；"
                f"竞品中位 {_num(middle)} 个（{len(texts)} 个竞品）"]
    evidence += [f"本品{name}缺「{term}」，{count}/{len(texts)} 个竞品{name}含该词"
                 for count, term in lacking[:6]]
    return [_finding(
        f"{section}.keyword_density", section, severity, f"{name}高价值词数量不足",
        f"本品{name}只用了 {ours} 个高价值词" + (f"：{'、'.join(present)}" if present else ""),
        evidence,
        f"同类竞品在{name}里覆盖了更多买家实际搜索和成交的词，本品可匹配的搜索面更窄。",
        f"按竞品覆盖数从高到低，把缺的词自然写进{name}。",
        keywords=[term for _, term in lacking[:6]],
    )]


def _missing_keywords(audit: _Audit, primary_reported: bool) -> list[AuditFinding]:
    total = len(audit.titled)
    primary = _norm(audit.core_terms[0]) if audit.core_terms else None
    flagged = []
    for rank, row in enumerate(audit.pool):
        key = _norm(row.term)
        if row.target_locations or (primary_reported and key == primary):
            continue
        holders = [c for c in audit.titled
                   if any(term_matches(row.term, text) for text in [c.title, *c.bullet_points])]
        ratio = len(holders) / total if total else 0
        if (total >= MIN_COMPETITORS and ratio >= 0.4) or key in audit.core_keys:
            flagged.append((rank, row, holders, ratio))

    def coverage(holders) -> str:
        return (f"{len(holders)}/{total} 个竞品标题或五点含该词" if total
                else "没有可对照的竞品文案")

    findings = []
    for rank, row, holders, ratio in flagged[:MISSING_KEYWORD_LIMIT]:
        in_titles = total and row.competitor_title_count / total >= 0.5
        section = "title" if in_titles else "bullets"
        # Every word already present (other order/split): a phrase gap, never a hard defect.
        own_text = "\n".join([audit.title, *audit.bullets, audit.description])
        scattered = not missing_tokens(row.term, own_text)
        hard = (total >= MIN_COMPETITORS and ratio >= MISSING_HARD_RATIO and rank < POOL_TOP
                and not scattered)
        relevance = RELEVANCE_LABELS.get(row.relevance)
        reason = f"与本品{relevance}" if relevance else "是本品核心词"
        findings.append(_finding(
            f"keyword.missing:{_norm(row.term)}", section, "hard" if hard else "advice",
            f"高价值词「{row.term}」没有完整写出" if scattered else f"高价值词「{row.term}」没有埋",
            (f"本品文案有「{row.term}」的各个词，但没有连续短语" if scattered
             else f"本品标题、五点、描述都没有出现「{row.term}」"),
            [coverage(holders) + (f"（其中标题 {row.competitor_title_count} 个）" if total else ""),
             f"按价值排序在高价值词池第 {rank + 1} 位（共 {len(audit.pool)} 个）",
             *audit.keyword_evidence(row.term)],
            f"「{row.term}」{reason}，文案里完全没有，买家搜这个词时本品缺少匹配。"
            + audit.relevance_note(row.term),
            f"把「{row.term}」自然写进{'标题' if section == 'title' else '靠前的五点'}。",
            keywords=[row.term], competitor_asins=[c.asin for c in holders],
        ))

    rest = flagged[MISSING_KEYWORD_LIMIT:]
    if rest:
        in_titles = total and all(row.competitor_title_count / total >= 0.5 for _, row, _, _ in rest)
        terms = [row.term for _, row, _, _ in rest]
        findings.append(_finding(
            "keyword.missing_more", "title" if in_titles else "bullets", "advice",
            f"另有 {len(rest)} 个高价值词没有埋",
            "本品标题、五点、描述都没有出现：" + "、".join(terms),
            [f"「{row.term}」：{coverage(holders)}" for _, row, holders, _ in rest],
            "这些词同样相关或属于核心词，缺失会缩小可匹配的搜索面。",
            "优先写进五点，放不下的写进描述。",
            keywords=terms,
        ))
    return findings


# ---------------------------------------------------------------------------
# Bullets, compliance
# ---------------------------------------------------------------------------

def _bullet_count(audit: _Audit) -> list[AuditFinding]:
    count = len(audit.bullets)
    if count >= 5:
        return []
    return [_finding(
        "bullets.count", "bullets", "hard", "五点没有写满",
        f"本品只有 {count} 条非空五点", [f"非空五点 {count} 条，应写满 5 条"],
        "空缺的要点位置没有传达卖点，也少了可匹配搜索词的文案。",
        "补足 5 条，分别承接核心人群、场景、功能、规格和使用说明。",
    )]


def _cosmo_gaps(audit: _Audit, not_checked: dict[str, str]) -> list[AuditFinding]:
    if not audit.data.cosmo_groups:
        not_checked.setdefault("cosmo", "缺少 COSMO 语义分组，未做语义缺口规则")
        return []
    if audit.cosmo_total < MIN_COMPETITORS:
        not_checked.setdefault(
            "cosmo", f"有 COSMO 结果的竞品只有 {audit.cosmo_total} 个（至少 {MIN_COMPETITORS} 个），未做语义缺口规则")
        return []
    if not audit.target_has_cosmo:
        # Without any own semantic every group would look missing.
        not_checked.setdefault("cosmo", "语义分组中没有本品结果，无法判断缺口，未做语义缺口规则")
        return []
    total = audit.cosmo_total
    gaps = [(len(found) / total, group, found) for group, found, has in audit.cosmo
            if not has and len(found) / total >= 0.5]
    gaps.sort(key=lambda item: item[0], reverse=True)

    def evidence(group, found) -> str:
        examples = "、".join(group.members[:3]) or group.term
        return f"{len(found)}/{total} 个竞品文案含此语义（如：{examples}）"

    def label(group) -> str:
        return f"{group.term_cn}（{group.term}）" if group.term_cn else group.term

    if not gaps:
        return []
    key_gaps = [g for g in gaps if g[1].cosmo_field in KEY_COSMO_FIELDS and g[0] >= COSMO_HARD_RATIO]
    hard = len(key_gaps) >= COSMO_HARD_GAPS
    shown = gaps[:COSMO_GAP_LIMIT * 2]
    lines = [f"{label(group)}：{evidence(group, found)}" for _, group, found in shown]
    if len(gaps) > len(shown):
        lines.append(f"另有 {len(gaps) - len(shown)} 个语义缺口，见附录 D")
    lines.append(f"其中人群、场景、功能类缺口 {len(key_gaps)} 个达到 {_percent(COSMO_HARD_RATIO)} 以上竞品覆盖")
    return [_finding(
        "bullets.cosmo_gap", "bullets", "hard" if hard else "advice",
        f"COSMO 语义覆盖不足：竞品多数写了、本品没写的语义 {len(gaps)} 个",
        "本品 Listing 的语义结果里没有：" + "、".join(label(group) for _, group, _ in shown[:6]),
        lines,
        "这些是过半竞品都在向买家和搜索系统说明的用途、人群和场景，本品没有表达，"
        "COSMO 语义匹配会弱于竞品。逐条确认本品确实适用后再补。",
        "确认属实的，在五点里用自然语句写出（优先人群、场景、解决的问题），不适用的忽略。",
        keywords=[group.term for _, group, _ in shown],
        competitor_asins=sorted(set().union(*(found for _, _, found in shown))),
    )]


_SIZE = re.compile(r"\bsize\s*(?:us\s*)?(\d{1,2}(?:\.\d{1,2})?)(?!\d|\.\d)", re.IGNORECASE)


def _size_value(raw: str) -> str:
    """Normalise a captured size so 6.50, 6.5 and 6.0/6 compare equal."""
    return f"{float(raw):g}"


def _size_conflict(audit: _Audit) -> list[AuditFinding]:
    """A single-variant Listing that names different sizes in title, bullets or description."""
    places = {"标题": [audit.title], **{f"五点{i}": [b] for i, b in enumerate(audit.listing.bullet_points, 1)},
              "描述": [audit.description]}
    found: dict[str, list[str]] = {}
    for place, texts in places.items():
        sizes = sorted({_size_value(m) for text in texts for m in _SIZE.findall(text or "")})
        if len(sizes) == 1:
            found.setdefault(sizes[0], []).append(place)
        elif len(sizes) > 1:
            return []  # a size list (e.g. "fits size 6–10") is not a contradiction
    if len(found) < 2:
        return []
    lines = [f"{'、'.join(where)}写的是 size {size}" for size, where in found.items()]
    section = "bullets" if any(p.startswith("五点") for where in found.values() for p in where) else "title"
    return [_finding(
        "listing.size_conflict", section, "hard", "尺寸前后矛盾",
        "；".join(lines), lines,
        "同一条 Listing 写了不同尺寸，买家会买错或犹豫，直接导致退货和差评。",
        "核对实物尺寸，把标题、五点和描述统一成同一个尺寸。",
    )]


def _without_brand(text: str, brand: str) -> str:
    if not brand:
        return text
    return re.sub(r"(?<!\w)" + re.escape(brand) + r"(?!\w)", " ", text, flags=re.IGNORECASE)


def _forbidden_chars(audit: _Audit) -> list[AuditFinding]:
    # Only the complete own-brand name grants an exception (see validate_listing).
    remaining = _without_brand(audit.title, (audit.listing.brand or "").strip())
    found = [char for char in FORBIDDEN_TITLE_CHARS if char in remaining]
    if not found:
        return []
    shown = " ".join(found)
    count = sum(remaining.count(char) for char in found)
    return [_finding(
        "title.forbidden_chars", "title", "hard", "标题含禁用字符",
        f"标题：“{_clip(audit.title)}”",
        [f"本品品牌名之外出现禁用字符 {shown}，共 {count} 处"],
        "这些字符不允许出现在商品标题中，有被改写或限制展示的风险。",
        "删除这些字符，用逗号、连字符或文字表达。",
    )]


def _other_brand(audit: _Audit) -> list[AuditFinding]:
    own = (audit.listing.brand or "").strip()
    brands: dict[str, tuple[str, list[str]]] = {}
    for item in audit.peers:
        brand = (item.brand or "").strip()
        key = brand.casefold()
        if len(brand) < 3 or key == own.casefold() or key in BRAND_STOPLIST:
            continue
        brands.setdefault(key, (brand, []))[1].append(item.asin)

    texts = {"标题": _without_brand(audit.title, own),
             "五点": _without_brand("\n".join(audit.bullets), own)}
    hits = []
    for brand, asins in brands.values():
        pattern = r"(?<!\w)" + re.escape(brand) + r"(?!\w)"
        places = [place for place, text in texts.items() if re.search(pattern, text, re.IGNORECASE)]
        if places:
            hits.append((brand, places, asins))
    if not hits:
        return []
    section = "title" if any("标题" in places for _, places, _ in hits) else "bullets"
    names = [brand for brand, _, _ in hits]
    return [_finding(
        "listing.other_brand", section, "hard", "文案出现其他品牌词",
        "；".join(f"“{brand}”出现在本品{'、'.join(places)}" for brand, places, _ in hits),
        [f"“{brand}”是竞品 {'、'.join(asins)} 的品牌" for brand, _, asins in hits],
        "使用他人品牌词有侵权投诉和下架风险。若只是普通英文词撞名，请人工确认。",
        "删除这些品牌词。",
        keywords=names, competitor_asins=_unique(a for _, _, asins in hits for a in asins),
    )]


# ---------------------------------------------------------------------------
# Images, A+, description
# ---------------------------------------------------------------------------

def _main_image(audit: _Audit) -> list[AuditFinding]:
    measure = audit.data.main_measure
    if measure is None:
        return []
    findings = []
    image_ids = [measure.image_id]
    width, height = measure.original_width, measure.original_height
    if max(width, height) < MIN_MAIN_SIDE:
        findings.append(_finding(
            "main.resolution", "main_image", "hard", "主图分辨率不足",
            f"主图原图 {width}×{height} 像素",
            [f"主图原图 {width}×{height} 像素，最长边 {max(width, height)}，低于 {MIN_MAIN_SIDE}"],
            f"亚马逊需 ≥{MIN_MAIN_SIDE}px 才能开启放大",
            "上传最长边不低于 1600 像素的原图。", image_ids=image_ids,
        ))
    white = measure.white_border_ratio
    if white is None:
        return findings
    corners = measure.white_corners
    # A product touching the edges lowers the border share; white corners still prove a white backdrop,
    # unless most of the border is not white (e.g. a dark backdrop with two light corners).
    if corners is not None:
        background_bad = corners <= 1 or white < MIN_WHITE_BORDER_WITH_CORNERS
    else:
        background_bad = white < MIN_WHITE_BORDER
    if background_bad:
        corner_text = f"，四个角中 {corners} 个为白色" if corners is not None else ""
        findings.append(_finding(
            "main.background", "main_image", "hard", "主图背景不是纯白",
            f"主图边缘近白像素占 {_percent(white)}{corner_text}",
            [f"主图边缘近白像素占 {_percent(white)}{corner_text}（纯白背景应接近 100%）"],
            "亚马逊主图要求纯白背景，不达标有被抑制展示的风险。",
            "抠图后换成纯白背景（RGB 255,255,255）。", image_ids=image_ids,
        ))
    elif measure.fill_ratio is not None and measure.fill_ratio < 0.7:
        fill = measure.fill_ratio
        findings.append(_finding(
            "main.fill", "main_image", "hard" if fill < 0.5 else "advice", "主图商品占画面比例偏小",
            f"商品外框的长边只占画面 {_percent(fill)}",
            [f"非白色区域长边占画面 {_percent(fill)}（建议至少 70%，低于 50% 为硬伤）"],
            "商品在搜索结果缩略图里显得小，买家看不清，影响点击。",
            "裁掉多余留白，让商品占画面 85% 左右。", image_ids=image_ids,
        ))
    return findings


def _gallery_count(audit: _Audit) -> list[AuditFinding]:
    listing = audit.listing
    if not (listing.main_image or listing.gallery_images or audit.data.main_measure):
        return []  # no image data at all: nothing to count
    total = 1 + len(listing.gallery_images)
    counts = [c.image_count for c in audit.peers if c.image_count > 0]
    middle = median(counts) if len(counts) >= MIN_COMPETITORS else None
    if total < MIN_IMAGES:
        severity = "hard"
    elif middle is not None and middle - total >= 2:
        severity = "advice"
    else:
        return []
    evidence = [f"本品共 {total} 张图（主图 1 张 + 副图 {total - 1} 张）"]
    if middle is not None:
        evidence.append(f"竞品图片数中位 {_num(middle)} 张（{len(counts)} 个竞品）")
    if severity == "hard":
        evidence.append(f"少于基本要求的 {MIN_IMAGES} 张")
    return [_finding(
        "gallery.count", "gallery", severity, "图片数量不足", f"本品只有 {total} 张图", evidence,
        "图片少，买家在下单前看不到足够的卖点、场景、尺寸和细节。",
        "补齐卖点图、场景图、尺寸图、细节图和包装清单。",
    )]


def _aplus_missing(audit: _Audit) -> list[AuditFinding]:
    if audit.has_aplus:
        return []
    known = [c for c in audit.peers if c.title.strip() or c.image_count > 0]
    having = [c for c in known if c.aplus_count > 0]
    if len(known) < MIN_COMPETITORS or len(having) / len(known) < 0.5:
        return []
    return [_finding(
        "aplus.missing", "aplus", "advice", "未检测到 A+（数据源可能未返回，需人工确认）",
        "本次取到的数据里没有任何 A+ 图片",
        [f"{len(having)}/{len(known)} 个竞品检测到 A+"],
        "如确实没有 A+，本品详情页的说服内容少于过半竞品；也可能只是数据源漏返回。",
        "先在前台页面确认；确实缺失则补做 A+。",
        competitor_asins=[c.asin for c in having],
    )]


def _description_empty(audit: _Audit) -> list[AuditFinding]:
    if audit.description or audit.has_aplus:
        return []
    return [_finding(
        "description.empty", "description", "advice", "描述为空且没有 A+",
        "商品描述为空，也未检测到 A+", ["描述 0 个字符；A+ 图片 0 张"],
        "详情区没有补充内容，也少了一处可匹配搜索词的文案。",
        "补写描述（使用场景、规格、包装清单、注意事项），或制作 A+。",
    )]


def _rule_findings(audit: _Audit, not_checked: dict[str, str]) -> list[AuditFinding]:
    findings = []
    if audit.listing.main_image and audit.data.main_measure is None:
        not_checked.setdefault("main_measure", "未取得主图像素测量，未做分辨率、白底和占比规则")
    if audit.has_text:
        if len(audit.titled) < MIN_COMPETITORS:
            not_checked.setdefault(
                "competitors",
                f"有标题的竞品只有 {len(audit.titled)} 个（至少 {MIN_COMPETITORS} 个），竞品对照类规则未完整执行")
        core = _core_rules(audit)
        findings += core
        if not audit.core_terms:
            not_checked.setdefault("core_terms", "未提供核心词，未做核心词位置规则")
        findings += _title_length(audit)
        has_relevance = any(row.relevance in RELEVANCE_LABELS or row.is_core for row in audit.table)
        if has_relevance:
            findings += _density(audit, "title")
            findings += _missing_keywords(
                audit, any(item.id == "title.core_missing" for item in core))
        else:
            not_checked.setdefault("keywords", "缺少相关性判断，未做关键词规则")
        findings += _bullet_count(audit)
        if has_relevance:
            findings += _density(audit, "bullets")
        findings += _cosmo_gaps(audit, not_checked)
        findings += _size_conflict(audit)
        findings += _forbidden_chars(audit)
        findings += _other_brand(audit)
        findings += _description_empty(audit)
    findings += _main_image(audit)
    findings += _gallery_count(audit)
    findings += _aplus_missing(audit)
    return findings


# ---------------------------------------------------------------------------
# Merge, score, summarize
# ---------------------------------------------------------------------------

def _merge_model_findings(findings: list[AuditFinding], data: ListingAuditCalcInput) -> list[AuditFinding]:
    merged = list(findings)
    seen = {(item.section, _norm(item.title)) for item in merged}
    numbers: dict[str, int] = {}
    # A model may only point at competitors and images it was actually given.
    known_asins = {c.asin.upper(): c.asin for c in data.competitors}
    known_images: set[str] = set()
    if data.main_measure:
        known_images.add(data.main_measure.image_id)
    if data.visual:
        known_images |= {r.image_id for r in data.visual.images} | set(data.visual.failed_images)
    for source in (data.text, data.visual):
        for item in source.findings if source else []:
            key = (item.section, _norm(item.title))
            if key in seen:
                continue
            seen.add(key)
            numbers[item.section] = numbers.get(item.section, 0) + 1
            severity, judgement = item.severity, item.judgement
            if severity == "hard" and not any(_strong_evidence(line, item) for line in item.evidence):
                severity = "advice"
                judgement += (f"（证据未达到硬伤门槛：需 ≥{_percent(MODEL_HARD_RATIO)} 竞品且样本不少于 {MODEL_HARD_MIN_COMPETITORS} 个，"
                              f"或评论提及 ≥{MODEL_HARD_MENTIONS} 人，降为建议）")
            merged.append(AuditFinding(
                **item.model_dump(exclude={"severity", "judgement", "image_ids", "competitor_asins"}),
                image_ids=_unique(i for i in item.image_ids if i in known_images),
                competitor_asins=_unique(known_asins[a.upper()] for a in item.competitor_asins
                                         if a.upper() in known_asins),
                id=f"{item.section}.model.{numbers[item.section]}", source="model",
                severity=severity, judgement=judgement, owner=SECTION_OWNERS[item.section],
            ))
    return merged


_ASIN_PATTERN = re.compile(r"\bB0[A-Z0-9]{8}\b", re.IGNORECASE)


_RATIO = re.compile(r"(\d+)\s*/\s*(\d+)\s*个?(?:竞品|同方案|流量赢家|同期)")
_MENTIONS = re.compile(r"(?:mentioned_by\s*[=:：]\s*(\d+)|(\d+)\s*(?:人|位用户|位买家|条评论|名用户))")


def _strong_evidence(line: str, item) -> bool:
    """Hard needs a majority of competitors (at least three) or a widely shared review signal."""
    if not _has_number(line, item):
        return False
    for found, total in _RATIO.findall(line):
        if int(total) >= MODEL_HARD_MIN_COMPETITORS and int(found) >= MODEL_HARD_RATIO * int(total):
            return True
    return any(int(a or b) >= MODEL_HARD_MENTIONS for a, b in _MENTIONS.findall(line))


def _has_number(line: str, item) -> bool:
    """A digit that is not just part of an ASIN or an image id the finding names."""
    for image_id in item.image_ids:
        line = line.replace(image_id, " ")
    return bool(re.search(r"\d", _ASIN_PATTERN.sub(" ", line)))


def _examined(section: str, audit: _Audit) -> tuple[bool, str]:
    """Whether the section's data was looked at, with the reason when it was not."""
    data, visual = audit.data, audit.data.visual
    if section in TEXT_SECTIONS:
        return audit.has_text, "缺少 Listing 文本"
    if section == "main_image":
        return visual is not None or data.main_measure is not None, "未做主图像素测量和图片分析"
    if visual is None:
        return False, "未做图片分析"
    if section == "aplus":
        seen = bool(audit.listing.aplus_images) or any(r.source == "aplus" for r in visual.images)
        return seen, "未获取到 A+ 图片，无法确认"
    return True, ""


def _review(section: str, findings: list[AuditFinding], audit: _Audit,
            not_checked: dict[str, str]) -> SectionReview:
    label = SECTION_LABELS[section]
    own = sorted((f for f in findings if f.section == section),
                 key=lambda f: (f.severity != "hard", f.source != "rule"))
    strengths = []
    for source in (audit.data.text, audit.data.visual):
        if source:
            strengths += source.strengths.get(section, [])
    strengths = _unique(strengths)
    examined, default_reason = _examined(section, audit)
    # A section whose review failed or never ran is "not checked" even when a rule left advice:
    # advice alone must not produce a score (and a green verdict) for an unchecked section.
    # A proven hard defect still fails the section.
    reason = not_checked.get(section) or (None if examined else default_reason)
    if reason and not any(f.severity == "hard" for f in own):
        not_checked.setdefault(section, reason)
        conclusion = "未检查" if not own else f"未完整检查（规则另有 {len(own)} 条建议，未计分）"
        return SectionReview(section=section, label=label, status="not_checked",
                             conclusion=conclusion, strengths=strengths, findings=own,
                             not_checked_reason=reason)
    deductions = []
    model_advice = 0
    for f in own:
        points = HARD_PENALTY if f.severity == "hard" else ADVICE_PENALTY
        if f.severity == "advice" and f.source == "model":
            # Model suggestions are judgement calls: together they cost at most MODEL_ADVICE_CAP.
            points = max(0, min(points, MODEL_ADVICE_CAP - model_advice))
            model_advice += points
        deductions.append(Deduction(finding_id=f.id, points=points))
    score = max(0, 10 - sum(item.points for item in deductions))
    if any(f.severity == "hard" for f in own):
        status = "failed"
    else:
        status = "needs_work" if score < 7 else "ok"
    conclusion = "未发现问题"
    if own:
        conclusion = own[0].title + (f"等 {len(own)} 个问题" if len(own) > 1 else "")
    return SectionReview(section=section, label=label, score=score, status=status,
                         conclusion=conclusion, strengths=strengths, findings=own,
                         deductions=deductions)


def _alignment(data: ListingAuditCalcInput) -> AlignmentVerdict:
    parts = [(name, source.alignment) for name, source in (("文案", data.text), ("图片", data.visual))
             if source]
    if not parts:
        return AlignmentVerdict(status="unknown", summary="未做语义对照")
    status = max((verdict.status for _, verdict in parts), key=ALIGNMENT_RANK.__getitem__)
    return AlignmentVerdict(
        status=status, summary="；".join(f"{name}：{verdict.summary}" for name, verdict in parts))


def _cosmo_table(audit: _Audit) -> list[CosmoRow]:
    rows = [CosmoRow(
        group_id=group.group_id, term=group.term, term_cn=group.term_cn,
        cosmo_field=group.cosmo_field, competitor_count=len(found),
        competitor_total=audit.cosmo_total, target_has=has,
    ) for group, found, has in audit.cosmo if len(found) >= 2]
    rows.sort(key=lambda row: row.competitor_count, reverse=True)
    return rows[:COSMO_TABLE_LIMIT]


@capability(
    "calc.product.listing_audit",
    description="Listing 分部分审查：确定性规则、合并模型发现、逐部分评分并生成报告",
    input_model=ListingAuditCalcInput,
    output_model=ListingAuditOutput,
)
def listing_audit(listing, competitors=None, keywords=None, core_terms=None, cosmo_groups=None,
                  demand=None, main_measure=None, text=None, visual=None, not_checked=None,
                  limitations=None) -> Result:
    supplied = {
        "listing": listing, "competitors": competitors, "keywords": keywords,
        "core_terms": core_terms, "cosmo_groups": cosmo_groups, "demand": demand,
        "main_measure": main_measure, "text": text, "visual": visual,
        "not_checked": not_checked, "limitations": limitations,
    }
    try:
        data = ListingAuditCalcInput.model_validate(
            {key: value for key, value in supplied.items() if value is not None})
    except ValidationError as exc:
        return err(Code.ERROR_PARAM, str(exc))

    audit = _Audit(data)
    target = data.listing
    if not (audit.has_text or target.main_image or target.gallery_images
            or target.aplus_images or data.main_measure):
        return err(Code.ERROR_MISSING_FIELDS, "缺少 Listing 文本和图片，无法审查",
                   missing=["listing"])

    notes = dict(data.not_checked)
    findings = _merge_model_findings(_rule_findings(audit, notes), data)
    sections = [_review(section, findings, audit, notes) for section in SECTIONS]

    hard_count = sum(f.severity == "hard" for f in findings)
    rule_hard = sum(f.severity == "hard" and f.source == "rule" for f in findings)
    # Red needs a rule-proven defect or several model defects; one model defect alone is yellow.
    # Without the semantic readings (or keyword relevance) a clean result proves nothing.
    incomplete = data.text is None or "keywords" in notes or any(
        s.status == "not_checked" for s in sections if s.section in {"main_image", "gallery"})
    if rule_hard or hard_count - rule_hard >= RED_MODEL_HARDS:
        verdict = "red"
    elif incomplete:
        verdict = "incomplete"
    elif hard_count:
        verdict = "yellow"
    elif any(s.score is not None and s.score < 7 for s in sections):
        verdict = "yellow"
    else:
        verdict = "green"
    ordered = sorted(findings, key=lambda f: (
        f.severity != "hard", FIX_PRIORITY.index(f.section), f.source != "rule"))

    visual_data = data.visual
    output = ListingAuditOutput(
        asin=target.asin, verdict=verdict, verdict_text=VERDICT_TEXT[verdict],
        alignment=_alignment(data), sections=sections,
        top_fixes=[f.id for f in ordered[:3]],
        hard_count=hard_count, advice_count=len(findings) - hard_count,
        core_terms=data.core_terms, competitors=data.competitors, demand=data.demand,
        keyword_table=audit.table[:KEYWORD_TABLE_LIMIT], cosmo_table=_cosmo_table(audit),
        image_readings=visual_data.images if visual_data else [],
        competitor_mains=visual_data.competitor_mains if visual_data else [],
        not_checked=notes,
        limitations=_unique([*data.limitations,
                             *(visual_data.limitations if visual_data else [])]),
    )
    output.report_markdown = render_report(output)
    return ok(data=output.model_dump(mode="json"))
