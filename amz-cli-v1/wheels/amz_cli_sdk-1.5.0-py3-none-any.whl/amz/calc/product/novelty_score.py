"""Deterministic "innovation worth following" score with a step-by-step explanation.

Per legacy group:

1. ``base`` comes from the strongest dimension's level (0/25/55/80), not a
   weighted sum, so a pure scenario or audience innovation can score high.
2. ``bonuses``: +8 for each further dimension at level 2+ (at most +16), +4 when
   buyers clearly seek it (``buyer_value`` 3).
3. ``caps``: low buyer value (0 → 30, 1 → 60) and non-innovation flags (IP
   derivative, bundle only, downgrade, model-specific, seasonal).

A model "same solution" whose form, function, scenario or audience is graded
level 2+ contradicts the definition (only tweaks) and is recorded as
``upgrade``, not existing. When any group is the same solution, ``existing`` is
true: the raw score comes from the lowest-scoring matched group and the final
score is capped (default 60). Otherwise the raw score is the lowest group score,
because the closest legacy solution bounds how new the product is.

Every step carries a Chinese reason and the model's evidence, so the output
explains the base score, each bonus and each cap.
"""

from __future__ import annotations

from amz.envelope import Result, ok
from amz.registry import capability
from amz.schemas.novelty import (
    BUYER_VALUE_CAPS, BUYER_VALUE_TEXT, DIMENSION_LABELS, EXTRA_STRONG_BONUS, FLAG_CAPS, FLAG_LABELS,
    LEVEL_BASE, LEVEL_TEXT, MAX_EXTRA_BONUS, NOVELTY_DIMENSIONS, STRUCTURAL_DIMENSIONS,
    TOP_BUYER_VALUE_BONUS, UPGRADE_LEVEL, BaseScore, GroupScore, NoveltyScoreInput, NoveltyScoreOutput,
    ScoreAdjustment, ScoreCap, ScoreExplanation,
)


def match_type(group) -> tuple[str, list[str]]:
    """same_solution is only kept when form/function/scenario/audience differ by tweaks (<= level 1)."""
    if not group.same_solution:
        return "different", []
    raised = [grade.dimension for grade in group.dimensions
              if grade.dimension in STRUCTURAL_DIMENSIONS and grade.level >= UPGRADE_LEVEL]
    return ("upgrade", sorted(raised, key=STRUCTURAL_DIMENSIONS.index)) if raised else ("same", [])


def _ranked(dimensions):
    """Highest level first; ties keep the NOVELTY_DIMENSIONS order (form first)."""
    return sorted(dimensions, key=lambda grade: (-grade.level, NOVELTY_DIMENSIONS.index(grade.dimension)))


def _name(grade) -> str:
    return f"{DIMENSION_LABELS[grade.dimension]}·{grade.pattern}"


def _base(ranked) -> BaseScore:
    top = ranked[0] if ranked and ranked[0].level > 0 else None
    if top is None:
        return BaseScore(points=0, level=0, reason="六个方面都没有看到和老品的差异，基础分 0。")
    return BaseScore(
        points=LEVEL_BASE[top.level], dimension=top.dimension, label=DIMENSION_LABELS[top.dimension],
        pattern=top.pattern, level=top.level, evidence=top.evidence, insight=top.insight,
        reason=f"最大的亮点是{_name(top)}，程度为{LEVEL_TEXT[top.level]}（{top.level} 级），"
               f"对应基础分 {LEVEL_BASE[top.level]}。",
    )


def _bonuses(group, ranked, base_points: int) -> list[ScoreAdjustment]:
    items, used = [], 0
    for grade in ranked[1:]:
        if grade.level < UPGRADE_LEVEL:
            break
        points = min(EXTRA_STRONG_BONUS, MAX_EXTRA_BONUS - used)
        used += points
        reason = f"另一个明显亮点：{_name(grade)}，{LEVEL_TEXT[grade.level]}（{grade.level} 级），+{EXTRA_STRONG_BONUS}。"
        if points == 0:
            reason = f"另一个明显亮点：{_name(grade)}，但多亮点加分已达上限 {MAX_EXTRA_BONUS}，不再加分。"
        items.append(ScoreAdjustment(kind="extra_dimension", points=points, reason=reason, evidence=grade.evidence))
    if group.buyer_value == 3 and base_points:
        items.append(ScoreAdjustment(
            kind="buyer_value", points=TOP_BUYER_VALUE_BONUS, evidence=group.buyer_value_reason,
            reason=f"买家价值 3 级（{BUYER_VALUE_TEXT[3]}），+{TOP_BUYER_VALUE_BONUS}。",
        ))
    return items


def _caps(group, uncapped: int) -> list[ScoreCap]:
    caps = []
    if group.buyer_value in BUYER_VALUE_CAPS:
        cap = BUYER_VALUE_CAPS[group.buyer_value]
        caps.append(ScoreCap(
            kind="buyer_value", cap=cap, evidence=group.buyer_value_reason, effective=cap < uncapped,
            reason=f"买家价值 {group.buyer_value} 级（{BUYER_VALUE_TEXT[group.buyer_value]}），最多 {cap} 分。",
        ))
    for item in group.flags:
        cap = FLAG_CAPS[item.flag]
        caps.append(ScoreCap(kind="flag", cap=cap, evidence=item.reason, effective=cap < uncapped,
                             reason=f"{FLAG_LABELS[item.flag]}，最多 {cap} 分。"))
    return caps


def group_score(group) -> dict:
    ranked = _ranked(group.dimensions)
    base = _base(ranked)
    bonuses = _bonuses(group, ranked, base.points)
    bonus = sum(item.points for item in bonuses)
    uncapped = min(100, base.points + bonus)
    caps = _caps(group, uncapped)
    score = min([uncapped, *(item.cap for item in caps)])
    return {"base": base, "bonuses": bonuses, "bonus": bonus, "uncapped_score": uncapped,
            "caps": caps, "score": score}


def _summary(row: GroupScore, caps: list[ScoreCap], final: int) -> str:
    parts = [f"基础分 {row.base.points}" + (f"（{row.base.label}·{row.base.pattern}，{LEVEL_TEXT[row.base.level]}）"
                                           if row.base.dimension else "（没有差异）")]
    parts += [f"+ {item.points}（{'另一个明显亮点' if item.kind == 'extra_dimension' else '买家会主动找'}）"
              for item in row.bonuses if item.points]
    text = " ".join(parts) + f" = {row.uncapped_score}"
    effective = [item for item in caps if item.effective]
    if effective:
        lowest = min(effective, key=lambda item: item.cap)
        text += f"；封顶：{lowest.reason.rstrip('。')}"
    else:
        text += "；没有触发封顶"
    return text + f" → 最终 {final} 分。"


@capability(
    "calc.product.novelty_score",
    description="按最强创新维度、买家价值和非创新标记计算创新分并逐步说明理由；与老品方案相同时封顶",
    input_model=NoveltyScoreInput,
    output_model=NoveltyScoreOutput,
)
def novelty_score(groups, existing_cap: int = 60) -> Result:
    data = NoveltyScoreInput(groups=groups, existing_cap=existing_cap)
    scores = []
    for group in data.groups:
        kind, raised = match_type(group)
        scores.append(GroupScore(
            group_name=group.group_name, same_solution=group.same_solution, match_type=kind,
            raised_dimensions=raised, **group_score(group),
        ))
    matched = [item for item in scores if item.match_type == "same"]
    existing = bool(matched)
    # A repeated solution defines the baseline; unmatched groups cannot lower it.
    closest = min(matched or scores, key=lambda item: item.score)
    raw = closest.score
    final = min(raw, data.existing_cap) if existing else raw

    judgement = next(group for group in data.groups if group.group_name == closest.group_name)
    if existing:
        selection = (f"本品与「{closest.group_name}」组老品 {'、'.join(judgement.matched_asins)} 是同一种做法"
                     "（形态、功能、场景、人群都只是小改），取同方案组中的最低分。")
    else:
        selection = f"没有发现同一种做法的老品；和各组老品分别比较后取最低分，「{closest.group_name}」组最接近。"
        if closest.match_type == "upgrade":
            labels = "、".join(DIMENSION_LABELS[d] for d in closest.raised_dimensions)
            selection += f"模型认为与该组同方案，但{labels}明显不同，记为改良款，不按同方案封顶。"
    caps = list(closest.caps)
    if existing:
        caps.append(ScoreCap(
            kind="existing", cap=data.existing_cap, effective=data.existing_cap < raw,
            evidence="、".join(judgement.matched_asins),
            reason=f"和已有老品是同一种做法，只是小改，最多 {data.existing_cap} 分。",
        ))
    explanation = ScoreExplanation(
        closest_group=closest.group_name, selection_reason=selection, base=closest.base,
        bonuses=closest.bonuses, uncapped_score=closest.uncapped_score, caps=caps, final_score=final,
        summary=_summary(closest, caps, final),
    )
    return ok(data=NoveltyScoreOutput(
        existing=existing, innovation_score=final, raw_score=raw,
        score_capped=existing and raw > data.existing_cap, existing_cap=data.existing_cap,
        closest_group=closest.group_name, explanation=explanation, group_scores=scores,
    ).model_dump(mode="json"))
