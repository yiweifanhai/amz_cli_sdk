"""Section-by-section audit of a live (new) Listing against real demand and competitors.

``Product.listing_audit`` prepares every fact the audit needs and delegates the
judgement:

1. Core terms: caller ``terms`` or the Product's primary keywords. A new Listing
   with too few reverse keywords must be given terms (no guessing).
2. Competitors in three groups: keyword sample → title prescreen for the same
   solution (``analysis.product.solution_prescreen``) split into same-period
   peers (listing date within ``peer_months``) and direct competitors; plus
   traffic winners (ABA top-3 click share of the core terms). Caller benchmarks
   are kept as their own group.
3. Keyword facts merged from the Product's and competitors' reverse lookups,
   judged for relevance by ``Product.keyword_relevance``.
4. Real demand: competitor (and, when reviewed, own) ``use_insights``.
5. COSMO coverage via ``Market.cosmo_aggregate`` on target + competitors.
6. Pixel facts of the main image; cleaned A+ list.
7. ``analysis.product.listing_text`` and ``analysis.product.listing_visual``
   read copy and images; ``calc.product.listing_audit`` scores and renders.

Optional evidence that fails is recorded as not-checked; nothing is filled in
from common sense. The result is a one-off task and is not cached.
"""

from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor
from datetime import date
from typing import TYPE_CHECKING, Any, Callable

from amz.entities._core import operations
from amz.entities._core.store import entity_store
from amz.entities.product.facts import _missing
from amz.envelope import Code, Result, err, ok
from amz.schemas.entity_ref import product_ref

if TYPE_CHECKING:
    from amz.entities.market import Market
    from amz.entities.product.entity import Product

FETCH_CONCURRENCY = 4
MIN_REVERSE_FOR_AUTO_TERMS = 5
MAX_KEYWORDS = 60
RELEVANCE_LIMIT = 40
REVERSE_COMPETITORS = 6
PRESCREEN_LIMIT = 20
MAX_PRESCREEN = 200
COSMO_COMPETITORS = 8
OWN_REVIEW_MIN = 30
GROUP_REASON = {
    "user": "调用方指定的基准竞品",
    "winner": "核心词点击份额前三",
    "peer": "同方案且上架时间相近",
    "direct": "同方案直接竞品",
}


RETRY_WAIT_SECONDS = 20


def _transient(result: Result | None) -> bool:
    message = str(getattr(result, "message", "") or "")
    return result is not None and result.code == Code.ERROR_LLM and any(
        mark in message for mark in ("HTTP 403", "HTTP 429", "HTTP 503", "rate limit", "timed out"))


def _with_retry(run: Callable[[], Result], usage: "_Usage", stage: str) -> Result:
    """Run a model stage; on a rate-limit style failure wait once and retry."""
    result = run()
    if _transient(result):
        usage.add(stage, result)
        time.sleep(RETRY_WAIT_SECONDS)
        result = run()
    return result


class _Usage:
    def __init__(self) -> None:
        self.requests = 0
        self.stages: dict[str, Any] = {}
        self.seconds: dict[str, float] = {}
        self._mark = time.monotonic()

    def lap(self, step: str) -> None:
        """Record wall-clock seconds since the previous lap under ``step``."""
        now = time.monotonic()
        self.seconds[step] = round(self.seconds.get(step, 0) + now - self._mark, 1)
        self._mark = now

    def add(self, stage: str, result: Result | None) -> None:
        usage = dict(getattr(getattr(result, "meta", None), "usage", None) or {})
        self.requests += int(usage.get("llm_requests", 0) or 0)
        previous = self.stages.get(stage)
        if previous is None:
            self.stages[stage] = usage
        else:
            self.stages[stage] = [*(previous if isinstance(previous, list) else [previous]), usage]

    def meta(self) -> dict:
        return {"llm_requests": self.requests, **self.stages, "seconds": self.seconds}


def _clean_terms(terms: list[str] | None) -> list[str]:
    cleaned: list[str] = []
    for term in terms or []:
        text = " ".join(str(term).split())
        if text and text.lower() not in {item.lower() for item in cleaned}:
            cleaned.append(text)
    return cleaned[:3]


def _norm(term: str) -> str:
    return " ".join(str(term or "").lower().split())


def _pct(value: Any) -> float | None:
    """Ratios from the reverse lookup arrive as 0–1; report as 0–100."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return round(float(value) * 100, 2) if 0 <= value <= 1 else round(float(value), 2)


def _int(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return int(value)
    return None


def _rank_text(item: dict) -> str:
    position = item.get("rankPosition")
    if isinstance(position, dict):
        page, pos = position.get("page"), position.get("position")
        if isinstance(page, int) and isinstance(pos, int) and pos > 0:
            return f"#{pos}" if page == 1 else f"P{page}#{pos}"
    return ""


def _parallel(items: list, fn: Callable) -> dict:
    """Run ``fn`` per item with bounded concurrency; one failure never aborts the task."""
    results: dict = {}
    if not items:
        return results
    with ThreadPoolExecutor(max_workers=min(FETCH_CONCURRENCY, len(items))) as executor:
        futures = {item: executor.submit(fn, item) for item in items}
        for item, future in futures.items():
            try:
                results[item] = future.result()
            except Exception as exc:  # noqa: BLE001 - recorded as an upstream failure
                results[item] = err(Code.ERROR_UPSTREAM, f"{type(exc).__name__}: {exc}")
    return results


def _reverse_items(entity: Product) -> list[dict] | Result:
    result = entity.enrich("reverse_keywords")
    if result.code != Code.OK:
        return result
    return [item.model_dump(mode="python") for item in entity.reverse_keywords or []]


def _competitor_facts(asin: str, marketplace: str) -> dict | Result:
    entity = entity_store.get_or_create(product_ref(marketplace, asin))
    failure = entity._ensure_analysis_facts(listing=True)
    if failure is not None:
        return failure
    images = [url for url in entity.images if str(url).strip()]
    return {
        "asin": entity.asin,
        "title": entity.title or "",
        "brand": entity.brand,
        "bullet_points": [text.strip() for text in entity.bullet_points if text.strip()],
        "listing_date": entity.listing_date or entity.available_date,
        "main_image": images[0] if images else "",
        "image_count": len(images),
        "aplus_count": len(entity.aplus_images or []),
        "count_review": entity.count_review,
    }


def _months_between(left: str | None, right: str | None) -> float | None:
    try:
        a = date.fromisoformat(str(left)[:10])
        b = date.fromisoformat(str(right)[:10])
    except (TypeError, ValueError):
        return None
    return abs((a - b).days) / 30.44


def _markets(product: Product, terms: list[str]) -> list[Market] | Result:
    from amz.entities.market import Market

    markets = []
    for term in terms:
        market = Market.fetch(term, marketplace=product.marketplace)
        if market is None:
            return err(Code.ERROR_UPSTREAM, f"failed to create Market for {term}")
        markets.append(market)
    return markets


def _sample_rows(markets: list[Market], pages: int, notes: list[str]) -> dict[str, dict]:
    rows: dict[str, dict] = {}
    for market in markets:
        result = market.enrich("products", pages=pages)
        if result.code != Code.OK:
            notes.append(f"关键词「{market.term}」取样失败：{result.message}")
            continue
        for item in market.products or []:
            asin = (item.asin or "").strip().upper()
            if not asin:
                continue
            rows.setdefault(asin, {
                "title": item.title or "", "listing_date": getattr(item, "listing_date", None) or item.available_date,
                "monthly_sales": item.monthly_sales, "count_review": item.count_review,
                "source": "market_sample", "query": market.term,
            })
    return rows


def _solution_rows(product: Product, terms: list[str], screen_model: str, usage: _Usage,
                   notes: list[str]) -> dict[str, dict]:
    from amz.data.market import market_competitors

    generated = operations.run_analysis("analysis.product.solution_terms", {
        "asin": product.asin, "title": product.title or "", "brand": product.brand,
        "bullet_points": [text for text in product.bullet_points if text.strip()],
        "avoid_terms": terms, "model": screen_model,
    })
    usage.add("solution_terms", generated)
    if generated.code != Code.OK:
        notes.append(f"方案词生成失败，未补搜同方案低销量商品：{generated.message}")
        return {}
    rows: dict[str, dict] = {}
    for term in generated.data.get("terms", []):
        found = market_competitors(keyword=term, pages=1)
        if found.code != Code.OK:
            notes.append(f"方案词「{term}」检索失败：{found.message}")
            continue
        for item in (found.data or {}).get("items", []):
            if isinstance(item, dict) and item.get("asin"):
                rows.setdefault(str(item["asin"]).strip().upper(), {
                    "title": str(item.get("title") or ""),
                    "listing_date": item.get("listing_date") or item.get("available_date"),
                    "monthly_sales": item.get("monthly_sales"), "count_review": item.get("count_review"),
                    "source": "solution_search", "query": term,
                })
    return rows


def _keyword_facts(own: list[dict], competitor_lists: dict[str, list[dict]], core_terms: list[str]) -> list[dict]:
    """Merge reverse-lookup rows by term; prefer the row that carries purchase data."""
    merged: dict[str, dict] = {}
    own_by_term = {_norm(item.get("term")): item for item in own if item.get("term")}

    def absorb(item: dict) -> None:
        key = _norm(item.get("term"))
        if not key:
            return
        current = merged.get(key)
        if current is None or (current.get("purchases") is None and item.get("purchases") is not None):
            merged[key] = item

    for item in own:
        absorb(item)
    for items in competitor_lists.values():
        for item in items:
            absorb(item)

    facts = []
    for key, item in merged.items():
        top3 = []
        for row in item.get("araClickTop3") or []:
            if isinstance(row, dict) and row.get("asin"):
                top3.append({"asin": str(row["asin"]).upper(), "click_share": _pct(row.get("clickRate")),
                             "conversion_share": _pct(row.get("conversionRate")), "title": str(row.get("productTitle") or "")})
        own_item = own_by_term.get(key)
        facts.append({
            "term": item.get("term"),
            "search_volume": _int(item.get("search_volume")),
            "clicks": _int(item.get("clicks")),
            "purchases": _int(item.get("purchases")),
            "purchase_rate": _pct(item.get("purchaseRate")),
            "ppc": item.get("ppc") if isinstance(item.get("ppc"), (int, float)) else None,
            "top3_click_share": _pct(item.get("top3ClickingRate")),
            "top3_conversion_share": _pct(item.get("top3ConversionRate")),
            "top3": top3,
            "traffic_competitors": sum(
                1 for items in competitor_lists.values() if any(_norm(row.get("term")) == key for row in items)
            ),
            "own_traffic_pct": own_item.get("traffic_pct") if own_item else None,
            "own_natural_ratio": own_item.get("natural_ratio") if own_item else None,
            "own_rank": _rank_text(own_item) if own_item else "",
            "is_core": key in {_norm(term) for term in core_terms},
        })
    for term in core_terms:  # a core term with no reverse data still has to be checked
        if _norm(term) not in merged:
            facts.append({"term": term, "is_core": True})

    def value(row: dict) -> float:
        if row.get("purchases") is not None:
            return float(row["purchases"])
        if row.get("search_volume") and row.get("purchase_rate"):
            return row["search_volume"] * row["purchase_rate"] / 100
        return float(row.get("search_volume") or 0)

    facts.sort(key=lambda row: (not row.get("is_core"), -value(row)))
    return facts[:MAX_KEYWORDS]


def _demand_signals(asin: str, insights: Any) -> list[dict]:
    if insights is None:
        return []
    data = insights.model_dump(mode="python") if hasattr(insights, "model_dump") else dict(insights)
    signals = []
    for kind, key, label, detail in (
        ("persona", "user_personas", "persona", "traits"),
        ("scenario", "use_scenarios", "scenario", "frequency"),
        ("motivation", "purchase_motivations", "motivation", "decision_factor_type"),
    ):
        for row in data.get(key) or []:
            if str(row.get(label) or "").strip():
                signals.append({
                    "kind": kind, "label": str(row[label]), "detail": str(row.get(detail) or ""),
                    "evidence": str(row.get("evidence") or "")[:300],
                    "mentioned_by": int(row.get("mentioned_by") or 0), "source_asin": asin,
                })
    return signals


def _insights_for(asin: str, marketplace: str) -> list[dict] | Result:
    entity = entity_store.get_or_create(product_ref(marketplace, asin))
    result = entity.enrich("use_insights")
    if result.code != Code.OK:
        return result
    return _demand_signals(asin, entity.use_insights)


def listing_audit(
    product: Product,
    terms: list[str] | None = None,
    benchmark_asins: list[str] | None = None,
    brief: str = "",
    pages: int = 1,
    peer_months: int = 6,
    max_winners: int = 6,
    max_direct: int = 5,
    max_peers: int = 5,
    review_competitors: int = 3,
    solution_search: bool = True,
    include_cosmo: bool = True,
    include_visual: bool = True,
    model: str = "pro",
    screen_model: str = "lite",
) -> Result:
    if product.marketplace != "US":
        return err(Code.ERROR_PARAM, "upstream product data currently supports marketplace US only")
    usage = _Usage()
    notes: list[str] = []
    not_checked: dict[str, str] = {}

    # 1. The audited Listing.
    failure = product._ensure_analysis_facts(listing=True)
    if failure is not None:
        return failure
    bullets = [text.strip() for text in product.bullet_points if text.strip()]
    missing = [name for name, present in (("title", (product.title or "").strip()), ("bullet_points", bullets)) if not present]
    images = [url for url in product.images if str(url).strip()]
    if not images:
        missing.append("images")
    if missing:
        return _missing(*missing)

    # 2. Core terms. Auto terms need enough reverse keywords; otherwise ask.
    own = _reverse_items(product)
    if isinstance(own, Result):
        notes.append(f"本品反查词获取失败：{own.message}")
        own = []
    core_terms = _clean_terms(terms)
    if not core_terms:
        if len(own) < MIN_REVERSE_FOR_AUTO_TERMS:
            return err(Code.ERROR_MISSING_FIELDS,
                       f"本品反查词只有 {len(own)} 个，无法可靠确定核心词；请传入 1–3 个核心关键词 terms",
                       missing=["terms"])
        primary = product.enrich("primary_keywords")
        candidates = [item.term for item in product.primary_keywords or []] if primary.code == Code.OK else []
        if not candidates:
            candidates = [row["term"] for row in sorted(own, key=lambda row: -(row.get("traffic_pct") or 0))]
        core_terms = _clean_terms(candidates[:2])
    if not core_terms:
        return _missing("terms")

    usage.lap("terms")
    # 3. Same-solution candidates from keyword samples and solution-term search.
    markets = _markets(product, core_terms)
    if isinstance(markets, Result):
        return markets
    rows = _sample_rows(markets, pages, notes)
    if solution_search:
        for asin, row in _solution_rows(product, core_terms, screen_model, usage, notes).items():
            rows.setdefault(asin, row)
    user_asins = [asin.strip().upper() for asin in benchmark_asins or [] if asin.strip()]
    pool = [asin for asin in rows if asin != product.asin and asin not in user_asins and rows[asin]["title"].strip()]
    if len(pool) > MAX_PRESCREEN:
        notes.append(f"候选 {len(pool)} 件，只预筛前 {MAX_PRESCREEN} 件。")
        pool = pool[:MAX_PRESCREEN]
    selected: list[str] = []
    if pool:
        screened = _with_retry(lambda: operations.run_analysis("analysis.product.solution_prescreen", {
            "target": {"asin": product.asin, "title": product.title, "bullet_points": bullets},
            "candidates": [{"asin": asin, "title": rows[asin]["title"]} for asin in pool],
            "limit": PRESCREEN_LIMIT, "model": screen_model,
        }), usage, "prescreen")
        usage.add("prescreen", screened)
        if screened.code == Code.OK:
            selected = [item["asin"] for item in screened.data["selected"]]
        else:
            notes.append(f"同方案预筛失败：{screened.message}")
    if not selected and not user_asins:
        notes.append("未找到同方案竞品；竞品对照只剩流量赢家。")

    usage.lap("sample_prescreen")
    # 4. Load competitors group by group; failed loads are replaced by the next candidate.
    anchor = product.listing_date or product.available_date or (rows.get(product.asin) or {}).get("listing_date")
    if not anchor:
        notes.append("本品缺上架日期，无法区分同期新品，同方案商品全部按直接竞品处理。")
    competitors: list[dict] = []
    taken: set[str] = {product.asin}
    failed: list[str] = []

    def load(asins: list[str], group: str, quota: int, reason: Callable[[str], str]) -> None:
        queue = [asin for asin in asins if asin not in taken]
        count = 0
        while queue and count < quota:
            batch, queue = queue[:quota - count], queue[quota - count:]
            facts = _parallel(batch, lambda asin: _competitor_facts(asin, product.marketplace))
            for asin in batch:
                fact = facts.get(asin)
                if isinstance(fact, Result) or fact is None:
                    failed.append(f"{asin}（{GROUP_REASON[group]}）：{getattr(fact, 'message', '资料缺失')}")
                    continue
                taken.add(asin)
                count += 1
                if not fact.get("listing_date"):
                    fact["listing_date"] = (rows.get(asin) or {}).get("listing_date")
                competitors.append({**fact, "group": group, "reason": reason(asin)})

    load(user_asins, "user", len(user_asins), lambda asin: GROUP_REASON["user"])
    peers, directs = [], []
    for asin in selected:
        gap = _months_between(anchor, (rows.get(asin) or {}).get("listing_date")) if anchor else None
        (peers if gap is not None and gap <= peer_months else directs).append(asin)
    load(peers, "peer", max_peers,
         lambda asin: f"同方案，上架 {str((rows.get(asin) or {}).get('listing_date') or '')[:10]}，与本品相差 ≤{peer_months} 个月")
    load(directs, "direct", max_direct, lambda asin: f"同方案（来自「{(rows.get(asin) or {}).get('query', '')}」）")

    usage.lap("competitor_details")
    # 5. Competitor reverse keywords, then traffic winners of the core terms.
    reverse_targets = [row["asin"] for row in competitors if row["group"] in {"peer", "direct", "user"}][:REVERSE_COMPETITORS]
    reverse_lists: dict[str, list[dict]] = {}
    for asin, items in _parallel(reverse_targets, lambda asin: _reverse_items(
            entity_store.get_or_create(product_ref(product.marketplace, asin)))).items():
        if isinstance(items, Result):
            notes.append(f"竞品 {asin} 反查词获取失败：{items.message}")
        else:
            reverse_lists[asin] = items
    keyword_rows = _keyword_facts(own, reverse_lists, core_terms)
    winner_reason: dict[str, str] = {}
    for row in keyword_rows:
        if not row.get("is_core"):
            continue
        for share in row.get("top3", []):
            if share["asin"] != product.asin and share["asin"] not in winner_reason:
                click = f"{share['click_share']:.1f}%" if share.get("click_share") is not None else "未知"
                winner_reason[share["asin"]] = f"「{row['term']}」点击份额前三（点击 {click}）"
    if not winner_reason:
        notes.append("核心词没有点击前三数据，未加入流量赢家组。")
    load(list(winner_reason), "winner", max_winners, lambda asin: winner_reason[asin])
    if failed:
        notes.append(f"{len(failed)} 个竞品资料无法补齐：" + "；".join(failed[:5]))

    usage.lap("reverse_winners")
    # 6. Relevance of candidate keywords to this Product.
    candidates = [row["term"] for row in keyword_rows][:RELEVANCE_LIMIT]
    relevance = _with_retry(lambda: product.keyword_relevance(keywords=candidates), usage, "relevance") \
        if candidates else None
    usage.add("relevance", relevance)
    if relevance is not None and relevance.code == Code.OK:
        judged = {_norm(item["keyword"]): item for item in relevance.data.get("results", [])}
        for row in keyword_rows:
            item = judged.get(_norm(row["term"]))
            if item:
                row["relevance"] = item.get("match", "unknown")
                row["relevance_reason"] = item.get("reason", "")
    elif relevance is not None:
        not_checked["keywords"] = f"关键词相关性判断失败：{relevance.message}"

    usage.lap("relevance")
    # 7. Real demand from reviewed same-solution competitors (and own reviews when enough).
    reviewers = sorted(
        (row for row in competitors if row["group"] in {"direct", "peer", "user"}),
        key=lambda row: -(row.get("count_review") or 0),
    )[:review_competitors]
    review_asins = [row["asin"] for row in reviewers]
    if (product.count_review or 0) >= OWN_REVIEW_MIN:
        review_asins.append(product.asin)
    signals: list[dict] = []
    used_reviews: list[str] = []
    for asin, found in _parallel(review_asins, lambda asin: _insights_for(asin, product.marketplace)).items():
        if isinstance(found, Result):
            notes.append(f"{asin} 评论洞察获取失败：{found.message}")
        else:
            signals.extend(found)
            used_reviews.append(asin)
    relevant = [row for row in keyword_rows if row.get("relevance") in {"perfect", "high"}]
    demand = {
        "signals": sorted(signals, key=lambda row: -row["mentioned_by"]),
        "review_asins": used_reviews,
        "keyword_signals": [row["term"] for row in relevant[:12]],
        "brief": brief.strip(),
        "notes": [] if used_reviews else ["没有可用的竞品评论洞察，需求画像只来自搜索词和简介。"],
    }

    usage.lap("demand_reviews")
    # 8. COSMO coverage of target + competitors.
    cosmo_groups: list[dict] = []
    if include_cosmo:
        refs = [product_ref(product.marketplace, product.asin)] + [
            product_ref(product.marketplace, row["asin"]) for row in competitors
            if row["group"] in {"direct", "peer", "user", "winner"}][:COSMO_COMPETITORS]
        if len(refs) >= 4:
            # Extract each Product's COSMO concurrently first; the aggregate then reads the cached fields.
            def warm(ref):
                return entity_store.get_or_create(ref).enrich("cosmo", model="lite", use_image=False)

            for ref, warmed in _parallel(refs, warm).items():
                if isinstance(warmed, Result) and warmed.code != Code.OK:
                    notes.append(f"{ref.identity['asin']} 的 COSMO 抽取失败：{warmed.message}")
            usage.lap("cosmo_extract")
            aggregated = _with_retry(lambda: markets[0].cosmo_aggregate(
                sample_refs=refs, target_product_ref=refs[0], use_image=False, min_success=3,
            ), usage, "cosmo")
            usage.add("cosmo", aggregated)
            if aggregated.code == Code.OK:
                for group in (aggregated.data or {}).get("groups", []):
                    cosmo_groups.append({
                        "group_id": str(group.get("group_id", "")), "term": group.get("representative_term", ""),
                        "term_cn": group.get("representative_term_cn", ""),
                        "cosmo_category": group.get("cosmo_category", ""), "cosmo_field": group.get("cosmo_field", ""),
                        "asins": [str(asin).upper() for asin in group.get("asins", [])],
                        "members": [member.get("term", "") for member in group.get("members", [])][:6],
                    })
            else:
                not_checked["cosmo"] = f"COSMO 聚合失败：{aggregated.message}"
        else:
            not_checked["cosmo"] = "可用竞品不足 3 个，未做 COSMO 语义对照"
    else:
        not_checked["cosmo"] = "调用方关闭了 COSMO 对照"

    usage.lap("cosmo")
    # 9. Pixel facts and cleaned A+.
    from amz.infra.images import measure_product_image, select_aplus_images

    main_measure = None
    try:
        main_measure = measure_product_image(images[0], "main")
    except Exception as exc:  # noqa: BLE001 - measurement is optional evidence
        notes.append(f"主图像素检测失败：{type(exc).__name__}: {exc}")
    aplus, aplus_stats = select_aplus_images(product.aplus_images or [])
    if aplus_stats["raw"] and aplus_stats["raw"] != aplus_stats["kept"]:
        notes.append(
            f"A+ 原始 {aplus_stats['raw']} 张，去掉小图 {aplus_stats['dropped_small']} 张、"
            f"商品缩略图 {aplus_stats['dropped_product_thumbnail']} 张、重复 {aplus_stats['dropped_duplicate']} 张、"
            f"超出上限 {aplus_stats['truncated']} 张，实际审查 {aplus_stats['kept']} 张。"
        )

    listing = {
        "asin": product.asin, "title": product.title or "", "brand": product.brand, "bullet_points": bullets,
        "description": product.description or "", "listing_date": anchor, "main_image": images[0],
        "gallery_images": images[1:], "aplus_images": aplus, "aplus_raw_count": aplus_stats["raw"],
        "brief": brief.strip(),
    }
    competitor_rows = [{key: row.get(key) for key in (
        "asin", "group", "reason", "title", "brand", "bullet_points", "listing_date", "main_image",
        "image_count", "aplus_count")} for row in competitors]
    shared = {"listing": listing, "competitors": competitor_rows, "keywords": keyword_rows, "demand": demand}

    usage.lap("pixels")
    # 10. Model reading of copy and images.
    text = _with_retry(lambda: operations.run_analysis(
        "analysis.product.listing_text", {**shared, "model": model}), usage, "listing_text")
    usage.add("listing_text", text)
    if text.code != Code.OK:
        notes.append(f"文案语义审查失败：{text.message}")
    usage.lap("listing_text")
    visual = None
    if include_visual:
        visual = _with_retry(lambda: operations.run_analysis(
            "analysis.product.listing_visual", {**shared, "model": model}), usage, "listing_visual")
        usage.add("listing_visual", visual)
        if visual.code != Code.OK:
            for section in ("gallery", "aplus"):
                not_checked[section] = f"图片语义审查失败：{visual.message}"
            notes.append(f"图片语义审查失败：{visual.message}")
    else:
        for section in ("gallery", "aplus"):
            not_checked[section] = "调用方关闭了图片语义审查"

    usage.lap("listing_visual")
    # 11. Deterministic rules, scores and report.
    result = operations.run_calc("calc.product.listing_audit", {
        **shared, "core_terms": core_terms, "cosmo_groups": cosmo_groups, "main_measure": main_measure,
        "text": text.data if text.code == Code.OK else None,
        "visual": visual.data if visual is not None and visual.code == Code.OK else None,
        "not_checked": not_checked, "limitations": notes,
    })
    if result.code != Code.OK:
        result.meta.usage = usage.meta()
        return result
    return ok(data=result.data, usage=usage.meta())
