"""Run the Market solution outlook task over Amazon and first-page Taobao samples."""
from __future__ import annotations

from datetime import date, datetime
from typing import TYPE_CHECKING
from zoneinfo import ZoneInfo

from amz.entities._core.operations import run_analysis, run_calc
from amz.entities.market.solution_sample import load_solution_sample
from amz.envelope import Code, Result, err, ok

if TYPE_CHECKING:
    from amz.entities.market.entity import Market

_MAX_EXAMPLES_AMAZON = 5
_MAX_EXAMPLES_TAOBAO = 3


def _examples(group: dict, signals: dict, rows: dict[str, dict], taobao: dict[str, str]) -> list[dict]:
    verified = [v["asin"] for v in signals["verified_new"]]
    suspected = {v["asin"] for v in signals.get("suspected_new", [])}
    rest = sorted(
        (a for a in group["amazon_ids"] if a not in verified and a not in suspected),
        key=lambda a: rows[a]["monthly_revenue"] or 0, reverse=True,
    )
    examples = [
        {"platform": "amazon", "item_id": asin, "title": rows[asin]["title"]}
        for asin in [*verified, *rest][:_MAX_EXAMPLES_AMAZON] if rows[asin]["title"]
    ]
    examples += [
        {"platform": "taobao", "item_id": item_id, "title": taobao[item_id]}
        for item_id in group["taobao_ids"][:_MAX_EXAMPLES_TAOBAO] if taobao.get(item_id)
    ]
    return examples


def solution_outlook(
    market: Market, taobao_term: str | None = None, pages: int | None = None,
    current_date: date | None = None, min_monthly_revenue: float = 5000,
    min_monthly_units: int = 200, new_days: int = 180, model: str = "pro",
) -> Result:
    sample = load_solution_sample(market, taobao_term, pages)
    if isinstance(sample, Result):
        return sample
    rows, taobao_items, taobao_sample = sample
    today = current_date or datetime.now(ZoneInfo("Asia/Shanghai")).date()
    thresholds = {"min_monthly_revenue": min_monthly_revenue, "min_monthly_units": min_monthly_units,
                  "new_days": new_days}
    verified = run_calc("calc.market.solution_validation", {
        "current_date": today, "thresholds": thresholds, "products": rows,
    })
    if verified.code != Code.OK:
        return verified

    classified = run_analysis("analysis.market.solution_classify", {
        "term": market.term, "taobao_term": taobao_sample["term"],
        "amazon": [{"asin": r["asin"], "title": r["title"]} for r in rows],
        "taobao": [{"item_id": p["item_id"], "title": p["title"]} for p in taobao_items], "model": model,
    })
    if classified.code != Code.OK:
        return classified
    classification = classified.data
    groups = classification["groups"]
    if not groups:
        return err(Code.ERROR_MISSING_FIELDS, "no solution groups could be formed from the titles",
                   missing=["classification.groups"], data=classification, usage=classified.meta.usage)

    members = [
        {"name": g["name"], "amazon_ids": g["amazon_ids"], "taobao_ids": g["taobao_ids"]}
        for g in groups
    ]
    signals = run_calc("calc.market.solution_signals", {
        "current_date": today, "thresholds": thresholds, "products": rows,
        "groups": members,
        "taobao_total": len(taobao_items), "verified_new": verified.data["verified_new"],
        "suspected_new": verified.data["suspected_new"],
        "taobao_prices_cny": {p["item_id"]: p["price_cny"] for p in taobao_items},
    })
    if signals.code != Code.OK:
        signals.meta.usage.update(classified.meta.usage)
        return signals

    by_asin = {r["asin"]: r for r in rows}
    taobao_titles = {p["item_id"]: p["title"] for p in taobao_items}
    by_name = {g["name"]: g for g in groups}
    solutions = []
    for item in signals.data["solutions"]:
        group = by_name[item["name"]]
        solutions.append({
            "name": group["name"], "summary": group["summary"], "solution": group["solution"],
            "signals": item, "examples": _examples(group, item, by_asin, taobao_titles),
        })
    outlook = run_analysis("analysis.market.solution_outlook", {
        "term": market.term, "taobao_term": classification["taobao_term"],
        "market": signals.data["market"], "thresholds": signals.data["thresholds"],
        "solutions": solutions, "model": model,
    })
    requests = classified.meta.usage.get("llm_requests", 0) + outlook.meta.usage.get("llm_requests", 0)
    if outlook.code != Code.OK:
        outlook.meta.usage["llm_requests"] = requests
        return outlook

    data = {
        **outlook.data,
        "current_date": today.isoformat(),
        "sample": market._sample_info().model_dump(mode="json"),
        "taobao_sample": taobao_sample,
        "classification_summary": classification["summary"],
        "solution_members": members,
        "unclassified": classification["unclassified"],
        "unassigned_verified": signals.data["unassigned_verified"],
        "unassigned_suspected": signals.data["unassigned_suspected"],
        "limitations": [*outlook.data["limitations"], *signals.data["limitations"], *classification["limitations"]],
    }
    return ok(data=data, usage={"llm_requests": requests})
