"""How products in one Amazon keyword market are evolving, and what is replacing what.

Pipeline:
  1. calc.market.solution_lines        rows → product lines + market structure
  2a. analysis.market.evolution_axes   storefront filters + titles → 2-4 dimensions, one primary
  2b. analysis.market.evolution_tags   titles + main images → each line's class (parallel batches)
  3. calc.market.solution_evolution    lines + tags → per-class share, trend, stage, grade, pairs
  4. analysis.market.evolution_judge   program facts + common sense → replacement chain and conclusion

``run_evolution`` is the reusable core: batch callers pass archived competing-lookup
rows and previously saved axes/tags/judgement so nothing is fetched or re-asked.
``solution_evolution`` is the Market task that loads the live sample and filters.
"""
from __future__ import annotations

import json
import math
import re
from datetime import UTC, date, datetime
from typing import TYPE_CHECKING
from zoneinfo import ZoneInfo

from amz.analysis.market.evolution_judge import recheck_judgement
from amz.entities._core.operations import run_analysis, run_calc
from amz.envelope import Code, Result, err, ok
from amz.schemas.solution_directions import DirectionsThresholds
from amz.schemas.solution_evolution import MAX_LINES, OPPORTUNITY_TIERS

if TYPE_CHECKING:
    from amz.entities.market.entity import Market

_ASIN = re.compile(r"^[A-Z0-9]{10}$")
# Product.missing_sample_fields 用规范字段名；sample_row 还会读这些上游原始别名
SAMPLE_FIELD_ALIASES = {
    "monthly_sales": ("monthly_sales", "totalUnits", "units"),
    "price_usd": ("price_usd", "price"),
    "count_review": ("count_review", "reviews"),
    "available_date": ("available_date", "availableDate", "listing_date"),
}
# 前台筛选里与产品方案无关的组（按组名小写包含判断）
_NOISE_GROUP_WORDS = (
    "brand", "seller", "deliver", "shipping", "deal", "discount", "review", "price", "sustainab", "subscribe",
    "local store", "condition", "handmade", "customiz", "climate", "release date", "model year", "global",
    "international", "new arrival", "availability", "out of stock", "prime", "coupon", "grade",
)
_SIZE_GROUPS = {"width", "height", "depth", "length", "thickness", "size", "weight", "item weight", "capacity",
                "diameter", "dimensions", "volume"}
_RANGE = re.compile(r"(\bup to\b|&\s*(above|up|over)\b|\bto\b.*\d|\d.*\b(in|inch|inches|ft|feet|cm|mm|lbs?|oz|"
                    r"pounds?|gallons?|qt|quarts?|liters?|ml)\b)", re.IGNORECASE)
MAX_FILTER_GROUPS = 12
MAX_FILTER_OPTIONS = 15
LIMITATIONS = [
    "只分析亚马逊站内搜索样本；淘宝和站外信息未纳入，后续只作供给线索。",
]


def _num(value) -> float | None:
    if isinstance(value, bool) or value is None:
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) and number >= 0 else None


def _date(value) -> str | None:
    if isinstance(value, (int, float)) and not isinstance(value, bool) and value > 0:
        return datetime.fromtimestamp(value / 1000, tz=UTC).date().isoformat()
    if isinstance(value, str) and re.match(r"^\d{4}-\d{2}-\d{2}", value):
        return value[:10]
    if isinstance(value, str) and value.isdigit():
        return _date(int(value))
    return None


def sales_trend(extra: dict) -> list[dict]:
    """Monthly units from competing-lookup (salesTrend dict/JSON string or trends list)."""
    history = extra.get("salesTrend")
    if isinstance(history, str):
        try:
            history = json.loads(history)
        except ValueError:
            history = None
    pairs = list(history.items()) if isinstance(history, dict) else []
    trends = extra.get("trends")
    if isinstance(trends, list):
        pairs.extend((row.get("dk"), row.get("sales")) for row in trends if isinstance(row, dict))
    points = {}
    for key, value in pairs:
        month = str(key)
        units = _num(value)
        if re.fullmatch(r"[0-9]{4}(0[1-9]|1[0-2])", month) and units is not None and units.is_integer():
            points[f"{month[:4]}-{month[4:]}"] = int(units)
    return [{"month": month, "units": units} for month, units in sorted(points.items())]


def sample_row(item: dict, m1: float | None = None) -> dict | None:
    """One competing-lookup row (raw camelCase or normalized snake_case) → SampleRow data."""
    asin = str(item.get("asin") or "").strip().upper()
    if not _ASIN.match(asin):
        return None
    parent = str(item.get("parent_asin") or item.get("parent") or "").strip().upper()
    units = _num(item.get("monthly_sales") if item.get("monthly_sales") is not None
                 else item.get("totalUnits", item.get("units")))
    reviews = _num(item.get("count_review") if item.get("count_review") is not None else item.get("reviews"))
    rating = _num(item.get("rating"))
    official = _num(item.get("amzUnit", item.get("official_units")))
    badge = item.get("badge") if isinstance(item.get("badge"), dict) else {}
    return {
        "asin": asin, "parent_asin": parent if _ASIN.match(parent) else None,
        "title": (item.get("title") or "").strip() or None,
        "image_url": item.get("image_url") or item.get("imageUrl"),
        "brand": item.get("brand") or None,
        "price_usd": _num(item.get("price_usd", item.get("price"))),
        "monthly_units": int(units) if units is not None else None,
        # 上游偶尔 totalAmount=0 而 revenue 有值：取第一个大于 0 的；都没有时由 solution_lines 用 月销×价格 补
        "monthly_revenue": next((v for k in ("totalAmount", "revenue", "monthly_revenue")
                                 if (v := _num(item.get(k)))), None),
        "rating": rating if rating is not None and rating <= 5 else None,
        "count_review": int(reviews) if reviews is not None else None,
        "available_date": _date(item.get("available_date") or item.get("availableDate") or item.get("listing_date")),
        "sales_trend": sales_trend(item),
        "official_units": int(official) if official is not None else None,
        "m1": m1 if m1 is None else float(m1),
        "amazon_choice": bool(item.get("amazonChoice") or badge.get("amazonChoice")),
        "best_seller": bool(item.get("bestSeller") or badge.get("bestSeller")),
    }


def market_rows(market: Market) -> list[dict]:
    """Sample rows from the Market's restored products; facts not observed this time are dropped."""
    rows = []
    for item in market.products or []:
        data = {**(item.model_extra or {}), **item.model_dump(exclude_none=True)}
        for field in (item.model_extra or {}).get("missing_sample_fields") or []:
            for key in SAMPLE_FIELD_ALIASES.get(field, (field,)):
                data.pop(key, None)
        if (row := sample_row(data)) is not None:
            rows.append(row)
    return rows


def filter_refinements(groups: dict[str, list[str]]) -> dict[str, list[str]]:
    """Keep storefront filter groups that describe the product itself."""
    kept = {}
    for name, options in groups.items():
        key = name.strip().casefold()
        if not options or any(word in key for word in _NOISE_GROUP_WORDS) or key in _SIZE_GROUPS:
            continue
        if sum(bool(_RANGE.search(o)) for o in options) * 2 >= len(options):
            continue
        kept[name.strip()] = options[:MAX_FILTER_OPTIONS]
        if len(kept) == MAX_FILTER_GROUPS:
            break
    return kept


def _storefront_filters(term: str) -> tuple[dict[str, list[str]], str | None]:
    from amz.data.product import product_refinements
    from amz.schemas.data_outputs import RefinementsOutput

    result = product_refinements(term)
    if result.code != Code.OK:
        return {}, f"亚马逊前台筛选获取失败（{result.code}），维度全部由模型定义。"
    try:
        groups = RefinementsOutput.model_validate(result.data or {}).refinements
    except ValueError:
        return {}, "亚马逊前台筛选格式无法识别，维度全部由模型定义。"
    return filter_refinements(groups), None


def _missing_rows(rows: list[dict]) -> Result | None:
    """At least one row must carry the facts every later step needs; checked before any model call."""
    if not rows:
        return err(Code.ERROR_MISSING_FIELDS, "empty Amazon Market sample", missing=["products"])
    if not any(row.get("title") and row.get("available_date") and row.get("monthly_units") is not None
               and (row.get("monthly_revenue") is not None or row.get("price_usd") is not None) for row in rows):
        return err(Code.ERROR_MISSING_FIELDS,
                   "no Amazon product has a title, launch date, monthly units and revenue or price together",
                   missing=["products.title/available_date/monthly_sales/monthly_revenue"])
    return None


def _tag_pool(lines: list[dict]) -> list[dict]:
    """Lines sent to the model: all with titles, capped by sales but always keeping verified lines."""
    titled = [l for l in lines if l["title"]]
    if len(titled) <= MAX_LINES:
        return titled
    verified = [l for l in titled if l["verified"]]
    rest = sorted((l for l in titled if not l["verified"]), key=lambda l: -(l["monthly_units"] or 0))
    return verified + rest[:MAX_LINES - len(verified)]


def _chain(judgement: dict, dynamics: dict) -> tuple[list[dict], int]:
    """Links backed by the current program pairs and verified lines; returns (links, dropped count)."""
    primary = next(a for a in dynamics["axes"] if a["primary"])
    rows = {row["value"]: row for row in primary["classes"]}
    pairs = {(p["riser"], p["incumbent"]) for p in dynamics["pairs"]}
    links, dropped = [], 0
    for c in judgement["classes"]:
        if not (c["replaces"] and c["tier"] in OPPORTUNITY_TIERS):
            continue
        row = rows.get(c["value"])
        if (c["value"], c["replaces"]) not in pairs or row is None or not set(c["evidence_ids"]) & set(row["verified"]):
            dropped += 1
            continue
        links.append({"incumbent": c["replaces"], "riser": c["value"], "tier": c["tier"], "grade": row["grade"],
                      "confidence": c["confidence"], "evidence_ids": c["evidence_ids"]})
    return links, dropped


def run_evolution(
    term: str, current_date: date, rows: list[dict], *, aba_top3: list[dict] | None = None,
    filters: dict[str, list[str]] | None = None, product_hint: str | None = None,
    axes: dict | None = None, tags: dict | None = None, judgement: dict | None = None,
    use_images: bool = True, thresholds: dict | None = None, model: str = "pro",
    skip_without_verified: bool = False, limitations: list[str] | None = None,
) -> Result:
    """Core pipeline; pass ``axes`` / ``tags`` / ``judgement`` saved earlier to skip the model."""
    usage = {"llm_requests": 0}
    if (missing := _missing_rows(rows)) is not None:
        return missing
    thresholds = thresholds or {}
    line_limits = {k: v for k, v in thresholds.items() if k in DirectionsThresholds.model_fields}
    lines_r = run_calc("calc.market.solution_lines", {"current_date": current_date, "rows": rows,
                                                      "aba_top3": aba_top3 or [], "thresholds": line_limits})
    if lines_r.code != Code.OK:
        return lines_r
    lines, structure = lines_r.data["lines"], lines_r.data["structure"]
    base = {"term": term, "current_date": current_date.isoformat(), "conclusion": None, "chain": [],
            "structure": structure, "filters": filters or {}, "axes": None, "tags": None, "dynamics": None,
            "judgement": None, "lines": lines, "usage": usage,
            "limitations": [*LIMITATIONS, *(limitations or []), *lines_r.data["limitations"]]}
    if skip_without_verified and not structure["verified_lines"]:
        base["limitations"].append("样本中没有已验证新品线，按调用方要求跳过分类与判断。")
        return ok(data=base, usage=usage)

    def call(capability_id: str, params: dict) -> Result:
        result = run_analysis(capability_id, params)
        usage["llm_requests"] += result.meta.usage.get("llm_requests", 0)
        if result.code != Code.OK:
            result.meta.usage.update(usage)
        return result

    pool = _tag_pool(lines)
    if not pool:
        return err(Code.ERROR_MISSING_FIELDS, "no product line has a title", missing=["products.title"])
    if axes is None:
        axes_r = call("analysis.market.evolution_axes", {
            "term": term, "product_hint": product_hint, "filters": filters or {}, "model": model,
            "items": [{"item_id": l["asin"], "title": l["title"], "price": l["price_usd"]} for l in pool]})
        if axes_r.code != Code.OK:
            return axes_r
        axes = axes_r.data
    base["axes"] = axes
    if tags is None:
        tags_r = call("analysis.market.evolution_tags", {
            "term": term, "axes": axes["axes"], "use_images": use_images, "model": model,
            "items": [{"item_id": l["asin"], "title": l["title"], "price": l["price_usd"],
                       "image_url": l["image_url"], "verified": l["verified"]} for l in pool]})
        if tags_r.code != Code.OK:
            return tags_r
        tags = tags_r.data
    base["tags"] = tags
    dyn_r = run_calc("calc.market.solution_evolution", {
        "current_date": current_date, "lines": lines, "axes": axes["axes"], "tags": tags["items"],
        "thresholds": thresholds})
    if dyn_r.code != Code.OK:
        return dyn_r
    dynamics = base["dynamics"] = dyn_r.data
    base["limitations"] += [*axes["limitations"], *tags["limitations"], *dynamics["limitations"]]
    if judgement is None:
        judge_r = call("analysis.market.evolution_judge", {
            "term": term, "product_hint": product_hint, "structure": structure, "dynamics": dynamics,
            "titles": {l["asin"]: l["title"] for l in lines if l["title"]}, "model": model})
        if judge_r.code == Code.OK:
            judgement = judge_r.data
        else:
            base["limitations"].append(f"替代判断未生成：{judge_r.message[:200]}；分类与各类证据仍可用。")
    else:
        # A saved judgement must pass the same program limits against today's evidence.
        judgement = recheck_judgement(judgement, dynamics)
    if judgement is not None:
        chain, dropped = _chain(judgement, dynamics)
        base.update(judgement=judgement, conclusion=judgement["summary"], chain=chain)
        base["limitations"] += judgement["limitations"]
        if dropped:
            base["limitations"].append(f"{dropped} 条替代关系与本次程序证据不符（不在此消彼长对里或没有引用本类已验证新品），未列入替代链。")
    return ok(data=base, usage=usage)


def solution_evolution(
    market: Market, pages: int | None = None, current_date: date | None = None,
    use_images: bool = True, model: str = "pro",
) -> Result:
    if market.marketplace != "US" or market.category:
        return err(Code.ERROR_PARAM, "solution evolution supports US keyword markets without a category filter")
    loaded = market.get_products(pages=pages)
    if loaded.code != Code.OK:
        return loaded
    rows = market_rows(market)
    if (missing := _missing_rows(rows)) is not None:
        return missing
    filters, note = _storefront_filters(market.term)
    today = current_date or datetime.now(ZoneInfo("Asia/Shanghai")).date()
    return run_evolution(market.term, today, rows, filters=filters, use_images=use_images, model=model,
                         limitations=[note] if note else None)
