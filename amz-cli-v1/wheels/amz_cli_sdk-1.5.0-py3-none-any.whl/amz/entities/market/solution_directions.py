"""Evidence-first solution directions for one Amazon keyword market.

Pipeline (one model request to tag, one optional request to explain):
  1. calc.market.solution_lines        rows → product lines + market structure
  2. analysis.market.solution_tags     titles → relation + axis values + change nature
  3. calc.market.solution_directions   lines + tags → roles, A/B/C grades, cards
  4. analysis.market.solution_explain  A/B cards → why / barriers / replaces / unknowns

``run_directions`` is the reusable core: batch callers (aba_candidate) pass archived
competing-lookup items, ABA top-3 rows and previously saved tags/explanations so
nothing is fetched or re-asked. ``solution_directions`` is the Market task that loads
the live sample (and optionally a Taobao first page) and calls the same core.
"""
from __future__ import annotations

from datetime import date, datetime
from typing import TYPE_CHECKING
from zoneinfo import ZoneInfo

from amz.entities._core.operations import run_analysis, run_calc
from amz.entities.market.solution_evolution import SAMPLE_FIELD_ALIASES, sample_row
from amz.envelope import Code, Result, err, ok

if TYPE_CHECKING:
    from amz.entities.market.entity import Market

MAX_TAG_ITEMS = 120
EXPLAIN_GRADES = ("A", "B")
_SAMPLE_FIELD_ALIASES = SAMPLE_FIELD_ALIASES
LIMITATIONS = [
    "方向卡只覆盖有已验证新品线的方向；没有新品做起来的市场不出卡（空缺型机会需另行研究）。",
]


def _explain_cards(cards: list[dict], axes: list[dict], lines: dict[str, dict]) -> list[dict]:
    out = []
    for index, card in enumerate(cards, 1):
        if card["grade"] not in EXPLAIN_GRADES:
            continue
        axis = next(a for a in axes if a["name"] == card["axis"])
        numbers = {k: card[k] for k in ("lines", "share", "recent_share", "base_share", "shift", "official_verified",
                                        "aba_verified", "entries_6m", "ramped_6m", "price_verified", "price_older",
                                        "rating_verified", "growth_3m", "taobao_count")}
        evidence = [{"asin": a, "title": (lines[a]["title"] or "")[:150], "price_usd": lines[a]["price_usd"],
                     "monthly_units": lines[a]["monthly_units"], "launch": str(lines[a]["launch"])}
                    for a in card["verified"][:6]]
        out.append({"ref": f"D{index}", "value": card["value"], "axis": card["axis"], "type": card["type"],
                    "grade": card["grade"], "desc": card["desc"], "numbers": numbers, "evidence": evidence,
                    "others": [v["value"] for v in axis["values"] if v["value"] != card["value"]]})
    return out


def run_directions(
    term: str, current_date: date, rows: list[dict], *, aba_top3: list[dict] | None = None,
    product_hint: str | None = None, category: str | None = None, tags: dict | None = None,
    explanations: list[dict] | None = None, explain: bool = True, taobao_items: list[dict] | None = None,
    thresholds: dict | None = None, model: str = "pro",
) -> Result:
    """Core pipeline; pass ``tags`` / ``explanations`` saved earlier to skip the model."""
    usage = {"llm_requests": 0}
    lines_r = run_calc("calc.market.solution_lines", {"current_date": current_date, "rows": rows,
                                                      "aba_top3": aba_top3 or [], "thresholds": thresholds or {}})
    if lines_r.code != Code.OK:
        return lines_r
    lines, structure = lines_r.data["lines"], lines_r.data["structure"]
    base = {"term": term, "current_date": current_date.isoformat(), "structure": structure, "lines": lines,
            "taobao_sample": None, "limitations": [*lines_r.data["limitations"], *LIMITATIONS]}
    if not structure["verified_lines"]:
        return ok(data={**base, "directions": None, "explanations": [], "tags": None, "usage": usage})

    if tags is None:
        items = [{"item_id": l["asin"], "title": l["title"], "price": l["price_usd"]} for l in lines][:MAX_TAG_ITEMS]
        items += [{"item_id": f"taobao:{t['item_id']}", "title": t.get("title"), "price": t.get("price_cny"),
                   "platform": "taobao"} for t in (taobao_items or [])][:max(0, MAX_TAG_ITEMS - len(items))]
        tags_r = run_analysis("analysis.market.solution_tags", {
            "term": term, "items": items, "product_hint": product_hint, "category": category, "model": model})
        usage["llm_requests"] += tags_r.meta.usage.get("llm_requests", 0)
        if tags_r.code != Code.OK:
            tags_r.meta.usage.update(usage)
            return tags_r
        tags = tags_r.data
    prices = {str(t["item_id"]): t["price_cny"] for t in (taobao_items or []) if t.get("price_cny") is not None}
    dir_r = run_calc("calc.market.solution_directions", {
        "current_date": current_date, "lines": lines, "tags": tags,
        "taobao_prices_cny": prices, "thresholds": thresholds or {}})
    if dir_r.code != Code.OK:
        return dir_r
    directions = dir_r.data

    if explanations is None:
        explanations = []
        cards = _explain_cards(directions["cards"], directions["axes"], {l["asin"]: l for l in lines})
        if explain and cards:
            exp_r = run_analysis("analysis.market.solution_explain", {
                "term": term, "cards": cards, "product_hint": product_hint, "model": model})
            usage["llm_requests"] += exp_r.meta.usage.get("llm_requests", 0)
            if exp_r.code == Code.OK:
                by_ref = {c["ref"]: c for c in cards}
                explanations = [{**e, "value": by_ref[e["ref"]]["value"], "axis": by_ref[e["ref"]]["axis"]}
                                for e in exp_r.data["explanations"]]
            else:
                base["limitations"].append(f"方向解释未生成：{exp_r.message[:200]}")
    _apply_nature_review(directions, explanations)
    return ok(data={**base, "directions": directions, "explanations": explanations, "tags": tags, "usage": usage},
              usage=usage)


def _apply_nature_review(directions: dict, explanations: list[dict]) -> None:
    """写解释时模型对照同维度做法复核为简化降配/加量套装的卡，移到 minor_cards（等级不变）。"""
    # 按 (维度, 取值) 匹配：不同维度可能出现同名取值；旧存档解释没有 axis 时退回只按取值匹配
    reviewed = {(e.get("axis"), e["value"]): e.get("nature") for e in explanations
                if e.get("nature") in ("简化降配", "加量套装")}
    keep = []
    for card in directions["cards"]:
        nature = reviewed.get((card["axis"], card["value"]), reviewed.get(("", card["value"]), reviewed.get((None, card["value"]))))
        if nature is None:
            keep.append(card)
            continue
        card.update(nature=nature, type=nature,
                    notes=[*card["notes"], f"打标时算新方案，写解释时对照同维度其他做法复核为{nature}，移到简化/加量"])
        directions["minor_cards"].append(card)
    directions["cards"] = keep


def solution_directions(
    market: Market, pages: int | None = None, current_date: date | None = None, taobao_term: str | None = None,
    explain: bool = True, model: str = "pro",
) -> Result:
    if market.marketplace != "US" or market.category:
        return err(Code.ERROR_PARAM, "solution directions support US keyword markets without a category filter")
    loaded = market.get_products(pages=pages)
    if loaded.code != Code.OK:
        return loaded
    rows = []
    for item in market.products or []:
        data = {**(item.model_extra or {}), **item.model_dump(exclude_none=True)}
        # 本次样本未观测到的字段只是旧导入的残留，不能当本次事实用（与 solution_outlook 同口径）
        for field in (item.model_extra or {}).get("missing_sample_fields") or []:
            for key in _SAMPLE_FIELD_ALIASES.get(field, (field,)):
                data.pop(key, None)
        if (row := sample_row(data)) is not None:
            rows.append(row)
    if not rows:
        return err(Code.ERROR_MISSING_FIELDS, "empty Amazon Market sample", missing=["products"])
    if not any(row["title"] and row["available_date"] and row["monthly_units"] is not None
               and (row["monthly_revenue"] is not None or row["price_usd"] is not None) for row in rows):
        return err(Code.ERROR_MISSING_FIELDS,
                   "no Amazon product has a title, launch date, monthly units and revenue or price together",
                   missing=["products.title/available_date/monthly_sales/monthly_revenue"])
    taobao_items, taobao_sample = None, None
    if taobao_term:
        from amz.entities.taobao import TaobaoMarket

        try:
            taobao = TaobaoMarket.fetch(taobao_term)
        except ValueError as exc:
            return err(Code.ERROR_PARAM, str(exc))
        got = taobao.get_products()
        if got.code == Code.OK:
            taobao_items = [{"item_id": p["item_id"], "title": p.get("title"), "price_cny": p.get("price_cny")}
                            for p in got.data["products"]]
            taobao_sample = {"term": taobao.term, "product_count": len(taobao_items)}
    today = current_date or datetime.now(ZoneInfo("Asia/Shanghai")).date()
    result = run_directions(market.term, today, rows, taobao_items=taobao_items, explain=explain, model=model)
    if result.code == Code.OK:
        result.data["taobao_sample"] = taobao_sample
        if taobao_term and taobao_sample is None:
            result.data["limitations"].append("淘宝样本获取失败，未计入供给对照。")
    return result
