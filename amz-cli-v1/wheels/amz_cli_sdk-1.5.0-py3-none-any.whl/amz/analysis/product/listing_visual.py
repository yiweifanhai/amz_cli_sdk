"""Read the Listing images against real demand and competitor main images.

``Product.listing_audit`` prepares the Listing, the competitor groups, keyword
facts and the demand portrait. This semantic task runs at most three model
requests (competitor mains, own main + gallery, own A+), validates image ids and
competitor references with one bounded repair per request, and returns image
readings plus findings for ``calc.product.listing_audit``. Background,
resolution and fill ratio are pixel facts measured by program, not judged here.
Hard findings whose evidence carries no number are downgraded to advice. No data
fetching beyond the supplied image URLs, no Entity or Store access.
"""

from __future__ import annotations

import json
import re
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from functools import partial
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator

from amz.analysis.base import AnalysisContractError, parse_structured
from amz.envelope import Code, Result, err, ok
from amz.infra.images import full_size_url, prepare_image
from amz.infra.llm import chat_json
from amz.registry import capability
from amz.schemas.listing_audit import (
    AlignmentVerdict, CompetitorListing, CompetitorMainReading, ImageReading,
    ListingVisualInput, ListingVisualOutput, ModelFinding,
)

MAX_GALLERY = 8
MAX_APLUS = 6
MAX_COMPETITORS = 8
BULLET_LIMIT = 400
DEMAND_LIMIT = 12
KEYWORD_LIMIT = 15
READ_TIMEOUT_S = 300
LOAD_WORKERS = 6

GROUP_PRIORITY = ("winner", "peer", "direct", "user")
GROUP_LABELS = {"winner": "流量赢家", "peer": "同期新品", "direct": "同方案直接竞品", "user": "用户指定"}
IMAGE_ROLES = ("卖点图", "场景图", "尺寸图", "对比图", "细节图", "包装清单", "人群使用", "品牌故事", "其他")

COMPETITOR_PROMPT = """# 任务
你在做亚马逊 Listing 视觉审查的第一步：逐张观察竞品主图，只记录画面事实。

# 每张主图回答
- people：画面里出现了谁（性别、年龄段、身份；宠物等使用对象也写明）；人和使用对象都没有时写“无人物”。
- scene：使用场景或背景环境；纯色背景且没有场景时照实写。
- message：这张图主要在向买家卖什么（用途、卖点、数量或组合内容）。

# 规则
只依据看得见的内容和图上文字，不推测看不见的材质、功能或销量。用中文回答。
只输出 JSON：{"mains": [{"asin": "...", "people": "...", "scene": "...", "message": "..."}]}，提供的每个 ASIN 恰好一次。
"""

_FINDING_RULES = """# 问题字段
- severity：hard 或 advice。只有 evidence 里带有下面这类量化事实、且问题明显影响买家理解或购买时才能用 hard；其余一律 advice。（程序会复核：hard 必须有一条证据写明“X/N 个竞品”且 X ≥ 0.6N、N ≥ 5，或写明评论提及人数 ≥ 30；达不到会被降为 advice，所以少数竞品或少量评论的问题直接用 advice）只报会明显影响点击或转化的问题；做得好的部分可以没有问题，不要为凑数而报，宁缺勿滥。
- title：一句话说清问题。
- current：本品现在怎么做的，写图号和画面里看到的内容，或引用原文。
- evidence：逐条抄写输入里的对照事实，例如“X/N 个竞品主图展示……”（从竞品主图读数里实际数出来）、需求画像某条信号的提及人数 mentioned_by、关键词的购买量 purchases。
- judgement：为什么这是问题，必须引用上面的事实。
- fix：设计师能直接执行的改法。
- image_ids：只能用本次给出的图片编号；缺某类图时可以为空数组。
- competitor_asins：只能用竞品主图读数里出现的 ASIN；没有则为空数组。
- keywords：相关的输入关键词；没有则为空数组。

# 边界
- 不评价主图是否白底、分辨率高低、产品占画面比例，这些由程序按原图像素测量。给你的图片经过缩小，也不要评价清晰度。
- 只依据输入事实和图片，不得编造数字、竞品内容或看不到的商品属性。
- 证据不足就不报；同一问题只报一次；做得好的 Listing 可以没有问题，不要凑数。
- 用中文回答；图上文字按原文抄写。只输出 JSON。
"""

GALLERY_PROMPT = """# 角色
你是亚马逊 Listing 视觉审查员，审查本品主图和副图是否对准真实买家。

# 要输出的内容
1. images：本次给出的每个图片编号恰好一条读数。
   - image_id：图片编号。
   - role：从 {roles} 中选一个。
   - people：画面里出现了谁（宠物等使用对象也写明）；都没有时写“无人物”。
   - scene：使用场景或背景环境。
   - message：这张图想告诉买家什么。
   - visible_text：图上文字逐行抄写；没有则为空数组。
2. alignment：status 取 aligned / partial / misaligned / unknown；summary 对比“真实买家是谁、在什么场景、要解决什么问题”和“图片实际展示的人群、场景、诉求”。没有需求证据时用 unknown。
3. strengths：{{"main_image": [...], "gallery": [...]}}，写确实做得好的点并带图号；没有则为空数组。
4. findings：section 只能是 main_image 或 gallery。重点检查：
   - 人群错位：图里的人和真实买家不是一类；
   - 场景错位：展示的使用场景和买家的真实场景不符；
   - 产品要解决的问题没有在任何图里展示；
   - 核心卖点或差异点在主图和前 3 张图（main、g1、g2）里看不出来；
   - 主图在缩略图大小下认不出是什么产品，或数量、包含内容不清楚；
   - 多数竞品在用而本品缺少的图片类型或表现手法（本次只给了竞品主图读数，不得声称竞品副图里有什么）；
   - 图上文字太小，手机上看不清；
   - 图片和标题、五点互相矛盾。

""".format(roles="、".join(IMAGE_ROLES)) + _FINDING_RULES

APLUS_PROMPT = """# 角色
你是亚马逊 Listing 视觉审查员，本次只审查本品的 A+ 图片。主图和副图已经读过，读数摘要在输入里。

# 要输出的内容
1. images：本次给出的每个 A+ 图片编号恰好一条读数。
   - image_id：图片编号。
   - role：从 {roles} 中选一个。
   - people：画面里出现了谁（宠物等使用对象也写明）；都没有时写“无人物”。
   - scene：使用场景或背景环境。
   - message：这张图想告诉买家什么。
   - visible_text：图上文字逐行抄写；没有则为空数组。
2. strengths：{{"aplus": [...]}}，写确实做得好的点并带图号；没有则为空数组。
3. findings：section 只能是 aplus。重点检查：
   - 只是重复副图内容，没有新增信息；
   - 没有回应需求画像里买家关心的问题或顾虑；
   - 对比图、场景图、品牌故事在本品上有用却缺失；
   - 面向的人群和真实买家错位。
   image_ids 可以引用本次的 A+ 编号，以及读数摘要里的主图、副图编号。本次没有提供竞品图片和竞品读数，
   competitor_asins 必须为空数组，evidence 不得写竞品数量对照，只能引用需求画像、关键词和主副图读数里的事实。

""".format(roles="、".join(IMAGE_ROLES)) + _FINDING_RULES


# ---------------------------------------------------------------------------
# Model drafts (program-owned fields such as source and pixel size are excluded)
# ---------------------------------------------------------------------------

class _Draft(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True)


class _CompetitorDraft(_Draft):
    asin: str = Field(min_length=1)
    people: str = Field(min_length=1)
    scene: str = Field(min_length=1)
    message: str = Field(min_length=1)


class _CompetitorMainsDraft(_Draft):
    mains: list[_CompetitorDraft]


class _ReadingDraft(_Draft):
    image_id: str = Field(min_length=1)
    role: Literal["卖点图", "场景图", "尺寸图", "对比图", "细节图", "包装清单", "人群使用", "品牌故事", "其他"]
    people: str = Field(min_length=1)
    scene: str = Field(min_length=1)
    message: str = Field(min_length=1)
    visible_text: list[str] = Field(default_factory=list)

    @field_validator("role", mode="before")
    @classmethod
    def _known_role(cls, value):
        # A free-form role label is not worth failing the whole reading.
        text = str(value or "").strip()
        return next((role for role in IMAGE_ROLES if role in text), "其他")


class _GalleryFinding(ModelFinding):
    section: Literal["main_image", "gallery"]


class _AplusFinding(ModelFinding):
    section: Literal["aplus"]


class _GalleryStrengths(_Draft):
    main_image: list[str]
    gallery: list[str]


class _AplusStrengths(_Draft):
    aplus: list[str]


class _GalleryDraft(_Draft):
    images: list[_ReadingDraft]
    alignment: AlignmentVerdict
    strengths: _GalleryStrengths
    findings: list[_GalleryFinding]


class _AplusDraft(_Draft):
    images: list[_ReadingDraft]
    strengths: _AplusStrengths
    findings: list[_AplusFinding]


# ---------------------------------------------------------------------------
# Public capability
# ---------------------------------------------------------------------------

@capability(
    "analysis.product.listing_visual",
    description="逐张看主图、副图和 A+，对照真实需求与竞品主图找出人群、场景和诉求偏离",
    input_model=ListingVisualInput,
    output_model=ListingVisualOutput,
)
def listing_visual(listing: dict, competitors: list[dict] | None = None, keywords: list[dict] | None = None,
                   demand: dict | None = None, model: str = "pro", max_side: int = 768) -> Result:
    # Multi-image requests on the pro tier outlast the default built-in read timeout.
    return _listing_visual(
        listing=listing, competitors=competitors, keywords=keywords, demand=demand, model=model,
        max_side=max_side, llm_call=partial(chat_json, builtin_read_timeout_s=READ_TIMEOUT_S),
        prepare=prepare_image,
    )


def _listing_visual(*, listing, competitors=None, keywords=None, demand=None, model="pro", max_side=768,
                    llm_call, prepare) -> Result:
    try:
        data = ListingVisualInput(
            listing=listing, competitors=competitors or [], keywords=keywords or [],
            demand=demand or {}, model=model, max_side=max_side,
        )
    except ValidationError as exc:
        return err(Code.ERROR_PARAM, str(exc))
    usage: dict = {"llm_requests": 0}
    target = data.listing
    if not target.main_image.strip():
        return err(Code.ERROR_MISSING_FIELDS, "ERROR_MISSING_FIELDS: main_image",
                   missing=["main_image"], usage=usage)

    def load(url: str):
        try:
            return prepare(full_size_url(url), max_side=data.max_side)
        except Exception:
            return None

    main = load(target.main_image)
    if main is None:
        return err(Code.ERROR_UPSTREAM, "main image could not be read", missing=["main_image"], usage=usage)

    failed_images: list[str] = []
    limitations: list[str] = []

    numbered: list[tuple[str, str]] = []  # (image id, url), own gallery and A+
    for prefix, label, urls, limit in (
        ("g", "副图", target.gallery_images, MAX_GALLERY), ("a", "A+ 图", target.aplus_images, MAX_APLUS),
    ):
        if len(urls) > limit:
            limitations.append(f"{label}共 {len(urls)} 张，只审查前 {limit} 张。")
        numbered += [(f"{prefix}{n}", url) for n, url in enumerate(urls[:limit], 1) if url.strip()]
    picked = _pick_competitors(target.asin, data.competitors)

    # Downloads are independent; read them in parallel and keep the input order.
    jobs = [url for _, url in numbered] + [rival.main_image for rival in picked]
    if jobs:
        with ThreadPoolExecutor(max_workers=min(LOAD_WORKERS, len(jobs))) as pool:
            loaded = list(pool.map(load, jobs))
    else:
        loaded = []
    own_loaded, rival_loaded = loaded[:len(numbered)], loaded[len(numbered):]

    gallery: dict = {}
    aplus: dict = {}
    for (image_id, _), image in zip(numbered, own_loaded):
        if image is None:
            failed_images.append(image_id)
        else:
            (gallery if image_id.startswith("g") else aplus)[image_id] = image
    if failed_images:
        limitations.append(f"以下图片无法读取，未纳入审查：{'、'.join(failed_images)}。")
    if not gallery:
        limitations.append("没有可读取的副图，副图内容未读取。")

    rivals = [(rival, image) for rival, image in zip(picked, rival_loaded) if image is not None]
    unreadable = [rival.asin for rival, image in zip(picked, rival_loaded) if image is None]
    if unreadable:
        limitations.append(f"{len(unreadable)} 个竞品主图无法读取，已跳过：{'、'.join(unreadable)}。")

    # Request 1: competitor main images. Failure only removes the comparison.
    competitor_mains: list[CompetitorMainReading] = []
    if rivals:
        draft, error = _request(
            _competitor_messages(rivals), _CompetitorMainsDraft,
            partial(_check_competitors, expected=[rival.asin for rival, _ in rivals]),
            "每个提供的 ASIN 恰好一次，不得增减。", data.model, llm_call, usage,
        )
        if draft is None:
            limitations.append("竞品主图读取没有得到有效结果，本次审查不含竞品主图对照。")
        else:
            readings = {item.asin.upper(): item for item in draft.mains}
            competitor_mains = [
                CompetitorMainReading(
                    asin=rival.asin, group=rival.group, people=readings[rival.asin.upper()].people,
                    scene=readings[rival.asin.upper()].scene, message=readings[rival.asin.upper()].message,
                )
                for rival, _ in rivals
            ]
    else:
        limitations.append("没有可读取的竞品主图，本次审查不含竞品主图对照。")
    rival_asins = {item.asin.upper() for item in competitor_mains}
    known_asins = rival_asins | {target.asin.strip().upper()} | {
        signal.source_asin.strip().upper() for signal in data.demand.signals
    }

    # Request 2: own main image and gallery. This one is required.
    own = {"main": main, **gallery}
    gallery_draft, error = _request(
        _gallery_messages(data, own, competitor_mains), _GalleryDraft,
        partial(_check_review, expected=list(own), image_ids=set(own), asins=rival_asins,
                known_asins=known_asins, rival_count=len(rival_asins)),
        f"images 必须恰好覆盖 {list(own)}；findings 的 section 只能是 main_image 或 gallery，"
        f"image_ids 只能取自上述编号，competitor_asins 只能取自 {sorted(rival_asins)}。",
        data.model, llm_call, usage,
    )
    if gallery_draft is None:
        return err(Code.ERROR_LLM, f"listing visual review failed: {error}", usage=usage)

    images = _readings(gallery_draft, own)
    findings = list(gallery_draft.findings)
    strengths = gallery_draft.strengths.model_dump()

    # Request 3: A+ images. Failure keeps the main and gallery results.
    if aplus:
        draft, error = _request(
            _aplus_messages(data, aplus, images), _AplusDraft,
            partial(_check_review, expected=list(aplus), image_ids={*aplus, *own}, asins=set(),
                    known_asins=known_asins, rival_count=0),
            f"images 必须恰好覆盖 {list(aplus)}；findings 的 section 只能是 aplus，"
            f"image_ids 只能取自 {[*aplus, *own]}，competitor_asins 必须为空数组（本次没有竞品读数）。",
            data.model, llm_call, usage,
        )
        if draft is None:
            limitations.append("A+ 未检查：A+ 图片审查没有得到有效结果，主图和副图的结果不受影响。")
        else:
            images += _readings(draft, aplus)
            findings += draft.findings
            strengths.update(draft.strengths.model_dump())
    else:
        limitations.append("A+ 未检查：没有可读取的 A+ 图片。")

    alignment = gallery_draft.alignment
    demand = data.demand
    if alignment.status != "unknown" and not (
        demand.signals or demand.keyword_signals or demand.brief.strip() or target.brief.strip()
    ):
        alignment = alignment.model_copy(update={"status": "unknown"})
        limitations.append("没有买家需求或简介证据，人群和诉求是否对齐无法判定，状态按 unknown 处理。")
    findings, downgraded = _grade(findings)
    if downgraded:
        limitations.append(f"{downgraded} 条问题缺少量化对照证据，已从硬伤降为建议。")
    limitations.append(
        f"送入模型的图片：本品主图 1 张、副图 {len(gallery)} 张、A+ {len(aplus)} 张，"
        f"竞品主图 {len(rivals)} 张（长边不超过 {data.max_side} 像素）。"
    )
    limitations.append("主图白底、分辨率和产品占画面比例由程序按原图像素测量，看图模型不作判断。")

    output = ListingVisualOutput(
        alignment=alignment,
        images=images,
        competitor_mains=competitor_mains,
        strengths={
            section: kept for section, items in strengths.items()
            if (kept := [item for item in items if item.strip()])
        },
        findings=findings,
        failed_images=failed_images,
        limitations=limitations,
    )
    return ok(data=output.model_dump(mode="json"), usage=usage)


# ---------------------------------------------------------------------------
# Inputs and messages
# ---------------------------------------------------------------------------

def _pick_competitors(own_asin: str, competitors: list[CompetitorListing]) -> list[CompetitorListing]:
    """Up to eight distinct competitors with a main image, best group first."""
    picked: dict[str, CompetitorListing] = {}
    for rival in sorted(competitors, key=lambda item: GROUP_PRIORITY.index(item.group)):
        asin = rival.asin.strip().upper()
        if rival.main_image.strip() and asin != own_asin.strip().upper():
            picked.setdefault(asin, rival.model_copy(update={"asin": rival.asin.strip()}))
    return list(picked.values())[:MAX_COMPETITORS]


def _text(value: str) -> dict:
    return {"type": "text", "text": value}


def _image(prepared) -> dict:
    return {"type": "image_url", "image_url": {"url": prepared.data_url}}


def _messages(system: str, content: list[dict]) -> list[dict]:
    return [{"role": "system", "content": system}, {"role": "user", "content": content}]


def _competitor_messages(rivals) -> list[dict]:
    content: list[dict] = []
    for rival, prepared in rivals:
        content.append(_text(f"竞品 {rival.asin}（{GROUP_LABELS[rival.group]}，group={rival.group}）主图："))
        content.append(_image(prepared))
    content.append(_text("请按规则输出 JSON。"))
    return _messages(COMPETITOR_PROMPT, content)


def _facts(data: ListingVisualInput) -> dict:
    listing, demand = data.listing, data.demand
    signals = sorted(demand.signals, key=lambda item: -item.mentioned_by)[:DEMAND_LIMIT]
    # Low-relevance terms only fill the list when nothing better is left.
    keywords = sorted(data.keywords, key=lambda item: (item.relevance == "low", -(item.purchases or 0)))
    return {
        "title": listing.title,
        "bullet_points": [b.strip()[:BULLET_LIMIT] for b in listing.bullet_points if b.strip()],
        "brief": listing.brief.strip() or demand.brief.strip(),
        "demand": {
            "signals": [
                signal.model_dump(include={"kind", "label", "detail", "mentioned_by", "source_asin"})
                for signal in signals
            ],
            "keyword_signals": demand.keyword_signals,
        },
        "keywords": [
            {"term": item.term, "purchases": item.purchases, "relevance": item.relevance}
            for item in keywords[:KEYWORD_LIMIT]
        ],
    }


def _dump(value) -> str:
    return json.dumps(value, ensure_ascii=False)


def _gallery_messages(data, own: dict, competitor_mains: list[CompetitorMainReading]) -> list[dict]:
    content = [
        _text(f"【本品文案与买家事实】\n{_dump(_facts(data))}"),
        _text(
            f"【竞品主图读数】共 {len(competitor_mains)} 个竞品\n"
            f"{_dump([item.model_dump(mode='json') for item in competitor_mains])}"
        ),
    ]
    for image_id, prepared in own.items():
        label = "本品主图" if image_id == "main" else "本品副图"
        content.append(_text(f"{label} {image_id}："))
        content.append(_image(prepared))
    content.append(_text(f"请按规则输出 JSON，images 覆盖这些编号：{'、'.join(own)}。"))
    return _messages(GALLERY_PROMPT, content)


def _aplus_messages(data, aplus: dict, gallery_readings: list[ImageReading]) -> list[dict]:
    summary = [
        item.model_dump(include={"image_id", "role", "people", "scene", "message"})
        for item in gallery_readings
    ]
    content = [
        _text(f"【本品文案与买家事实】\n{_dump(_facts(data))}"),
        _text(f"【主图和副图读数摘要】\n{_dump(summary)}"),
    ]
    for image_id, prepared in aplus.items():
        content.append(_text(f"本品 A+ 图 {image_id}："))
        content.append(_image(prepared))
    content.append(_text(f"请按规则输出 JSON，images 覆盖这些编号：{'、'.join(aplus)}。"))
    return _messages(APLUS_PROMPT, content)


# ---------------------------------------------------------------------------
# Request, validation and merge
# ---------------------------------------------------------------------------

def _add_tokens(usage: dict, tokens) -> None:
    if isinstance(tokens, dict):
        for field in ("prompt_tokens", "completion_tokens", "input_tokens", "output_tokens", "total_tokens"):
            if isinstance(tokens.get(field), int):
                usage[field] = usage.get(field, 0) + tokens[field]


def _request(messages: list[dict], draft_model: type[BaseModel], check: Callable, repair_hint: str,
             model: str, llm_call, usage: dict):
    """One model request with one bounded repair. Returns ``(draft, error)``."""
    for attempt in range(2):
        usage["llm_requests"] += 1
        try:
            response = llm_call(
                messages=messages, json_schema=draft_model.model_json_schema(),
                model=model, temperature=0.2,
            )
        except Exception as exc:
            _add_tokens(usage, getattr(exc, "usage", None))
            return None, f"request failed: {exc}"
        _add_tokens(usage, response.get("usage") if isinstance(response, dict) else None)
        try:
            draft = parse_structured(response, draft_model)
            check(draft)
            return draft, None
        except (ValidationError, AnalysisContractError) as exc:
            if attempt:
                return None, f"invalid result: {exc}"
            previous = response.get("json", {}) if isinstance(response, dict) else {}
            messages = [*messages,
                {"role": "assistant", "content": _dump(previous)},
                {"role": "user", "content": f"校验失败：{exc}\n请修正并返回完整 JSON。{repair_hint}"},
            ]


def _check_ids(label: str, actual: list[str], expected: list[str]) -> None:
    if sorted(actual) != sorted(expected):
        raise AnalysisContractError(f"{label} must contain each of {expected} exactly once, got {actual}")


def _check_competitors(draft: _CompetitorMainsDraft, *, expected: list[str]) -> None:
    _check_ids("mains.asin", [item.asin.upper() for item in draft.mains], [asin.upper() for asin in expected])


# ASINs and image ids contain digits but are not quantities.
_REFERENCE = re.compile(r"(?<![A-Za-z0-9])(?:B0[A-Z0-9]{8}|[ag][1-8])(?![A-Za-z0-9])", re.IGNORECASE)
_ASIN = re.compile(r"(?<![A-Za-z0-9])B0[A-Z0-9]{8}(?![A-Za-z0-9])", re.IGNORECASE)
_RIVAL_RATIO = re.compile(r"(\d+)\s*/\s*(\d+)\s*(?:个|家|款)?\s*竞品")


def _check_review(draft: _GalleryDraft | _AplusDraft, *, expected: list[str], image_ids: set[str],
                  asins: set[str], known_asins: set[str], rival_count: int) -> None:
    _check_ids("images.image_id", [item.image_id for item in draft.images], expected)
    if isinstance(draft, _GalleryDraft) and not draft.alignment.summary.strip():
        raise AnalysisContractError("alignment.summary must not be empty")
    for finding in draft.findings:
        unknown_images = sorted(set(finding.image_ids) - image_ids)
        if unknown_images:
            raise AnalysisContractError(f"finding '{finding.title}' references unknown image ids: {unknown_images}")
        unknown_asins = sorted({asin.strip().upper() for asin in finding.competitor_asins} - asins)
        if unknown_asins:
            raise AnalysisContractError(
                f"finding '{finding.title}' references unknown competitor asins: {unknown_asins}"
            )
        text = "\n".join([finding.current, finding.judgement, finding.fix, *finding.evidence])
        invented = sorted({asin.upper() for asin in _ASIN.findall(text)} - known_asins)
        if invented:
            raise AnalysisContractError(f"finding '{finding.title}' mentions ASINs not in the input: {invented}")
        for hit, total in _RIVAL_RATIO.findall(text):
            if int(total) != rival_count or int(hit) > int(total):
                raise AnalysisContractError(
                    f"finding '{finding.title}' claims {hit}/{total} 个竞品 but {rival_count} competitor "
                    "main image readings were provided; count from the readings"
                )


def _readings(draft: _GalleryDraft | _AplusDraft, prepared: dict) -> list[ImageReading]:
    """Readings in image order, with program-owned source and original size."""
    by_id = {item.image_id: item for item in draft.images}
    readings = []
    for image_id, image in prepared.items():
        source = "main" if image_id == "main" else "gallery" if image_id.startswith("g") else "aplus"
        readings.append(ImageReading(
            **by_id[image_id].model_dump(), source=source,
            original_width=image.original_width, original_height=image.original_height,
        ))
    return readings


def _grade(findings: list[ModelFinding]) -> tuple[list[ModelFinding], int]:
    """Normalise ASINs and keep ``hard`` only where the evidence carries a number."""
    graded, downgraded = [], 0
    for finding in findings:
        item = finding.model_dump()
        item["competitor_asins"] = [asin.strip().upper() for asin in finding.competitor_asins]
        quantified = any(re.search(r"\d", _REFERENCE.sub("", line)) for line in finding.evidence)
        if finding.severity == "hard" and not quantified:
            item["severity"] = "advice"
            downgraded += 1
        graded.append(ModelFinding(**item))
    return graded, downgraded
