"""Public traffic-map dimension and product classification contracts."""
from __future__ import annotations
from pydantic import BaseModel, ConfigDict, Field

class _TrafficModel(BaseModel):
    model_config = ConfigDict(extra="ignore")


class Dimension(_TrafficModel):
    """流量地图维度（一个可枚举的产品属性）。"""

    name: str  # 维度名（如 Material / Use Case）
    values: list[str] = Field(default_factory=list)  # 维度取值列表（可枚举）
    rationale: str = ""  # 选取该维度的理由
    role: str = "llm"  # 维度角色：llm（LLM 原始输出）/ primary_pricing（主定价维度）/ discriminative（判别性正交维度）


class PrimaryDimensionOutput(_TrafficModel):
    """主定价维度发现输出。"""

    primary_pricing_dimension: Dimension  # 解释市场价格差异的主定价维度


class DimensionsOutput(_TrafficModel):
    """正交维度发现输出。"""

    dimensions: list[Dimension] = Field(default_factory=list)  # 与主定价维度正交的判别性维度列表（最多 4 个）


class AsinClassificationOutput(_TrafficModel):
    """单 ASIN 维度打标输出。"""

    classification: dict[str, str] = Field(default_factory=dict)  # 维度名→该 ASIN 所属取值的映射
