"""Contracts for classifying a Taobao search sample by solution."""

from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


Text = Annotated[str, Field(min_length=1)]
ItemId = Annotated[str, Field(pattern=r"^[0-9]+$")]


class TaobaoTitle(BaseModel):
    """Read-only product input. No Entity methods or implicit data loading."""

    model_config = ConfigDict(frozen=True, str_strip_whitespace=True)
    item_id: ItemId
    title: str | None = Field(default=None, max_length=2000)


class TaobaoClassifyInput(BaseModel):
    model_config = ConfigDict(frozen=True, str_strip_whitespace=True)
    term: str = Field(min_length=1, max_length=200)
    products: tuple[TaobaoTitle, ...] = Field(max_length=100)
    model: str = Field(default="pro", min_length=1)

    @model_validator(mode="after")
    def unique_ids(self):
        ids = [product.item_id for product in self.products]
        if len(set(ids)) != len(ids):
            raise ValueError("products must have unique item_id values")
        return self


from amz.schemas.market_summary import (
    TitleEvidence, Context, GroupDraft, SolutionGroup, Unclassified, Classification, MarketSummary,
)


class TaobaoTitleEvidence(TitleEvidence):
    item_id: ItemId


class TaobaoContext(Context):
    evidence: list[TaobaoTitleEvidence]


class TaobaoGroupDraft(GroupDraft):
    product_ids: list[ItemId] = Field(min_length=1)


class TaobaoSolutionGroup(SolutionGroup):
    product_ids: list[ItemId] = Field(min_length=1)
    audiences: list[TaobaoContext]
    scenarios: list[TaobaoContext]
    evidence: list[TaobaoTitleEvidence] = Field(min_length=1)


class TaobaoUnclassified(Unclassified):
    item_id: ItemId


class TaobaoClassification(Classification):
    groups: list[TaobaoGroupDraft]
    unclassified: list[TaobaoUnclassified]


class TaobaoMarketSummary(MarketSummary):
    groups: list[TaobaoSolutionGroup]
    unclassified: list[TaobaoUnclassified]
    input_product_ids: list[ItemId]
