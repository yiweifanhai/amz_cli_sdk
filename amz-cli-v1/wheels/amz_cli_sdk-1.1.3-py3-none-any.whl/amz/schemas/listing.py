"""Public output contracts for Listing editing and allocation."""

from __future__ import annotations
from pydantic import BaseModel, ConfigDict, Field


class _ListingModel(BaseModel):
    model_config = ConfigDict(extra="ignore")


class ListingOutput(_ListingModel):
    """全量 Listing 改写输出。"""

    title: str  # 改写后的标题
    title_differentiation: str = Field(default="", max_length=125)
    bullet_points: list[str] = Field(default_factory=list)  # 改写后的五点描述


class TextInsertionOutput(_ListingModel):
    """单文本微插入输出。"""

    text: str  # 插入后的完整文本
    inserted: list[str] = Field(default_factory=list)  # 实际插入的片段列表


class MicroInsertOutput(_ListingModel):
    """联合契约：兼容完整 Listing 与旧版单文本微插入。"""

    title: str | None = None  # 插入后的标题（完整 Listing 模式）
    title_differentiation: str = Field(default="", max_length=125)
    bullet_points: list[str] = Field(default_factory=list)  # 插入后的五点（完整 Listing 模式）
    text: str | None = None  # 插入后的文本（单文本模式）
    inserted: list[str] = Field(default_factory=list)  # 实际插入的片段列表


class AllocationOutput(_ListingModel):
    """关键词到 Listing 各位置的分配结果。"""

    title: list[str] = Field(default_factory=list)  # 分配给标题的关键词
    bp1: list[str] = Field(default_factory=list)  # 分配给卖点 1 的关键词
    bp2: list[str] = Field(default_factory=list)  # 分配给卖点 2 的关键词
    bp3: list[str] = Field(default_factory=list)  # 分配给卖点 3 的关键词
    bp4: list[str] = Field(default_factory=list)  # 分配给卖点 4 的关键词
    bp5: list[str] = Field(default_factory=list)  # 分配给卖点 5 的关键词
    unassigned: list[str] = Field(default_factory=list)  # 未分配（不建议埋入）的关键词


class PartRewriteOutput(_ListingModel):
    """局部改写输出。"""

    text: str  # 局部改写后的文本
