"""Product VOC 的公共输入、输出模型。"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import (
    AliasChoices,
    BaseModel,
    ConfigDict,
    Field,
    field_validator,
    model_validator,
)


class _StrictModel(BaseModel):
    """VOC 边界模型：字段显式声明，拒绝静默透传未知数据。"""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class ProductVocListing(_StrictModel):
    """产品 VOC 分析所需的最小 Listing 快照。"""

    asin: str | None = Field(default=None, json_schema_extra={"entity_field": "asin"})
    title: str = Field(..., min_length=1, json_schema_extra={"entity_field": "title"})
    bullet_points: list[str] = Field(
        default_factory=list,
        validation_alias=AliasChoices("bullet_points", "features"),
        json_schema_extra={"entity_field": "bullet_points"},
    )
    details: str | list[dict[str, Any]] | dict[str, Any] = Field(
        default="",
        validation_alias=AliasChoices("details", "productDetails"),
        json_schema_extra={"entity_field": "product_details_raw"},
    )
    description: str = Field(
        default="",
        validation_alias=AliasChoices("description", "productDescription"),
        json_schema_extra={"entity_field": "description"},
    )
    brand: str | None = Field(default=None, json_schema_extra={"entity_field": "brand"})
    product_rating: float | None = Field(
        default=None,
        validation_alias=AliasChoices("product_rating", "productRating", "rating"),
        json_schema_extra={"entity_field": "rating"},
    )
    count_ratings: int | None = Field(
        default=None,
        ge=0,
        validation_alias=AliasChoices(
            "count_ratings", "countRatings", "count_review", "countReview"
        ),
        json_schema_extra={"entity_field": "count_review"},
    )

    @field_validator("product_rating", mode="before")
    @classmethod
    def _parse_product_rating(cls, value: Any) -> Any:
        if value in (None, ""):
            return None
        try:
            return float(str(value).split()[0])
        except (TypeError, ValueError, IndexError):
            return value


class ProductVocReview(_StrictModel):
    """单条评论快照；ID 和正文必须由取数层明确提供。"""

    review_id: str = Field(
        ...,
        validation_alias=AliasChoices("review_id", "reviewId"),
        json_schema_extra={"entity_field": "review_id"},
    )
    text: str = Field(
        ...,
        validation_alias=AliasChoices("text", "body"),
        json_schema_extra={"entity_field": "text"},
    )
    rating: float | None = Field(
        default=None,
        ge=1,
        le=5,
        json_schema_extra={"entity_field": "rating"},
    )
    title: str = Field(default="", json_schema_extra={"entity_field": "title"})
    date: str | None = Field(default=None, json_schema_extra={"entity_field": "date"})
    country: str = ""
    verified: bool = Field(default=False, json_schema_extra={"entity_field": "verified"})
    user_name: str = Field(default="", json_schema_extra={"entity_field": "user_name"})
    images: list[str] = Field(default_factory=list, json_schema_extra={"entity_field": "images"})

    @field_validator("rating", mode="before")
    @classmethod
    def _parse_rating(cls, value: Any) -> Any:
        if value in (None, ""):
            return None
        try:
            return float(str(value).split()[0])
        except (TypeError, ValueError, IndexError):
            return value


class ReviewStarShare(_StrictModel):
    """单个星级在全量评分中的占比。"""

    percentage: float = Field(default=0, ge=0, le=100)
    count: int | None = Field(default=None, ge=0)

    @model_validator(mode="before")
    @classmethod
    def _accept_scalar_percentage(cls, value: Any) -> Any:
        if isinstance(value, (int, float, str)):
            return {"percentage": value}
        return value

    @field_validator("percentage", mode="before")
    @classmethod
    def _parse_percentage(cls, value: Any) -> Any:
        if isinstance(value, str):
            return value.strip().rstrip("%") or 0
        return value


class ReviewSummary(_StrictModel):
    """全量星级分布，兼容 Amazon 的 ``fiveStar`` 等字段名。"""

    five_star: ReviewStarShare = Field(
        default_factory=ReviewStarShare,
        validation_alias=AliasChoices("five_star", "fiveStar"),
        serialization_alias="fiveStar",
    )
    four_star: ReviewStarShare = Field(
        default_factory=ReviewStarShare,
        validation_alias=AliasChoices("four_star", "fourStar"),
        serialization_alias="fourStar",
    )
    three_star: ReviewStarShare = Field(
        default_factory=ReviewStarShare,
        validation_alias=AliasChoices("three_star", "threeStar"),
        serialization_alias="threeStar",
    )
    two_star: ReviewStarShare = Field(
        default_factory=ReviewStarShare,
        validation_alias=AliasChoices("two_star", "twoStar"),
        serialization_alias="twoStar",
    )
    one_star: ReviewStarShare = Field(
        default_factory=ReviewStarShare,
        validation_alias=AliasChoices("one_star", "oneStar"),
        serialization_alias="oneStar",
    )
    total_reviews: int | None = Field(
        default=None,
        ge=0,
        validation_alias=AliasChoices(
            "total_reviews", "totalReviews", "count_ratings", "countRatings"
        ),
        serialization_alias="countRatings",
    )

    @model_validator(mode="before")
    @classmethod
    def _unwrap_review_summary(cls, value: Any) -> Any:
        if isinstance(value, dict):
            nested = value.get("reviewSummary") or value.get("review_summary")
            if isinstance(nested, dict):
                merged = dict(nested)
                for key in ("countRatings", "count_ratings", "totalReviews", "total_reviews"):
                    if key in value and not any(
                        name in merged
                        for name in ("countRatings", "count_ratings", "totalReviews", "total_reviews")
                    ):
                        merged[key] = value[key]
                return merged
        return value


RatingLabel = Literal["高满意度", "中等满意度", "低满意度", "未知评分"]


class VocSatisfactionMetrics(_StrictModel):
    """由 Calc 生成的确定性满意度指标。"""

    positive_pct: int | None = Field(ge=0, le=100, description="全量好评率；未提供全量分布时为 null")
    negative_pct: int | None = Field(ge=0, le=100, description="全量差评率；未提供全量分布时为 null")
    total_reviews: int = Field(ge=0)
    product_rating: float | None = Field(default=None, ge=1, le=5)
    rating_label: RatingLabel


class VocSatisfactionContext(VocSatisfactionMetrics):
    """弱点分析输出中的满意度背景。"""

    product_rating: float | None = Field(default=None, ge=1, le=5)
    rating_label: RatingLabel = "未知评分"
    assessment: str


class InnovationAdvantage(_StrictModel):
    innovation_summary: str
    detail: str
    innovation_type: str
    user_validated: bool | None = None
    user_evidence: str = ""


class VocStrengthsOutput(_StrictModel):
    summary: str
    innovation_and_competitive_advantages: list[InnovationAdvantage]

    @classmethod
    def empty(cls) -> "VocStrengthsOutput":
        return cls(summary="", innovation_and_competitive_advantages=[])


class VocIssue(_StrictModel):
    pain_point: str
    severity: Literal["High", "Medium", "Low"]
    evidence: str
    cnt: int = Field(ge=0)
    total_referenced: int = Field(default=0, ge=0)
    ratio: str
    issue_type: Literal["Structural", "Quality", "Instructional"]
    dialectical_note: str


class UnmetNeed(_StrictModel):
    unmet_need: str
    impact: Literal["High", "Medium", "Low"]
    description: str
    evidence: str
    cnt: int = Field(ge=0)
    total_referenced: int = Field(default=0, ge=0)
    ratio: str


class VocWeaknessSignalsOutput(_StrictModel):
    """弱点语义原子的输出，不重新计算满意度指标。"""

    satisfaction_assessment: str
    top_issues: list[VocIssue]
    unmet_needs: list[UnmetNeed]
    balanced_assessment: str


class VocWeaknessesOutput(_StrictModel):
    satisfaction_context: VocSatisfactionContext
    top_issues: list[VocIssue]
    unmet_needs: list[UnmetNeed]
    balanced_assessment: str

    @classmethod
    def empty(
        cls,
        satisfaction: VocSatisfactionMetrics | None = None,
    ) -> "VocWeaknessesOutput":
        metrics = satisfaction or VocSatisfactionMetrics(
            positive_pct=None,
            negative_pct=None,
            total_reviews=0,
            product_rating=None,
            rating_label="未知评分",
        )
        return cls(
            satisfaction_context=VocSatisfactionContext(
                **metrics.model_dump(),
                assessment="无评论数据",
            ),
            top_issues=[],
            unmet_needs=[],
            balanced_assessment="",
        )


class UseScenario(_StrictModel):
    scenario: str
    frequency: Literal["高频", "中频", "低频"]
    evidence: str
    mentioned_by: int = Field(ge=0)


class UserPersona(_StrictModel):
    persona: str
    traits: str
    evidence: str
    mentioned_by: int = Field(ge=0)


class PurchaseMotivation(_StrictModel):
    motivation: str
    decision_factor_type: Literal[
        "功能需求", "价格敏感", "外观设计", "品牌信任",
        "礼品需求", "替代升级", "推荐种草", "其他",
    ]
    evidence: str
    mentioned_by: int = Field(ge=0)


class VocUseInsightsOutput(_StrictModel):
    use_scenarios: list[UseScenario]
    user_personas: list[UserPersona]
    purchase_motivations: list[PurchaseMotivation]

    @classmethod
    def empty(cls) -> "VocUseInsightsOutput":
        return cls(
            use_scenarios=[],
            user_personas=[],
            purchase_motivations=[],
        )


class ProductVoc(_StrictModel):
    """单个产品的三路 VOC 原子分析结果。"""

    strengths: VocStrengthsOutput
    weaknesses: VocWeaknessesOutput
    use_insights: VocUseInsightsOutput


class VocSatisfactionInput(_StrictModel):
    """``calc.voc.satisfaction`` 输入。"""

    reviews: list[ProductVocReview] = Field(default_factory=list)
    review_summary: ReviewSummary | None = None
    star_ratios: ReviewSummary | None = None
    total_reviews: int | None = Field(default=None, ge=0)
    product_rating: float | str | None = None


class VocStrengthsAnalysisInput(_StrictModel):
    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
        json_schema_extra={"entity_source": "product"},
    )

    product_info: ProductVocListing


class VocWeaknessSignalsInput(_StrictModel):
    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
        json_schema_extra={"entity_source": "product"},
    )

    product_info: ProductVocListing
    reviews: list[ProductVocReview] = Field(
        ..., json_schema_extra={"projection": "_project_voc_reviews"}
    )
    satisfaction: VocSatisfactionMetrics


class VocUseInsightsAnalysisInput(_StrictModel):
    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
        json_schema_extra={"entity_source": "product"},
    )

    product_info: ProductVocListing
    reviews: list[ProductVocReview] = Field(
        ..., json_schema_extra={"projection": "_project_voc_reviews"}
    )


class _VocModel(BaseModel):
    model_config = ConfigDict(extra="ignore")


class ValuePerception(_VocModel):
    """价值感知（用户对性价比的整体评价）。"""

    overall_sentiment: str = "信息不足"  # 整体情感（超值/物有所值/偏贵但不后悔/信息不足）
    summary: str = ""  # 一句话概括性价比整体评价
    evidence: list[str] = Field(default_factory=list)  # 原文证据摘录列表
    mentioned_by: int = 0  # 提及用户数


class VocPraiseOutput(_VocModel):
    """好评赞美分析输出。"""

    loved_features: list[dict] = Field(default_factory=list)  # 被称赞的功能列表 {feature, enthusiasm, evidence, mentioned_by}
    delight_factors: list[dict] = Field(default_factory=list)  # 超出预期的惊喜点 {delight, category, evidence, mentioned_by}
    value_perception: ValuePerception = Field(default_factory=ValuePerception)  # 价值感知
    durability_signals: list[dict] = Field(default_factory=list)  # 耐用性信号 {observation, usage_duration, evidence, mentioned_by}
    competitive_mentions: list[dict] = Field(default_factory=list)  # 竞品提及 {competitor_name, comparison_result, win_reason, evidence, mentioned_by}
    feature_satisfaction_ranking: list[dict] = Field(default_factory=list)  # 功能满意度排名 {feature, praise_count, representative_quote}


class VocWishlistOutput(_VocModel):
    """愿望清单输出（用户渴望的新功能/变体/配件）。"""

    feature_requests: list[dict] = Field(default_factory=list)  # 新功能请求 {request, source_type, feasibility, evidence, mentioned_by}
    improvement_suggestions: list[dict] = Field(default_factory=list)  # 现有功能改进建议 {target_feature, suggestion, evidence, mentioned_by}
    variant_requests: list[dict] = Field(default_factory=list)  # 变体需求（新颜色/尺寸/规格等） {variant, evidence, mentioned_by}
    accessory_requests: list[dict] = Field(default_factory=list)  # 配件需求 {accessory, evidence, mentioned_by}
