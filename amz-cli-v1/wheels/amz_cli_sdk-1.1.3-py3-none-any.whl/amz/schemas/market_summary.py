"""Shared contracts for title-based market solution summaries."""
from typing import Annotated, Literal
from pydantic import BaseModel, ConfigDict, Field

Text = Annotated[str, Field(min_length=1)]


class ProductTitle(BaseModel):
    model_config = ConfigDict(frozen=True, str_strip_whitespace=True)
    item_id: Text
    title: str | None = Field(default=None, max_length=2000)


class _Output(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class TitleEvidence(_Output):
    item_id: Text
    quote: Text


class Context(_Output):
    label: Text
    basis: Literal["title", "inference"]
    evidence: list[TitleEvidence]


class GroupDraft(_Output):
    name: Text
    summary: Text
    solution: Text
    audiences: list[Text]
    scenarios: list[Text]
    product_ids: list[Text] = Field(min_length=1)
    unknowns: list[Text]


class SolutionGroup(GroupDraft):
    audiences: list[Context]
    scenarios: list[Context]
    evidence: list[TitleEvidence] = Field(min_length=1)


class Unclassified(_Output):
    item_id: Text
    reason: Text


class Classification(_Output):
    """The semantic task's model output, before coverage validation."""

    summary: Text
    groups: list[GroupDraft]
    unclassified: list[Unclassified]


class MarketSummary(Classification):
    groups: list[SolutionGroup]
    term: Text
    input_product_ids: list[Text]
    basis: Literal["titles_only"] = "titles_only"
    limitations: list[Text]
