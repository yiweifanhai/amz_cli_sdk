"""Small public models for Taobao search samples."""
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, field_validator


class TaobaoItem(BaseModel):
    item_id: str = Field(pattern=r"^[0-9]+$")
    title: str | None = None
    image_url: str | None = None
    url: str | None = None


class TaobaoSearch(BaseModel):
    keyword: str
    source: str = "onebound.item_search"
    page: Literal[1] = 1
    collected_at: str
    products: list[TaobaoItem]
    skipped_count: int = 0


class TaobaoProductRef(BaseModel):
    model_config = ConfigDict(frozen=True)
    entity_type: Literal["taobao_product"] = "taobao_product"
    key: tuple[Literal["CN"], str]

    @field_validator("key")
    @classmethod
    def valid_key(cls, value):
        TaobaoItem(item_id=value[1])
        return value


def taobao_product_ref(item_id: str) -> TaobaoProductRef:
    """Single factory for Taobao product references."""
    return TaobaoProductRef(key=("CN", item_id))


class TaobaoSample(BaseModel):
    source: str = "onebound.item_search"
    page: Literal[1] = 1
    collected_at: str
    product_refs: list[TaobaoProductRef]
    skipped_count: int = 0
