"""Canonical, immutable business identities and local field cache contracts."""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


def normalize_marketplace(value: str) -> str:
    value = unicodedata.normalize("NFKC", str(value)).strip().upper()
    if not re.fullmatch(r"[A-Z]{2}", value):
        raise ValueError("marketplace must be a two-letter code")
    return value


def normalize_asin(value: str) -> str:
    value = unicodedata.normalize("NFKC", str(value)).strip().upper()
    if not re.fullmatch(r"[A-Z0-9]+", value):
        raise ValueError("asin must contain letters and digits")
    return value


def normalize_category(value: str | None) -> str:
    return unicodedata.normalize("NFKC", str(value or "")).strip()


def normalize_term(value: str) -> str:
    value = " ".join(unicodedata.normalize("NFKC", str(value)).split()).casefold()
    if not value:
        raise ValueError("term must not be empty")
    return value


class EntityRef(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    entity_type: Literal["product", "keyword", "market"]
    key: tuple[str, ...]

    @model_validator(mode="after")
    def normalize(self):
        expected = 2 if self.entity_type == "product" else 3
        if len(self.key) != expected:
            raise ValueError(f"{self.entity_type} identity needs {expected} parts")
        if self.entity_type == "product":
            key = (normalize_marketplace(self.key[0]), normalize_asin(self.key[1]))
        else:
            key = (normalize_marketplace(self.key[0]), normalize_category(self.key[1]), normalize_term(self.key[2]))
        object.__setattr__(self, "key", key)
        return self

    @property
    def cache_id(self) -> str:
        return json.dumps(self.key, ensure_ascii=False, separators=(",", ":"))

    @property
    def file_id(self) -> str:
        raw = json.dumps(self.model_dump(mode="json"), ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    @property
    def identity(self) -> dict[str, str]:
        names = ("marketplace", "asin") if self.entity_type == "product" else ("marketplace", "category", "term")
        return dict(zip(names, self.key))


def product_ref(marketplace: str, asin: str) -> EntityRef:
    return EntityRef(entity_type="product", key=(marketplace, asin))


def keyword_ref(marketplace: str, category: str, term: str) -> EntityRef:
    return EntityRef(entity_type="keyword", key=(marketplace, category, term))


def market_ref(marketplace: str, category: str, term: str) -> EntityRef:
    return EntityRef(entity_type="market", key=(marketplace, category, term))


class FieldCache(BaseModel):
    model_config = ConfigDict(extra="forbid")
    state: Literal["ready", "missing", "failed"] = "ready"
    error: str | None = None
    updated_at: str | None = None
    last_params: dict[str, Any] = Field(default_factory=dict)
    fetch_key: str | None = None
    version: str | None = None
    provided: bool = False
    value: Any = None

    @field_validator("updated_at", mode="before")
    @classmethod
    def normalize_time(cls, value):
        return value.isoformat() if isinstance(value, datetime) else value


class EntityFieldMeta(BaseModel):
    ref: EntityRef
    field_name: str
    state: str
    updated_at: str | None = None
    ttl_valid: bool = False
    last_params: dict[str, Any] = Field(default_factory=dict)
    fetch_key: str | None = None
    version: str | None = None
    error: str | None = None


class EntityLoadError(BaseModel):
    ref: EntityRef
    error: str
