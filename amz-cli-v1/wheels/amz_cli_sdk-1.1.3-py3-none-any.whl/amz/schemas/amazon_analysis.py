"""Amazon input identity and public market-summary contracts."""
from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from amz.schemas.market_summary import (
    Context, MarketSummary, SolutionGroup, TitleEvidence, Unclassified,
)

Asin = Annotated[str, Field(pattern=r"^[A-Z0-9]{10}$")]


class AmazonTitle(BaseModel):
    model_config = ConfigDict(frozen=True, str_strip_whitespace=True)
    asin: Asin
    title: str | None = Field(default=None, max_length=2000)

    @field_validator("asin", mode="before")
    @classmethod
    def normalize_asin(cls, value):
        return value.strip().upper() if isinstance(value, str) else value


class AmazonClassifyInput(BaseModel):
    model_config = ConfigDict(frozen=True, str_strip_whitespace=True)
    term: str = Field(min_length=1, max_length=200)
    products: tuple[AmazonTitle, ...] = Field(max_length=200)
    model: str = Field(default="pro", min_length=1)

    @model_validator(mode="after")
    def unique_asins(self):
        asins = [product.asin for product in self.products]
        if len(set(asins)) != len(asins):
            raise ValueError("products must have unique ASINs")
        return self


class AmazonTitleEvidence(TitleEvidence):
    item_id: Asin = Field(description="原始 Amazon ASIN")


class AmazonContext(Context):
    evidence: list[AmazonTitleEvidence]


class AmazonSolutionGroup(SolutionGroup):
    product_ids: list[Asin] = Field(min_length=1, description="本类商品的 ASIN 列表")
    audiences: list[AmazonContext]
    scenarios: list[AmazonContext]
    evidence: list[AmazonTitleEvidence] = Field(min_length=1)


class AmazonUnclassified(Unclassified):
    item_id: Asin = Field(description="未分类商品的 ASIN")


class AmazonMarketSummary(MarketSummary):
    groups: list[AmazonSolutionGroup]
    unclassified: list[AmazonUnclassified]
    input_product_ids: list[Asin] = Field(description="完整输入的 ASIN 列表")
