"""
data/calc 层能力的输出模型（JSON Schema 声明）。

字段以 ``data/normalizer.py`` 产出的标准字段为准；未知/未映射字段由
``extra="allow"`` 透传，不参与校验。模型仅用于生成 harness 可见的 schema。
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator


class _Loose(BaseModel):
    """允许任意额外字段的基类（输出声明只描述已知形状）。"""

    model_config = ConfigDict(extra="allow")


# ---------------------------------------------------------------------------
# product.*
# ---------------------------------------------------------------------------


class ProductInfoOutput(_Loose):
    """``product.get`` 输出：标准化后的 product-info 详情。"""

    asin: str = Field(default="", description="ASIN")
    title: str = Field(default="", description="商品标题")
    brand: str = Field(default="", description="品牌")
    price_usd: float | None = Field(default=None, description="当前售价（USD）")
    rating: float | None = Field(default=None, description="评分（0-5）")
    count_review: int | None = Field(default=None, description="评论数")
    bullet_points: list[str] = Field(default_factory=list, description="五点描述")
    images: list[str] = Field(default_factory=list, description="图片 URL 列表")
    description: str | None = Field(default=None, description="商品描述")
    categories: list[str] = Field(default_factory=list, description="类目路径")
    variations: list[dict[str, Any]] = Field(default_factory=list, description="变体列表")
    bsr: dict[str, Any] | None = Field(default=None, description="BSR {rank, category}")
    dimensions_cm: dict[str, Any] | None = Field(default=None, description="包装尺寸（cm）")
    weight_g: float | None = Field(default=None, description="包装重量（g）")
    listing_date: str | None = Field(default=None, description="上架日期（ISO）")
    retail_price: float | None = Field(default=None, description="划线价（USD）")
    product_details_raw: list[dict[str, Any]] = Field(default_factory=list, description="原始 productDetails 列表")
    categories_extended: list[dict[str, Any]] = Field(default_factory=list, description="完整类目树")


class ReviewItemOutput(_Loose):
    """单条评论。"""

    review_id: str = Field(default="")
    rating: int | None = Field(default=None, description="星级（1-5）")
    title: str = Field(default="")
    text: str = Field(default="")
    date: str | None = Field(default=None, description="评论日期")
    verified: bool = Field(default=False, description="是否已购验证")
    user_name: str = Field(default="")
    images: list[str] = Field(default_factory=list)


class ReviewsOutput(_Loose):
    """``product.reviews`` 输出。"""

    asin: str = Field(default="")
    items: list[ReviewItemOutput] = Field(default_factory=list)
    mode: str = Field(default="mid")
    star_filter: str = Field(default="all")
    count: int = Field(default=0)
    count_ratings: int | None = Field(default=None, description="商品全量评分数")
    rating: float | None = Field(default=None, description="商品综合评分")
    review_summary: dict[str, Any] = Field(
        default_factory=dict,
        description="上游全量星级分布，不是抽样评论分布",
    )
    star_counts: dict[str, int] = Field(
        default_factory=dict,
        description="已抽样评论的 1-5 星实际数量",
    )


class RufusOutput(_Loose):
    """``product.rufus`` 输出：Rufus AI 问答。"""

    asin: str = Field(default="")
    rufus: list[str] = Field(default_factory=list, description="问答文本列表")


class RefinementsOutput(_Loose):
    """``product.refinements`` 输出：搜索筛选维度（上游透传）。"""

    keyword: str = Field(default="")
    refinements: list[dict[str, Any]] = Field(default_factory=list)


class ProductSearchOutput(_Loose):
    """``product.search`` 输出：关键词搜索结果（上游透传）。"""

    keyword: str = Field(default="")
    items: list[dict[str, Any]] = Field(default_factory=list)


class NrPageOutput(_Loose):
    """``product.nr-page`` 输出：New Releases 榜单页解析结果（上游透传）。"""

    url: str = Field(default="")
    items: list[dict[str, Any]] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# market.*
# ---------------------------------------------------------------------------


class CompetingItemOutput(_Loose):
    """competing-lookup 标准化后的单个竞品项。"""

    asin: str = Field(default="")
    title: str = Field(default="")
    price_usd: float | None = Field(default=None)
    monthly_sales: int | None = Field(default=None, description="月销量")
    rating: float | None = Field(default=None)
    count_review: int | None = Field(default=None)
    available_date: str | None = Field(default=None)
    brand: str | None = Field(default=None)
    seller_nation: str | None = Field(default=None)
    fba_fee: float | None = Field(default=None)
    bsr: dict[str, Any] | None = Field(default=None)
    bsr_rank: int | None = Field(default=None)
    categories: list[str] = Field(default_factory=list)
    category_name: str | None = Field(default=None)
    image_url: str | None = Field(default=None)
    weight_g: float | None = Field(default=None)
    dimensions_cm: dict[str, Any] | None = Field(default=None)

    @field_validator("categories", mode="before")
    @classmethod
    def _accept_legacy_category_path(cls, value: Any) -> list[str]:
        """兼容旧缓存/直调中尚未标准化的冒号分隔类目路径。"""
        if value in (None, ""):
            return []
        if isinstance(value, str):
            return [part.strip() for part in value.split(":") if part.strip()]
        if isinstance(value, (list, tuple)):
            categories: list[str] = []
            for item in value:
                if isinstance(item, str) and item.strip():
                    categories.append(item.strip())
                elif isinstance(item, dict):
                    label = item.get("name") or item.get("label")
                    if label not in (None, ""):
                        categories.append(str(label).strip())
            return categories
        return []


class CompetitorsOutput(_Loose):
    """``market.competitors`` 输出。"""

    items: list[CompetingItemOutput] = Field(default_factory=list)
    total: int = Field(default=0)


class SnapshotOutput(_Loose):
    """``market.snapshot`` 输出：降级为竞品原始数据 + keyword。"""

    keyword: str = Field(default="")
    items: list[CompetingItemOutput] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# keyword.*
# ---------------------------------------------------------------------------


class KeywordReverseItemOutput(_Loose):
    """keyword-reverse 标准化后的单个关键词项。"""

    term: str = Field(default="")
    search_volume: int | None = Field(default=None)
    traffic_pct: float | None = Field(default=None, description="流量占比（%）")
    natural_ratio: float | None = Field(default=None, description="自然占比（%）")
    ad_ratio: float | None = Field(default=None, description="广告占比（%）")
    rank: int | None = Field(default=None)
    ppc: float | None = Field(default=None)
    trend: list[dict[str, Any]] | None = Field(default=None)


class KeywordReverseOutput(_Loose):
    """``keyword.reverse`` 输出。"""

    asin: str = Field(default="")
    items: list[KeywordReverseItemOutput] = Field(default_factory=list)


class PrimaryKeywordItemOutput(_Loose):
    """``calc.keyword.primary`` 的单个主力词；百分比统一为 0-100。"""

    term: str
    keyword_cn: str = Field(default="")
    search_volume: int = Field(default=0)
    traffic_pct: float = Field(default=0)
    purchase_rate: float = Field(default=0)
    cvr: float = Field(default=0)
    cpa: float = Field(default=0)
    ppc: float = Field(default=0)
    top3_clicking_rate: float = Field(default=0)
    top3_conversion_rate: float = Field(default=0)
    trend: list[dict[str, Any]] = Field(default_factory=list)
    rank: str = Field(default="")
    types: list[str] = Field(default_factory=list)
    natural_ratio: float = Field(default=0)
    synonyms: list[str] = Field(default_factory=list)
    reasons: list[str] = Field(default_factory=list)


class PrimaryKeywordAnalysisOutput(_Loose):
    total_traffic_pct: float
    avg_ppc: float
    competition: str
    avg_natural_ratio: float
    health: str


class PrimaryKeywordsOutput(_Loose):
    """``calc.keyword.primary`` 输出。"""

    primary_keywords: list[PrimaryKeywordItemOutput]
    analysis: PrimaryKeywordAnalysisOutput


class KeywordMinerItemOutput(_Loose):
    """keyword-miner 标准化后的单个关键词项。"""

    term: str = Field(default="")
    search_volume: int | None = Field(default=None)
    ppc: float | None = Field(default=None)
    click_rate: float | None = Field(default=None, description="点击率（%）")
    conversion_rate: float | None = Field(default=None, description="转化率（%）")
    top3_asins: list[str] = Field(default_factory=list)


class KeywordMinerOutput(_Loose):
    """``keyword.miner`` 输出。"""

    keyword: str = Field(default="")
    items: list[KeywordMinerItemOutput] = Field(default_factory=list)


class KeywordTrendsOutput(_Loose):
    """``keyword.trends`` 输出：趋势时间序列。"""

    keyword: str = Field(default="")
    points: list[dict[str, Any]] = Field(default_factory=list, description="[{date, value}...]")


# ---------------------------------------------------------------------------
# category.* / supply.* / ads.* / search.*
# ---------------------------------------------------------------------------


class CategoryTreeOutput(_Loose):
    """``category.tree`` 输出（上游透传）。"""

    type: str = Field(default="")
    nodes: list[dict[str, Any]] = Field(default_factory=list)


class CategorySearchOutput(_Loose):
    """``category.search`` 输出（上游透传）。"""

    items: list[dict[str, Any]] = Field(default_factory=list)


class SupplySearchOutput(_Loose):
    """``supply.search-1688`` 输出：Top50 相似度排序的供应商列表。"""

    asin: str = Field(default="")
    items: list[dict[str, Any]] = Field(default_factory=list)


class AdsFunnelItemOutput(_Loose):
    """SIF 单个关键词；广告成本保留各策略的区间，不选取任意单值。"""

    term: str = Field(min_length=1)
    search_volume: int | None = Field(default=None, ge=0)
    clicks: int | None = Field(default=None, ge=0)
    purchases: int | None = Field(default=None, ge=0)
    cpc: float | dict[str, Any] | None = Field(
        default=None, description="CPC 单值或上游按策略/类目分组的 start/median/end 区间"
    )
    cpa: float | dict[str, Any] | None = Field(
        default=None, description="CPA 单值或上游按策略分组的 start/median/end 区间"
    )
    acos: float | dict[str, Any] | None = Field(
        default=None, description="ACOS 单值或上游按策略分组的 start/median/end 区间"
    )
    period: str | None = Field(
        default=None, description="该词统计周期，依次采用记录的 period、记录的 weekDate、响应的 weekDate"
    )


class AdsFunnelOutput(_Loose):
    """``ads.keyword-funnel`` 输出：SIF 关键词流量漏斗。"""

    items: list[AdsFunnelItemOutput] = Field(description="本次响应中全部关键词的标准字段")
    total_search_volume: int | None = Field(
        default=None,
        description="仅为返回 items 的搜索量之和；有缺失值或混合统计周期时为 null，不代表全部分页或市场总量",
    )
    keywords: list[dict[str, Any]] = Field(description="完整保留本次响应的原始关键词记录")
    weekDate: str | None = Field(default=None, description="上游响应的统计周日期，原样保留")


class WebSearchOutput(_Loose):
    """``search.web`` 输出（上游透传）。"""

    query: str = Field(default="")
    items: list[dict[str, Any]] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# calc.* 输出
# ---------------------------------------------------------------------------


class CalcCosmoMergeOutput(_Loose):
    """``calc.cosmo.merge`` 输出：跨 ASIN COSMO 确定性合并。"""

    terms: list[dict[str, Any]] = Field(default_factory=list, description="[{term, cosmo_category, cosmo_field, count, weighted_score, asins}...]")


class DemandScoreOutput(_Loose):
    """``calc.demand.score`` 输出：需求分与红蓝海判定。"""

    block: str
    score: int
    stop: bool
    stop_reason: str | None = None
    score_breakdown: dict[str, Any]
    data: dict[str, Any]


class MarketStatsOutput(_Loose):
    """``calc.market.stats`` 输出。"""

    price: dict[str, Any]
    rating: dict[str, Any]
    listing_date: dict[str, Any]
    reviews: dict[str, Any]
    monopoly: dict[str, Any]
    sellers: dict[str, Any]
    aplus_video_pct: float | None = None
    return_rate: dict[str, Any] | None = None


class MarketProfileOutput(_Loose):
    """``calc.market.profile`` 输出。"""

    keyword: str
    dimensions: dict[str, Any]
    overall_score: float


class MarketOpportunityOutput(_Loose):
    """``calc.market.opportunity`` 输出。"""

    keyword: str
    opportunity_score: float
    gaps: list[dict[str, Any]]
    proposals: list[dict[str, Any]]


class KeywordGapOutput(_Loose):
    """``calc.keyword.gap`` 输出：S/A 关键词覆盖检查。"""

    covered: list[dict[str, Any]] = Field(default_factory=list, description="[{keyword, grade, found_in:[title|bp1..bp5]}...]")
    missing: list[dict[str, Any]] = Field(default_factory=list, description="[{keyword, grade}...]")


class WordDiffOutput(_Loose):
    """``calc.listing.word-diff`` 输出：LCS word diff 段。"""

    segments: list[dict[str, Any]] = Field(default_factory=list, description="[{text, type: equal|added|removed}...]")


class MaterialEligibilityOutput(_Loose):
    """``calc.material.eligibility`` 输出：材质可开发性门槛判定。"""

    material_passed: bool = Field(default=False)
    material_fail_reason: str = Field(default="")


class TrafficCodeOutput(_Loose):
    """``calc.traffic.code-dimensions`` 输出：价格带/评分带/品牌来源打标。"""

    price_band: str = Field(default="")
    rating_band: str = Field(default="")
    brand_origin: str = Field(default="")


class FeeOutput(_Loose):
    """``calc.fba.fee`` 输出：US FBA 配送费明细。"""

    fee_usd: float = Field(default=0)
    base_fee_usd: float = Field(default=0)
    fuel_surcharge_usd: float = Field(default=0)
    fuel_surcharge_rate_pct: float = Field(default=0)
    size_tier: str = Field(default="")
    weight_used_g: float = Field(default=0)
    unit_weight_g: float = Field(default=0)
    dimensional_weight_g: float = Field(default=0)
    tier_weight_g: float = Field(default=0)
    is_oversized: bool = Field(default=False)
    is_overmax: bool = Field(default=False)
    category: str = Field(default="")
    price_band: str = Field(default="")
    season: str = Field(default="")
    fulfillment_date: str = Field(default="")
    rate_year: int = Field(default=2026)


class MarginOutput(_Loose):
    """``calc.fba.margin`` 输出：毛利率（含 M1/M2 分层利润）。"""

    referral_fee: float = Field(default=0)
    fba_fee: float = Field(default=0)
    shipping_cost: float = Field(default=0)
    purchase_price: float = Field(default=0)
    total_cost: float = Field(default=0)
    gross_profit: float = Field(default=0)
    gross_margin_pct: float = Field(default=0)
    break_even_price: float = Field(default=0)
    m1_margin_pct: float | None = Field(default=None)
    m2_margin_pct: float | None = Field(default=None)
    cpa: float | None = Field(default=None)
    cpc: float | None = Field(default=None)
    cvr: float | None = Field(default=None)


class ReturnOnCapitalOutput(_Loose):
    """``calc.finance.return-on-capital`` 输出：资金效率指标。"""

    shipping_cost: float = Field(default=0)
    capital_per_unit: float = Field(default=0)
    profit_per_unit: float = Field(default=0)
    roi_pct: float = Field(default=0)
    daily_return_pct: float = Field(default=0)
