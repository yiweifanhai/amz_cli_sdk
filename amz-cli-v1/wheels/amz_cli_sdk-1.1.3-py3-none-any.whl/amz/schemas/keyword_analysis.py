"""Public result models for keyword analysis."""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class _AnalysisModel(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)


class RelevanceItem(_AnalysisModel):
    """单个关键词与产品的语义相关性判断。"""

    keyword: str  # 关键词
    match: Literal["perfect", "high", "partial", "low", "unknown"] = "unknown"
    reason: str = ""  # 判断理由


class RelevanceOutput(_AnalysisModel):
    """相关性判断输出。"""

    results: list[RelevanceItem] = Field(default_factory=list)  # 各关键词判断结果


class DimensionScores(_AnalysisModel):
    """四维评分（均 1-10）。"""

    relevance: float  # 相关性分
    traffic: float  # 流量分（搜索量/曝光加权）
    conversion: float  # 转化分（购买率/CVR/购买量加权）
    competition: float  # 竞争友好度分（分数越高=竞争越低=越好）


class ScoredKeyword(_AnalysisModel):
    """单个关键词的综合评分。"""

    keyword: str  # 关键词
    score: float = Field(ge=0, le=10)  # 综合分 0-10（四维加权 + 趋势调整）
    grade: Literal["S", "A", "B", "C"]  # 等级（S≥8 / A≥6 / B≥4 / C<4）
    dimension_scores: DimensionScores  # 四维分项
    trend_adjustment: float = 0  # 趋势调整值（正加负减）
    match_level: Literal["perfect", "high", "partial", "low", "unknown"] = "unknown"
    reason: str = ""  # 评分理由


class KeywordScoreOutput(_AnalysisModel):
    """关键词评分批量输出。"""

    scored_keywords: list[ScoredKeyword] = Field(default_factory=list)  # 评分结果列表
    total_count: int = 0  # 关键词总数
    grade_distribution: dict[str, int] = Field(default_factory=dict)  # 等级分布（如 {"S": 3, "A": 5}）
    average_score: float = 0  # 平均综合分


class GapKeyword(_AnalysisModel):
    """覆盖检查中的单个关键词（仅 S/A 级）。"""

    keyword: str  # 关键词
    grade: Literal["S", "A"]  # 等级（仅统计 S/A 级核心词）
    source: str = "a10"  # 来源（a10 = A10 评分词；cosmo = COSMO 语义词）
    found_in: list[str] = Field(default_factory=list)  # 在 Listing 哪些位置找到（title/bullet 等）


class KeywordGapOutput(_AnalysisModel):
    """关键词覆盖检查输出。"""

    covered: list[GapKeyword] = Field(default_factory=list)  # 已覆盖的关键词
    missing: list[GapKeyword] = Field(default_factory=list)  # 缺失的关键词（未出现在 Listing 中）


class KeywordCluster(_AnalysisModel):
    """单个关键词簇（意图聚类）。"""

    name: str  # 簇名
    intent: str = ""  # 搜索意图（如"信息查询"/"购买"）
    relevant_to_main: bool = True  # 是否与主词相关
    keywords: list[str] = Field(default_factory=list)  # 簇内关键词
    search_total: float = 0  # 簇内总搜索量
    members_count: int = 0  # 簇内关键词数


class KeywordClusterOutput(_AnalysisModel):
    """关键词聚类输出。"""

    clusters: list[KeywordCluster] = Field(default_factory=list)  # 簇列表
    keyword_to_cluster: dict[str, str] = Field(default_factory=dict)  # 关键词→簇名映射
    total_assigned: int = 0  # 已分配关键词总数
