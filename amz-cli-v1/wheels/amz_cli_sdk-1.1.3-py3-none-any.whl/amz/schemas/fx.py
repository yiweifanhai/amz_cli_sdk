"""Daily reference exchange rates and their provenance."""

from datetime import date, datetime
from typing import Literal

from pydantic import BaseModel, Field


class ExchangeRateInput(BaseModel):
    base: str = Field(default="USD", pattern=r"^[A-Za-z]{3}$")
    quote: str = Field(default="CNY", pattern=r"^[A-Za-z]{3}$")
    force_refresh: bool = False


class ExchangeRateOutput(BaseModel):
    base: str
    quote: str
    rate: float = Field(gt=0, allow_inf_nan=False)
    date: date
    fetched_at: datetime
    source: str
    kind: Literal["daily_reference"] = "daily_reference"
