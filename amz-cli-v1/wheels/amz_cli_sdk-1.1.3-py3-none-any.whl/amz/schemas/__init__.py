"""
能力 I/O 的显式 JSON Schema 声明。

背景
----
``registry._infer_input_model`` 只能从函数签名推导出标量参数的 schema；
对 ``dict`` / ``list[dict]`` 参数会退化为裸 ``{"type": "object"}``，harness
无法知道要传哪些字段。本包为这些能力提供**显式输入模型**（``analysis_inputs``）
与 **data/calc 层缺失的输出模型**（``data_outputs``），挂载到
``@capability(input_model=..., output_model=...)`` 后：

- ``amz capabilities`` 导出的目录携带完整、结构化的 I/O schema
- ``registry.invoke()`` 按 schema 做输入校验与类型强制

约定
----
- Data 模型按数据源兼容需求声明默认值和额外字段行为。
- Analysis 的公共契约显式声明必需输入、有效输出与允许的空结果。
- Registry 校验已声明的输入和成功输出；Analysis 还负责校验模型响应。
"""

from amz.schemas.data_outputs import (
    AdsFunnelOutput,
    CategorySearchOutput,
    CategoryTreeOutput,
    CompetingItemOutput,
    CompetitorsOutput,
    KeywordMinerItemOutput,
    KeywordMinerOutput,
    KeywordReverseItemOutput,
    KeywordReverseOutput,
    KeywordTrendsOutput,
    NrPageOutput,
    ProductInfoOutput,
    ProductSearchOutput,
    RefinementsOutput,
    ReviewItemOutput,
    ReviewsOutput,
    RufusOutput,
    SnapshotOutput,
    SupplySearchOutput,
    WebSearchOutput,
    # calc 层输出
    CalcCosmoMergeOutput,
    DemandScoreOutput,
    KeywordGapOutput,
    MaterialEligibilityOutput,
    TrafficCodeOutput,
    WordDiffOutput,
)
from amz.schemas.analysis_inputs import (
    CalcCosmoMergeInput,
    CalcDemandScoreInput,
    CalcKeywordGapInput,
    CalcMaterialEligibilityInput,
    CalcTrafficCodeInput,
    ClassifyAsinInput,
    CompareInnovationInput,
    CosmoClassifyInput,
    CosmoExtractInput,
    DemandAssessInput,
    DimensionInput,
    GoogleTrendsInput,
    MaterialAnalysisInput,
    RefinementDimensionsInput,
    KeywordClusterInput,
    KeywordGapInput,
    KeywordItemInput,
    KeywordRelevanceInput,
    KeywordScoreInput,
    ListingAllocateInput,
    ListingMicroInsertInput,
    ListingPartRewriteInput,
    ListingRewriteInput,
    ListingTextInput,
    MarketGapInput,
    MarketProposalsInput,
    MarketSuccessFactorsInput,
    MarketTimingInput,
    MaterialAssessInput,
    PriceBandInput,
    ProductInfoInput,
    ReviewItemInput,
    TrafficAnalysisInput,
    PriceDimensionInput,
    VocInput,
    VocStrengthsInput,
    VocWeaknessesInput,
)
from amz.schemas.voc import (
    InnovationAdvantage,
    ProductVoc,
    ProductVocListing,
    ProductVocReview,
    PurchaseMotivation,
    ReviewStarShare,
    ReviewSummary,
    UnmetNeed,
    UseScenario,
    UserPersona,
    VocIssue,
    VocSatisfactionContext,
    VocSatisfactionInput,
    VocSatisfactionMetrics,
    VocStrengthsAnalysisInput,
    VocStrengthsOutput,
    VocUseInsightsAnalysisInput,
    VocUseInsightsOutput,
    VocWeaknessSignalsInput,
    VocWeaknessSignalsOutput,
    VocWeaknessesOutput,
    ValuePerception,
    VocPraiseOutput,
    VocWishlistOutput,
)
from amz.schemas.innovation import (
    Barrier,
    BarrierAnalysis,
    CopyabilityOutput,
    MaterialAssessmentOutput,
    ComparativeInnovationOutput,
)
from amz.schemas.cosmo import ProductCosmo, MarketCosmo

from amz.schemas.listing import (
    ListingOutput, TextInsertionOutput, MicroInsertOutput, AllocationOutput, PartRewriteOutput,
)
from amz.schemas.keyword_analysis import (
    RelevanceItem, RelevanceOutput, DimensionScores, ScoredKeyword, KeywordScoreOutput,
    GapKeyword, KeywordGapOutput as KeywordGapAnalysisOutput, KeywordCluster, KeywordClusterOutput,
)
from amz.schemas.demand import DemandScoreBreakdown, DemandOutput, TimingDetails, TimingOutput
from amz.schemas.market_analysis import (
    SuccessFactor, SuccessFactorsOutput, MarketPoint, MarketGapOutput, RenovationProposal, ProposalsOutput,
)
from amz.schemas.traffic import Dimension, PrimaryDimensionOutput, DimensionsOutput, AsinClassificationOutput

__all__ = [
    # data 层输出
    "ProductInfoOutput", "CompetingItemOutput", "CompetitorsOutput",
    "SnapshotOutput", "KeywordReverseItemOutput", "KeywordReverseOutput",
    "KeywordMinerItemOutput", "KeywordMinerOutput", "KeywordTrendsOutput",
    "CategoryTreeOutput", "CategorySearchOutput", "SupplySearchOutput",
    "AdsFunnelOutput", "WebSearchOutput", "ReviewItemOutput", "ReviewsOutput",
    "RufusOutput", "RefinementsOutput", "NrPageOutput", "ProductSearchOutput",
    # calc 层输出
    "CalcCosmoMergeOutput", "DemandScoreOutput", "KeywordGapOutput",
    "MaterialEligibilityOutput", "TrafficCodeOutput", "WordDiffOutput",
    # 共享输入形状
    "ProductInfoInput", "ReviewItemInput", "KeywordItemInput",
    "ListingTextInput", "PriceBandInput", "DimensionInput",
    "RefinementDimensionsInput", "GoogleTrendsInput", "MaterialAnalysisInput",
    # 能力级输入模型
    "VocInput", "VocStrengthsInput", "VocWeaknessesInput",
    "CosmoExtractInput", "MaterialAssessInput", "CompareInnovationInput",
    "KeywordRelevanceInput", "KeywordGapInput", "ListingAllocateInput",
    "ClassifyAsinInput", "TrafficAnalysisInput", "PriceDimensionInput",
    "CalcDemandScoreInput", "CalcKeywordGapInput",
    "CalcMaterialEligibilityInput", "CalcTrafficCodeInput", "CalcCosmoMergeInput",
    "CosmoClassifyInput", "KeywordScoreInput", "KeywordClusterInput",
    "ListingRewriteInput", "ListingMicroInsertInput", "ListingPartRewriteInput",
    "DemandAssessInput", "MarketTimingInput",
    "MarketSuccessFactorsInput", "MarketGapInput", "MarketProposalsInput",
    # Product VOC 公共模型
    "ProductVocListing", "ProductVocReview", "ReviewStarShare", "ReviewSummary",
    "VocSatisfactionInput", "VocSatisfactionMetrics", "VocSatisfactionContext",
    "VocStrengthsAnalysisInput", "VocWeaknessSignalsInput",
    "VocUseInsightsAnalysisInput", "InnovationAdvantage", "VocStrengthsOutput",
    "VocIssue", "UnmetNeed", "VocWeaknessSignalsOutput",
    "VocWeaknessesOutput", "UseScenario",
    "UserPersona", "PurchaseMotivation", "VocUseInsightsOutput", "ProductVoc",
    "ValuePerception", "VocPraiseOutput", "VocWishlistOutput",
    # Product analysis and contextual comparison public models
    "Barrier", "BarrierAnalysis", "CopyabilityOutput", "MaterialAssessmentOutput",
    "ComparativeInnovationOutput",
    "ProductCosmo", "MarketCosmo",
    "ListingOutput",
    "TextInsertionOutput",
    "MicroInsertOutput",
    "AllocationOutput",
    "PartRewriteOutput",
    "RelevanceItem",
    "RelevanceOutput",
    "DimensionScores",
    "ScoredKeyword",
    "KeywordScoreOutput",
    "GapKeyword",
    "KeywordGapAnalysisOutput",
    "KeywordCluster",
    "KeywordClusterOutput",
    "DemandScoreBreakdown",
    "DemandOutput",
    "TimingDetails",
    "TimingOutput",
    "SuccessFactor",
    "SuccessFactorsOutput",
    "MarketPoint",
    "MarketGapOutput",
    "RenovationProposal",
    "ProposalsOutput",
    "Dimension",
    "PrimaryDimensionOutput",
    "DimensionsOutput",
    "AsinClassificationOutput",
]
