"""Public result contracts for market strengths, gaps, and proposals."""
from __future__ import annotations
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field


class _MarketModel(BaseModel):
    model_config = ConfigDict(extra="ignore")


class SuccessFactor(_MarketModel):
    """单个市场成功要素。"""

    factor_name: str  # 成功要素名称
    description: str = ""  # 要素描述
    example_asins: list[str] = Field(default_factory=list)  # 示例 ASIN 列表
    why_it_works: str = ""  # 为什么有效


class SuccessFactorsOutput(_MarketModel):
    """市场成功因子提炼输出。"""

    market_leaders_success_factors: list[SuccessFactor] = Field(default_factory=list)  # 市场头部卖家成功要素列表


class MarketPoint(_MarketModel):
    """单个痛点或机会点。"""

    point: str  # 要点描述
    description: str = ""  # 详细说明
    severity: Literal["High", "Medium", "Low"] | None = None  # 严重程度（仅痛点使用）
    opportunity_score: int = Field(default=0, ge=0, le=10)  # 机会分 0-10（仅机会点使用）
    asin_cnt: int = 0  # 涉及 ASIN 数
    asin_list: list[str] = Field(default_factory=list)  # 涉及 ASIN 列表


class MarketGapOutput(_MarketModel):
    """市场缺口分析输出。"""

    market_summary: str = ""  # 市场总结
    problem_points: list[MarketPoint] = Field(default_factory=list)  # 痛点列表
    opportunity_points: list[MarketPoint] = Field(default_factory=list)  # 机会点列表
    market_use_insights: dict = Field(default_factory=dict)  # 市场使用洞察（场景/人群/动机）


class RenovationProposal(_MarketModel):
    """单个微改造提案。"""

    title: str  # 提案标题
    target_pain_point: str = ""  # 针对的目标痛点
    change_description: str = ""  # 改动描述
    expected_benefit: str = ""  # 预期收益
    difficulty: Literal["低", "中", "高"]  # 实施难度
    related_asins: list[str] = Field(default_factory=list)  # 相关 ASIN 列表


class ProposalsOutput(_MarketModel):
    """微改造提案输出。"""

    micro_renovation_proposals: list[RenovationProposal] = Field(default_factory=list)  # 微改造提案列表
