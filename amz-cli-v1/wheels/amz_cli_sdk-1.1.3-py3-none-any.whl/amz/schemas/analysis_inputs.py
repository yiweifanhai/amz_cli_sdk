"""
analysis/calc 层能力的显式输入模型（JSON Schema 声明）。

解决 ``_infer_input_model`` 对 ``dict`` / ``list[dict]`` 参数退化为裸
``{"type": "object"}`` 的问题：为每个带结构化 dict 参数的能力声明输入模型，
harness 可据此构造参数，``registry.invoke()`` 按此校验。
"""

from __future__ import annotations

from datetime import date, datetime
from typing import Annotated, Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from amz.schemas.data_outputs import CompetingItemOutput, MarketStatsOutput


class _Loose(BaseModel):
    """允许任意额外字段（dict 参数形状声明，不强校验）。"""

    model_config = ConfigDict(extra="allow")


# ---------------------------------------------------------------------------
# 共享输入形状
# ---------------------------------------------------------------------------


class ProductInfoInput(_Loose):
    """analysis.* 共用的产品信息输入（各模块按需取键）。

    投影源：Product 实体（entity_field 指向 Product 属性）；作为嵌套字段出现时
    由外层模型的 entity_source 决定投影源对象，投影器自动递归。
    """

    asin: str = Field(default="", json_schema_extra={"entity_field": "asin"})
    title: str = Field(default="", description="商品标题", json_schema_extra={"entity_field": "title"})
    bullet_points: list[str] = Field(default_factory=list, description="五点描述", json_schema_extra={"entity_field": "bullet_points"})
    details: str | list[dict[str, Any]] | dict[str, Any] = Field(default="", description="产品参数（productDetails 列表或拼接文本）", json_schema_extra={"entity_field": "product_details_raw"})
    description: str = Field(default="", json_schema_extra={"entity_field": "description"})
    brand: str = Field(default="", json_schema_extra={"entity_field": "brand"})
    product_rating: float | None = Field(
        default=None,
        description="商品综合评分",
        json_schema_extra={"entity_field": "rating"},
    )
    count_ratings: int | None = Field(
        default=None,
        description="商品全量评分数",
        json_schema_extra={"entity_field": "count_review"},
    )
    image_url: str = Field(default="", json_schema_extra={"projection": "_project_image_url"})
    main_image_url: str = Field(default="", json_schema_extra={"projection": "_project_image_url"})
    full_description: str = Field(default="", json_schema_extra={"entity_field": "description"})
    product_information: dict[str, Any] | str | None = Field(default=None)


class ReviewItemInput(_Loose):
    """评论项输入（analysis.voc.* 的 reviews 元素）。

    投影源：ReviewItem（entity_field 指向 ReviewItem 属性）。
    """

    rating: int | float | None = Field(default=None, json_schema_extra={"entity_field": "rating"})
    title: str = Field(default="", json_schema_extra={"entity_field": "title"})
    text: str = Field(default="", json_schema_extra={"entity_field": "text"})
    date: str | None = Field(default=None, json_schema_extra={"entity_field": "date"})
    country: str = Field(default="")
    verified: bool = Field(default=False, json_schema_extra={"entity_field": "verified"})
    user_name: str = Field(default="", json_schema_extra={"entity_field": "user_name"})


class KeywordItemInput(_Loose):
    """关键词项输入（score/gap/cluster 等的 keywords 元素）。"""

    term: str = Field(default="")
    keyword: str = Field(default="", description="兼容别名")
    search_volume: int | None = Field(default=None)
    ppc: float | None = Field(default=None)
    click_rate: float | None = Field(default=None)
    conversion_rate: float | None = Field(default=None)
    traffic_pct: float | None = Field(default=None)
    grade: str = Field(default="", description="S/A/B/C")
    source: str = Field(default="a10")


class ReverseKeywordInput(_Loose):
    """主力词计算使用的标准反查关键词 DTO。

    百分比字段统一使用 ``0-100``；字段名与 normalizer 输出一致。
    """

    term: str = Field(default="")
    search_volume: int | None = Field(default=None)
    traffic_pct: float | None = Field(default=None, description="流量占比，0-100")
    natural_ratio: float | None = Field(default=None, description="自然占比，0-100")
    ad_ratio: float | None = Field(default=None, description="广告占比，0-100")
    rank: int | None = Field(default=None)
    ppc: float | None = Field(default=None)
    trend: list[dict[str, Any]] | None = Field(default=None)
    keyword_cn: str = Field(default="")
    traffic_keyword_types: list[str] = Field(default_factory=list)
    purchase_rate: float | None = Field(default=None, description="购买率，0-100")
    purchases: int = Field(default=0)
    clicks: int = Field(default=0)
    supply_demand_ratio: float | None = Field(default=None)
    top3_clicking_rate: float | None = Field(default=None, description="0-100")
    top3_conversion_rate: float | None = Field(default=None, description="0-100")


class ListingTextInput(_Loose):
    """Listing 文本输入（gap/allocate 的 listing_text）。"""

    title: str = Field(default="")
    bullet_points: list[str] = Field(default_factory=list, description="最多取前 5 条")


class PriceBandInput(_Loose):
    """价格带输入（traffic/asin 分析的 price_bands 元素）。"""

    label: str = Field(default="", description="价格带标签，如 \"$10-$15\"")
    min: float | None = Field(default=None)
    max: float | None = Field(default=None)
    count: int = Field(default=0, description="该带商品数")


class RefinementDimensionsInput(_Loose):
    """搜索筛选维度（上游透传，仅声明已知键）。"""

    price: list[dict[str, Any]] = Field(default_factory=list, description="价格筛选（Deals & Discounts 等）")
    rating: list[dict[str, Any]] = Field(default_factory=list, description="评分筛选")
    brand: list[dict[str, Any]] = Field(default_factory=list, description="品牌筛选")
    delivery: list[dict[str, Any]] = Field(default_factory=list, description="配送筛选")


class GoogleTrendsInput(_Loose):
    """calc.demand.score 的 google_trends 输入。"""

    target_avg: float | None = Field(default=None, description="目标词近 3 年均值")
    baseline_avg: float | None = Field(default=None, description="基线词近 3 年均值")
    compare_index: float | None = Field(default=None, description="target/baseline 比值（缺失则自动计算）")
    cagr_3y: float | None = Field(default=None)
    trend_direction: str = Field(default="", description="上升/下降/持平")
    trends_ok: bool | None = Field(default=None, description="趋势数据是否有效")
    yearly: dict[str, Any] = Field(default_factory=dict)
    yoy: dict[str, Any] = Field(default_factory=dict)


class MaterialAnalysisInput(_Loose):
    """calc.material.eligibility 的 material_analysis 输入。"""

    easy_to_develop_mark: bool | str = Field(default=False, description="是否易改造标记（bool 或字符串 'true'/'false'）")
    material_reason: str = Field(default="")
    material_conclusion: str = Field(default="")
    easy_to_develop_reason: str = Field(default="")


class DimensionInput(_Loose):
    """购买决策维度输入（classify 的 dimensions 元素）。"""

    name: str = Field(default="")
    values: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# analysis.voc.*
# ---------------------------------------------------------------------------


class VocInput(_Loose):
    """analysis.voc.praise / use-insights / wishlist 输入。

    投影源：Product 实体（entity_source="product"）。
    """

    model_config = ConfigDict(extra="allow", json_schema_extra={"entity_source": "product"})

    product_info: ProductInfoInput = Field(default_factory=ProductInfoInput)
    reviews: list[ReviewItemInput] | None = Field(default=None, description="评论列表（可空，空则返回空结果）", json_schema_extra={"projection": "_project_voc_reviews"})


class VocStrengthsInput(VocInput):
    """analysis.voc.strengths 输入。"""

    reviews_evidence: str | None = Field(default=None, description="预格式化好评摘要，用于创新点交叉验证")


class VocWeaknessesInput(VocInput):
    """analysis.voc.weaknesses 输入。"""

    star_ratios: dict[str, Any] | str | None = Field(default=None, description="reviewSummary 字典或预格式化星级分布字符串")


# ---------------------------------------------------------------------------
# analysis.cosmo.* / analysis.innovation.*
# ---------------------------------------------------------------------------


class CosmoProductInput(ProductInfoInput):
    images: list[str] = Field(default_factory=list, json_schema_extra={"entity_field": "images"})
    aplus_images: list[str] = Field(default_factory=list, json_schema_extra={"entity_field": "aplus_images"})


class CosmoExtractInput(_Loose):
    """analysis.cosmo.extract 输入。"""

    model_config = ConfigDict(extra="allow", json_schema_extra={"entity_source": "product"})

    product_info: CosmoProductInput
    image_url: str = Field(default="", description="补充商品图 URL（可选，只识别图中文字）", json_schema_extra={"projection": "_project_image_url"})
    model: str = Field(default="lite", min_length=1, description="COSMO 图文抽取档位；图片最长边缩到 512 像素后与文字一起输入")


class MaterialAssessInput(_Loose):
    """analysis.material.assess 输入。"""

    model_config = ConfigDict(extra="allow", json_schema_extra={"entity_source": "product"})

    product_info: ProductInfoInput = Field(default_factory=ProductInfoInput)
    image_url: str = Field(default="", json_schema_extra={"projection": "_project_image_url"})


class CompareInnovationInput(_Loose):
    """analysis.innovation.compare 输入。"""

    new_product: ProductInfoInput = Field(default_factory=ProductInfoInput)
    benchmarks: list[ProductInfoInput] | None = Field(default=None, description="基准品列表")


# ---------------------------------------------------------------------------
# analysis.keyword.* / analysis.listing.*
# ---------------------------------------------------------------------------


class KeywordRelevanceInput(_Loose):
    """analysis.keyword.relevance 输入。"""

    model_config = ConfigDict(extra="allow", json_schema_extra={"entity_source": "product"})

    keywords: list[str] = Field(default_factory=list)
    product_info: ProductInfoInput = Field(default_factory=ProductInfoInput)
    batch_size: int = Field(default=20)
    max_retries: int = Field(default=2)


class KeywordGapInput(_Loose):
    """analysis.keyword.gap / calc.keyword.gap 输入。"""

    keywords: list[KeywordItemInput] = Field(default_factory=list, description="[{term, grade}...]")
    listing_text: ListingTextInput = Field(default_factory=ListingTextInput)


class ListingAllocateInput(_Loose):
    """analysis.listing.allocate 输入。"""

    listing: ListingTextInput = Field(default_factory=ListingTextInput)
    missing_keywords: list[str] = Field(default_factory=list)
    use_llm: bool = Field(default=True, description="True=LLM 语义分配, False=确定性规则分配")


# ---------------------------------------------------------------------------
# analysis.asin.*（流量地图 ASIN 维度）
# ---------------------------------------------------------------------------


class PriceDimensionInput(_Loose):
    """analysis.asin.primary-pricing-dimension 输入。"""

    main_keyword: str = Field(default="")
    price_bands: list[PriceBandInput] = Field(default_factory=list)
    refinement_dimensions: RefinementDimensionsInput = Field(default_factory=RefinementDimensionsInput, description="搜索筛选维度（上游透传）")
    keyword_clusters: list[dict[str, Any]] | dict[str, Any] = Field(default_factory=list, description="关键词聚类结果")
    products: list[CompetingItemOutput] = Field(default_factory=list, description="竞品列表")


class TrafficAnalysisInput(PriceDimensionInput):
    """analysis.asin.discover-dimensions 输入。"""

    primary_dimension: DimensionInput | None = Field(default=None, description="仅 discover-dimensions 需要：已选主维度")


class ClassifyAsinInput(_Loose):
    """analysis.asin.classify 输入。"""

    product: CompetingItemOutput = Field(default_factory=CompetingItemOutput)
    dimensions: list[DimensionInput] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# calc.* 输入
# ---------------------------------------------------------------------------


class CalcDemandScoreInput(_Loose):
    """calc.demand.score 输入。"""

    keyword: str = Field(default="")
    google_trends: GoogleTrendsInput = Field(default_factory=GoogleTrendsInput, description="{target_avg, baseline_avg, cagr_3y, trend_direction, yearly, yoy...}")
    amazon_trend: dict[str, Any] | None = Field(default=None, description="{yoy_pct...}")
    market_data: dict[str, Any] | None = Field(default=None, description="{monthly_avg_revenue_usd...}")


class CalcPrimaryKeywordsInput(_Loose):
    """``calc.keyword.primary`` 输入：标准化反查词列表。"""

    items: list[ReverseKeywordInput] = Field(default_factory=list)


class CalcKeywordGapInput(KeywordGapInput):
    """calc.keyword.gap 输入（同 analysis.keyword.gap）。"""


class CalcMaterialEligibilityInput(_Loose):
    """calc.material.eligibility 输入。"""

    material_analysis: MaterialAnalysisInput = Field(default_factory=MaterialAnalysisInput, description="{easy_to_develop_mark, material_reason, material_conclusion, easy_to_develop_reason}")


class CalcTrafficCodeInput(_Loose):
    """calc.traffic.code-dimensions 输入。"""

    product: CompetingItemOutput = Field(default_factory=CompetingItemOutput)
    price_bands: list[PriceBandInput] = Field(default_factory=list)


class CalcCosmoMergeInput(_Loose):
    """calc.cosmo.merge / analysis.cosmo.merge / aggregate 输入。"""

    cosmo_outputs: list[dict[str, Any]] = Field(default_factory=list, description="多个 ASIN 的 cosmo_extract 输出（[{asin, cosmo:{...}}...]）")


class CosmoAggregateInput(CalcCosmoMergeInput):
    """Legacy aggregate parameters, including explicit model selection."""

    min_count: int = Field(default=1, ge=1)
    target_product: str = ""
    model: str = Field(default="lite", min_length=1)


class CalcFeeInput(_Loose):
    """calc.fba.fee 输入：US FBA 配送费查表（2026 费率卡）。"""

    model_config = ConfigDict(extra="allow", allow_inf_nan=False)

    weight_grams: float = Field(..., gt=0, description="包装重量（g）")
    length_cm: float = Field(..., gt=0, description="包装尺寸（cm，顺序无关）")
    width_cm: float = Field(..., gt=0, description="包装尺寸（cm，顺序无关）")
    height_cm: float = Field(..., gt=0, description="包装尺寸（cm，顺序无关）")
    product_type: str | None = Field(default=None, description="non_apparel/apparel(clothing)/dangerous_goods(hazmat)")
    selling_price: float = Field(..., gt=0, description="售价（USD）")
    fulfillment_date: date | datetime | str | None = Field(default=None, description="FBA 出库日期（YYYY-MM-DD，默认今天）")
    include_fuel_surcharge: bool = Field(default=True, description="是否计入 3.5% 燃油附加费")


class CalcMarginInput(_Loose):
    """calc.fba.margin 输入：毛利率（含 M1/M2 分层利润）。

    投影源：Product 实体（entity_source="product"）；purchase_price / cpc / cvr
    等无实体来源的字段留给 params。
    """

    model_config = ConfigDict(extra="allow", allow_inf_nan=False, json_schema_extra={"entity_source": "product"})

    selling_price: float = Field(..., gt=0, description="售价（USD）", json_schema_extra={"entity_field": "price_usd"})
    pkg_weight_g: float = Field(default=0, ge=0, description="包装重量（g）", json_schema_extra={"entity_field": "weight_g"})
    pkg_dims_cm: tuple[
        Annotated[float, Field(gt=0)],
        Annotated[float, Field(gt=0)],
        Annotated[float, Field(gt=0)],
    ] | None = Field(default=None, description="包装尺寸（length, width, height）cm", json_schema_extra={"projection": "_project_pkg_dims"})
    shipping_method: Literal["slow", "fast", "air", "express"] = Field(default="fast", description="头程方式 slow/fast/air/express")
    purchase_price: float | None = Field(default=None, ge=0, description="采购价（USD），未知则仅算平台利润")
    referral_rate: float = Field(default=0.15, ge=0, lt=1, description="佣金率（0 <= rate < 1）")
    cpc: float | None = Field(default=None, ge=0, description="单次点击成本（USD），用于 M2")
    cvr: float | None = Field(default=None, ge=0, le=1, description="转化率（0-1），用于 M2")
    product_type: str | None = Field(default=None, description="non_apparel/apparel/dangerous_goods")
    fulfillment_date: date | datetime | str | None = Field(default=None, description="FBA 出库日期（YYYY-MM-DD）")
    include_fuel_surcharge: bool = Field(default=True, description="是否计入燃油附加费")
    fba_fee_usd: float | None = Field(default=None, ge=0, description="已知 FBA 配送费，传入时跳过本地查表", json_schema_extra={"entity_field": "fba_fee"})
    exchange_rate: float = Field(default=7.0, gt=0, description="人民币兑美元汇率（人民币/美元）")

    @field_validator("pkg_dims_cm", mode="before")
    @classmethod
    def validate_dimensions(cls, value: Any) -> Any:
        if isinstance(value, (list, tuple)) and len(value) != 3:
            raise ValueError("pkg_dims_cm must contain exactly three dimensions")
        return value


class CalcReturnOnCapitalInput(_Loose):
    """calc.finance.return-on-capital 输入：资金效率（4 渠道 ROI/日回报）。"""

    model_config = ConfigDict(extra="allow", json_schema_extra={"entity_source": "product"})

    selling_price: float = Field(..., description="售价（USD）", json_schema_extra={"entity_field": "price_usd"})
    unit_cost: float = Field(..., description="采购成本（USD，不含头程与平台费）")
    shipping_method: str = Field(default="fast", description="物流方式 slow/fast/air/express")
    units_per_order: int = Field(default=1, description="每单件数")
    cycle_days: int = Field(default=60, description="资金周转天数")
    roi_target_pct: float = Field(default=30.0, description="目标 ROI%")
    weight_g: float | None = Field(default=None, description="商品重量（g），None 时退回 0.5kg 起步估算", json_schema_extra={"entity_field": "weight_g"})
    platform_cost: float | None = Field(default=None, description="平台费用（佣金+FBA，USD），None 时按 15% 佣金近似")
    exchange_rate: float = Field(default=7.0, description="人民币兑美元汇率（人民币/美元）")


class CalcMarketStatsInput(_Loose):
    """``calc.market.stats`` 输入。"""

    items: list[dict[str, Any]] = Field(default_factory=list)


class CalcMarketProfileInput(_Loose):
    """``calc.market.profile`` 输入。"""

    stats: MarketStatsOutput
    keyword: str = Field(default="")


class CalcMarketOpportunityInput(_Loose):
    """``calc.market.opportunity`` 输入。"""

    stats: MarketStatsOutput
    keyword: str = Field(default="")


# ---------------------------------------------------------------------------
# analysis.cosmo.classify / analysis.keyword.score / cluster
# ---------------------------------------------------------------------------


class CosmoClassifyInput(_Loose):
    """analysis.cosmo.classify 输入。"""

    groups: list[dict[str, Any]] = Field(default_factory=list, description="cosmo_aggregate 输出的 groups")
    total_asins: int = Field(default=0)
    product_info: ProductInfoInput | None = Field(default=None)
    batch_size: int = Field(default=50)


class KeywordScoreInput(_Loose):
    """analysis.keyword.score 输入。"""

    model_config = ConfigDict(extra="allow", json_schema_extra={"entity_source": "product"})

    keywords: list[KeywordItemInput] = Field(default_factory=list, description="显式候选集合；评分为集合内相对值，不自动取数：[{term, search_volume, ppc, ...}]")
    product_info: ProductInfoInput | None = Field(default=None, description="评分所需的商品事实，不自动取数")


class KeywordClusterInput(_Loose):
    """analysis.cluster.keywords 输入。"""

    keywords: list[KeywordItemInput] = Field(default_factory=list, description="显式候选集合，不自动取数：[{term, search_volume}]")
    main_keyword: str = Field(default="")
    seed_count: int = Field(default=30)
    batch_size: int = Field(default=50)


# ---------------------------------------------------------------------------
# analysis.listing.* 输入
# ---------------------------------------------------------------------------


class ListingPolicyInput(_Loose):
    brand: str = Field(default="", description="已确认的本品品牌；不要从竞品标题推断")
    forbidden_terms: list[str] = Field(default_factory=list, description="已知其他品牌或商标词；不是完整商标库")
    media_title_limit: int | None = Field(default=None, gt=0, description="仅媒介类：传入已核实的类目标题上限；其他类目省略，使用 75")


class ListingRewriteInput(ListingPolicyInput):
    """analysis.listing.rewrite 输入。"""

    model_config = ConfigDict(extra="allow", json_schema_extra={"entity_source": "product"})

    title_differentiation: str = Field(default="", description="原商品亮点，独立于五点描述")
    title: str = Field(default="", json_schema_extra={"entity_field": "title"})
    bullet_points: list[str] = Field(default_factory=list, json_schema_extra={"entity_field": "bullet_points"})
    keywords: dict[str, list[str]] | None = Field(default=None, description="{S:[...], A:[...], B:[...], C:[...]} 关键词分层")
    price: str = Field(default="", json_schema_extra={"entity_field": "price_usd"})
    image_url: str = Field(default="", json_schema_extra={"projection": "_project_image_url"})
    feedback: str = Field(default="")


class ListingMicroInsertInput(ListingPolicyInput):
    """analysis.listing.micro-insert 输入。"""

    model_config = ConfigDict(extra="allow", json_schema_extra={"entity_source": "product"})

    title_differentiation: str = Field(default="", description="原商品亮点，独立于五点描述")
    title: str = Field(default="", json_schema_extra={"entity_field": "title"})
    bullet_points: list[str] | None = Field(default=None, json_schema_extra={"entity_field": "bullet_points"})
    insert_plan: dict[str, list[str]] | None = Field(default=None, description="{title:[kw], bp1:[kw], ...} 插入计划")
    text: str = Field(default="")
    keywords: list[str] | None = Field(default=None)
    feedback: str = Field(default="")


class ListingPartRewriteInput(ListingPolicyInput):
    """analysis.listing.part-rewrite 输入。"""

    model_config = ConfigDict(extra="allow", json_schema_extra={"entity_source": "product"})

    product_title: str = Field(default="", json_schema_extra={"entity_field": "title"})
    part_label: str = Field(default="")
    current_text: str = Field(default="")
    keywords: list[KeywordItemInput] = Field(default_factory=list)
    existing_keywords: list[str] | None = Field(default=None)
    other_parts: dict[str, Any] | None = Field(default=None)
    asin: str = Field(default="", json_schema_extra={"entity_field": "asin"})
    price: str = Field(default="", json_schema_extra={"entity_field": "price_usd"})


# ---------------------------------------------------------------------------
# analysis.demand.* / analysis.market.* 输入
# ---------------------------------------------------------------------------


class DemandAssessInput(_Loose):
    """analysis.demand.assess 输入。"""

    model_config = ConfigDict(extra="allow", json_schema_extra={"entity_source": "product"})

    keyword: str = Field(default="")
    asin: str = Field(default="", json_schema_extra={"entity_field": "asin"})
    google_trends: GoogleTrendsInput | None = Field(default=None, description="{target_avg, baseline_avg, cagr_3y, trend_direction, yearly, yoy...}，必填")
    amazon_trend: dict[str, Any] | None = Field(default=None)
    market_data: dict[str, Any] | None = Field(default=None)


class MarketTimingInput(_Loose):
    """analysis.market.timing 输入。"""

    model_config = ConfigDict(extra="allow", json_schema_extra={"entity_source": "product"})

    asin: str = Field(default="", json_schema_extra={"entity_field": "asin"})
    keyword: str = Field(default="")
    market_data: dict[str, Any] | None = Field(default=None)
    product_info: ProductInfoInput | None = Field(default=None)
    current_date: str = Field(default="")
    preparation_months: int = Field(default=3, ge=0, le=24, description="从分析日期到计划开售的准备月数")


class MarketSuccessFactorsInput(_Loose):
    """analysis.market.success-factors 输入。"""

    leaders: list[dict[str, Any]] = Field(default_factory=list, description="[{asin, strengths: {summary, innovation_and_competitive_advantages}}...]")


class MarketGapInput(_Loose):
    """analysis.market.gap / gap-analysis 输入。"""

    weaknesses: list[dict[str, Any]] = Field(default_factory=list, description="[{asin, weaknesses: {top_issues, unmet_needs}}...]")
    use_insights: list[dict[str, Any]] | None = Field(default=None)


class MarketProposalsInput(_Loose):
    """analysis.market.proposals / renovation-proposal 输入。"""

    success_factors: list[dict[str, Any]] | None = Field(default=None)
    problem_points: list[dict[str, Any]] | None = Field(default=None)
    opportunity_points: list[dict[str, Any]] | None = Field(default=None)
    use_insights: dict[str, Any] | None = Field(default=None)
