"""Public Product and Market COSMO contracts."""

from __future__ import annotations

from typing import Literal

from pydantic import AliasChoices, BaseModel, ConfigDict, Field, field_validator, model_validator

class _CosmoOutputModel(BaseModel):
    """COSMO 抽取结果的严格契约。"""

    model_config = ConfigDict(extra="forbid", populate_by_name=True, strict=True)


class _CosmoDerivedModel(BaseModel):
    """聚合和分类阶段的兼容契约。"""

    model_config = ConfigDict(extra="ignore", populate_by_name=True)


class TermLocation(_CosmoOutputModel):
    """术语在 Listing 各位置的出现标记（True=出现）。"""

    title: bool  # 出现在标题
    bulletPoints: bool  # 出现在五点描述
    review: bool  # 出现在评论
    imageDescription: bool  # 出现在商品图识别出的文字
    aPlus: bool  # Legacy description/A+ slot; does not prove an A+ page was supplied.


class TermWithLocation(_CosmoOutputModel):
    """带出现位置的术语。"""

    term: str = Field(min_length=1)
    location: TermLocation  # 出现位置标记

    @field_validator("term")
    @classmethod
    def nonempty_term(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("COSMO term must not be blank")
        return value


class ProductEssence(_CosmoOutputModel):
    """产品本质维度（"是什么"）。"""

    is_a_description: list[TermWithLocation]  # "是什么"描述性术语
    is_a_category: str  # 类目归类（自由文本）
    used_as: list[TermWithLocation]  # 被当作什么用
    made_of: list[TermWithLocation]  # 材质构成


class FunctionalUtility(_CosmoOutputModel):
    """功能效用维度（"能做什么"）。"""

    used_to: list[TermWithLocation]  # 用来做什么
    capable_of: list[TermWithLocation]  # 具备的能力
    used_for_func: list[TermWithLocation]  # 功能用途


class ContextualMapping(_CosmoOutputModel):
    """场景映射维度（"在什么场合/环境用"）。"""

    used_for_eve: list[TermWithLocation]  # 适用场合/事件（如生日、露营）
    used_on: list[TermWithLocation]  # 作用对象/表面（如皮肤、桌面）
    used_in_loc: list[TermWithLocation]  # 使用场所（如厨房、户外）
    used_in_body: list[TermWithLocation]  # 使用的身体部位（如头发、手腕）


class AudiencePsychographics(_CosmoOutputModel):
    """人群心理画像维度（"谁用、为什么用"）。"""

    used_for_aud: list[TermWithLocation]  # 目标人群（如给婴儿、给老人）
    used_by: list[TermWithLocation]  # 使用者
    xis_a: list[TermWithLocation]  # 用户身份（X 是什么人）
    xinterested_in: list[TermWithLocation]  # 用户感兴趣的事
    xwant: list[TermWithLocation]  # 用户想要什么
    lifestyle_symbol_of: list[TermWithLocation] = Field(
        validation_alias=AliasChoices("lifestyle_symbol_of", "lifestyle_symbol")
    )  # 生活方式象征（兼容旧 Prompt 字段名）


class EcosystemEconomics(_CosmoOutputModel):
    """生态经济维度（"搭配什么、定价逻辑"）。"""

    used_with: list[TermWithLocation]  # 搭配使用的产品（如保护壳、替换滤芯）
    pricing_justified: str = Field(
        validation_alias=AliasChoices("pricing_justified", "value_proposition")
    )  # 定价合理性说明（兼容旧 Prompt 字段名）


class CosmoFacts(_CosmoOutputModel):
    """COSMO 5 个一级域、19 个二级语义字段的提取结果。"""

    product_essence: ProductEssence  # 产品本质（是什么）
    functional_utility: FunctionalUtility  # 功能效用（能做什么）
    contextual_mapping: ContextualMapping  # 场景映射（什么场合用）
    audience_psychographics: AudiencePsychographics  # 人群画像（谁用）
    ecosystem_economics: EcosystemEconomics  # 生态经济（搭配与定价）


class ImageTextRead(_CosmoOutputModel):
    """Text read from one image, without visual inference."""

    status: Literal["text", "no_text", "unreadable"]
    lines: list[str]

    @model_validator(mode="after")
    def check_lines(self):
        if any(not line.strip() for line in self.lines):
            raise ValueError("Image text lines must not be blank")
        if (self.status == "text") != bool(self.lines):
            raise ValueError("Image text status and lines disagree")
        return self


class CosmoImageText(_CosmoOutputModel):
    """Image provenance and verbatim text retained with COSMO."""

    source: Literal["product_image", "aplus_image"]
    image_url: str
    lines: list[str]


class CosmoImage(_CosmoOutputModel):
    """Image source and actual resize metadata; no encoded image payload."""

    image_id: str
    source: Literal["product_image", "aplus_image"]
    image_url: str
    original_width: int = Field(gt=0)
    original_height: int = Field(gt=0)
    width: int = Field(gt=0, le=512)
    height: int = Field(gt=0, le=512)
    original_bytes: int = Field(gt=0)
    image_bytes: int = Field(gt=0)


class ProductCosmo(CosmoFacts):
    # Retained only for reading results made by the earlier OCR pipeline.
    image_texts: list[CosmoImageText] = Field(default_factory=list)
    images: list[CosmoImage] = Field(default_factory=list)


class MergedTerm(_CosmoDerivedModel):
    """跨 ASIN 合并后的单个术语统计。"""

    term: str  # 术语文本
    cosmo_category: str  # COSMO 大类（五大维度之一）
    cosmo_field: str  # COSMO 子字段（如 used_to / made_of）
    count: int = 0  # 总出现次数（各位置之和）
    title_count: int = 0  # 标题中出现次数
    bullet_points_count: int = 0  # 五点中出现次数
    review_count: int = 0  # 评论中出现次数
    image_description_count: int = 0  # 图片描述中出现次数
    a_plus_count: int = 0  # A+ 页面中出现次数
    asins: list[str] = Field(default_factory=list)  # 出现该术语的 ASIN 列表
    weighted_score: int = 0  # 五位置加权分（标题权重最高）


class CosmoMergeOutput(_CosmoDerivedModel):
    """多 ASIN COSMO 结果合并输出。"""

    terms: list[MergedTerm] = Field(default_factory=list)  # 合并后的术语统计列表
    groups: list[MergedTerm] = Field(default_factory=list)  # 术语分组（当前与 terms 同内容，向后兼容）


class TermGroup(_CosmoDerivedModel):
    """同义术语聚合组（含 LLM 分类结果）。"""

    group_id: str  # 分组 ID
    representative_term: str  # 代表术语（英文）
    representative_term_cn: str = ""  # 代表术语中文
    synonyms: list[str] = Field(default_factory=list)  # 同义词列表
    members: list[MergedTerm] = Field(default_factory=list)  # 组内成员术语
    cosmo_category: str  # COSMO 大类
    cosmo_field: str  # COSMO 子字段
    count: int = 0  # 组内总出现次数
    title_count: int = 0  # 组内标题出现次数
    bullet_points_count: int = 0  # 组内五点出现次数
    review_count: int = 0  # 组内评论出现次数
    image_description_count: int = 0  # 组内图片描述出现次数
    a_plus_count: int = 0  # 组内 A+ 出现次数
    weighted_score: int = 0  # 组加权分
    asins: list[str] = Field(default_factory=list)  # 涉及 ASIN 列表
    needs_review: bool = False  # 是否需要人工复核
    warnings: list[str] = Field(default_factory=list)  # 告警信息
    classification: Literal["S", "A", "B", "C"] | None = None  # LLM 分类等级（S 最高）
    keep_in_listing: bool | None = None  # 是否保留在 Listing 中
    suggested_position: str | None = None  # 建议埋词位置（title/bullet 等）
    scores: dict = Field(default_factory=dict)  # 评分明细
    reason: str = ""  # 分类结论理由


class CosmoAggregateOutput(_CosmoDerivedModel):
    """同义聚合输出。"""

    groups: list[TermGroup] = Field(default_factory=list)  # 聚合组列表


class CosmoClassifyOutput(_CosmoDerivedModel):
    """分组分类输出。"""

    groups: list[TermGroup] = Field(default_factory=list)  # 分类后的组列表


# Keep the old public model import compatible.
CosmoOutput = ProductCosmo


from amz.schemas.entity_ref import EntityRef


class MarketProductCosmoInput(BaseModel):
    """Prepared, read-only product result and its source metadata."""

    model_config = ConfigDict(extra="forbid")
    ref: EntityRef
    cosmo: ProductCosmo
    updated_at: str = ""
    source: Literal["listing", "listing_and_image"] = "listing"

    @model_validator(mode="after")
    def check_sources(self):
        # This contract only accepts the current listing/image extraction mode.
        if (self.cosmo.image_texts or self.cosmo.images) and self.source != "listing_and_image":
            raise ValueError("Image evidence requires an image source")
        for name in CosmoFacts.model_fields:
            section = getattr(self.cosmo, name).model_dump()
            for terms in section.values():
                if not isinstance(terms, list):
                    continue
                for item in terms:
                    location = item["location"]
                    if location["review"]:
                        raise ValueError("Review evidence is outside the listing/image COSMO source mode")
                    if location["imageDescription"] and self.source != "listing_and_image":
                        raise ValueError("Image evidence requires an image source")
        return self


class MarketCosmoInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    products: list[MarketProductCosmoInput] = Field(min_length=1, max_length=200)
    failed_product_refs: list[EntityRef] = Field(default_factory=list)
    min_success: int = Field(default=1, ge=1, description="Minimum successful products; 1 only enforces non-empty input, not market representativeness")
    model: str = Field(default="lite", min_length=1)


class MarketCosmoMember(BaseModel):
    term: str
    product_refs: list[EntityRef]


class MarketCosmoGroup(BaseModel):
    group_id: str
    representative_term: str
    representative_term_cn: str = ""
    cosmo_category: str
    cosmo_field: str
    members: list[MarketCosmoMember]
    product_refs: list[EntityRef]
    coverage_count: int = Field(ge=0)
    coverage_ratio: float = Field(ge=0, le=1)
    mention_count: int = Field(ge=0)
    position_counts: dict[str, int]
    weighted_score: int = Field(ge=0)
    needs_review: bool = False
    warnings: list[str] = Field(default_factory=list)


class CosmoSource(BaseModel):
    product_ref: EntityRef
    updated_at: str = ""
    source: str


class MarketCosmo(BaseModel):
    """Market result derived from an explicit set of Product COSMO fields."""

    model_config = ConfigDict(extra="forbid")
    groups: list[MarketCosmoGroup]
    used_product_refs: list[EntityRef]
    failed_product_refs: list[EntityRef]
    success_count: int = Field(ge=1)
    sample_count: int = Field(ge=1)
    coverage_denominator: int = Field(ge=1)
    sources: list[CosmoSource]
    limitations: list[str]
