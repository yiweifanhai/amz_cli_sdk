"""Public demand and market timing result contracts."""
from __future__ import annotations
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field

class _DemandModel(BaseModel):
    model_config = ConfigDict(extra="ignore")


class DemandScoreBreakdown(_DemandModel):
    """需求分拆解。"""

    bluered_sub_score: int  # 蓝海/红海子分（市场供需结构）
    trend_sub_score: int  # 趋势子分（真实搜索趋势）
    reason: str  # 评分说明


class DemandOutput(_DemandModel):
    """需求评估输出（确定性计算）。"""

    block: Literal["demand"] = "demand"  # 固定块标识
    score: int = Field(ge=0, le=10)  # 需求分 0-10
    stop: bool  # 是否触发 STOP 规则（硬性否决）
    stop_reason: str | None = None  # STOP 原因
    score_breakdown: DemandScoreBreakdown  # 分项得分
    data: dict  # 输入明细数据（回传）


class TimingDetails(_DemandModel):
    """市场进入时机明细。"""

    product_function: str  # 产品功能
    use_case_inference: str  # 使用场景推断链（功能→场景→具体高峰月份）
    seasonality_type: Literal["A", "B", "C", "D"]  # 季节性类型：A 强季节 / B 节日绑定 / C 弱季节 / D 无季节
    seasonality_label: str  # 季节性标签（如 summer、holiday）
    peak_demand_window: str  # 需求高峰窗口（具体月份）
    launch_window: str  # 建议上架窗口（具体月/年）
    mismatch_reason: str  # 上架窗口与需求窗口匹配/错配原因


class TimingOutput(_DemandModel):
    """市场进入时机评估输出。"""

    block: Literal["market_timing"] = "market_timing"  # 固定块标识
    score: int = Field(ge=0, le=100)  # 时机分 0-100
    verdict: Literal["GO", "CAUTION", "STOP"]  # 结论：适合进入 / 谨慎 / 放弃
    verdict_reason: str  # 结论理由
    details: TimingDetails  # 时机明细
