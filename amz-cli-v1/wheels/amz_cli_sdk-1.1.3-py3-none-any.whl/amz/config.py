"""
全局配置管理；managed 模式仅接受宿主提供的冻结运行投影。

加载优先级（从低到高）：
  1. 默认值（内置）
  2. 项目 .env（项目根目录，key=value 格式）
  3. ~/.amz/config.yaml（用户级 YAML）
  4. 环境变量（AMZ_* / DOUBAO_API_KEY / ARK_API_KEY）

API keys 三种设置方式：
  - .env:         ARK_API_KEY=your-key
  - config.yaml:  api_keys: {doubao: "your-key"}
  - 环境变量:     export ARK_API_KEY=your-key
"""

from __future__ import annotations

import json
import math
import os
import re
from copy import deepcopy
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

import yaml


DEFAULT_CONFIG_YAML = """
api_keys:
  doubao: ""
  ark: ""

data_api:
  base_url: https://amz.jxpxxzj.cn
  token: ""
  timeout_s: 60
  default_cache_ttl_s: 86400

sif:
  token_file: ~/.sif_token

cosmo:
  use_images: false

llm:
  default_backend: doubao
  backends_file: ""
  temperature: 0.2
  cache_dir: ~/.cache/amz-cli/llm
  fallback_chain:
    - pro
    - lite
    - mini

cache:
  dir: ~/.cache/amz-cli
  reuse_legacy: true
  engine: sqlite

task:
  db: ~/.amz/amz-cli.db

normalizer:
  currency_exchange:
    default: USD
  bsr_category_rules: {}
  pct_convention: "0-100"
"""


def _expand_path(path: str) -> Path:
    """展开 ~ 和 $HOME 的路径"""
    return Path(os.path.expanduser(os.path.expandvars(path)))


class ConfigError(ValueError):
    """Invalid configuration, without configuration values in the diagnostic."""


def _bootstrap_mode() -> str:
    mode = os.environ.get("AMZ_CONFIG_MODE", "standalone")
    if mode not in {"standalone", "managed"}:
        raise ConfigError("AMZ_CONFIG_MODE must be standalone or managed")
    return mode


def _absolute_path(value: Any, field: str) -> Path:
    if not isinstance(value, str) or not value or "\x00" in value:
        raise ConfigError(f"{field} must be an absolute path")
    path = Path(value)
    if not path.is_absolute():
        raise ConfigError(f"{field} must be an absolute path")
    try:
        return path.resolve()
    except (OSError, RuntimeError, ValueError):
        raise ConfigError(f"{field} cannot be resolved") from None


def _within(path: Path, root: Path, field: str) -> None:
    if not path.is_relative_to(root):
        raise ConfigError(f"{field} must be inside paths.workspace_root")


def _validate_tree(value: Any, ancestors: set[int] | None = None) -> None:
    """Reject recursive YAML aliases and values outside the JSON data model."""
    ancestors = set() if ancestors is None else ancestors
    if isinstance(value, (dict, list)):
        identity = id(value)
        if identity in ancestors:
            raise ConfigError("managed configuration must not contain recursive values")
        ancestors.add(identity)
        items = value.values() if isinstance(value, dict) else value
        if isinstance(value, dict) and any(not isinstance(key, str) for key in value):
            raise ConfigError("managed configuration keys must be strings")
        for item in items:
            _validate_tree(item, ancestors)
        ancestors.remove(identity)
    elif value is not None and not isinstance(value, (str, bool, int, float)):
        raise ConfigError("managed configuration must contain JSON-compatible values")
    elif isinstance(value, float) and not math.isfinite(value):
        raise ConfigError("managed configuration numbers must be finite")


def _validate_url(value: Any, field: str) -> None:
    if not isinstance(value, str):
        raise ConfigError(f"{field} must be an HTTP(S) URL or an empty string")
    if not value:
        return
    try:
        parsed = urlsplit(value)
        valid = (
            parsed.scheme in {"http", "https"}
            and parsed.hostname
            and not parsed.username
            and not parsed.password
            and not parsed.query
            and not parsed.fragment
            and not any(char.isspace() for char in value)
        )
        parsed.port
    except ValueError:
        valid = False
    if not valid:
        raise ConfigError(f"{field} must be an HTTP(S) URL without credentials or query")


def _validate_headers(value: Any, field: str) -> None:
    if not isinstance(value, dict):
        raise ConfigError(f"{field} must be an object of HTTP header strings")
    seen: set[str] = set()
    for name, content in value.items():
        if (
            not isinstance(name, str)
            or re.fullmatch(r"[!#$%&'*+.^_`|~0-9A-Za-z-]+", name) is None
            or not isinstance(content, str)
            or any(char in content for char in "\r\n\x00")
            or name.lower() in seen
            or name.lower() in {"host", "content-length", "transfer-encoding", "connection"}
        ):
            raise ConfigError(f"{field} contains an invalid or duplicate HTTP header")
        try:
            content.encode("latin-1")
        except UnicodeEncodeError:
            raise ConfigError(f"{field} values must be encodable as HTTP header strings") from None
        seen.add(name.lower())


class _Config:
    """配置单例"""

    def __init__(self):
        self._data: dict[str, Any] = {}
        self._loaded = False
        self._config_path: Path | None = None
        self._config_stamp: tuple[int, int] | None = None
        self._mode: str | None = None
        self._source_path: Path | None = None

    def bootstrap(self) -> None:
        """Validate the mode and initialize managed state before capability discovery."""
        if self._loaded and self._mode == "managed":
            return
        if _bootstrap_mode() == "managed":
            self.load()

    @property
    def is_managed(self) -> bool:
        return self._mode == "managed" if self._loaded else _bootstrap_mode() == "managed"

    @property
    def source_path(self) -> Path | None:
        return self._source_path

    def load(self, path: str | Path | None = None):
        """Load standalone sources or freeze a managed snapshot on first use."""
        if self._loaded and self._mode == "managed":
            if path is not None and _absolute_path(str(path), "config path") != self._source_path:
                raise ConfigError("managed configuration is frozen; another source cannot be loaded")
            return
        if _bootstrap_mode() == "managed":
            self._load_managed(path)
            return
        if path is None:
            path = "~/.amz/config.yaml"
        config_path = _expand_path(str(path))

        # 从默认 YAML 开始
        self._data = yaml.safe_load(DEFAULT_CONFIG_YAML) or {}

        # 用户级 ~/.amz/.env（服务端/systemd 场景：与 cwd 无关）
        self._load_dotenv_file(_expand_path("~/.amz/.env"))

        # 项目级 .env 文件（项目根目录，优先级高于用户级）
        self._load_dotenv()

        # 用户配置文件覆盖
        if config_path.exists():
            user_config = yaml.safe_load(config_path.read_text()) or {}
            _deep_merge(self._data, user_config)

        # 环境变量覆盖（AMZ_ 前缀）
        self._apply_env_overrides()

        self._loaded = True
        self._config_path = config_path
        self._config_stamp = self._saved_config_stamp()

        self._mode = "standalone"
        self._source_path = config_path.resolve()

    def _saved_config_stamp(self) -> tuple[int, int] | None:
        if self._config_path is None:
            return None
        try:
            stat = self._config_path.stat()
            return stat.st_mtime_ns, stat.st_size
        except FileNotFoundError:
            return None

    def _load_managed(self, path: str | Path | None) -> None:
        configured = os.environ.get("AMZ_CONFIG_FILE", "")
        source = _absolute_path(configured, "AMZ_CONFIG_FILE")
        if path is not None and _absolute_path(str(path), "config path") != source:
            raise ConfigError("managed configuration must use AMZ_CONFIG_FILE")
        try:
            content = source.read_text(encoding="utf-8-sig")
            snapshot = json.loads(content) if source.suffix.lower() == ".json" else yaml.safe_load(content)
        except (OSError, UnicodeError, json.JSONDecodeError, yaml.YAMLError, RecursionError):
            raise ConfigError("AMZ_CONFIG_FILE must contain a readable UTF-8 JSON/YAML object") from None
        if not isinstance(snapshot, dict):
            raise ConfigError("managed configuration must be an object")
        try:
            _validate_tree(snapshot)
        except RecursionError:
            raise ConfigError("managed configuration is nested too deeply") from None
        for section in ("paths", "cache", "composite", "cli", "data_api", "sif", "llm", "api_keys", "task", "normalizer"):
            if section in snapshot and not isinstance(snapshot[section], dict):
                raise ConfigError(f"{section} must be an object")
        workspace = _absolute_path(snapshot.get("paths", {}).get("workspace_root"), "paths.workspace_root")
        cache = _absolute_path(snapshot.get("cache", {}).get("dir"), "cache.dir")
        _within(cache, workspace, "cache.dir")
        data = yaml.safe_load(DEFAULT_CONFIG_YAML)
        _deep_merge(data, {
            "paths": {"workspace_root": str(workspace)},
            "data_api": {"base_url": "", "token": "", "headers": {}},
            "sif": {"token_file": "", "token": "", "endpoint_url": "", "timeout_s": 15},
            "llm": {"default_backend": "host", "cache_dir": "", "fallback_chain": []},
            "cache": {"dir": str(cache), "reuse_legacy": False},
            "task": {"db": ""},
            "composite": {
                "roots": [], "write_dir": str(workspace / ".amz" / "composite"),
                "mode": "declarative", "load_user_dir": False, "load_entry_points": False,
            },
            "cli": {"output": "json"},
        })
        _deep_merge(data, snapshot)
        self._validate_managed(data, workspace, cache)
        self._data = data
        self._source_path = source
        self._mode = "managed"
        self._loaded = True

    @staticmethod
    def _validate_managed(data: dict, workspace: Path, cache: Path) -> None:
        data["paths"]["workspace_root"] = str(workspace)
        data["cache"]["dir"] = str(cache)
        if data["cache"]["reuse_legacy"] is not False:
            raise ConfigError("cache.reuse_legacy must be false in managed mode")
        composite = data["composite"]
        for field in ("load_user_dir", "load_entry_points"):
            if composite[field] is not False:
                raise ConfigError(f"composite.{field} must be false in managed mode")
        if composite["mode"] != "declarative":
            raise ConfigError("composite.mode must be declarative in managed mode")
        if not isinstance(composite["roots"], list):
            raise ConfigError("composite.roots must be a list of absolute paths")
        composite["roots"] = [str(_absolute_path(root, "composite.roots")) for root in composite["roots"]]
        write_dir = _absolute_path(composite["write_dir"], "composite.write_dir")
        _within(write_dir, workspace, "composite.write_dir")
        composite["write_dir"] = str(write_dir)
        if data["cli"]["output"] != "json":
            raise ConfigError("cli.output must be json in managed mode")
        for section, field in (("data_api", "base_url"), ("sif", "endpoint_url")):
            _validate_url(data[section][field], f"{section}.{field}")
        for section in ("data_api", "sif"):
            if not isinstance(data[section]["token"], str):
                raise ConfigError(f"{section}.token must be a string")
            timeout = data[section]["timeout_s"]
            if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or not math.isfinite(timeout) or timeout <= 0:
                raise ConfigError(f"{section}.timeout_s must be a positive finite number")
        if data["sif"]["token_file"]:
            raise ConfigError("sif.token_file is unavailable in managed mode")
        _validate_headers(data["data_api"]["headers"], "data_api.headers")
        if any(not isinstance(key, str) for key in data["api_keys"].values()):
            raise ConfigError("api_keys values must be strings")
        if not isinstance(data["llm"]["default_backend"], str):
            raise ConfigError("llm.default_backend must be a string")
        temperature = data["llm"]["temperature"]
        if temperature is not None and (isinstance(temperature, bool) or not isinstance(temperature, (int, float)) or not math.isfinite(temperature)):
            raise ConfigError("llm.temperature must be a finite number or null")

    def _load_dotenv(self):
        """从当前工作目录向上查找 .env 文件（取最近的）读取配置"""
        cwd = Path.cwd()
        for parent in [cwd] + list(cwd.parents):
            dotenv = parent / ".env"
            if dotenv.exists():
                self._parse_dotenv(dotenv)
                break

    def _load_dotenv_file(self, path: Path):
        """读取指定 .env 文件（存在时）。"""
        if path.exists():
            self._parse_dotenv(path)

    def _parse_dotenv(self, path: Path):
        """解析 .env 文件，将有对应配置项的 key 合并到 self._data"""
        import re
        # 环境变量 → 配置路径映射
        env_to_config = {
            "DOUBAO_API_KEY": ("api_keys", "doubao"),
            "ARK_API_KEY": ("api_keys", "ark"),
            "AMZ_API_TOKEN": ("data_api", "token"),
            "AMZ_LLM_BACKEND": ("llm", "default_backend"),
        }
        for line in path.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            m = re.match(r"^(\w+)\s*=\s*(.+)$", line)
            if not m:
                continue
            key, value = m.group(1), m.group(2).strip().strip('"').strip("'")
            if key in env_to_config:
                obj = self._data
                cfg_path = env_to_config[key]
                for k in cfg_path[:-1]:
                    obj = obj.setdefault(k, {})
                obj[cfg_path[-1]] = value

    def _apply_env_overrides(self):
        """环境变量 AMZ_* 覆盖配置"""
        overrides = {
            "AMZ_API_TOKEN": ("data_api", "token"),
            "AMZ_DATA_BASE_URL": ("data_api", "base_url"),
            "AMZ_LLM_BACKEND": ("llm", "default_backend"),
            "AMZ_CACHE_DIR": ("cache", "dir"),
        }
        # 各 LLM provider 的 API key 也支持环境变量覆盖
        env_key_map = {
            "DOUBAO_API_KEY": "doubao",
            "ARK_API_KEY": "ark",
        }
        for env_var, provider in env_key_map.items():
            val = os.environ.get(env_var)
            if val:
                overrides[env_var] = ("api_keys", provider)

        for env_var, path in overrides.items():
            val = os.environ.get(env_var)
            if val:
                obj = self._data
                for key in path[:-1]:
                    obj = obj.setdefault(key, {})
                obj[path[-1]] = val

    def get(self, *path: str, default: Any = None) -> Any:
        """按路径读取配置，如 config.get("data_api", "base_url")"""
        if not self._loaded:
            self.load()
        obj = self._data
        for key in path:
            if isinstance(obj, dict):
                obj = obj.get(key)
            else:
                return deepcopy(default)
            if obj is None:
                return deepcopy(default)
        return deepcopy(obj)

    def all(self) -> dict:
        """返回全部配置"""
        if not self._loaded:
            self.load()
        return deepcopy(self._data)

    # -- 便捷属性 ------------------------------------------------------------

    @property
    def data_api_base_url(self) -> str:
        return self.get("data_api", "base_url", default="https://amz.jxpxxzj.cn")

    @property
    def data_api_token(self) -> str:
        return self.get("data_api", "token", default="")

    @property
    def data_api_timeout(self) -> float:
        return self.get("data_api", "timeout_s", default=60)

    @property
    def data_api_headers(self) -> dict[str, str]:
        return self.get("data_api", "headers", default={})

    @property
    def cache_dir(self) -> Path:
        value = self.get("cache", "dir", default="~/.cache/amz-cli")
        return Path(value) if self.is_managed else _expand_path(value)

    @property
    def reuse_legacy_cache(self) -> bool:
        return self.get("cache", "reuse_legacy", default=True)

    @property
    def sif_token_file(self) -> Path:
        if self.is_managed:
            raise ConfigError("sif.token_file is unavailable in managed mode")
        return _expand_path(self.get("sif", "token_file", default="~/.sif_token"))

    @property
    def cosmo_use_images(self) -> bool:
        # Pick up changes from a separate setup process before the next extraction.
        if self._loaded and not self.is_managed and self._saved_config_stamp() != self._config_stamp:
            self.load(str(self._config_path))
        value = self.get("cosmo", "use_images", default=False)
        if not isinstance(value, bool):
            raise ValueError("cosmo.use_images must be true or false")
        return value

    @property
    def llm_default_backend(self) -> str:
        # Old installations may still store a different default. Built-in Analysis
        # now uses Doubao; other explicit providers are rejected by the LLM client.
        backend = self.get("llm", "default_backend", default="doubao")
        if self.is_managed or self.get("llm", "backends", backend) is not None:
            return backend
        return backend if backend in {"doubao", "ark"} else "doubao"

    @property
    def llm_temperature(self) -> float:
        return self.get("llm", "temperature", default=0.2)

    @property
    def llm_cache_dir(self) -> Path:
        if self.is_managed:
            return self.cache_dir / "llm"
        return _expand_path(self.get("llm", "cache_dir", default="~/.cache/amz-cli/llm"))

    @property
    def llm_fallback_chain(self) -> list[str]:
        return self.get("llm", "fallback_chain", default=["pro", "lite", "mini"])

    # -- API keys ------------------------------------------------------------

    def api_key(self, provider: str) -> str:
        """获取指定 provider 的 API key"""
        if provider not in {"doubao", "ark"}:
            return ""
        key = self.get("api_keys", provider, default="")
        if not key and provider in {"doubao", "ark"}:
            alias = "ark" if provider == "doubao" else "doubao"
            key = self.get("api_keys", alias, default="")
        return key


def _deep_merge(base: dict, override: dict):
    """递归合并配置"""
    for key, val in override.items():
        if key in base and isinstance(base[key], dict) and isinstance(val, dict):
            _deep_merge(base[key], val)
        else:
            base[key] = val


# 全局单例
config = _Config()
