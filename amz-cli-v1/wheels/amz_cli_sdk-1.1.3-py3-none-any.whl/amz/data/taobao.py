"""Normalize the existing OneBound search contract."""
import os
import re
import unicodedata
from datetime import datetime, timezone
from urllib.parse import urlparse, quote, quote_plus
from pydantic import BaseModel, field_validator
from amz.envelope import Code, Result, err, ok
from amz.registry import capability
from amz.schemas.taobao import TaobaoItem, TaobaoSearch
from amz.data.sources import onebound


def normalize_term(value: str) -> str:
    value = " ".join(unicodedata.normalize("NFKC", value).split()).casefold()
    if not 1 <= len(value) <= 200:
        raise ValueError("keyword must contain 1 to 200 characters")
    return value


class SearchInput(BaseModel):
    keyword: str
    _term = field_validator("keyword")(normalize_term)


def clean_text(value):
    if not isinstance(value, str):
        return None
    for name in ("ONEBOUND_API_KEY", "ONEBOUND_API_SECRET"):
        secret = os.environ.get(name)
        if secret:
            for token in (secret, quote(secret, safe=""), quote_plus(secret)):
                value = value.replace(token, "[REDACTED]")
    return value


def safe_url(value):
    value = clean_text(value)
    if not value or "\\" in value or any(ord(c) < 32 for c in value):
        return None
    value = "https:" + value if value.startswith("//") else value
    try:
        parsed = urlparse(value)
        if parsed.scheme in ("http", "https") and parsed.hostname and not parsed.username and not parsed.password:
            return value
    except ValueError:
        pass
    return None


def normalize_search(body, keyword):
    if not isinstance(body, dict):
        return err(Code.ERROR_UPSTREAM, "Invalid OneBound response")
    code = str(body.get("error_code", ""))
    if code == "2000":
        rows = []
    elif code != "0000":
        kind = Code.ERROR_AUTH if code in {"4004", "4005", "4012"} else Code.ERROR_RATE_LIMIT if code == "4013" else Code.ERROR_UPSTREAM
        label = code if re.fullmatch(r"[0-9]{4}", code) else "unknown"
        return err(kind, f"OneBound error {label}; not retried")
    else:
        rows = body.get("items")
        rows = rows.get("item") if isinstance(rows, dict) else rows
    if not isinstance(rows, list) or not all(isinstance(row, dict) for row in rows):
        return err(Code.ERROR_UPSTREAM, "Invalid OneBound product list")
    products, seen, skipped = [], set(), 0
    for row in rows:
        item_id = str(row.get("num_iid", ""))
        if not re.fullmatch(r"[0-9]+", item_id):
            skipped += 1
            continue
        if item_id in seen:
            continue
        seen.add(item_id)
        products.append(TaobaoItem(item_id=item_id, title=clean_text(row.get("title")), image_url=safe_url(row.get("pic_url")), url=safe_url(row.get("detail_url"))))
    return ok(TaobaoSearch(keyword=keyword, collected_at=datetime.now(timezone.utc).isoformat(), products=products, skipped_count=skipped).model_dump())


@capability("data.taobao.search", input_model=SearchInput, output_model=TaobaoSearch, description="淘宝关键词第一页搜索样本")
def taobao_search(keyword: str) -> Result:
    result = onebound.search(normalize_term(keyword))
    if result.code != Code.OK:
        return result
    normalized = normalize_search(result.data, normalize_term(keyword))
    normalized.meta = result.meta
    return normalized
