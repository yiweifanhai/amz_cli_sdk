"""
SIF API 适配器：关键词流量漏斗 + 广告成本数据。

认证：~/.sif_token（JWT，Header + Cookie）。
API：https://www.sif.com/api/search/keywordFunnel/list
"""

from __future__ import annotations

import json
import time
from typing import Any

from amz.config import config
from amz.envelope import Result, err, Code
from amz.data.normalizer import normalize_sif_funnel
from amz.data.sources.base import DataSource

ADMIN_TOKEN_HINT = "Ask your SIF account administrator for an updated Token. Automatic login is disabled."

class SifApi(DataSource):
    """SIF 关键词流量漏斗 API"""

    source_name = "sif"

    SLUG = "sif-keyword-funnel"
    # Earlier responses were truncated before caching, including single-keyword
    # requests that returned related terms. Never reuse those incomplete records.
    CACHE_SLUG = "sif-keyword-funnel-v2"
    TTL_HOURS = 24 * 14  # 14 天
    API_URL = "https://www.sif.com/api/search/keywordFunnel/list"

    def _get_token(self) -> str:
        """读取 ~/.sif_token"""
        token_file = config.sif_token_file
        if not token_file.exists():
            raise FileNotFoundError(f"SIF token file not found: {token_file}")
        token = token_file.read_text().strip()
        if not token:
            raise FileNotFoundError("SIF token file is empty")
        return token

    def _call_endpoint(self, endpoint_id: str, params: dict) -> dict:
        """不适用于 SIF（有独立调用流程）"""
        raise NotImplementedError

    def _normalize_funnel(self, data: Any, *, from_cache: bool = False) -> Result:
        try:
            normalized = normalize_sif_funnel(data)
        except (ValueError, TypeError) as exc:
            return err(
                Code.ERROR_UPSTREAM, f"Invalid SIF response: {exc}",
                upstream=self.SLUG, from_cache=from_cache,
            )
        return self.normalize_response(normalized, self.SLUG, from_cache=from_cache)

    def keyword_funnel(self, keywords: list[str]) -> Result:
        """查询关键词流量漏斗

        Returns:
            Result.data includes normalized items and all original keywords.
            Cost strategy ranges and the original reporting period are preserved.
        """
        if not keywords:
            return err(Code.ERROR_PARAM, "keywords is required")

        if config.is_managed:
            return err(
                Code.ERROR_AUTH,
                "SIF is unavailable in managed mode; a host SIF adapter is required",
            )

        cache_key = "+".join(_safe_cache(k) for k in keywords)

        # 读缓存
        cached = self._read_cache(self.CACHE_SLUG, cache_key, self.TTL_HOURS)
        if cached is not None:
            return self._normalize_funnel(cached, from_cache=True)

        # 获取 token
        try:
            token = self._get_token()
        except FileNotFoundError as e:
            return err(Code.ERROR_AUTH, str(e),
                       hint=ADMIN_TOKEN_HINT)

        ts = str(int(time.time() * 1000))
        url = f"{self.API_URL}?country=US&_t={ts}&_m=Sif_12cd-563b-405e-b473-f4d2"

        headers = {
            "Authorization": token,
            "Cookie": f"sif_token={token}",
            "Content-Type": "application/json",
        }

        body = {
            "pageSize": 100,
            "pageNum": 1,
            "sortBy": "",
            "customPrice": "",
            "customProfitRate": "",
            "desc": True,
            "strategy": "legacyForSales_exact",
            "matchTypes": [],
            "keywords": keywords,
        }

        # HTTP POST
        import urllib.request
        import urllib.error

        try:
            req = urllib.request.Request(
                url,
                data=json.dumps(body).encode("utf-8"),
                headers=headers,
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=15) as resp:
                result = json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            if e.code in (401, 403):
                return err(Code.ERROR_AUTH, f"SIF authentication failed: HTTP {e.code}",
                           upstream=self.source_name, hint=ADMIN_TOKEN_HINT)
            return err(Code.ERROR_UPSTREAM, f"SIF API error: HTTP {e.code}")
        except Exception as e:
            return err(Code.ERROR_UPSTREAM, f"SIF API error: {e}")

        if not isinstance(result, dict):
            return err(Code.ERROR_UPSTREAM, "Invalid SIF response: expected an object",
                       upstream=self.SLUG)

        if result.get("code") != 1:
            message = result.get("message") or result.get("msg") or "unknown SIF error"
            auth_error = result.get("code") in (-5, -10)
            return err(
                Code.ERROR_AUTH if auth_error else Code.ERROR_UPSTREAM,
                f"SIF API returned code={result.get('code')}: {message}",
                upstream=self.source_name,
                hint=ADMIN_TOKEN_HINT if auth_error else "",
            )

        data = result.get("data", result)

        normalized = self._normalize_funnel(data)
        if normalized.code == Code.OK:
            self._write_cache(self.CACHE_SLUG, cache_key, self.TTL_HOURS, data)
        return normalized


def _safe_cache(keyword: str) -> str:
    key = keyword.lower().replace(" ", "_")
    for ch in ("/", "\\", ":"):
        key = key.replace(ch, "_")
    return key
