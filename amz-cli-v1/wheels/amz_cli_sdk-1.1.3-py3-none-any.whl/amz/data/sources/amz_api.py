"""
AmzDataApi 适配器 — 移植自 amz-api skills。

直连 amz-spider-server 现有 /api/* 端点（amz.jxpxxzj.cn），
以 HTTP POST + Bearer Auth 消费。提供：缓存、重试（网络抖动 + 慢端点等待）、
QPS 限速、TOP2K 分段分页。

端点：
  - product-info       /api/amazon/product_info        (慢端点)
  - reviews            /api/amazon/reviews
  - competing-lookup   /api/seller-sprite/competing-lookup
  - keyword-reverse    /api/seller-sprite/keyword-reverse
  - keyword-miner      /api/seller-sprite/keyword-miner
  - market-research    /api/seller-sprite/market-research  (上游403禁用，降级见 01-数据对接.md §5)
  - product-search-1688  /api/1688/product-search
  - sif-keyword-funnel SIF API (独立认证)

扩展端点（按需）:
  - trends / search / refinements / rufus / tree-list / tree-search / nr-page / web_search
"""

from __future__ import annotations

import json
import time
import urllib.request
import urllib.error
from typing import Any

from amz.config import ConfigError, config
from amz.envelope import Result, ok, err, Code
from amz.data.sources.base import DataSource


class AmzDataApi(DataSource):
    """amz-spider-server 的 HTTP 适配器"""

    source_name = "amz_api"

    # ------------------------------------------------------------------
    # 端点元数据（对齐 amz-api skills）：slug, TTL, URL, 慢端点标记
    # ------------------------------------------------------------------

    ENDPOINTS = {
        "product-info": {
            "slug": "product-info",
            "ttl_hours": 24,
            "path": "/api/amazon/product_info",
            "slow": True,   # 首调触发服务端抓取，需等 10-30s 重试
        },
        "reviews": {
            "slug": "reviews",
            "ttl_hours": 48,
            "path": "/api/amazon/reviews",
            "slow": False,
        },
        "competing-lookup": {
            "slug": "competing-lookup",
            "ttl_hours": 24,
            "path": "/api/seller-sprite/competing-lookup",
            "slow": False,
        },
        "keyword-reverse": {
            "slug": "keyword-reverse",
            "ttl_hours": 48,
            "path": "/api/seller-sprite/keyword-reverse",
            "slow": False,
        },
        "keyword-miner": {
            "slug": "keyword-miner",
            "ttl_hours": 48,
            "path": "/api/seller-sprite/keyword-miner",
            "slow": False,
        },
        "market-research": {
            "slug": "market-research",
            "ttl_hours": 72,
            "path": "/api/seller-sprite/market-research",
            "slow": False,
        },
        "product-search-1688": {
            "slug": "product-search-1688",
            "ttl_hours": 168,  # 7 天
            "path": "/api/1688/product-search",
            "slow": False,
        },
        # -- 扩展端点 --
        "trends": {
            "slug": "trends",
            "ttl_hours": 48,
            "path": "/api/seller-sprite/trends",
            "slow": False,
        },
        "amazon-search": {
            "slug": "amazon-search",
            "ttl_hours": 24,
            "path": "/api/amazon/search",
            "slow": False,
        },
        "refinements": {
            "slug": "refinements",
            "ttl_hours": 24,
            "path": "/api/amazon/refinements",
            "slow": False,
        },
        "rufus": {
            "slug": "rufus",
            "ttl_hours": 24,
            "path": "/api/amazon/rufus",
            "slow": False,
        },
        "tree-list": {
            "slug": "tree-list",
            "ttl_hours": 168,
            "path": "/api/amazon/tree-list",
            "slow": False,
        },
        "tree-search": {
            "slug": "tree-search",
            "ttl_hours": 168,
            "path": "/api/amazon/tree-search",
            "slow": False,
        },
        "nr-page": {
            "slug": "nr-page",
            "ttl_hours": 24,
            "path": "/api/amazon/nr-page",
            "slow": False,
        },
        "web-search": {
            "slug": "web-search",
            "ttl_hours": 24,
            "path": "/api/volc/web_search",
            "slow": False,
        },
    }

    # ------------------------------------------------------------------
    # 初始化
    # ------------------------------------------------------------------

    def __init__(self):
        super().__init__()
        self._base_url = config.data_api_base_url.rstrip("/")
        if config.is_managed and not self._base_url:
            raise ConfigError("data_api.base_url is required for managed data calls")
        self._token = config.data_api_token
        self._timeout = config.data_api_timeout
        self._configured_headers = config.data_api_headers

    @property
    def _headers(self) -> dict:
        headers = {
            "Authorization": f"Bearer {self._token}",
            "Content-Type": "application/json",
        }
        for name, value in self._configured_headers.items():
            headers = {key: content for key, content in headers.items() if key.lower() != name.lower()}
            headers[name] = value
        return headers

    # ------------------------------------------------------------------
    # 核心 HTTP POST（移植自 _base.py http_post）
    # ------------------------------------------------------------------

    def _call_endpoint(self, endpoint_id: str, params: dict) -> Result:
        """核心调用：缓存 → HTTP POST → 归一化"""
        meta = self.ENDPOINTS.get(endpoint_id)
        if meta is None:
            return err(Code.ERROR_PARAM, f"unknown endpoint: {endpoint_id}")

        slug = meta["slug"]
        ttl = meta["ttl_hours"]
        url = f"{self._base_url}{meta['path']}"
        is_slow = meta.get("slow", False)

        # 缓存 key
        cache_key = params.get("_cache_key", self._make_cache_key(endpoint_id, params))

        # 读缓存
        cached = self._read_cache(slug, cache_key, ttl)
        if cached is not None:
            # product-info 特殊逻辑：空 items 强制重取
            if endpoint_id == "product-info":
                if isinstance(cached, dict) and cached.get("items") and len(cached["items"]) > 0:
                    return self.normalize_response(cached, slug, from_cache=True)
            else:
                return self.normalize_response(cached, slug, from_cache=True)

        # QPS 限速
        self._qps_wait(endpoint_id, qps=1.0)

        # HTTP POST（带重试）
        body = {k: v for k, v in params.items() if not k.startswith("_")}

        if is_slow:
            return self._slow_fetch(url, body, slug, cache_key, ttl)
        else:
            return self._fast_fetch(url, body, slug, cache_key, ttl)

    def _fast_fetch(self, url: str, body: dict, slug: str, cache_key: str, ttl_hours: int) -> Result:
        """普通端点：3 次快速重试"""
        resp_data = self._http_post(url, body, max_retries=3, retry_delay=1)

        if resp_data is None:
            return err(Code.ERROR_UPSTREAM, f"[{slug}] HTTP POST failed after 3 retries", upstream=slug)

        self._write_cache(slug, cache_key, ttl_hours, resp_data)
        return self.normalize_response(resp_data, slug)

    def _slow_fetch(self, url: str, body: dict, slug: str, cache_key: str, ttl_hours: int) -> Result:
        """慢端点（product-info）：首调触发抓取 + 等待 + 重试"""
        # 第一轮：3 次快速重试
        resp_data = self._http_post(url, body, timeout=12, max_retries=3, retry_delay=1)

        if resp_data and isinstance(resp_data, dict) and resp_data.get("items"):
            self._write_cache(slug, cache_key, ttl_hours, resp_data)
            return self.normalize_response(resp_data, slug)

        # 第二轮：等待服务端抓取 + 2 次重试
        time.sleep(15)

        for retry in range(2):
            resp_data = self._http_post(url, body, timeout=15, max_retries=1, retry_delay=0)
            if resp_data and isinstance(resp_data, dict) and resp_data.get("items"):
                self._write_cache(slug, cache_key, ttl_hours, resp_data)
                return self.normalize_response(resp_data, slug)
            if retry < 1:
                time.sleep(10)

        return err(
            Code.ERROR_UPSTREAM,
            f"[{slug}] server returned empty items after all retries (waited ~40s for server-side fetch)",
            upstream=slug,
            hint="try again later or check if ASIN is valid",
        )

    # ------------------------------------------------------------------
    # HTTP 底层
    # ------------------------------------------------------------------

    def _http_post(
        self,
        url: str,
        body: dict,
        headers: dict | None = None,
        timeout: int | None = None,
        max_retries: int = 1,
        retry_delay: float = 1.0,
    ) -> dict | None:
        """POST 请求，带重试。返回 dict 或 None。"""
        _headers = headers or self._headers
        _timeout = timeout or self._timeout

        for attempt in range(1, max_retries + 1):
            try:
                req = urllib.request.Request(
                    url,
                    data=json.dumps(body).encode("utf-8"),
                    headers=_headers,
                    method="POST",
                )
                with urllib.request.urlopen(req, timeout=_timeout) as resp:
                    return json.loads(resp.read().decode())
            except urllib.error.HTTPError as e:
                # 不重试的 HTTP 错误
                if e.code < 500 and e.code != 429:
                    return None
                if attempt < max_retries:
                    time.sleep(retry_delay * (2 ** (attempt - 1)))
                continue
            except Exception:
                if attempt < max_retries:
                    time.sleep(retry_delay)
                continue

        return None

    # ------------------------------------------------------------------
    # 端点方法（直接调用）
    # ------------------------------------------------------------------

    def product_info(self, asin: str) -> Result:
        """获取 ASIN 详情（慢端点）"""
        return self._call_endpoint("product-info", {"asin": asin, "_cache_key": asin})

    # 模式 → 每星级抓取页数（Woot 每页 ~20 条）
    _MODE_PAGES = {"low": 2, "mid": 5, "high": 10}
    _STAR_FILTERS = ["one_star", "two_star", "three_star", "four_star", "five_star"]
    _REVIEWS_CACHE_VERSION = "v2"

    @staticmethod
    def _review_key(item: dict) -> tuple:
        """生成稳定的评论去重键。

        上游当前经常返回空 reviewId，因此需要使用评论内容作为兜底，
        避免同一条评论被多个星级请求重复合并。
        """
        review_id = item.get("review_id") or item.get("reviewId") or item.get("id")
        if review_id:
            return ("id", str(review_id))
        return (
            "content",
            str(item.get("user_name") or item.get("userName") or item.get("author") or ""),
            str(item.get("date") or ""),
            str(item.get("title") or item.get("reviewSummary") or ""),
            str(item.get("text") or item.get("body") or ""),
        )

    @classmethod
    def _dedupe_reviews(cls, items: list) -> list:
        seen: set[tuple] = set()
        deduped = []
        for item in items:
            if not isinstance(item, dict):
                continue
            key = cls._review_key(item)
            if key in seen:
                continue
            seen.add(key)
            deduped.append(item)
        return deduped

    def reviews(self, asin: str, star_filter: str = "all", max_pages: int = 1, domain_code: str = "com") -> Result:
        """获取评论列表"""
        # v1 曾使用上游不识别的 camelCase 参数，已经污染按星级缓存。
        # 版本化 cache key 以确保修复后不会继续命中旧数据。
        cache_key = f"{self._REVIEWS_CACHE_VERSION}_{asin}"
        if star_filter != "all":
            cache_key = f"{cache_key}_{star_filter}"
        if max_pages > 1:
            cache_key = f"{cache_key}_p{max_pages}"

        # /api/amazon/reviews 的入参契约是 snake_case。camelCase 会被忽略，
        # 导致五个星级请求全部返回同一批“全部评论”。
        body = {"asin": asin, "domain_code": domain_code}
        if star_filter != "all":
            body["filter_by_star"] = star_filter
        if max_pages > 1:
            body["max_pages"] = max_pages

        result = self._call_endpoint("reviews", {**body, "_cache_key": cache_key})
        if result.code == Code.OK and isinstance(result.data, dict):
            data = dict(result.data)
            data["items"] = self._dedupe_reviews(data.get("items", []))
            result.data = data
        return result

    def reviews_by_mode(self, asin: str, mode: str = "mid", domain_code: str = "com") -> Result:
        """按模式抓取评论：low/mid/high 分别每星抓 20/50/100 条。

        并发拉取 5 个星级，每个星级独立缓存，合并返回。
        """
        pages = self._MODE_PAGES.get(mode)
        if pages is None:
            return err(Code.ERROR_PARAM, f"invalid mode: {mode}, expected low/mid/high")

        from amz.infra.concurrent import run_sync
        import logging
        _log = logging.getLogger(__name__)

        def _fetch_star(star: str) -> tuple[str, list, dict, str | None, bool]:
            result = self.reviews(asin, star_filter=star, max_pages=pages, domain_code=domain_code)
            if result.code != Code.OK:
                _log.warning("reviews_by_mode: star=%s failed: %s", star, result.message)
                return star, [], {}, result.message or str(result.code), False
            data = result.data or {}
            items = data.get("items", [])
            head = next((item for item in items if isinstance(item, dict)), {})
            context = {
                "count_ratings": data.get(
                    "count_ratings",
                    data.get("countRatings", head.get("count_ratings", head.get("countRatings"))),
                ),
                "rating": data.get(
                    "rating",
                    data.get(
                        "productRating",
                        head.get("product_rating", head.get("productRating")),
                    ),
                ),
                "review_summary": data.get(
                    "review_summary",
                    data.get(
                        "reviewSummary",
                        head.get("review_summary", head.get("reviewSummary")),
                    ),
                ),
            }
            if not isinstance(context["review_summary"], dict):
                context["review_summary"] = None
            _log.info("reviews_by_mode: star=%s fetched=%d pages=%d", star, len(items), pages)
            return star, items, context, None, result.meta.from_cache

        outcome = run_sync(self._STAR_FILTERS, _fetch_star, max_concurrency=5)

        all_items = []
        merged_context: dict = {}
        failures = [
            f"{entry['item']}: {entry['error']}"
            for entry in outcome["errors"]
        ]
        cache_hits = []
        star_order = {star: index for index, star in enumerate(self._STAR_FILTERS)}
        ordered_results = sorted(
            outcome["results"], key=lambda entry: star_order[entry[0]]
        )
        for star, items, context, failure, from_cache in ordered_results:
            all_items.extend(items)
            for key, value in context.items():
                if value is not None and key not in merged_context:
                    merged_context[key] = value
            if failure:
                failures.append(f"{star}: {failure}")
            else:
                cache_hits.append(from_cache)

        if not all_items and failures:
            return err(
                Code.ERROR_UPSTREAM,
                f"all star fetches failed: {'; '.join(failures)}",
                upstream="reviews",
                hint="check network or spider-server availability",
            )

        deduped = self._dedupe_reviews(all_items)
        hint = f"partial review data: {'; '.join(failures)}" if failures else ""
        return ok(
            data={
                "asin": asin,
                "items": deduped,
                "mode": mode,
                **merged_context,
            },
            upstream="reviews",
            from_cache=bool(cache_hits) and all(cache_hits),
            hint=hint,
        )

    def competing_lookup(
        self,
        keyword: str | None = None,
        asin: str | list[str] | None = None,
        page: int = 1,
        pages: int = 1,
    ) -> Result:
        """竞品查询：按关键词 / ASIN（支持多 ASIN + 分页）"""
        if keyword:
            body = {"keyword": keyword}
            cache_key = f"kw_{_safe_keyword_cache(keyword)}"
        elif isinstance(asin, list):
            body = {"asin": sorted(asin)}
            cache_key = "_".join(sorted(asin))
        elif asin:
            body = {"asin": asin}
            cache_key = asin
        else:
            return err(Code.ERROR_PARAM, "competing_lookup requires keyword or asin")

        if pages > 1:
            cache_key = f"{cache_key}_p1-{pages}"

        if pages == 1:
            if page > 1:
                body["page"] = page
            return self._call_endpoint("competing-lookup", {**body, "_cache_key": cache_key})

        # 多页：逐页拉取 + 合并去重
        all_items = []
        seen = set()
        base_data = None

        for p in range(1, pages + 1):
            page_body = dict(body)
            if p > 1:
                page_body["page"] = p
            result = self._call_endpoint("competing-lookup", {**page_body, "_cache_key": f"{cache_key}_p{p}"})
            if result.code != Code.OK:
                continue
            page_data = result.data
            if base_data is None:
                base_data = dict(page_data) if page_data else {}
            for item in (page_data or {}).get("items", []):
                a = item.get("asin")
                if a and a not in seen:
                    seen.add(a)
                    all_items.append(item)
            if p < pages:
                time.sleep(1)

        if base_data is None:
            return err(Code.ERROR_UPSTREAM, "competing_lookup: all pages failed")

        base_data["items"] = all_items
        return ok(data=base_data, upstream="sellersprite")

    def keyword_reverse(self, asin: str) -> Result:
        """ASIN 反查关键词"""
        return self._call_endpoint("keyword-reverse", {"asin": asin, "_cache_key": asin})

    def keyword_miner(self, keyword: str, history_date: str | None = None) -> Result:
        """关键词特征挖掘"""
        cache_key = _safe_keyword_cache(keyword)
        body = {"keyword": keyword, "history_date": history_date}
        return self._call_endpoint("keyword-miner", {**body, "_cache_key": cache_key})

    def market_research(self, keyword: str) -> Result:
        """市场研究（上游当前 403 禁用，默认走聚合降级）"""
        cache_key = _safe_keyword_cache(keyword)
        result = self._call_endpoint("market-research", {"keyword": keyword, "_cache_key": cache_key})
        if result.code == Code.ERROR_UPSTREAM:
            result.meta.hint = "market-research endpoint disabled (403), use market.snapshot with aggregate fallback"
        return result

    def product_search_1688(self, asin: str, image_url: str) -> Result:
        """1688 图搜"""
        body = {"title": image_url}
        return self._call_endpoint("product-search-1688", {**body, "_cache_key": asin})

    # -- 扩展端点 ------------------------------------------------------------

    def trends(self, keyword: str) -> Result:
        """关键词趋势"""
        return self._call_endpoint("trends", {"keyword": keyword, "_cache_key": _safe_keyword_cache(keyword)})

    def amazon_search(self, keyword: str) -> Result:
        """Amazon 关键词搜索"""
        return self._call_endpoint("amazon-search", {"keyword": keyword, "_cache_key": _safe_keyword_cache(keyword)})

    def refinements(self, keyword: str) -> Result:
        """搜索筛选维度"""
        return self._call_endpoint("refinements", {"keyword": keyword, "_cache_key": _safe_keyword_cache(keyword)})

    def rufus(self, asin: str) -> Result:
        """Rufus 问答"""
        return self._call_endpoint("rufus", {"asin": asin, "_cache_key": asin})

    def tree_list(self, type_: str) -> Result:
        """类目树"""
        return self._call_endpoint("tree-list", {"type": type_, "_cache_key": type_})

    def tree_search(self, keyword: str = "", category_name: str = "", category_id: str = "") -> Result:
        """类目搜索"""
        body = {}
        cache_parts = []
        if keyword:
            body["keyword"] = keyword
            cache_parts.append(_safe_keyword_cache(keyword))
        if category_name:
            body["category_name"] = category_name
            cache_parts.append(_safe_keyword_cache(category_name))
        if category_id:
            body["category_id"] = category_id
            cache_parts.append(category_id)
        return self._call_endpoint("tree-search", {**body, "_cache_key": "_".join(cache_parts)})

    def nr_page(self, url: str) -> Result:
        """New Releases 榜单页"""
        import hashlib
        cache_key = hashlib.md5(url.encode()).hexdigest()[:12]
        return self._call_endpoint("nr-page", {"url": url, "_cache_key": cache_key})

    def web_search(self, query: str, limit: int | None = None) -> Result:
        """火山 web 搜索"""
        body = {"query": query}
        if limit:
            body["limit"] = limit
        return self._call_endpoint("web-search", {**body, "_cache_key": _safe_keyword_cache(query)})

    # ------------------------------------------------------------------
    # 工具方法
    # ------------------------------------------------------------------

    @staticmethod
    def _make_cache_key(endpoint_id: str, params: dict) -> str:
        """生成缓存 key"""
        import hashlib
        raw = json.dumps({"ep": endpoint_id, "p": params}, sort_keys=True)
        return hashlib.md5(raw.encode()).hexdigest()[:12]


def _safe_keyword_cache(keyword: str) -> str:
    """关键词 → 安全的缓存 key"""
    key = keyword.lower().replace(" ", "_")
    for ch in ("/", "\\", ":"):
        key = key.replace(ch, "_")
    return key
