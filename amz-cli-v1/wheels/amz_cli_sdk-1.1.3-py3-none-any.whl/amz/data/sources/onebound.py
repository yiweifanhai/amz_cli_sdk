"""OneBound single-page search. No automatic retries or redirects."""
import json
import os
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import HTTPRedirectHandler, ProxyHandler, build_opener
from amz.envelope import Code, err, ok

ENDPOINT = "https://api-gw.onebound.cn/taobao/item_search/"


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def search(keyword):
    key = os.environ.get("ONEBOUND_API_KEY")
    secret = os.environ.get("ONEBOUND_API_SECRET")
    if not key or (key != "test_api_key" and not secret):
        return err(Code.ERROR_AUTH, "Missing OneBound credentials", usage={"request_count": 0})
    params = {"key": key, "q": keyword, "page": 1, "cache": "yes", "result_type": "json", "lang": "cn"}
    if secret:
        params["secret"] = secret
    try:
        with build_opener(ProxyHandler({}), NoRedirect()).open(
            ENDPOINT + "?" + urlencode(params), timeout=30
        ) as response:
            body = json.load(response)
    except HTTPError as exc:
        return err(Code.ERROR_UPSTREAM, f"OneBound HTTP {exc.code}; not retried", usage={"request_count": 1})
    except (URLError, TimeoutError, OSError, ValueError):
        return err(Code.ERROR_UPSTREAM, "OneBound request or JSON failed; not retried", usage={"request_count": 1})
    return ok(body, upstream="onebound.item_search", usage={"request_count": 1})
