"""Fetch public daily reference rates; calculation remains in Calc."""

from datetime import datetime, timezone
import json
import re
import urllib.error
import urllib.request

from amz.envelope import Code, Result, err, ok
from amz.infra.cache import file_read, file_write
from amz.registry import capability
from amz.schemas.fx import ExchangeRateInput, ExchangeRateOutput

SOURCE = "https://api.frankfurter.dev/v2/rate"
SLUG = "fx-daily-v1"


def _validate(data: dict, base: str, quote: str) -> ExchangeRateOutput:
    rate = ExchangeRateOutput.model_validate(data)
    if (rate.base, rate.quote) != (base, quote):
        raise ValueError("exchange rate currency pair does not match the request")
    age = (datetime.now(timezone.utc).date() - rate.date).days
    if age < 0 or age > 7:
        raise ValueError("exchange rate date is in the future or over 7 days old")
    return rate


@capability(
    "data.fx.rate", description="最新日参考汇率（含报价日期与来源，非盘中成交价）",
    input_model=ExchangeRateInput, output_model=ExchangeRateOutput,
)
def exchange_rate(base: str = "USD", quote: str = "CNY", force_refresh: bool = False) -> Result:
    base, quote = base.upper(), quote.upper()
    if not all(re.fullmatch(r"[A-Z]{3}", currency) for currency in (base, quote)):
        return err(Code.ERROR_PARAM, "base and quote must be three-letter currency codes")
    key = f"{base}-{quote}"
    if not force_refresh:
        cached = file_read(SLUG, key, 1)
        if cached:
            try:
                return ok(_validate(cached, base, quote).model_dump(mode="json"), from_cache=True, upstream=SOURCE)
            except (ValueError, TypeError):
                pass
    try:
        request = urllib.request.Request(f"{SOURCE}/{base}/{quote}", headers={"Accept": "application/json", "User-Agent": "amz-cli"})
        with urllib.request.urlopen(request, timeout=15) as response:
            payload = json.load(response)
        rate = _validate({**payload, "fetched_at": datetime.now(timezone.utc), "source": SOURCE, "kind": "daily_reference"}, base, quote)
    except Exception as exc:
        return err(Code.ERROR_UPSTREAM, f"exchange rate unavailable: {exc}", upstream=SOURCE,
                   hint="Retry or explicitly supply exchange_rate; no fixed-rate fallback was used.")
    data = rate.model_dump(mode="json")
    file_write(SLUG, key, 1, data)
    return ok(data, upstream=SOURCE)
