"""Local-only entity access, explicit field loading, and atomic field writes."""

from __future__ import annotations

import threading
from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, TypeAdapter

from amz.config import config
from amz.entities.base import Entity, _atomic_write, _file_lock, _serialize_value, _utc_now
from amz.schemas.entity_ref import EntityFieldMeta, EntityLoadError, EntityRef, FieldCache


class BatchLoadResult(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    entities: list[Any] = Field(default_factory=list)
    errors: list[EntityLoadError] = Field(default_factory=list)

    @property
    def missing_refs(self) -> list[EntityRef]:
        return [error.ref for error in self.errors]


class EntityStore:
    def __init__(self):
        self._types: dict[str, type[Entity]] = {}
        self._objects: dict[tuple[str, EntityRef], Entity] = {}
        self._lock = threading.RLock()

    def register(self, entity_cls: type[Entity]) -> None:
        with self._lock:
            existing = self._types.get(entity_cls.entity_type)
            if existing is not None and existing is not entity_cls:
                raise ValueError(f"duplicate entity type: {entity_cls.entity_type}")
            self._types[entity_cls.entity_type] = entity_cls

    def get(self, ref: EntityRef | str, cache_id: str | list[str] | None = None,
            fields: list[str] | None = None) -> Entity | None:
        """Read local state; the former get(type, cache_id) form also stays local."""
        with self._lock:
            if isinstance(ref, str):
                cls = self._types.get(ref)
                if cls is None or not isinstance(cache_id, str):
                    return None
                if ref in {"market", "keyword"}:
                    try:
                        identity = cls._ref_for_cache_id(cache_id)
                    except ValueError:
                        # Historical bare terms meant US with no category.
                        # A malformed structured key has unknown scope: do not guess.
                        if cache_id.lstrip().startswith("["):
                            return None
                        try:
                            identity = EntityRef(entity_type=ref, key=("US", "", cache_id))
                        except ValueError:
                            return None
                    selected = fields if fields is not None else list(set(cls.model_fields) | set(cls.lazy_fields))
                    return self.get(identity, fields=selected)
                try:
                    return cls.load(cache_id)
                except ValueError:
                    return None
            ref = EntityRef.model_validate(ref)
            cls = self._types.get(ref.entity_type)
            if cls is None:
                return None
            object_key = (str(config.cache_dir), ref)
            current = self._objects.get(object_key)
            if current is not None:
                current._remember()
            if isinstance(cache_id, list):
                fields = cache_id
            requested = set(fields or [])
            unknown = requested - set(cls.model_fields) - set(cls.lazy_fields)
            if unknown:
                raise ValueError(f"unknown fields: {sorted(unknown)}")
            core = {name for name, info in cls.model_fields.items() if name not in cls.lazy_fields and not info.exclude}
            core |= set(cls.identity_fields)
            if "core" in cls.lazy_fields:
                core.add("core")
            entity = cls.load(ref.cache_id, fields=sorted(core | requested))
            if entity is not None:
                self._objects[object_key] = entity
            return entity

    def get_or_create(self, ref: EntityRef) -> Entity:
        ref = EntityRef.model_validate(ref)
        with self._lock:
            entity = self.get(ref)
            if entity is not None:
                return entity
            cls = self._types.get(ref.entity_type)
            if cls is None:
                raise ValueError(f"unknown entity type: {ref.entity_type}")
            entity = cls(**ref.identity)
            entity._cache_id = ref.cache_id
            entity._remember()
            self._objects[(str(config.cache_dir), ref)] = entity
            return entity

    def get_many(self, refs: list[EntityRef], fields: list[str] | None = None) -> BatchLoadResult:
        entities, errors = [], []
        for ref in refs:
            ref = EntityRef.model_validate(ref)
            try:
                entity = self.get(ref, fields=fields)
                if entity is None:
                    errors.append(EntityLoadError(ref=ref, error="local cache not found or invalid"))
                else:
                    entities.append(entity)
            except (OSError, ValueError, TypeError) as exc:
                errors.append(EntityLoadError(ref=ref, error=str(exc)))
        return BatchLoadResult(entities=entities, errors=errors)

    def get_field_meta(self, refs: list[EntityRef], field_name: str) -> list[EntityFieldMeta]:
        result = []
        for ref in refs:
            ref = EntityRef.model_validate(ref)
            cls = self._types.get(ref.entity_type)
            payload = None
            if cls is not None:
                candidates = cls._cache_candidates(ref.cache_id)
                for path in candidates:
                    if path.exists():
                        payload = cls._read_cache_payload(path, ref.cache_id)
                        if payload is not None or path == candidates[0]:
                            break
            entries = payload.get("fields", {}) if payload else {}
            entry = entries.get(field_name, {})
            valid = bool(cls and self._valid_meta(cls, entries, field_name, set()))
            state = entry.get("state", "missing")
            if state == "ready" and not valid:
                state = "stale"
            result.append(EntityFieldMeta(
                ref=ref, field_name=field_name, state=state,
                updated_at=entry.get("updated_at"), ttl_valid=valid,
                last_params=entry.get("last_params", {}), fetch_key=entry.get("fetch_key"),
                version=entry.get("version"), error=entry.get("error") if payload else "local cache not found or invalid",
            ))
        return result

    @classmethod
    def _valid_meta(cls, entity_cls: type[Entity], entries: dict, field_name: str, seen: set[str]) -> bool:
        entry = entries.get(field_name, {})
        if entry.get("state") != "ready" or field_name in seen:
            return False
        spec = entity_cls.lazy_fields.get(field_name)
        if spec is None:
            return True
        if entry.get("version") != spec.version:
            return False
        method = getattr(entity_cls, spec.method)
        loader = getattr(method, "__entity_loader__", method)
        try:
            expected_key = Entity._make_call_key(None, loader, (), entry.get("last_params", {}),
                                                version=spec.version, source=spec.source)
            if entry.get("fetch_key") != expected_key:
                return False
        except (TypeError, ValueError):
            return False
        try:
            stamp = datetime.fromisoformat(entry["updated_at"].replace("Z", "+00:00"))
            if (datetime.now(timezone.utc) - stamp).total_seconds() > spec.ttl_hours * 3600:
                return False
        except (ValueError, TypeError, KeyError, AttributeError):
            return False
        for dependency in spec.invalidation_dependencies:
            other = entries.get(dependency, {})
            if entry.get("provided") and not other.get("updated_at"):
                continue
            if dependency not in spec.depends and not other.get("updated_at"):
                continue
            if not cls._valid_meta(entity_cls, entries, dependency, seen | {field_name}):
                return False
            if other.get("updated_at") and other["updated_at"] > entry["updated_at"]:
                return False
        return True

    def save_field(self, ref: EntityRef, field_name: str, field: FieldCache | dict) -> None:
        ref = EntityRef.model_validate(ref)
        field = FieldCache.model_validate(field)
        cls = self._types.get(ref.entity_type)
        if cls is None:
            raise ValueError(f"unknown entity type: {ref.entity_type}")
        info = cls.model_fields.get(field_name)
        if info is None and field_name not in cls.lazy_fields:
            raise ValueError(f"unknown field: {field_name}")
        if info is not None and info.exclude:
            raise ValueError(f"field is not persistent: {field_name}")
        if field_name in cls.identity_fields:
            raise ValueError("identity fields cannot be changed through save_field")
        value = None
        if field.state == "ready":
            value = TypeAdapter(info.annotation).validate_python(field.value) if info is not None else field.value
        entry = field.model_dump(mode="python")
        entry["value"] = _serialize_value(value)
        if field.state == "ready" and field.updated_at is None:
            entry["updated_at"] = _utc_now()
        spec = cls.lazy_fields.get(field_name)
        if spec is not None:
            entry["version"] = field.version or spec.version
            if entry["fetch_key"] is None:
                method = getattr(cls, spec.method)
                loader = getattr(method, "__entity_loader__", method)
                entry["fetch_key"] = Entity._make_call_key(None, loader, (), field.last_params,
                                                           version=spec.version, source=spec.source)
        path = cls._cache_file(ref.cache_id)
        with cls._save_lock(path), _file_lock(path):
            payload = cls._read_cache_payload(path, ref.cache_id) if path.exists() else None
            if path.exists() and payload is None:
                raise ValueError("refusing to overwrite invalid entity cache")
            if payload is None:
                payload = {"schema": "amz.entity.v3", "entity_type": ref.entity_type,
                           "cache_id": ref.cache_id, "ref": ref.model_dump(mode="json"),
                           "fields": {name: {"state": "ready", "value": value} for name, value in ref.identity.items()}}
            payload["fields"][field_name] = entry
            pending = [field_name]
            while pending:
                changed = pending.pop()
                for name, rule in cls.lazy_fields.items():
                    if changed in rule.invalidation_dependencies and name in payload["fields"]:
                        previous = payload["fields"][name]
                        if previous.get("state") != "missing":
                            payload["fields"][name] = {**previous, "state": "missing", "updated_at": None, "value": None}
                            pending.append(name)
            payload["saved_at"] = _utc_now()
            _atomic_write(path, payload)

    def list_types(self) -> list[str]:
        with self._lock:
            return sorted(self._types)

    def classes(self) -> list[type[Entity]]:
        with self._lock:
            return list(self._types.values())


EntityRegistry = EntityStore
entity_store = EntityStore()
entity_registry = entity_store
