"""
Market 实体：绑定到关键词的市场分析。

Market 以 keyword term 为标识，聚合竞品列表 → 市场画像统计 → 市场画像 → 机会分析。
与 Keyword 实体的区别：Keyword 关注词本身的特征（搜索量、趋势、评分），Market 关注
该词对应的市场竞争格局（价格带、垄断度、卖家结构、机会缺口）。
"""

from __future__ import annotations

import inspect
from typing import Annotated, Any, Callable, ClassVar, cast

from pydantic import BaseModel, Field, PrivateAttr

from amz.config import config
from amz.entities.base import Entity, EnrichSpec, lazy_field
from amz.envelope import Result, ok, err, Code
from amz.schemas.data_outputs import CompetingItemOutput
from amz.schemas.amazon_analysis import AmazonMarketSummary
from amz.schemas.entity_ref import EntityRef, market_ref
from amz.schemas.cosmo import MarketCosmo


SummaryPages = Annotated[int, Field(ge=1, le=3)]
MinSuccess = Annotated[int, Field(ge=1)]


# -- 市场分析辅助模型 -----------------------------------------------------------

class PriceBand(BaseModel):
    """价格带"""
    label: str = ""
    min: float = 0.0
    max: float = 0.0
    count: int = 0
    share_pct: float = 0.0


class PriceStats(BaseModel):
    """价格统计"""
    p25: float | None = None
    p50: float | None = None
    p75: float | None = None
    band_count: int = 0
    bands: list[PriceBand] = Field(default_factory=list)


class RatingStats(BaseModel):
    """评分统计"""
    avg: float | None = None
    dist: dict[str, int] = Field(default_factory=dict)


class MonopolyStats(BaseModel):
    """垄断度统计"""
    cr10: float | None = None       # Top10 品牌份额
    cr20: float | None = None       # Top20 品牌份额
    top_brand_share: float | None = None


class SellerStats(BaseModel):
    """卖家结构"""
    total: int = 0
    cn_pct: float | None = None
    amazon_pct: float | None = None


class MarketSample(BaseModel):
    """The selected local sample used to calculate a market result."""
    term: str
    marketplace: str
    category: str = ""
    pages: int | None = None
    product_count: int = 0
    source: str
    updated_at: str | None = None


class MarketStats(BaseModel):
    """市场画像统计（calc.market.stats 输出）"""
    price: PriceStats = Field(default_factory=PriceStats)
    rating: RatingStats = Field(default_factory=RatingStats)
    listing_date: dict[str, Any] = Field(default_factory=dict)    # {median, new_release_pct}
    reviews: dict[str, Any] = Field(default_factory=dict)         # {median, count_dist}
    monopoly: MonopolyStats = Field(default_factory=MonopolyStats)
    sellers: SellerStats = Field(default_factory=SellerStats)
    aplus_video_pct: float | None = None
    return_rate: dict[str, Any] | None = None                     # {pct, risk}
    sample: MarketSample | None = None


class MarketProfile(BaseModel):
    """8 维市场画像"""
    keyword: str = ""
    dimensions: dict[str, Any] = Field(default_factory=dict)
    overall_score: float = 0.0
    sample: MarketSample | None = None


class Opportunity(BaseModel):
    """市场机会"""
    keyword: str = ""
    gaps: list[dict[str, Any]] = Field(default_factory=list)
    proposals: list[dict[str, Any]] = Field(default_factory=list)
    opportunity_score: float = 0.0
    sample: MarketSample | None = None


# -- Market 实体 ---------------------------------------------------------------

class Market(Entity):
    """Market 实体 — 以 keyword term 为标识的市场竞争格局"""

    entity_type: ClassVar[str] = "market"
    identity_fields: ClassVar[tuple[str, ...]] = ("marketplace", "category", "term")
    _sample_fields: ClassVar[frozenset[str]] = frozenset({
        "products", "stats", "profile", "opportunity", "summary", "cosmo",
    })

    lazy_fields: ClassVar[dict[str, EnrichSpec]] = {
        "product_refs": EnrichSpec(
            field="product_refs", method="get_product_refs", depends=[],
            source="/competing-lookup", ttl_hours=24,
        ),
        "products": EnrichSpec(
            field="products", method="get_products", depends=["product_refs"],
            source="entity.product", ttl_hours=24,
            dependency_params={"product_refs": ["pages"]},
        ),
        "stats": EnrichSpec(
            field="stats", method="get_stats",
            depends=["products"], source="calc.market.stats", ttl_hours=24,
            dependency_params={"products": ["pages"]}, version="2",
        ),
        "profile": EnrichSpec(
            field="profile", method="get_profile",
            depends=["stats"], source="calc.market.profile", ttl_hours=24,
            dependency_params={"stats": ["pages"]}, version="2",
        ),
        "opportunity": EnrichSpec(
            field="opportunity", method="get_opportunity",
            depends=["stats"], source="calc.market.opportunity", ttl_hours=24,
            dependency_params={"stats": ["pages"]}, version="2",
        ),
        "summary": EnrichSpec(
            field="summary", method="get_summary", depends=["products"],
            source="analysis.market.classify", ttl_hours=24,
            dependency_params={"products": ["pages"]},
            version="3",
        ),
        "cosmo": EnrichSpec(
            field="cosmo", method="get_cosmo", depends=["product_refs"],
            source="analysis.market.cosmo", ttl_hours=168,
            dependency_params={"product_refs": ["pages"]},
        ),
    }

    # -- 核心字段 ----------------------------------------------------------------

    term: str = Field(min_length=1, json_schema_extra={"alias": "term"})
    marketplace: str = Field(default="US", json_schema_extra={"alias": "marketplace"})
    category: str = Field(default="", json_schema_extra={"alias": "category"})

    # -- lazy 字段 ---------------------------------------------------------------

    product_refs: list[EntityRef] | None = None
    products: list[CompetingItemOutput] | None = Field(default=None, exclude=True)
    product_sources: list[dict[str, Any]] = Field(default_factory=list)
    cosmo_sources: list[dict[str, Any]] = Field(default_factory=list)
    cosmo: MarketCosmo | None = None
    _cosmo_inputs: list[dict[str, Any]] = PrivateAttr(default_factory=list)
    _cosmo_failed: list[dict[str, Any]] = PrivateAttr(default_factory=list)
    stats: MarketStats | None = None              # 类型化的市场画像统计
    profile: MarketProfile | None = None           # 类型化的 8 维市场画像
    opportunity: Opportunity | None = None          # 类型化的市场机会分析
    summary: AmazonMarketSummary | None = None

    # ------------------------------------------------------------------
    # 工厂方法
    # ------------------------------------------------------------------

    @classmethod
    def fetch(cls, term: str, marketplace: str = "US", category: str = "") -> Market | None:
        """创建 Market 实体（不立即拉取数据）"""
        ref = market_ref(marketplace, category, term)
        cached = cls.load(ref.cache_id)
        if cached:
            return cached
        instance = cls(**ref.identity)
        instance.save()
        return instance

    # ------------------------------------------------------------------
    # 实体方法
    # ------------------------------------------------------------------

    def _selected_pages(self) -> int:
        """Keep the persisted sample selection when a caller omits pages."""
        return self._last_params.get("product_refs", {}).get("pages", 2)

    def _field_cache_key(self, field: str, kwargs: dict[str, Any]) -> str | None:
        if field in self._sample_fields and kwargs.get("pages") is None:
            kwargs = {**kwargs, "pages": self._selected_pages()}
        return super()._field_cache_key(field, kwargs)

    def _resolve_lazy(
        self, field: str, loader: Callable[..., Result],
        args: tuple[Any, ...], kwargs: dict[str, Any],
    ) -> Result:
        if field in self._sample_fields or field == "product_refs":
            # A partial load may omit sample metadata; read it before choosing a
            # default. This remains a local cache read, not an upstream request.
            if self._loaded_fields is not None and "product_refs" not in self._loaded_fields:
                restored = type(self).load(
                    self._cache_id, use_identity=False,
                    fields=sorted(self._loaded_fields | {"product_refs"}),
                )
                if restored is not None:
                    self._copy_state_from(restored)
            try:
                bound = inspect.signature(loader).bind(self, *args, **kwargs)
                bound.apply_defaults()
            except TypeError as exc:
                return err(Code.ERROR_PARAM, str(exc))
            params = {name: value for name, value in bound.arguments.items() if name != "self"}
            if field in self._sample_fields and params["pages"] is None:
                params["pages"] = self._selected_pages()
            if type(params["pages"]) is not int or not 1 <= params["pages"] <= 3:
                return err(Code.ERROR_PARAM, "pages must be an integer between 1 and 3")
            args, kwargs = (), params
        return super()._resolve_lazy(field, loader, args, kwargs)

    def _sample_info(self) -> MarketSample:
        pages = self._last_params.get("product_refs", {}).get("pages")
        return MarketSample(
            term=self.term, marketplace=self.marketplace, category=self.category,
            pages=pages, product_count=len(self.product_refs or []),
            source=self.lazy_fields["product_refs"].source if pages is not None else "local_product_refs",
            updated_at=self._fetched_at.get("product_refs"),
        )

    def model_post_init(self, __context: Any) -> None:
        super().model_post_init(__context)
        if isinstance(__context, dict) and __context.get("entity_loading"):
            return
        if self.products is not None and self.product_refs is None:
            self.product_refs = self._store_products(self.products)
            self._mark_fetched("product_refs")
            # Declared products are a ready local projection of the supplied sample.
            self._set_products_projection()

    def _store_products(self, rows: list) -> list[EntityRef]:
        from amz.entities.product import Product
        refs = []
        for row in rows:
            data = row.model_dump(mode="python") if isinstance(row, BaseModel) else row
            product = Product.from_competitor(data, marketplace=self.marketplace)
            if product is not None and product.ref not in refs:
                refs.append(product.ref)
        return refs

    def _writeback(self, field: str, value: Any) -> None:
        if field == "products":
            self.product_refs = self._store_products(value)
            self._last_params.pop("product_refs", None)
            self._mark_fetched("product_refs")
            self._set_products_projection()
            self.save()
            return
        super()._writeback(field, value)

    def _set_products_projection(self) -> Result | None:
        """Load the current local Product facts without persisting copies in Market."""
        from amz.entities.product import Product
        rows = []
        sources = []
        for ref in self.product_refs or []:
            if ref.entity_type != "product" or ref.identity["marketplace"] != self.marketplace:
                return err(Code.ERROR_PARAM, "market product references must match the marketplace")
            product = Product.load(ref.cache_id)
            if product is None:
                return err(Code.ERROR_MISSING_FIELDS, "referenced Product is not available locally", missing=[ref.cache_id])
            rows.append(CompetingItemOutput.model_validate(product.to_competitor()))
            sources.append({
                "ref": ref.model_dump(mode="json"),
                "updated_at": product._fetched_at.get("core"),
                "fetch_key": product._fetch_keys.get("core"),
            })
        stamps = sources
        if stamps != self.product_sources:
            self._invalidate_dependents("products")
            self.product_sources = stamps
        self.products = rows
        self._fetched_at["products"] = self._fetched_at.get("product_refs", "")
        pages = self._last_params.get("product_refs", {}).get("pages", 2)
        self._last_params["products"] = {"pages": pages}
        self._fetch_keys["products"] = (
            self._active_fetch_keys.get("products")
            or self._field_cache_key("products", {"pages": pages})
        )
        return None

    @lazy_field("product_refs")
    def get_product_refs(self, pages: SummaryPages = 2) -> Result:
        """Fetch the market sample and save only Product references on this Market."""
        if self.marketplace != "US" or self.category:
            return err(Code.ERROR_PARAM, "upstream market data currently supports marketplace US and no category filter only")
        from amz.data.market import market_competitors
        result = market_competitors(keyword=self.term, pages=pages)
        if result.code == Code.OK:
            refs = self._store_products((result.data or {}).get("items", []))
            self._writeback("product_refs", refs)
        return result

    @lazy_field("products")
    def get_products(self, pages: SummaryPages | None = None) -> Result:
        """Return the legacy competitor rows projected from locally stored Products."""
        failure = self._set_products_projection()
        if failure is not None:
            return failure
        self.save()
        return ok(data=self.products)

    def _prepare_dependencies(self, field: str, call_params: dict) -> Result | None:
        if field in {"products", "stats", "summary", "profile", "opportunity"} and self.product_refs is not None:
            failure = self._set_products_projection()
            if failure is not None:
                return failure
        if field in {"profile", "opportunity"} and self.stats is None:
            result = self.get_stats(pages=call_params.get("pages"))
            if result.code != Code.OK:
                return result
        if field != "cosmo":
            return None
        if call_params.get("min_success", 1) < 1:
            return err(Code.ERROR_PARAM, "min_success must be at least 1")
        return self._prepare_cosmo(call_params)

    def _prepare_cosmo(self, call_params: dict) -> Result | None:
        from amz.entities.store import entity_store
        use_image = bool(call_params.get("use_image", True) and config.cosmo_use_images)
        products = []
        failed = []
        stamps = []
        for ref in self.product_refs or []:
            if ref.entity_type != "product" or ref.identity["marketplace"] != self.marketplace:
                return err(Code.ERROR_PARAM, "market product references must match the marketplace")
            try:
                product = entity_store.get_or_create(ref)
                result = product.get_cosmo(
                    model=call_params.get("product_model", "lite"),
                    use_image=use_image,
                )
            except (OSError, ValueError, RuntimeError) as exc:
                failed.append(ref.model_dump(mode="json"))
                stamps.append({"ref": ref.model_dump(mode="json"), "state": "error", "error": str(exc)})
                continue
            stamp = {
                "ref": ref.model_dump(mode="json"),
                "state": result.code.value,
                "updated_at": product._fetched_at.get("cosmo"),
                "fetch_key": product._fetch_keys.get("cosmo"),
                "details_updated_at": product._fetched_at.get("product_details"),
            }
            stamps.append(stamp)
            if result.code != Code.OK or product.cosmo is None:
                failed.append(ref.model_dump(mode="json"))
                continue
            has_image = bool(use_image and (product.images or product.aplus_images))
            products.append({
                "ref": ref.model_dump(mode="json"),
                "cosmo": product.cosmo.model_dump(mode="json"),
                "updated_at": stamp["updated_at"] or "",
                "source": "listing_and_image" if has_image else "listing",
            })
        self._cosmo_inputs = products
        self._cosmo_failed = failed
        if stamps != self.cosmo_sources:
            self._invalidate_field("cosmo")
            self.cosmo_sources = stamps
            self.save()
        minimum = call_params.get("min_success", 1)
        if len(products) < minimum:
            self._invalidate_field("cosmo")
            self.save()
            return err(Code.ERROR_UPSTREAM, f"COSMO has {len(products)} successful products; requires at least {minimum}")
        return None

    @lazy_field("cosmo")
    def get_cosmo(
        self,
        pages: SummaryPages | None = None,
        min_success: MinSuccess = 1,
        model: str = "lite",
        product_model: str = "lite",
        use_image: bool = True,
    ) -> Result:
        """Aggregate verified Product COSMO results with explicit partial-failure coverage."""
        if min_success < 1:
            return err(Code.ERROR_PARAM, "min_success must be at least 1")
        from amz.analysis.market.cosmo import market_cosmo
        result = market_cosmo(
            products=self._cosmo_inputs,
            failed_product_refs=self._cosmo_failed,
            min_success=min_success,
            model=model,
        )
        if result.code == Code.OK:
            self._writeback("cosmo", MarketCosmo.model_validate(result.data))
        return result

    @lazy_field("stats")
    def get_stats(self, pages: SummaryPages | None = None) -> Result:
        """计算市场画像统计（价格带/评分/上架时间/垄断度/卖家结构）"""
        from amz.calc.market import calculate_stats
        stats = calculate_stats([
            item.model_dump(mode="python") for item in (self.products or [])
        ])
        stats["sample"] = self._sample_info()
        self._writeback("stats", stats)
        return ok(data=self.stats)

    @lazy_field("profile")
    def get_profile(self, pages: SummaryPages | None = None) -> Result:
        """8 维市场画像（综合评分，委托 calc.market.calculate_profile）"""
        from amz.calc.market import calculate_profile
        profile = calculate_profile(
            self.stats.model_dump(mode="python"), keyword=self.term,
        )
        profile["sample"] = self.stats.sample
        self._writeback("profile", profile)
        return ok(data=self.profile)

    @lazy_field("opportunity")
    def get_opportunity(self, pages: SummaryPages | None = None) -> Result:
        """市场机会/缺口分析（gap + 微改造提案 + 机会分，委托 calc.market.opportunity）"""
        from amz.calc.market import calculate_opportunity_score
        opportunity = calculate_opportunity_score(
            self.stats.model_dump(mode="python"), keyword=self.term,
        )
        opportunity["sample"] = self.stats.sample
        self._writeback("opportunity", opportunity)
        return ok(data=self.opportunity)

    @lazy_field("summary")
    def get_summary(self, pages: SummaryPages | None = None, model: str = "pro") -> Result:
        """按解决方案分类竞品样本，概述人群、场景并保留 ASIN"""
        from amz.analysis.market import market_classify

        result = market_classify(
            term=self.term,
            products=[{"asin": p.asin, "title": p.title} for p in (self.products or [])],
            model=model,
        )
        if result.code == Code.OK:
            self._writeback("summary", AmazonMarketSummary.model_validate(result.data))
        return result

    # ------------------------------------------------------------------
    # Python object API
    # ------------------------------------------------------------------

    def require_products(self, pages: SummaryPages | None = None) -> list[CompetingItemOutput]:
        """Return lightweight competitors, fetching them when needed.

        These are deliberately summaries rather than full ``Product`` entities so a
        ``Product -> Market -> products`` traversal cannot recursively embed another
        complete Product/Market object graph.
        """
        return cast(
            list[CompetingItemOutput],
            self._require_field_value("products", self.get_products(pages=pages)),
        )

    def require_stats(self, pages: SummaryPages | None = None) -> MarketStats:
        """Return typed market statistics, loading products first when needed."""
        return cast(
            MarketStats,
            self._require_field_value("stats", self.get_stats(pages=pages)),
        )

    def require_profile(self, pages: SummaryPages | None = None) -> MarketProfile:
        """Return the typed eight-dimension market profile."""
        return cast(
            MarketProfile,
            self._require_field_value("profile", self.get_profile(pages=pages)),
        )

    def require_opportunity(self, pages: SummaryPages | None = None) -> Opportunity:
        """Return the typed market opportunity assessment."""
        return cast(
            Opportunity,
            self._require_field_value("opportunity", self.get_opportunity(pages=pages)),
        )

    def require_summary(self, pages: SummaryPages | None = None, model: str = "pro") -> AmazonMarketSummary:
        """Return the typed solution summary, loading its product sample when needed."""
        return cast(
            AmazonMarketSummary,
            self._require_field_value("summary", self.get_summary(pages=pages, model=model)),
        )
