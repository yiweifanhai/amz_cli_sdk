"""
PipelineLoader — 多根目录发现，统一归一为 ``PipelineSpec``。

查找优先级（高 → 低）：

1. ``~/.amz/composite/``（用户自建）
2. ``AMZ_COMPOSITE_DIR``（项目/团队目录）
3. Python entry points 组 ``amz.composite``（pip 插件包，可选）
4. ``amz/composite/``（内置，最低）

每个 pipeline 子目录可含：

- ``spec.json`` / ``spec.yaml`` / ``spec.yml``（声明式 spec，优先）
- ``pipeline.py``（导出 ``PIPELINE`` 或 ``SPEC``）

同名冲突按优先级取最高者。所有路径统一归一为 ``PipelineSpec``。
"""

from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path

from amz.config import config
from amz.infra.paths import PathBoundaryError, configured_root, confined_path, validate_component
from amz.composite.spec import PipelineSpec


def builtin_root() -> Path:
    """内置 pipeline 目录（``amz/composite/`` 本目录）。"""
    return Path(__file__).parent


def pipeline_roots() -> list[Path]:
    """按优先级返回全部 pipeline 根目录。"""
    if config.is_managed:
        if config.get("composite", "mode") != "declarative":
            raise ValueError("managed composite mode must be declarative")
        return [configured_root(root) for root in config.get("composite", "roots", default=[])]
    roots: list[Path] = []
    roots.append(Path(os.path.expanduser("~/.amz/composite")))

    env = os.environ.get("AMZ_COMPOSITE_DIR")
    if env:
        roots.append(Path(env).expanduser())

    # entry points 组 amz.composite（值形如 "pkg.composite:path_attr"）
    try:
        from importlib.metadata import entry_points

        eps = entry_points()
        group = eps.select(group="amz.composite") if hasattr(eps, "select") else eps.get("amz.composite", [])
        for ep in group:
            try:
                obj = ep.load()
                roots.append(Path(obj if isinstance(obj, (str, os.PathLike)) else str(obj)))
            except Exception:
                continue
    except Exception:
        pass

    roots.append(builtin_root())
    return roots


def list_pipeline_specs() -> list[PipelineSpec]:
    """列出全部 pipeline（去重后按优先级取最高者），按名称排序。"""
    return sorted(_discover().values(), key=lambda s: s.name)


def get_pipeline_spec(name: str) -> PipelineSpec:
    """按名称取 PipelineSpec。

    Raises:
        ValueError: pipeline 不存在
        ImportError: pipeline.py 导入失败
    """
    validate_component(name, label="pipeline name")
    discovered = _discover()
    if name not in discovered:
        raise ValueError(f"unknown pipeline: '{name}'")
    return discovered[name]


def discover_path(name: str) -> Path | None:
    """返回某 pipeline 的源目录（用于写回 / 展示来源）。"""
    validate_component(name, label="pipeline name")
    discovered = _discover()
    spec = discovered.get(name)
    if spec is None:
        return None
    # _discover 返回 {name: spec}；源目录需另行跟踪
    for root in pipeline_roots():
        d = confined_path(root, name)
        if d.is_dir():
            return d
    return None


def _discover() -> dict[str, PipelineSpec]:
    """扫描全部根目录，按优先级去重，返回 ``{name: PipelineSpec}``。"""
    result: dict[str, PipelineSpec] = {}
    for root in pipeline_roots():
        if not root.is_dir():
            continue
        for d in sorted(root.iterdir()):
            d = confined_path(root, d.name)
            if not d.is_dir() or d.name.startswith("_") or d.name.startswith("."):
                continue
            if d.name in result:
                continue  # 高优先级已占用
            spec = _load_dir(d)
            if spec is not None:
                result[d.name] = spec
    return result


def _load_dir(d: Path) -> PipelineSpec | None:
    # 声明式 spec 优先
    for fname in ("spec.json", "spec.yaml", "spec.yml"):
        f = confined_path(d, fname)
        if f.exists():
            validate_component(d.name, label="pipeline name")
            pipeline = _load_spec_file(f)
            if config.is_managed:
                if pipeline.name != d.name:
                    raise PathBoundaryError("pipeline name must match its directory")
                pipeline.validate_managed()
            return pipeline
    # pipeline.py
    if config.is_managed:
        return None
    f = d / "pipeline.py"
    if f.exists():
        validate_component(d.name, label="pipeline name")
        return _load_pipeline_py(f, d.name)
    return None


def _load_spec_file(f: Path) -> PipelineSpec:
    if f.suffix == ".json":
        data = json.loads(f.read_text(encoding="utf-8"))
    else:
        import yaml

        data = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
    return PipelineSpec(**data)


def _load_pipeline_py(f: Path, name: str) -> PipelineSpec:
    """动态导入 ``pipeline.py``，取 ``SPEC`` 或 ``PIPELINE``，归一为 PipelineSpec。"""
    if config.is_managed:
        raise ValueError("managed composite cannot load Python plugins; use a JSON/YAML spec")
    module_name = f"_amz_composite_plugin_{name}_pipeline"
    spec = importlib.util.spec_from_file_location(module_name, f)
    if spec is None or spec.loader is None:
        raise ImportError(f"failed to load spec for {f}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    obj = getattr(module, "SPEC", None)
    if obj is not None:
        if isinstance(obj, PipelineSpec):
            return obj
        return PipelineSpec(**obj)

    pipeline = getattr(module, "PIPELINE", None)
    if pipeline is None:
        raise ImportError(f"module {module_name} does not export PIPELINE or SPEC")
    if hasattr(pipeline, "to_spec"):
        return pipeline.to_spec()
    raise ImportError(f"module {module_name} PIPELINE is not a Pipeline instance")
