"""
amz-cli-sdk: Amazon 数据 SDK。

三层架构：infra → data/calc → entities/analysis/composite/agents

用法::

    from amz import registry, config, Result, Code, ok, err

    # 原子能力
    result = registry.invoke("product.get", {"asin": "B0XXXX"})

    # 实体（也是 Pydantic 模型，字段定义一次）
    from amz.entities.product import Product
    p = Product.fetch("B0XXXX")
    p.get_finance(shipping_method="fast")
    p.model_dump()              # → 完整字段 dict
    p.model_json_schema()       # → JSON Schema

    # 固定 workflow
    result = registry.invoke("composite.product_analysis", {"asins": [...]})

    # Agent 判断
    result = registry.invoke("agent.risk.entry", {"asin": "B0XXXX"})

数据流
------

    data/  data/normalizer.py  entities/            calc/  analysis/
    ─────  ───────────────────  ─────────            ─────  ─────────
    HTTP → normalize → dict → Entity(BaseModel)  →  纯函数  LLM推理
           (字段标准化)         (聚合根+缓存+lazy)    (确定)  (原子)

层级速览
--------

========= ======================================= ==========================================
层级       目录                                    职责
========= ======================================= ==========================================
L3         composite/  agents/                     复合能力产出（固定 DAG / Agent 判断）
L2         entities/  analysis/                    实体聚合 + 原子推理（LLM 固定框架）
L1         data/  calc/                            数据获取 + 确定性计算
L0         infra/                                  基础设施（llm/cache/http/store/parse）
========= ======================================= ==========================================


datatypes/ 目录已删除：所有模型（实体 + 辅助）统一在 entities/，字段 alias 直接写在 Field 定义中。
"""

__version__ = "1.1.3"

from amz.envelope import Result, Code, ok, err
from amz.config import config

config.bootstrap()

from amz.registry import registry, capability
from amz.discovery import load_builtin_capabilities


def call(capability_id: str, params=None, **kwargs) -> Result:
    """调用一个原子能力。

    ``params`` 可以是普通 mapping，也可以直接传该能力的 Pydantic InputModel。
    这是 Python SDK 的最短稳定入口；返回值始终是 :class:`Result`。
    """
    return registry.invoke(capability_id, params, **kwargs)

# SDK 的文档用法是 ``from amz import registry`` 后直接 invoke；因此包导入时
# 必须完成内置能力发现，而不能只依赖 CLI 的私有导入函数。
load_builtin_capabilities()

__all__ = [
    "Result", "Code", "ok", "err", "config", "registry", "capability",
    "call", "__version__",
]
