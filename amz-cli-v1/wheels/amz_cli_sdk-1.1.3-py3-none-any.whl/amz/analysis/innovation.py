"""Compatibility facade for Product innovation analysis."""

import re

from amz.envelope import Result, ok, err, Code
from amz.registry import capability
from amz.infra.llm import chat_json
from amz.analysis.base import require_json
from amz.schemas.analysis_inputs import CompareInnovationInput, MaterialAssessInput
from amz.schemas.innovation import (
    Barrier, BarrierAnalysis, CopyabilityOutput, MaterialAssessmentOutput,
    ComparativeInnovationOutput,
)
from amz.analysis.product.innovation import (
    COPYABILITY_PROMPT, COPYABILITY_SYSTEM_PROMPT, COPYABILITY_USER_PROMPT,
    MATERIAL_PROMPT, _assess_copyability, _assess_material, _rating_value,
)



from amz.analysis.product.compare import _TRAILING_PAREN_CONTENT, _normalize_dimension_tag, INNOVATION_COMPARE_SYSTEM_PROMPT, INNOVATION_COMPARE_STEPS, _compare_innovation


def assess_copyability(
    asin: str = "",
    image_url: str = "",
    innovation_desc: str = "",
    description: str = "",
    reviews: list[dict] | None = None,
    title: str = "",
) -> Result:
    return _assess_copyability(
        asin, image_url, innovation_desc, description, reviews, title, llm_call=chat_json,
    )


def assess_material(product_info: dict, image_url: str = "") -> Result:
    return _assess_material(product_info, image_url, llm_call=chat_json)


def compare_innovation(new_product: dict, benchmarks: list[dict] | None = None) -> Result:
    return _compare_innovation(
        new_product=new_product, benchmarks=benchmarks,
        llm_call=chat_json,
    )
