"""Compatibility imports for market analyses; implementations live in market/."""
from amz.infra.llm import chat_json
from amz.schemas.market_analysis import (
    _MarketModel, SuccessFactor, SuccessFactorsOutput, MarketPoint, MarketGapOutput,
    RenovationProposal, ProposalsOutput,
)
from amz.analysis.market._output import _JSON_ONLY, _llm_output
from amz.analysis.market.success_factors import SUCCESS_FACTORS_PROMPT, market_success_factors
from amz.analysis.market.gap import GAP_PROMPT, market_gap
from amz.analysis.market.proposals import PROPOSALS_PROMPT, market_proposals
