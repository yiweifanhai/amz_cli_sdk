"""Product listing insert capability."""

from __future__ import annotations
from amz.envelope import Result
from amz.registry import capability
from amz.infra.llm import chat_json
from amz.schemas.analysis_inputs import ListingMicroInsertInput
from amz.schemas.listing import ListingOutput, TextInsertionOutput, MicroInsertOutput
from amz.analysis.product._listing import _json_output, listing_rules, validate_listing
from amz.analysis._compat import resolve_chat_json

_DEFAULT_CHAT_JSON = chat_json


MICRO_INSERT_PROMPT = """# Role: Amazon Listing 微调编辑器

你是一个精准的文本微调编辑器，不是创作者。你的任务是将指定关键词自然融入 Listing 文本，做最小幅度的改动。

# 插入计划:
{insert_plan}

# 硬约束（必须遵守）:
1. **只修改需要插入关键词的部分**，其余文本保持原样一字不差
2. **不要改变任何 Bullet 的主题和核心卖点**
3. **不要删除已有的关键词**
4. **每条 Bullet 的改动不超过 15 个单词**
5. **保持每条 Bullet 不超过 250 字符**
6. **非媒介类 Title 不超过 75 字符（含空格）**
7. 没有被分配关键词的 Bullet，原文照抄不动

# 插入技巧:
- 将关键词融入现有句子，替换同义表述或扩展描述
- 如果原文说 "cooking tools"，可以改为 "cooking tools and baking utensils"
- 优先在句尾或并列结构处插入
- 保持语法正确和自然流畅

# 输出格式 (纯 JSON):
```json
{{
  "title_differentiation": "商品亮点，最多 125 字符，逗号分隔短语",
  "title": "修改后的完整标题",
  "bullet_points": [
    "BP1 文本（修改后或原文）",
    "BP2 文本",
    "BP3 文本",
    "BP4 文本",
    "BP5 文本"
  ]
}}
```"""


@capability(
    "analysis.listing.micro-insert",
    description="在文本中自然插入关键词（微插入，最小改动）",
    input_model=ListingMicroInsertInput,
    output_model=MicroInsertOutput,
    requires=["product.get"],
)
def listing_micro_insert(
    title: str = "",
    bullet_points: list[str] | None = None,
    insert_plan: dict | None = None,
    text: str = "",
    keywords: list[str] | None = None,
    feedback: str = "",
    brand: str = "",
    forbidden_terms: list[str] | None = None,
    media_title_limit: int | None = None,
    title_differentiation: str = "",
) -> Result:
    return _run_listing_micro_insert(
        title=title, bullet_points=bullet_points, insert_plan=insert_plan, text=text, keywords=keywords, feedback=feedback,
        brand=brand, forbidden_terms=forbidden_terms, media_title_limit=media_title_limit,
        title_differentiation=title_differentiation,
        llm_call=resolve_chat_json(chat_json, default=_DEFAULT_CHAT_JSON, legacy_modules=('amz.analysis.listing',)),
    )


def _run_listing_micro_insert(
    title: str = "",
    bullet_points: list[str] | None = None,
    insert_plan: dict | None = None,
    text: str = "",
    keywords: list[str] | None = None,
    feedback: str = "",
    brand: str = "",
    forbidden_terms: list[str] | None = None,
    media_title_limit: int | None = None,
    title_differentiation: str = "",
    *, llm_call,
) -> Result:
    """analysis.listing.micro-insert — 微插入

    两种调用方式：
    1. 传入 insert_plan（推荐）: {{title: [kw1], bp1: [kw2], bp2: [], ...}}
    2. 传入 text + keywords（兼容旧版）: 在 text 中插入 keywords

    Args:
        title: 原标题
        bullet_points: 原五点描述
        insert_plan: 详细的插入计划
        text: 兼容模式 — 要修改的文本
        keywords: 兼容模式 — 要插入的关键词
    """
    bullet_points = bullet_points or []

    # 兼容旧版调用
    if text and not insert_plan:
        prompt = f"""# Role: Amazon Listing 微调编辑器

将以下关键词自然融入文本，做最小幅度改动。

Text: {text}
Keywords to insert: {", ".join(keywords or [])}

Constraints: keep original meaning and tone. Only modify where needed.

Return JSON: {{"text": "modified text", "inserted": ["keyword1", "keyword2"]}}"""
        # 兼容模式的输出与完整 Listing 不同，单独做结构校验。
        prompt += listing_rules(brand, forbidden_terms, media_title_limit)
        return _json_output(prompt, TextInsertionOutput, model="lite", temperature=0.3, llm_call=llm_call,
                            validate=lambda data: validate_listing(data, brand, forbidden_terms, media_title_limit))

    # 新版：构建插入计划
    plan = insert_plan or {}

    # 构建插入计划文本
    plan_lines = []
    highlight_kws = plan.get("title_differentiation", [])
    if highlight_kws:
        plan_lines.append(f"**商品亮点** — 需插入: {', '.join(highlight_kws)}")
    title_kws = plan.get("title", [])
    if title_kws:
        plan_lines.append(f'**Title** — 需插入: {", ".join(title_kws)}')
        plan_lines.append(f"原文: {title}")
    else:
        plan_lines.append(f"**Title** — 无需修改\n原文: {title}")

    for i, bp in enumerate(bullet_points):
        bp_key = f"bp{i+1}"
        bp_kws = plan.get(bp_key, [])
        if bp_kws:
            plan_lines.append(f'**BP{i+1}** — 需插入: {", ".join(bp_kws)}')
            plan_lines.append(f"原文: {bp}")
        else:
            plan_lines.append(f"**BP{i+1}** — 无需修改\n原文: {bp}")

    insert_plan_text = "\n".join(plan_lines)

    prompt = MICRO_INSERT_PROMPT.format(insert_plan=insert_plan_text)
    if feedback:
        prompt += f"\n\n# 用户修改意见（基于上次微调结果继续调整）\n{feedback}"
    prompt += f"\n原商品亮点: {title_differentiation}"
    prompt += listing_rules(brand, forbidden_terms, media_title_limit)
    return _json_output(prompt, ListingOutput, model="pro", temperature=0.3, llm_call=llm_call,
                        validate=lambda data: validate_listing(data, brand, forbidden_terms, media_title_limit))
