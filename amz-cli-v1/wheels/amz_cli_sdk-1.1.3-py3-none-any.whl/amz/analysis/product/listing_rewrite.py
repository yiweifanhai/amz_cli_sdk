"""Product listing rewrite capability."""

from __future__ import annotations
from amz.envelope import Result
from amz.registry import capability
from amz.infra.llm import chat_json
from amz.schemas.analysis_inputs import ListingRewriteInput
from amz.schemas.listing import ListingOutput
from amz.analysis.product._listing import _json_output, listing_rules, validate_listing
from amz.analysis._compat import resolve_chat_json

_DEFAULT_CHAT_JSON = chat_json


LISTING_REWRITE_PROMPT = """# Role: Amazon Listing 优化改写专家

# Task:
基于现有产品 Listing 和关键词分析结果，对 Listing 进行优化改写。
保留原文的优点和准确信息，同时融入关键词提升搜索排名。

# 原始 Listing:
**标题**: {old_title}
**五点描述**:
{old_bullets}
**价格**: {price}

# 关键词分析结果（按优先级分层）:
### S 级关键词（优先放在标题中，服从字符和品牌限制）:
{s_keywords}
### A 级关键词（优先在标题或首条 Bullet Point 中）:
{a_keywords}
### B 级关键词（分散融入 Bullet Points）:
{b_keywords}
### C 级关键词（可选融入，不勉强）:
{c_keywords}

# 改写规范:

1. **改写原则**:
   - 基于原文改写，不是从零生成
   - 保留原文中准确的产品信息和卖点
   - 自然融入关键词，不影响可读性和语义通顺
   - 改写幅度适中：有明显优化但不面目全非

2. **标题规范**:
   - 非媒介类最多 75 字符（含空格）
   - 首字母大写（介词和冠词除外）
   - 禁止字符和品牌例外见下方发布约束
   - 不包含促销词（Best, Cheapest, #1）
   - 品牌名保留在最前面
   - S 级关键词优先自然融入标题，放不下时分配到亮点或五点

3. **五点描述规范**:
   - 每条以大写关键词短语开头
   - 事实充足时每条建议 200-250 字符；事实不足时写短句，不为凑字数扩展卖点
   - 突出一个核心卖点
   - A 级关键词优先融入前两条
   - B 级关键词分散在各条中
   - 使用具体数据和描述

4. **关键词融入策略**:
   - S 级：优先放在标题中，服从字符和品牌限制
   - A 级：优先在标题或首条 Bullet Point 中
   - B 级：分散融入五点描述
   - C 级：自然契合时融入，不勉强

# 输出格式 (纯 JSON):
```json
{{
  "title_differentiation": "商品亮点，最多 125 字符，逗号分隔短语",
  "title": "改写后的标题",
  "bullet_points": [
    "KEYWORD PHRASE - Description of benefit 1",
    "KEYWORD PHRASE - Description of benefit 2",
    "KEYWORD PHRASE - Description of benefit 3",
    "KEYWORD PHRASE - Description of benefit 4",
    "KEYWORD PHRASE - Description of benefit 5"
  ]
}}
```"""


@capability(
    "analysis.listing.rewrite",
    description="Listing 全量改写（基于关键词分层策略）",
    input_model=ListingRewriteInput,
    output_model=ListingOutput,
    requires=["product.get"],
)
def listing_rewrite(
    title: str,
    bullet_points: list[str],
    keywords: dict | None = None,
    price: str = "",
    image_url: str = "",
    feedback: str = "",
    brand: str = "",
    forbidden_terms: list[str] | None = None,
    media_title_limit: int | None = None,
    title_differentiation: str = "",
) -> Result:
    return _run_listing_rewrite(
        title=title, bullet_points=bullet_points, keywords=keywords, price=price, image_url=image_url, feedback=feedback,
        brand=brand, forbidden_terms=forbidden_terms, media_title_limit=media_title_limit,
        title_differentiation=title_differentiation,
        llm_call=resolve_chat_json(chat_json, default=_DEFAULT_CHAT_JSON, legacy_modules=('amz.analysis.listing',)),
    )


def _run_listing_rewrite(
    title: str,
    bullet_points: list[str],
    keywords: dict | None = None,
    price: str = "",
    image_url: str = "",
    feedback: str = "",
    brand: str = "",
    forbidden_terms: list[str] | None = None,
    media_title_limit: int | None = None,
    title_differentiation: str = "",
    *, llm_call,
) -> Result:
    """analysis.listing.rewrite — 全量改写

    Args:
        title: 原标题
        bullet_points: 原五点描述
        keywords: {{S: [...], A: [...], B: [...], C: [...]}} 关键词分层
        price: 价格
        image_url: 产品图（暂未使用）
    """
    kw = keywords or {"S": [], "A": [], "B": [], "C": []}

    prompt = LISTING_REWRITE_PROMPT.format(
        old_title=title,
        old_bullets="\n".join(f"{i+1}. {bp}" for i, bp in enumerate(bullet_points)),
        s_keywords=", ".join(kw.get("S", [])) or "无",
        a_keywords=", ".join(kw.get("A", [])) or "无",
        b_keywords=", ".join(kw.get("B", [])) or "无",
        c_keywords=", ".join(kw.get("C", [])) or "无",
        price=price or "unknown",
    )

    if feedback:
        prompt += f"\n\n# 用户修改意见（基于上次结果继续调整）\n{feedback}"
    prompt += f"\n原商品亮点: {title_differentiation}"
    prompt += listing_rules(brand, forbidden_terms, media_title_limit)
    return _json_output(prompt, ListingOutput, model="pro", temperature=0.4, llm_call=llm_call,
                        validate=lambda data: validate_listing(data, brand, forbidden_terms, media_title_limit))
