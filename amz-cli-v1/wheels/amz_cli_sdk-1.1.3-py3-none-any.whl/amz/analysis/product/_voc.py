"""Shared VOC snapshots, formatting and output validation."""

from __future__ import annotations
import json
from pydantic import BaseModel, ValidationError
from amz.envelope import Result, ok, err, Code
from amz.analysis.base import AnalysisContractError, parse_structured, require_json
from amz.schemas.voc import ValuePerception, VocPraiseOutput, VocWishlistOutput, ProductVocListing, ProductVocReview


def _llm_output(prompt: str, output_model: type[BaseModel], model: str = "pro", *, llm_call) -> Result:
    try:
        result = llm_call(
            prompt=prompt,
            json_schema=output_model.model_json_schema(),
            model=model,
            temperature=0.3,
        )
        # Defaults support old stored values and explicit no-review results, but
        # must not conceal an incomplete model response.
        if output_model in (VocPraiseOutput, VocWishlistOutput):
            raw = require_json(result)
            if isinstance(raw, dict):
                missing = set(output_model.model_fields) - raw.keys()
                if missing:
                    raise AnalysisContractError(
                        "LLM output is missing fields: " + ", ".join(sorted(missing))
                    )
                if output_model is VocPraiseOutput:
                    value = raw.get("value_perception")
                    if isinstance(value, dict):
                        missing_value = set(ValuePerception.model_fields) - value.keys()
                        if missing_value:
                            raise AnalysisContractError(
                                "LLM output is missing value_perception fields: "
                                + ", ".join(sorted(missing_value))
                            )
        parsed = parse_structured(result, output_model)
        return ok(data=parsed.model_dump())
    except Exception as exc:
        return err(Code.ERROR_LLM, str(exc))


def _features(product_info: dict) -> list[str]:
    raw = product_info.get("bullet_points", product_info.get("features", [])) or []
    return [raw] if isinstance(raw, str) else [str(item) for item in raw]


def _product_details(product_info: dict) -> str:
    parts: list[str] = []
    for key in ("details", "product_information", "productDescription", "description"):
        value = product_info.get(key)
        if value:
            parts.append(json.dumps(value, ensure_ascii=False) if isinstance(value, (dict, list)) else str(value))
    for key in ("aboutProduct", "productDetails"):
        value = product_info.get(key)
        if value:
            parts.append(json.dumps(value, ensure_ascii=False))
    return "\n".join(parts)[:12000]


def _format_reviews(reviews: list[dict]) -> str:
    """格式化 Product 已抽样的评论；Analysis 不再二次截断。"""
    lines = []
    for r in reviews:
        review_id = r.get("review_id") or r.get("reviewId") or "unknown"
        rating = r.get("rating", "?")
        title = r.get("title", "")
        text = r.get("text", "") or ""
        lines.append(f"[{review_id}|{rating}★] {title}\n{text}\n")
    return "\n".join(lines)


def _format_positive_reviews(reviews: list[dict]) -> str:
    """从 Product 已抽样评论中格式化全部 4-5 星评论。"""
    positive = [r for r in reviews if _rating_value(r.get("rating")) >= 4]
    positive.sort(key=lambda r: _rating_value(r.get("rating")), reverse=True)  # 5星优先
    lines = []
    for r in positive:
        rating = r.get("rating", "?")
        title = r.get("title", "")
        text = r.get("text", "") or ""
        lines.append(f"[{rating}★] {title}\n{text}\n")
    return "\n".join(lines)


def _rating_value(value: object) -> float:
    try:
        return float(str(value).split()[0])
    except (TypeError, ValueError, IndexError):
        return 0.0


def _input_error(exc: ValidationError) -> Result:
    missing = sorted({
        ".".join(str(part) for part in item.get("loc", ()))
        for item in exc.errors()
        if item.get("type") == "missing"
    })
    if missing:
        return err(
            Code.ERROR_MISSING_FIELDS,
            "missing required fields: " + ", ".join(missing),
            missing=missing,
        )
    return err(Code.ERROR_PARAM, str(exc))


def _listing_snapshot(product_info: dict) -> ProductVocListing:
    """把旧 ProductInfo 宽松字典收敛为严格 VOC Listing。"""
    return ProductVocListing.model_validate({
        "asin": product_info.get("asin"),
        "title": product_info.get("title"),
        "bullet_points": _features(product_info),
        "details": _product_details(product_info),
        "description": product_info.get("description")
        or product_info.get("productDescription")
        or "",
        "brand": product_info.get("brand"),
        "product_rating": product_info.get("product_rating")
        or product_info.get("productRating")
        or product_info.get("rating"),
        "count_ratings": product_info.get("count_ratings")
        or product_info.get("countRatings")
        or product_info.get("count_review")
        or product_info.get("countReview"),
    })


def _review_snapshots(
    reviews: list[dict] | None,
    *,
    legacy_ids: bool = False,
) -> list[ProductVocReview]:
    snapshots: list[ProductVocReview] = []
    for index, review in enumerate(reviews or []):
        raw = dict(review)
        if legacy_ids:
            legacy_title = raw.get("title")
            if not legacy_title and isinstance(raw.get("reviewSummary"), str):
                legacy_title = raw["reviewSummary"]
            raw = {
                "review_id": raw.get("review_id")
                or raw.get("reviewId")
                or f"legacy-{index + 1}",
                "text": raw.get("text") or raw.get("body") or "",
                "rating": raw.get("rating"),
                "title": legacy_title or "",
                "date": raw.get("date"),
                "country": raw.get("country") or "",
                "verified": raw.get("verified", False),
                "user_name": raw.get("user_name") or raw.get("userName") or "",
                "images": raw.get("images") or raw.get("imageUrlList") or [],
            }
        snapshots.append(ProductVocReview.model_validate(raw))
    return snapshots


_JSON_ONLY_SUFFIX = """
严格要求：只输出 JSON，不要任何 markdown 标题、说明文字或 ``` 围栏。字符串值内部如需引用词语，一律用中文引号「」或『』，绝不能使用英文双引号 "（否则会破坏 JSON 结构导致解析失败）。"""
