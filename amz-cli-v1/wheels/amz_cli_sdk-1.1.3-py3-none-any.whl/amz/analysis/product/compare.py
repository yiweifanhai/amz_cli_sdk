"""Compare a Product with an explicit benchmark context."""

from __future__ import annotations
import re
from amz.envelope import Result, ok, err, Code
from amz.registry import capability
from amz.infra.llm import chat_json
from amz.analysis.base import require_json
from amz.schemas.analysis_inputs import CompareInnovationInput
from amz.schemas.innovation import ComparativeInnovationOutput
from amz.analysis._compat import resolve_chat_json

_DEFAULT_CHAT_JSON = chat_json


_TRAILING_PAREN_CONTENT = re.compile(r"\s*[（(][^（）()]*[)）]\s*$")


def _normalize_dimension_tag(value: object) -> str:
    text = str(value or "").strip()
    while text:
        normalized = _TRAILING_PAREN_CONTENT.sub("", text).strip()
        if normalized == text:
            break
        text = normalized
    return text


INNOVATION_COMPARE_SYSTEM_PROMPT = """# Role
你是一位拥有敏锐洞察力的“亚马逊蓝海选品专家”。你的核心能力是通过对比“市场现有畅销品（Benchmark）”和“新发布产品（New Release）”，精准识别出具有颠覆性创新的市场机会。

# Task
我会给你提供两组数据：
1. **[New Product]**: 一个新上架产品的标题、图片特征描述（或直接提供图片）、卖点。
2. **[Benchmark Group]**: 该关键词下销量最高的 3-5 个老爆款产品的标题、图片特征描述（或图片）。

你的任务是进行“差分分析”，判断 [New Product] 是否属于“伪创新”，还是真正的“蓝海机会”。

# Innovation Dimensions (创新评判维度)
请严格基于以下 10 个维度来寻找差异。如果产品仅仅是换了包装或稍微改了尺寸，不属于创新。

1. **形态颠覆 (Form Factor Innovation)**: 把产品原本固有的形状彻底改变（例：把平铺的菜板做成书本状；把传统的风扇做成无叶的）。
2. **跨界混搭 (Hybridization)**: 两个毫不相关的成熟品类强行融合（例：保温杯+蓝牙音箱；行李箱+滑板车）。
3. **场景细分 (Micro-Scenario)**: 针对极特定的场景设计（例：不是普通的“地毯”，而是“房车专用防潮地毯”；不是“台灯”，是“乐谱架专用灯”）。
4. **场景迁移 (Scenario Migration)**: 把A场景的产品拿到B场景用（例：原本是手术室用的精密剪刀，现在作为厨房剪刀卖）。
5. **人群迁移 (Demographic Shift)**: 使用对象发生根本转变（例：原本给婴儿用的硅胶餐具，现在做成宠物专用；原本是女性用的美妆蛋，现在做成男性专用）。
6. **人群标签化 (Identity/Subculture)**: 强绑定某种亚文化或身份标签（例：Goth（哥特风）家居；LGBTQ 彩虹主题办公用品）。
7. **情绪价值放大 (Emotional Value)**: 功能不重要，卖的是解压、治愈、搞怪或炫耀（例：木鱼解压玩具；巨型回车键；“禁止焦虑”摆件）。
8. **功能叠加 (All-in-One)**: 极度的多功能集成（例：一个野营灯同时是：充电宝+驱蚊器+SOS信号灯+收音机）。
9. **极致单点突破 (Extreme Feature)**: 放弃其他功能，把某一个参数做到变态（例：不做多功能，但待机时间长达 1 年的录音笔）。
10. **视觉/材质升级 (Aesthetic/Material Upgrade)**: 功能不变，但材质或设计风格降维打击（例：把塑料收纳盒做成亚克力+黄铜轻奢风；把普通数据线做成流光夜光线）。

# Critical Rule (去噪原则)
如果 [New Product] 和 [Benchmark Group] 根本不是同一类东西（例如：新品是手机壳，竞品是浇水软管），这是数据错误，请直接标记为 "INVALID_PAIR"。"""


INNOVATION_COMPARE_STEPS = """请严格按照以下逻辑步骤进行分析并输出 JSON：

**Step 1: 确定基准 (Establish Baseline)**
- **情况 A (如果 [PART A] 有数据):** 基于 [PART A] 的内容，总结该品类的“平庸标准”。
- **情况 B (如果 [PART A] 为 "NONE" 或数据无效):** 1. 首先提取 [PART B] 的**核心产品词 (Root Keyword)**（例如把 "Cute Dinosaur Taco Holder" 还原为 "Taco Holder"）。
  2. 调取你的**内部常识库**，构建该产品在亚马逊市场上的“大众化画像”（通常是什么材质？什么形状？有什么标配功能？）。这将作为你的“虚拟基准”。

**Step 2: 差异识别 (Identify Deviation)**
将 [PART B] 与 Step 1 确定的基准（无论是真实的还是虚拟的）进行对比。
- 新品是否在形态、场景、功能或材质上，显著背离了你认知的“标准品”？
- 如果新品属于知名/经典IP（Hello Kitty、米老鼠、初音未来等）、热门电影/游戏作品、球队/球星等的周边产品，由于涉及潜在的知识产权问题，请给予0-2分的“弱创新”/“无创新”评价。
- 如果原品是通用款（例如适用于所有车型的配件），而新品是某个具体型号的定制款（适用于某个具体车型的配件），由于这两类产品并不能直接对比，请给予小于等于5分的“弱创新”评价。
- *警告：* 如果你使用的是“内部常识”，请采取保守策略。不要把现代标配（如 Type-C 接口、普通防水）误判为颠覆性创新。在使用“内部常识模式”时，请务必自我质疑： "这个所谓的创新点（例如无线、便携），在最近 2 年的亚马逊市场上是否已经泛滥？" 只有当你确信这是一个极少见的设计时，才给予 7 分以上的高分。如果不确定，请给予 4-6 分的“中度优化”评价。

**Step 3: 维度匹配 (Categorize)**
匹配 10 大创新维度，从强到弱排序。

**Step 4: 评分 (Scoring)**
按 0-10 分打分。

**Output Format (JSON Only):**
请使用中文回答语言，并返回一个 JSON 对象，返回的格式如下：
{
  "status": "VALID",
  "comparison_mode": "REAL_BENCHMARK" 或 "INTERNAL_KNOWLEDGE",
  "root_product_keyword": "例如：Cutting Board (仅在内部常识模式下必填)",
  "baseline_summary": "描述你用来对比的标准（是基于竞品数据总结的，还是基于常识构建的）...",
  "innovation_analysis": "分析新品哪里不一样...",
  "primary_dimension": "核心维度",
  "secondary_dimensions": ["其他维度"],
  "innovation_score": 打分0-10分,
  "one_sentence_reason": "简短的几句话理由..."
}"""


@capability(
    "analysis.innovation.compare",
    description="新品与 3-5 个畅销基准品的多模态差分创新评估",
    input_model=CompareInnovationInput,
    output_model=ComparativeInnovationOutput,
)
def compare_innovation(new_product: dict, benchmarks: list[dict] | None = None) -> Result:
    return _compare_innovation(
        new_product=new_product, benchmarks=benchmarks,
        llm_call=resolve_chat_json(chat_json, default=_DEFAULT_CHAT_JSON, legacy_modules=('amz.analysis.innovation',)),
    )


def _compare_innovation(new_product: dict, benchmarks: list[dict] | None = None, *, llm_call) -> Result:
    benchmark_items = (benchmarks or [])[:5]
    benchmark_text = "NONE" if not benchmark_items else "\n".join(
        f'- [{index}] {item.get("product_name", item.get("title", ""))} (ASIN: {item.get("asin", "")})'
        for index, item in enumerate(benchmark_items, start=1)
    )
    new_text = (
        f'- {new_product.get("product_name", new_product.get("title", ""))} '
        f'(ASIN: {new_product.get("asin", "")})'
    )
    content: list[dict] = [
        {"type": "text", "text": "请分析以下产品数据。\n注意：[PART A] 可能为空。如果为空，请触发“内部常识判断模式”。"},
        {"type": "text", "text": f"**[PART A: Benchmark Group (老爆款/参照系)]**\n这是产品标题 {benchmark_text} 以下是产品图片"},
    ]
    for item in benchmark_items:
        image_url = str(item.get("image_url") or item.get("main_image_url") or "").strip()
        if image_url:
            content.append({"type": "image_url", "image_url": {"url": image_url}})
    content.append({
        "type": "text",
        "text": f"**[PART B: New Product (待验证新品)]**\n这是产品标题 {new_text} 以下是产品图片",
    })
    new_image = str(new_product.get("image_url") or new_product.get("main_image_url") or "").strip()
    if new_image:
        content.append({"type": "image_url", "image_url": {"url": new_image}})
    content.append({"type": "text", "text": INNOVATION_COMPARE_STEPS})
    try:
        result = llm_call(
            messages=[
                {"role": "system", "content": INNOVATION_COMPARE_SYSTEM_PROMPT},
                {"role": "user", "content": content},
            ],
            json_schema=ComparativeInnovationOutput.model_json_schema(),
            model="pro", temperature=0.2,
        )
        raw = require_json(result)
        if not isinstance(raw, dict):
            raise ValueError("comparative innovation output must be a JSON object")
        if raw.get("comparison_mode") not in {"REAL_BENCHMARK", "INTERNAL_KNOWLEDGE"}:
            raw["comparison_mode"] = "REAL_BENCHMARK"
        raw["primary_dimension"] = _normalize_dimension_tag(raw.get("primary_dimension"))
        secondary = raw.get("secondary_dimensions", [])
        if not isinstance(secondary, (list, tuple)):
            secondary = [secondary]
        raw["secondary_dimensions"] = list(dict.fromkeys(
            tag for item in secondary if (tag := _normalize_dimension_tag(item))
        ))
        output = ComparativeInnovationOutput.model_validate(raw)
        if not benchmark_items:
            output.comparison_mode = "INTERNAL_KNOWLEDGE"
        return ok(data=output.model_dump())
    except Exception as exc:
        return err(Code.ERROR_LLM, str(exc))
