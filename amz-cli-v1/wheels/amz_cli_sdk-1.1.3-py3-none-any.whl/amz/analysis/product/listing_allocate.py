"""Product listing allocate capability."""

from __future__ import annotations
from amz.envelope import Result, ok
from amz.registry import capability
from amz.infra.llm import chat_json
from amz.schemas.analysis_inputs import ListingAllocateInput
from amz.schemas.listing import AllocationOutput
from amz.analysis.product._listing import _json_output
from amz.analysis._compat import resolve_chat_json

_DEFAULT_CHAT_JSON = chat_json


LISTING_ALLOCATE_PROMPT = """# Role: Amazon Listing 关键词位置分配助手

# Task:
将以下缺失关键词分配到 Listing 的最佳位置（Title 或 BP1-5），基于语义相关性。

# 当前 Listing:
**Title**: {title}
{bullets_text}

# 待分配的缺失关键词:
{keywords}

# 分配规则:
1. 基于每条 Bullet 的主题/卖点，将关键词分配到语义最相关的位置
2. 每条 Bullet Point 最多分配 3 个关键词（避免单条过度修改）
3. Title 只分配最重要的核心词（一般 1-2 个），加入后标题不得超过 75 字符（含空格）；其他词放五点或 unassigned。禁止加入其他品牌或商标词。
4. 如果某个词无法合理分配到任何位置，放入 unassigned
5. 尽量均匀分散，不要把大量词堆到同一条

# 输出格式 (纯 JSON):
```json
{{
  "title": ["分配到标题的词"],
  "bp1": ["分配到BP1的词"],
  "bp2": ["分配到BP2的词"],
  "bp3": ["分配到BP3的词"],
  "bp4": ["分配到BP4的词"],
  "bp5": ["分配到BP5的词"],
  "unassigned": ["无合适位置的词"]
}}
```"""


@capability(
    "analysis.listing.allocate",
    description="关键词位置分配（LLM 语义分配，Title + BP1-5）",
    input_model=ListingAllocateInput,
    output_model=AllocationOutput,
    requires=["analysis.keyword.gap"],
)
def listing_allocate(
    listing: dict,
    missing_keywords: list[str],
    use_llm: bool = True,
) -> Result:
    return _run_listing_allocate(
        listing=listing, missing_keywords=missing_keywords, use_llm=use_llm,
        llm_call=resolve_chat_json(chat_json, default=_DEFAULT_CHAT_JSON, legacy_modules=('amz.analysis.listing',)),
    )


def _run_listing_allocate(
    listing: dict,
    missing_keywords: list[str],
    use_llm: bool = True,
    *, llm_call,
) -> Result:
    """analysis.listing.allocate — 位置分配

    Args:
        listing: {{title, bullet_points: []}}
        missing_keywords: 需分配的关键词
        use_llm: True=LLM 语义分配, False=确定性规则分配
    """
    title = listing.get("title", "")
    bps = listing.get("bullet_points", [])
    # 输出协议固定为 BP1-BP5；不能把关键词分配到无法返回的 BP6+。
    n_bps = 5

    if not use_llm:
        # 确定性规则：短词放 title，长词均匀分配到各 BP
        assigned_title = []
        assigned_bps = [[] for _ in range(n_bps)]

        for kw in missing_keywords:
            words = len(kw.split())
            if words <= 3 and len(assigned_title) < 2 and len(" ".join([title, *assigned_title, kw])) <= 75:
                assigned_title.append(kw)
            else:
                bp_idx = min(range(len(assigned_bps)), key=lambda i: len(assigned_bps[i]))
                assigned_bps[bp_idx].append(kw)

        return ok(data={
            "title": assigned_title,
            "bp1": assigned_bps[0],
            "bp2": assigned_bps[1],
            "bp3": assigned_bps[2],
            "bp4": assigned_bps[3],
            "bp5": assigned_bps[4],
            "unassigned": [],
        })

    # LLM 语义分配
    bullets_text = "\n".join(f"BP{i+1}: {bp}" for i, bp in enumerate(bps[:5]))

    prompt = LISTING_ALLOCATE_PROMPT.format(
        title=title,
        bullets_text=bullets_text,
        keywords=", ".join(missing_keywords),
    )

    return _json_output(prompt, AllocationOutput, model="lite", temperature=0.2, llm_call=llm_call)
