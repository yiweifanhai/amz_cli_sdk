"""Compatibility facade for the individual Product VOC capabilities."""

from __future__ import annotations

from amz.envelope import Result
from amz.infra.llm import chat_json
from amz.schemas.analysis_inputs import VocInput, VocStrengthsInput, VocWeaknessesInput
from amz.schemas.voc import (
    ValuePerception,
    VocPraiseOutput,
    VocWishlistOutput,
    ProductVocListing,
    ProductVocReview,
    VocSatisfactionMetrics,
    VocStrengthsAnalysisInput,
    VocStrengthsOutput,
    VocUseInsightsAnalysisInput,
    VocUseInsightsOutput,
    VocWeaknessSignalsInput,
    VocWeaknessSignalsOutput,
    VocWeaknessesOutput,
)

from amz.analysis.product.strengths import VOC_STRENGTHS_PROMPT, _run_voc_strength_signals, _run_voc_strengths, _analyze_strengths
from amz.analysis.product.weaknesses import VOC_WEAKNESSES_PROMPT, _run_voc_weakness_signals, _run_voc_weaknesses, _analyze_weakness_signals
from amz.analysis.product.use_insights import VOC_USE_INSIGHTS_PROMPT, _run_voc_use_signals, _run_voc_use_insights, _analyze_use_signals
from amz.analysis.product.praise import VOC_PRAISE_PROMPT, _run_voc_praise
from amz.analysis.product.wishlist import VOC_WISHLIST_PROMPT, _run_voc_wishlist
from amz.analysis.product._voc import _features, _product_details, _format_reviews, _format_positive_reviews, _rating_value, _input_error, _listing_snapshot, _review_snapshots, _JSON_ONLY_SUFFIX


def voc_strength_signals(product_info: dict) -> Result:
    return _run_voc_strength_signals(
        product_info=product_info,
        llm_call=chat_json,
    )


def voc_strengths(
    product_info: dict,
    reviews: list[dict] | None = None,
    reviews_evidence: str | None = None,
) -> Result:
    return _run_voc_strengths(
        product_info=product_info, reviews=reviews, reviews_evidence=reviews_evidence,
        llm_call=chat_json,
    )


def voc_weakness_signals(
    product_info: dict,
    reviews: list[dict],
    satisfaction: dict,
) -> Result:
    return _run_voc_weakness_signals(
        product_info=product_info, reviews=reviews, satisfaction=satisfaction,
        llm_call=chat_json,
    )


def voc_weaknesses(
    product_info: dict,
    reviews: list[dict] | None = None,
    star_ratios: dict | str | None = None,
) -> Result:
    return _run_voc_weaknesses(
        product_info=product_info, reviews=reviews, star_ratios=star_ratios,
        llm_call=chat_json,
    )


def voc_use_signals(product_info: dict, reviews: list[dict]) -> Result:
    return _run_voc_use_signals(
        product_info=product_info, reviews=reviews,
        llm_call=chat_json,
    )


def voc_use_insights(
    product_info: dict,
    reviews: list[dict] | None = None,
) -> Result:
    return _run_voc_use_insights(
        product_info=product_info, reviews=reviews,
        llm_call=chat_json,
    )


def voc_praise(
    product_info: dict,
    reviews: list[dict] | None = None,
) -> Result:
    return _run_voc_praise(
        product_info=product_info, reviews=reviews,
        llm_call=chat_json,
    )


def voc_wishlist(
    product_info: dict,
    reviews: list[dict] | None = None,
) -> Result:
    return _run_voc_wishlist(
        product_info=product_info, reviews=reviews,
        llm_call=chat_json,
    )
