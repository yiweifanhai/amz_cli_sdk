"""Product VOC use insights analysis."""

from __future__ import annotations
from pydantic import ValidationError
from amz.envelope import Result, ok
from amz.registry import capability
from amz.infra.llm import chat_json
from amz.schemas.analysis_inputs import VocInput
from amz.schemas.voc import ProductVocListing, ProductVocReview, VocUseInsightsAnalysisInput, VocUseInsightsOutput
from amz.analysis._compat import resolve_chat_json
from amz.analysis.product._voc import _llm_output, _format_reviews, _input_error, _listing_snapshot, _review_snapshots, _JSON_ONLY_SUFFIX

_DEFAULT_CHAT_JSON = chat_json


VOC_USE_INSIGHTS_PROMPT = """你是一位资深的消费者行为研究员，擅长从用户评论中提取产品使用场景、用户画像和购买动机。

任务：对下面的产品评论做消费者洞察挖掘，从评论中提取三类信息——用户如何使用（场景）、谁在使用（人群）、为什么购买（动机）。请同时从好评和差评中提取信息，正面评论中的场景/动机信号往往更丰富。

## 提取维度

### 1. 使用场景（Use Scenarios）
- 用户在哪里使用这个产品？（场景：家里、办公室、户外、旅行、车上、教堂、健身房等）
- 什么时候使用？（时间：日常、出差、假期、周末、特定活动）
- 如何使用？（方式：搭配什么使用、使用频率、是否作为替代品）
- 特别关注用户提到的意外使用方式或创造性用法

### 2. 用户画像（User Personas）
- 购买者是谁？（角色：自用者、送礼者、家长、教师、办公室职员等）
- 终端使用者是谁？（若购买者与使用者不同，需区分）
- 有什么特征？（年龄暗示、职业暗示、兴趣爱好、生活方式、技术水平）
- 有什么特殊需求？（如：左撇子、过敏体质、老年用户、初学者等）

### 3. 购买动机（Purchase Motivations）
- 为什么选择这款产品？（触发因素：替换旧品、新需求、被推荐、促销）
- 和什么对比过？（竞品比较：和哪些品牌/类型对比过，为什么最终选了这个）
- 决策关键因素是什么？（价格、功能、材质、外观、品牌信任、评价、配送速度等）
- 哪些是惊喜点？（超出预期的功能或体验）

## 输入数据
产品标题：{title}

用户评论：
{reviews}

## 输出 JSON 结构（所有 value 用中文，frequency 取 高频|中频|低频）：
{{
  "use_scenarios": [
    {{"scenario": "场景描述（具体，包含时间、地点、方式）", "frequency": "高频|中频|低频", "evidence": "原文证据摘录", "mentioned_by": 提及用户数整数}}
  ],
  "user_personas": [
    {{"persona": "用户群体名称（例如 职场新手妈妈、退休园艺爱好者）", "traits": "具体特征和行为描述", "evidence": "原文证据摘录", "mentioned_by": 提及用户数整数}}
  ],
  "purchase_motivations": [
    {{"motivation": "购买动机描述", "decision_factor_type": "功能需求|价格敏感|外观设计|品牌信任|礼品需求|替代升级|推荐种草|其他", "evidence": "原文证据摘录", "mentioned_by": 提及用户数整数}}
  ]
}}

按 mentioned_by 从高到低排序，每个维度至少提取 3-5 条（若有足够信号）。
""" + _JSON_ONLY_SUFFIX


def _analyze_use_signals(
    listing: ProductVocListing,
    review_models: list[ProductVocReview],
    *, llm_call,
) -> Result:
    """执行一次使用洞察语义推理；不负责评论抽样。"""
    if not review_models:
        return ok(data=VocUseInsightsOutput.empty().model_dump())

    prompt = VOC_USE_INSIGHTS_PROMPT.format(
        title=listing.title,
        reviews=_format_reviews([
            review.model_dump(mode="python") for review in review_models
        ]),
    )
    return _llm_output(prompt, VocUseInsightsOutput, model="lite", llm_call=llm_call)


@capability(
    "analysis.voc.use-signals",
    description="从严格评论快照提取使用场景、用户画像和购买动机",
    input_model=VocUseInsightsAnalysisInput,
    output_model=VocUseInsightsOutput,
    requires=["product.get", "product.reviews"],
)
def voc_use_signals(product_info: dict, reviews: list[dict]) -> Result:
    return _run_voc_use_signals(
        product_info=product_info, reviews=reviews,
        llm_call=resolve_chat_json(chat_json, default=_DEFAULT_CHAT_JSON, legacy_modules=('amz.analysis.voc', 'amz.analysis.product.voc')),
    )


def _run_voc_use_signals(product_info: dict, reviews: list[dict], *, llm_call) -> Result:
    """严格原子入口：从已抽样评论提取场景、人群和购买动机。"""
    try:
        listing = _listing_snapshot(product_info)
        review_models = _review_snapshots(reviews)
    except ValidationError as exc:
        return _input_error(exc)
    return _analyze_use_signals(listing, review_models, llm_call=llm_call)


@capability(
    "analysis.voc.use-insights",
    description="产品使用洞察兼容入口；新链路使用 use-signals",
    input_model=VocInput,
    output_model=VocUseInsightsOutput,
)
def voc_use_insights(
    product_info: dict,
    reviews: list[dict] | None = None,
) -> Result:
    return _run_voc_use_insights(
        product_info=product_info, reviews=reviews,
        llm_call=resolve_chat_json(chat_json, default=_DEFAULT_CHAT_JSON, legacy_modules=('amz.analysis.voc', 'amz.analysis.product.voc')),
    )


def _run_voc_use_insights(
    product_info: dict,
    reviews: list[dict] | None = None,
    *, llm_call,
) -> Result:
    """保留旧参数形状，并收敛到同一个使用洞察语义实现。"""
    try:
        listing = _listing_snapshot(product_info)
        review_models = _review_snapshots(reviews, legacy_ids=True)
    except ValidationError as exc:
        return _input_error(exc)
    return _analyze_use_signals(listing, review_models, llm_call=llm_call)
