"""Product VOC wishlist analysis."""

from __future__ import annotations
from amz.envelope import Result, ok
from amz.registry import capability
from amz.infra.llm import chat_json
from amz.schemas.analysis_inputs import VocInput
from amz.schemas.voc import VocWishlistOutput
from amz.analysis._compat import resolve_chat_json
from amz.analysis.product._voc import _llm_output, _features, _format_reviews, _JSON_ONLY_SUFFIX

_DEFAULT_CHAT_JSON = chat_json


VOC_WISHLIST_PROMPT = """你是一位资深的产品经理，擅长从用户评论中提取产品迭代信号——不只是修 bug，更是发现用户渴望的新功能和新变体。

任务：对下面的全部产品评论做愿望清单挖掘。注意：以下提取的不是用户投诉（那些是痛点），而是用户表达「想要」「希望」「如果能有」的积极愿望。即使是好评用户，也常会说「I love it, but I wish it had...」。

## 提取维度

### 1. 功能请求（Feature Requests）
- 用户明确提出想要的新功能、新特性（"I wish it had..."、"would be nice if..."、"如果能X就好了"）
- 标记来源：好评中提及 | 差评中提及 | 中性
- 评估可行性：高（小改动即可实现）| 中（需要一定开发）| 低（需要重大改动或违背产品定位）

### 2. 改进建议（Improvement Suggestions）
- 用户对现有功能的改进意见（"would be better if..."、"建议把X改成Y"）
- 必须指定针对哪个现有功能做改进
- 区分改进建议 vs 痛点投诉：改进建议是建设性的、具体的、指向解决方案的；痛点投诉是「X 坏了/不好用」但没有提出怎么改

### 3. 变体请求（Variant Requests）
- 用户想要但当前没有的尺寸、颜色、材质、款式等变体
- 例如：「希望有更大的尺寸」「如果有白色就好了」「能不能出个便携版」

### 4. 配件/附带需求（Accessory Requests）
- 用户希望附带或单独购买的配件
- 例如：「希望附带收纳盒」「如果能配一个挂墙支架就好了」「需要额外的替换头」

## 重要边界
- 不要提取已经在产品中实现的功能（参考五点描述确认）
- 不要提取纯粹的投诉（那是弱点分析的事），只提取有「建设性提议」的内容
- 即使是 1-2 条用户提到的小众需求也要记录——小众需求也可能是蓝海信号

## 输入数据
产品标题：{title}

五点描述（供了解产品现有功能列表）：
{features}

全部用户评论（包含好评和差评）：
{reviews}

## 输出 JSON 结构（所有 value 用中文）：
{{
  "feature_requests": [
    {{"request": "用户想要的功能描述", "source_type": "好评中提及|差评中提及|中性", "evidence": "原文证据摘录（必须引用原文）", "mentioned_by": 提及用户数整数, "feasibility": "高|中|低"}}
  ],
  "improvement_suggestions": [
    {{"suggestion": "具体改进建议", "target_feature": "针对的现有功能名称", "evidence": "原文证据摘录", "mentioned_by": 提及用户数整数}}
  ],
  "variant_requests": [
    {{"variant": "用户想要的变体描述", "evidence": "原文证据摘录", "mentioned_by": 提及用户数整数}}
  ],
  "accessory_requests": [
    {{"accessory": "用户希望附带或配套的配件", "evidence": "原文证据摘录", "mentioned_by": 提及用户数整数}}
  ]
}}

按 mentioned_by 从高到低排序。如果某个维度没有足够信号，返回空数组。
""" + _JSON_ONLY_SUFFIX


@capability(
    "analysis.voc.wishlist",
    description="从评论中提取用户愿望清单：功能请求、改进建议、变体需求、配件需求",
    input_model=VocInput,
    output_model=VocWishlistOutput,
)
def voc_wishlist(
    product_info: dict,
    reviews: list[dict] | None = None,
) -> Result:
    return _run_voc_wishlist(
        product_info=product_info, reviews=reviews,
        llm_call=resolve_chat_json(chat_json, default=_DEFAULT_CHAT_JSON, legacy_modules=('amz.analysis.voc', 'amz.analysis.product.voc')),
    )


def _run_voc_wishlist(
    product_info: dict,
    reviews: list[dict] | None = None,
    *, llm_call,
) -> Result:
    """analysis.voc.wishlist — 用户愿望清单

    从全部评论（好评+差评）中提取建设性的产品迭代信号：
    - 功能请求（用户想要的新功能）
    - 改进建议（对现有功能的具体改进意见）
    - 变体请求（用户想要的尺寸/颜色/款式）
    - 配件需求（用户希望附带或配套的配件）

    注意：这不是痛点提取（那是 weaknesses 的职责），
    而是捕捉用户「想要」「希望」「如果能」的建设性愿望。
    好评用户也常说「I love it, but I wish it had...」。

    Args:
        product_info: {title, bullet_points}
        reviews: 评论列表
    """
    reviews = reviews or []
    reviews_text = _format_reviews(reviews)
    if not reviews_text.strip():
        return ok(data={
            **VocWishlistOutput().model_dump(),
        })

    prompt = VOC_WISHLIST_PROMPT.format(
        title=product_info.get("title", ""),
        features="\n".join(_features(product_info)[:10]),
        reviews=reviews_text,
    )
    return _llm_output(prompt, VocWishlistOutput, llm_call=llm_call)
