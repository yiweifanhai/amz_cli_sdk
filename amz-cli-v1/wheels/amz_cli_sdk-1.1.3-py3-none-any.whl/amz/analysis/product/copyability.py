"""Product copyability analysis."""

from __future__ import annotations
from amz.envelope import Result, ok, err, Code
from amz.registry import capability
from amz.infra.llm import chat_json
from amz.analysis.base import parse_structured
from amz.schemas.innovation import CopyabilityOutput
from amz.analysis._compat import resolve_chat_json

_DEFAULT_CHAT_JSON = chat_json


def _rating_value(value: object, default: float = 5.0) -> float:
    try:
        return float(str(value).split()[0])
    except (TypeError, ValueError, IndexError):
        return default


COPYABILITY_PROMPT = """# Role
你是一位有丰富 Amazon 实战经验的"竞品逆向工程专家"。你的核心能力是判断：一个竞品的创新**能不能被低成本复制**，以及**怎么做差异化微改进**。

# Task
我会给你提供：
1. **产品信息**：标题 + 产品描述
2. **创新点描述**：用户认为这个产品的核心亮点
3. **差评信息**（可选）：买家投诉点，微改进方向的来源

你的任务是从以下四个维度判断复制难度，然后给出微改进方向：

## 复制难度四维度

### 1. 专利壁垒
- 外观/功能是否有明显专利风险？
- 独创性结构 vs 通用设计
- 只做粗筛，有明显风险时标记

### 2. 供应链门槛
- 需要特殊工艺（精密注塑、CNC、激光切割）还是通用工艺？
- 需要定制模具还是公模可做？
- 材料是否特殊（普通塑料/硅胶 vs 特种合金/碳纤维）？
- 1688 上有没有类似方案？

### 3. 技术复杂度
- 纯硬件结构创新 vs 软件/算法/芯片方案？
- 硬件结构通常容易复制，软件算法壁垒更高
- 是否涉及认证门槛（FCC/UL/FDA）？

### 4. 品牌绑定
- 创新价值是否依赖品牌认知（特定配色体系、IP 授权）？
- 去掉品牌后创新本身还有没有独立价值？

## 微改进方向
从两个来源挖掘：
- **差评痛点**（优先）：区分结构性缺陷（改了就是新品）和品控问题（改了意义不大）
- **产品本身的机会**：功能叠加（成本+≤20%，感知价值翻倍）、外观微调（颜色/材质/包装）、规格扩展（尺寸/容量变体）

# Critical Rules
- 如果提供了图片，视觉分析必须包含至少 2 处对图片细节的具体引用
- 微改进建议要具体可执行，避免"优化用户体验"这类空话
- 专利风险只做粗筛，不做法律意见；有明显风险时提醒深查
- 如果没有差评信息，基于产品图片和品类常识推测痛点，标注为"推测"

---
**产品信息**
- ASIN: {asin}
- 标题: {title}
- 产品描述: {description}
- 图片 URL: {image_url}

**用户识别的创新点**
{innovation_desc}

**差评/痛点信息**
{reviews_info}

---

请严格按照以下逻辑步骤分析并输出 JSON：

**Step 1: 复制难度四维度判断**
分别从专利壁垒、供应链门槛、技术复杂度、品牌绑定四个角度评估。

**Step 2: 微改进方向**
结合差评痛点和产品机会，给出 3-5 条具体可执行的微改进建议。

**Step 3: 综合评分**
0-10 分。评分逻辑：复制门槛适中 + 差异化空间大 = 高分（理想状态）。

**Output Format (JSON Only):**
请使用中文回答，返回一个 JSON 对象：
{{
  "visual_observations": "从产品图片中观察到的至少两处关键视觉特征",
  "copy_difficulty": "低 / 中 / 高",
  "barrier_analysis": {{
    "patent_risk": {{
      "level": "低 / 中 / 高",
      "reason": "判断依据..."
    }},
    "supply_chain": {{
      "level": "低 / 中 / 高",
      "reason": "判断依据，包括工艺/模具/材料分析..."
    }},
    "tech_complexity": {{
      "level": "低 / 中 / 高",
      "reason": "判断依据..."
    }},
    "brand_bindness": {{
      "level": "低 / 中 / 高",
      "reason": "判断依据..."
    }}
  }},
  "differentiation_suggestions": [
    {{
      "type": "差评痛点 / 功能叠加 / 外观微调 / 规格扩展",
      "suggestion": "具体改进内容",
      "expected_effect": "预期效果",
      "cost_impact": "成本影响估计"
    }}
  ],
  "score": 0-10整数,
  "score_reason": "一句话评分理由",
  "verdict": "值得复制 / 可以尝试 / 需要谨慎 / 不建议复制"
}}"""


COPYABILITY_SYSTEM_PROMPT = """# Role
你是一位有丰富 Amazon 实战经验的"竞品逆向工程专家"。你的核心能力是判断：一个竞品的创新**能不能被低成本复制**，以及**怎么做差异化微改进**。

# ⚠️ 视觉分析强制要求
你会收到产品图片。你 **必须** 仔细观察图片并在分析中 **明确引用你从图片中看到的视觉细节**。例如：
- "从图片中可以看到，该产品使用了一体成型的铝合金外壳，需要精密 CNC 模具"
- "图片显示产品有独特的卡扣结构设计，这种结构在 1688 上有大量通用方案"
- "从产品图观察到包装采用了磁吸翻盖礼盒，成本增加但容易复制"

如果无法从图片中提取有意义的视觉信息（图片模糊或无法加载），请在输出中明确说明。
**禁止** 只基于标题文字分析而忽略图片内容。

# Task
我会给你提供：
1. **产品信息**：标题 + 产品图片
2. **创新点描述**：用户认为这个产品的核心亮点
3. **差评信息**（可选）：买家投诉点，微改进方向的来源

你的任务是从以下四个维度判断复制难度，然后给出微改进方向：

## 复制难度四维度

### 1. 专利壁垒
- 外观/功能是否有明显专利风险？
- 基于产品图片中的结构特征判断：独创性结构 vs 通用设计
- 只做粗筛，有明显风险时标记

### 2. 供应链门槛
- 需要特殊工艺（精密注塑、CNC、激光切割）还是通用工艺？
- 需要定制模具还是公模可做？
- 材料是否特殊（普通塑料/硅胶 vs 特种合金/碳纤维）？
- 1688 上有没有类似方案？

### 3. 技术复杂度
- 纯硬件结构创新 vs 软件/算法/芯片方案？
- 硬件结构通常容易复制，软件算法壁垒更高
- 是否涉及认证门槛（FCC/UL/FDA）？

### 4. 品牌绑定
- 创新价值是否依赖品牌认知（特定配色体系、IP 授权）？
- 去掉品牌后创新本身还有没有独立价值？

## 微改进方向
从两个来源挖掘：
- **差评痛点**（优先）：区分结构性缺陷（改了就是新品）和品控问题（改了意义不大）
- **产品本身的机会**：功能叠加（成本+≤20%，感知价值翻倍）、外观微调（颜色/材质/包装）、规格扩展（尺寸/容量变体）

# Critical Rules
- 视觉分析中必须包含至少 2 处对图片视觉细节的具体引用
- 微改进建议要具体可执行，避免"优化用户体验"这类空话
- 专利风险只做粗筛，不做法律意见；有明显风险时提醒深查
- 如果没有差评信息，基于产品图片和品类常识推测痛点，标注为"推测"。"""


COPYABILITY_USER_PROMPT = """请分析以下竞品的创新可复制性。

---
**产品信息**
- ASIN: {asin}
- 标题: {title}
- 以下是产品图片（请仔细观察外观、材质、结构、配件、包装）：

---
**用户识别的创新点**
{innovation}

---
{reviews_section}

---

请严格按照以下逻辑步骤分析并输出 JSON：

**Step 1: 视觉观察记录**
仔细描述你从产品图片中观察到的关键视觉特征：材质、颜色、结构、尺寸比例、配件组成、包装形式。

**Step 2: 复制难度四维度判断**
分别从专利壁垒、供应链门槛、技术复杂度、品牌绑定四个角度评估。

**Step 3: 微改进方向**
结合差评痛点和产品机会，给出 3-5 条具体可执行的微改进建议。

**Step 4: 综合评分**
0-10 分。评分逻辑：复制门槛适中 + 差异化空间大 = 高分（理想状态）。

**Output Format (JSON Only):**
请使用中文回答，返回一个 JSON 对象：
{{
  "visual_observations": "从产品图片中观察到的关键视觉特征...",
  "copy_difficulty": "低 / 中 / 高",
  "barrier_analysis": {{
    "patent_risk": {{"level": "低 / 中 / 高", "reason": "判断依据，必须引用图片细节..."}},
    "supply_chain": {{"level": "低 / 中 / 高", "reason": "判断依据..."}},
    "tech_complexity": {{"level": "低 / 中 / 高", "reason": "判断依据..."}},
    "brand_bindness": {{"level": "低 / 中 / 高", "reason": "判断依据..."}}
  }},
  "differentiation_suggestions": [
    {{
      "type": "差评痛点 / 功能叠加 / 外观微调 / 规格扩展",
      "suggestion": "具体改进内容",
      "expected_effect": "预期效果",
      "cost_impact": "成本影响估计"
    }}
  ],
  "score": 8,
  "score_reason": "一句话评分理由",
  "verdict": "值得复制 / 可以尝试 / 需要谨慎 / 不建议复制"
}}"""


@capability(
    "analysis.innovation.copyability",
    description="多模态创新可复制性评估（专利/供应链/技术/品牌）",
    output_model=CopyabilityOutput,
    requires=["product.get"],
)
def assess_copyability(
    asin: str = "",
    image_url: str = "",
    innovation_desc: str = "",
    description: str = "",
    reviews: list[dict] | None = None,
    title: str = "",
) -> Result:
    return _assess_copyability(
        asin=asin, image_url=image_url, innovation_desc=innovation_desc, description=description, reviews=reviews, title=title,
        llm_call=resolve_chat_json(chat_json, default=_DEFAULT_CHAT_JSON, legacy_modules=('amz.analysis.innovation', 'amz.analysis.product.innovation')),
    )


def _assess_copyability(
    asin: str = "",
    image_url: str = "",
    innovation_desc: str = "",
    description: str = "",
    reviews: list[dict] | None = None,
    title: str = "",
    *, llm_call,
) -> Result:
    """analysis.innovation.copyability — 可复制性

    Args:
        asin: ASIN
        image_url: 产品图 URL（作为多模态图片内容传入）
        innovation_desc: 用户认为的创新点
        description: 产品描述
        reviews: 差评/评论列表 [{rating, title, text}, ...]
    """
    if not any(str(value or "").strip() for value in (title, description, innovation_desc, image_url)):
        return err(
            Code.ERROR_MISSING_FIELDS,
            "provide title, description, innovation_desc or image_url; ASIN alone is not analysis input",
            missing=["title"],
        )
    # 格式化差评信息
    reviews_info = ""
    if reviews:
        neg_reviews = [r for r in reviews if _rating_value(r.get("rating")) <= 3]
        if neg_reviews:
            lines = []
            for r in neg_reviews:
                review_title = r.get("title", "")
                text = r.get("text", r.get("body", "")) or ""
                lines.append(f"[{r.get('rating', '?')}★] {review_title}\n{text}")
            reviews_info = "**差评/痛点信息**\n" + "\n\n".join(lines)
        else:
            reviews_info = (
                f"**差评/痛点信息**\n共 {len(reviews)} 条评论，无明显差评。"
                "请基于产品图片和品类常识推测可能的痛点，标注为\"推测\"。"
            )
    elif not reviews:
        reviews_info = '**差评/痛点信息**\n（未提供，请基于产品图片和品类常识推测可能的痛点，标注为"推测"）'

    prompt = COPYABILITY_USER_PROMPT.format(
        asin=asin or "unknown",
        title=title or description or innovation_desc or "unknown product",
        innovation=innovation_desc or "no specific innovation described",
        reviews_section=reviews_info,
    )
    parts = prompt.split("\n---\n")
    user_content: list[dict] = [
        {"type": "text", "text": parts[0].strip()},
        {"type": "text", "text": parts[1].strip() if len(parts) > 1 else ""},
    ]
    if description:
        user_content.append({"type": "text", "text": "产品描述：\n" + description})
    if image_url:
        user_content.append({"type": "image_url", "image_url": {"url": image_url}})
    if len(parts) > 2:
        user_content.append({"type": "text", "text": "\n---\n".join(parts[2:]).strip()})
    source_note = "" if image_url else (
        "\n\n本次没有提供图片。只根据文字分析，不得声称看到外观或图片细节。"
        "上述视觉观察要求不适用于本次输入；visual_observations 返回空字符串。"
    )
    try:
        result = llm_call(
            messages=[
                {"role": "system", "content": COPYABILITY_SYSTEM_PROMPT + source_note},
                {"role": "user", "content": user_content},
            ],
            json_schema=CopyabilityOutput.model_json_schema(),
            model="pro", temperature=0.2,
        )
        output = parse_structured(result, CopyabilityOutput)
        if image_url and not output.visual_observations.strip():
            return err(Code.ERROR_LLM, "multimodal output omitted visual_observations")
        if not image_url and output.visual_observations.strip():
            return err(Code.ERROR_LLM, "visual_observations requires an input image")
        return ok(data=output.model_dump())
    except Exception as e:
        return err(Code.ERROR_LLM, str(e))
