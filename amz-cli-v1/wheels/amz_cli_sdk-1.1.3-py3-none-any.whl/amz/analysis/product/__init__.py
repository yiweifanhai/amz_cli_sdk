"""Analysis whose result belongs to one Product."""
