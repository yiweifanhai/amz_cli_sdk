"""Compatibility facade for Product material and copyability."""

from __future__ import annotations

from amz.envelope import Result
from amz.infra.llm import chat_json
from amz.schemas.analysis_inputs import MaterialAssessInput
from amz.schemas.innovation import CopyabilityOutput, MaterialAssessmentOutput
from amz.analysis.product.copyability import _rating_value, COPYABILITY_PROMPT, COPYABILITY_SYSTEM_PROMPT, COPYABILITY_USER_PROMPT, _assess_copyability
from amz.analysis.product.material import MATERIAL_PROMPT, _assess_material


def assess_copyability(
    asin: str = "",
    image_url: str = "",
    innovation_desc: str = "",
    description: str = "",
    reviews: list[dict] | None = None,
    title: str = "",
) -> Result:
    return _assess_copyability(
        asin=asin, image_url=image_url, innovation_desc=innovation_desc, description=description, reviews=reviews, title=title,
        llm_call=chat_json,
    )


def assess_material(product_info: dict, image_url: str = "") -> Result:
    return _assess_material(
        product_info=product_info, image_url=image_url,
        llm_call=chat_json,
    )
