"""Product VOC strengths analysis."""

from __future__ import annotations
from pydantic import ValidationError
from amz.envelope import Result
from amz.registry import capability
from amz.infra.llm import chat_json
from amz.schemas.analysis_inputs import VocStrengthsInput
from amz.schemas.voc import ProductVocListing, VocStrengthsAnalysisInput, VocStrengthsOutput
from amz.analysis._compat import resolve_chat_json
from amz.analysis.product._voc import _llm_output, _product_details, _input_error, _listing_snapshot, _JSON_ONLY_SUFFIX

_DEFAULT_CHAT_JSON = chat_json


VOC_STRENGTHS_PROMPT = """你是一位拥有10年经验的亚马逊选品专家和工业设计师，擅长通过 Listing 的细微差异发现产品的核心竞争力。

任务：基于下面的产品标题、五点描述、产品参数，对该产品做深度解构，找出它真实的创新点和竞争优势。

要求：
1. 去伪存真：忽略 "High Quality"、"Best Choice" 这类营销辞令，只看真实的参数、结构变化和独特功能。
2. 差分分析：假设市场上 90% 的同类产品都具备基础功能，重点找出这个产品相比它们做了哪些改进（材质升级、增加配件、结构优化、人性化设计等）。
3. 参数量化：每个创新点必须在 detail 中引用具体的参数、材质、尺寸数值或结构描述作为证据。例如，「304不锈钢」而非「优质不锈钢」，「10叶片电机」而非「高效电机」，「防水等级 IPX5」而非「防水设计」。
4. 差异化程度标注：每个创新点标注是「实质性创新」（参数/材质/结构有可验证的差异）还是「定位创新」（功能相同但通过组合/包装/人群定位形成差异）。

## 输入数据
产品标题：{title}

五点描述：
{features}

产品参数：
{details}

## 输出 JSON 结构（所有 value 用中文）：
{{
  "summary": "一句话概括该产品的核心定位与市场切入点",
  "innovation_and_competitive_advantages": [
    {{"innovation_summary": "物理变化+功能获益的简短标题", "detail": "详细拆解，包括材质/尺寸/结构差异等，引用原文中的具体参数作为证据", "innovation_type": "实质性创新|定位创新"}}
  ]
}}
按重要性从高到低排序。
""" + _JSON_ONLY_SUFFIX


def _analyze_strengths(
    listing: ProductVocListing,
    reviews_evidence: str | None = None,
    *, llm_call,
) -> Result:
    """执行一次优势语义推理；公开能力只负责输入适配。"""
    prompt = VOC_STRENGTHS_PROMPT.format(
        title=listing.title,
        features="\n".join(listing.bullet_points[:10]),
        details=_product_details(listing.model_dump()) or "无额外参数数据",
    )
    if reviews_evidence and reviews_evidence.strip():
        prompt += f"""

## 用户好评交叉验证（兼容旧入口）
以下是该产品的真实用户好评摘要。请对每个创新点做交叉验证：
- 有明确支持证据：user_validated = true，并摘录 user_evidence
- 有明确反证：user_validated = false
- 信号不足：user_validated = null

好评摘要：
{reviews_evidence[:3000]}
"""
    return _llm_output(prompt, VocStrengthsOutput, llm_call=llm_call)


@capability(
    "analysis.voc.strength-signals",
    description="从严格 Listing 快照提取产品创新优势",
    input_model=VocStrengthsAnalysisInput,
    output_model=VocStrengthsOutput,
    requires=["product.get"],
)
def voc_strength_signals(product_info: dict) -> Result:
    return _run_voc_strength_signals(
        product_info=product_info,
        llm_call=resolve_chat_json(chat_json, default=_DEFAULT_CHAT_JSON, legacy_modules=('amz.analysis.voc', 'amz.analysis.product.voc')),
    )


def _run_voc_strength_signals(product_info: dict, *, llm_call) -> Result:
    """严格原子入口：仅根据 Listing 事实提取创新优势。"""
    try:
        listing = _listing_snapshot(product_info)
    except ValidationError as exc:
        return _input_error(exc)
    return _analyze_strengths(listing, llm_call=llm_call)


@capability(
    "analysis.voc.strengths",
    description="产品创新优势兼容入口；新链路使用 strength-signals",
    input_model=VocStrengthsInput,
    output_model=VocStrengthsOutput,
)
def voc_strengths(
    product_info: dict,
    reviews: list[dict] | None = None,
    reviews_evidence: str | None = None,
) -> Result:
    return _run_voc_strengths(
        product_info=product_info, reviews=reviews, reviews_evidence=reviews_evidence,
        llm_call=resolve_chat_json(chat_json, default=_DEFAULT_CHAT_JSON, legacy_modules=('amz.analysis.voc', 'amz.analysis.product.voc')),
    )


def _run_voc_strengths(
    product_info: dict,
    reviews: list[dict] | None = None,
    reviews_evidence: str | None = None,
    *, llm_call,
) -> Result:
    """保留旧参数形状，并收敛到同一个优势语义实现。"""
    del reviews
    try:
        listing = _listing_snapshot(product_info)
    except ValidationError as exc:
        return _input_error(exc)
    return _analyze_strengths(listing, reviews_evidence, llm_call=llm_call)
