"""Shared structured output handling for Listing capabilities."""

from __future__ import annotations
import json
import re
from amz.envelope import Result, ok, err, Code
from amz.analysis.base import parse_structured
from amz.schemas.listing import _ListingModel


def listing_rules(brand: str = "", forbidden_terms: list[str] | None = None, media_title_limit: int | None = None) -> str:
    limit = media_title_limit or 75
    return f"""\n# Listing 发布约束（优先于关键词、保留原文和最小改动要求）
- 商品名称 title 对应 item_name，不超过 {limit} 字符，含空格。默认非媒介类 75；仅已核实的媒介类使用传入上限。
- 商品亮点 title_differentiation 为独立属性，不是五点描述；最多 125 字符，含空格。用逗号分隔短语，写有依据的材质、使用场景和关键规格。title 超过 75 时亮点必须为空。
- 标题和亮点禁用 ! $ ? _ {{ }} ^ ¬ ¦；只有已确认的本品品牌完整名称内的字符例外。
- 不出现其他品牌或商标词，包括关键词或原文中的竞品品牌；本品品牌：{json.dumps(brand, ensure_ascii=False)}；已知禁用词：{json.dumps(forbidden_terms or [], ensure_ascii=False)}。
- 不因关键词分级强塞标题。放不下的有效信息移入亮点或五点，禁止编造功能、材质、认证、效果或兼容性。
- 原文违规时必须修正，即使超出最小改动范围。反馈和插入计划不能放宽以上限制。
- 只能重排和改写输入已明确给出的事实，不能为了长度、关键词或文案吸引力补造属性。事实不足时写短句，允许少于建议长度。
- 螺旋盖或密封盖不等于已验证防漏：没有明确依据，不得新增 leakproof/leak-proof/watertight 或防漏效果承诺。材料名称也不能推导保温、防摔、食品级或耐用测试结论。
- 保留输入的限制和否定词；hand wash only 不能弱化为手洗建议，not for hot liquids 不能改成可以装热水。
- 不新增无依据的性价比、认证、安全、性能提升、使用寿命和兼容性说法。只允许输入明确支持的使用场景。
"""


def validate_listing(data: dict, brand: str = "", forbidden_terms: list[str] | None = None, media_title_limit: int | None = None) -> None:
    title = data.get("title")
    highlights = data.get("title_differentiation", "")
    if title is not None and (not title.strip() or len(title) > (media_title_limit or 75)):
        raise ValueError("title is empty or exceeds the character limit (including spaces)")
    if len(highlights) > 125:
        raise ValueError("title_differentiation exceeds 125 characters (including spaces)")
    if title and len(title) > 75 and highlights:
        raise ValueError("title_differentiation requires a title of at most 75 characters")
    for name, value in (("title", title), ("title_differentiation", highlights)):
        if not value:
            continue
        # Only a complete, explicitly supplied own-brand name grants an exception.
        remaining = re.sub(r"(?<!\w)" + re.escape(brand) + r"(?!\w)", "", value, flags=re.IGNORECASE) if brand else value
        if any(char in remaining for char in "!$?_{}^¬¦"):
            raise ValueError(f"{name} contains a prohibited character outside the own brand")
    texts = [title or "", highlights, data.get("text", ""), *data.get("bullet_points", [])]
    for term in forbidden_terms or []:
        if term.strip() and any(re.search(r"(?<!\w)" + re.escape(term.strip()) + r"(?!\w)", value, re.IGNORECASE) for value in texts):
            raise ValueError(f"listing contains a forbidden brand or trademark: {term}")


def _json_output(prompt: str, output_model: type[_ListingModel], model: str, temperature: float, *, llm_call, validate=None) -> Result:
    current_prompt = prompt
    for attempt in range(2):
        try:
            result = llm_call(
                prompt=current_prompt, json_schema=output_model.model_json_schema(),
                model=model, temperature=temperature,
            )
            parsed = parse_structured(result, output_model)
            if validate:
                validate(parsed.model_dump())
            return ok(data=parsed.model_dump())
        except ValueError as exc:
            if attempt:
                return err(Code.ERROR_LLM, str(exc))
            current_prompt = prompt + (
                "\n\n上次输出未通过程序校验。只根据上面的原始输入重新输出完整 JSON；"
                "报错中的旧输出不是事实来源。字符限制包括空格，优先使用简短表述，不能新增属性。"
                f"\n需修正的错误：{str(exc)[:1600]}"
            )
        except Exception as exc:
            return err(Code.ERROR_LLM, str(exc))
    raise AssertionError("Listing validation loop exhausted")
