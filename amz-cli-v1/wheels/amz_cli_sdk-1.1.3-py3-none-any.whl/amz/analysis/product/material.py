"""Product material analysis."""

from __future__ import annotations
from amz.envelope import Result, ok, err, Code
from amz.registry import capability
from amz.infra.llm import chat_json
from amz.analysis.base import parse_structured
from amz.schemas.analysis_inputs import MaterialAssessInput
from amz.schemas.innovation import MaterialAssessmentOutput
from amz.analysis._compat import resolve_chat_json

_DEFAULT_CHAT_JSON = chat_json


MATERIAL_PROMPT = """你是一位专业的产品材质分析师，现在需要你根据一个产品的图片，对应的关键词数据，以及产品的标题，判断材质以及改造生产难度

# 输入数据
    1. 主关键词，以及标题中提到的其他搜索关键词
    2. 产品的标题
    3. 关键词对应的市场的一级分类
    4. 二级分类
    5. 三级分类
    6. 产品的图片

# 主要工作
1. 判断该市场的产品的材质。材质需要为金属、陶瓷、玻璃、塑料、橡胶、布料纤维、纸张、骨头、木材、皮革、硅胶、石头珠宝、液体、碳/石墨材料中的一种，如果不属于其中的材质，请输出你认为的材质
如果是电子电器产品、电线、线缆、接头等，不需要判断材质，结果判断为电子产品。
如果产品是某个其他产品的附件（从图片中直接判别，或者分类是 Accessories等），例如手机壳、收纳袋、保护套等，就只看这个附件的材质，不关注主体产品的材质。
金属类产品，如果金属只是装饰或极少量使用（例如固定用的钢丝等），则不是产品的主要材质
2. 判断产品是否容易进行差异化改造的，从生产的角度判断是否容易进行低成本的差异化改造和生产。如3C电子电器产品需要开模会比较贵，但是陶瓷、玻璃、木材、纸张等材质的产品容易进行低成本的差异化改造。
金属类和不锈钢类产品，如果产品主体涉及金属加工，且工艺涉及铸造、弯折、冲压、电镀、表面处理、钻孔、切割、打磨、雕刻、机加工、CNC、激光刻字、激光雕刻等复杂工艺，这些工艺通常都比较复杂，会比较贵，因此不容易改造。
金属类制品如果要认为容易改造，一定是混合材质产品、且不大幅度改变产品金属部分，只改动塑料、布、皮等容易改造材质的情况，比如可以给塑料换个颜色之类的；金属部分，可以是类似改变尺寸等简单加工或者改造。
生物制品（或者含有生物制品、成分的）、化妆品、肉类、可食用产品、保健品（也包括宠物保健品）、化工用品、饲料、种子、药品、猫砂等，涉及复杂的安全性检查和检疫流程，都比较贵，不能简单改造。
电子产品（包括充电类的儿童玩具），先判断是不是充电的（需要插座供电的就属于没有电池+不需要充电），如果带有电池，或是需要充电类型的，涉及电池生产加工很贵，都认为不容易改造；
电子产品一定是在不改变软硬件本体的情况下，才算容易改造。
如果是工具套装等组合类产品，可以分开考虑各个部分，只要有一些部分容易改造，或者可以扩充其他工具，就算容易改造。
3. 给出最终的判断结果。

# 输出
material_reason # 材质判断的理由
material_conclusion # 最终的材质判断结果
easy_to_develop_reason # 是否容易开发该产品，不需要复杂的生产流程就可以低成本快速改造的理由
easy_to_develop_conclusion # 是否容易开发该产品的结论
easy_to_develop_mark # 是否容易开发该产品，使用bool类型描述，True为容易改造，False为难改造。

所有输出必须为中文。"""


@capability(
    "analysis.material.assess",
    description="新品材质与低成本可开发性多模态分析",
    input_model=MaterialAssessInput,
    output_model=MaterialAssessmentOutput,
)
def assess_material(product_info: dict, image_url: str = "") -> Result:
    return _assess_material(
        product_info=product_info, image_url=image_url,
        llm_call=resolve_chat_json(chat_json, default=_DEFAULT_CHAT_JSON, legacy_modules=('amz.analysis.innovation', 'amz.analysis.product.innovation')),
    )


def _assess_material(product_info: dict, image_url: str = "", *, llm_call) -> Result:
    if not isinstance(product_info, dict):
        return err(Code.ERROR_PARAM, "product_info must be an object")
    resolved_image = image_url or product_info.get("image_url", product_info.get("main_image_url", "")) or ""
    fact_keys = (
        "product_name", "title", "main_keyword", "keywords", "categories", "category",
        "category_display_name_1", "category_display_name_2", "category_display_name_3",
    )
    if not str(resolved_image).strip() and not any(product_info.get(key) for key in fact_keys):
        return err(
            Code.ERROR_MISSING_FIELDS,
            "provide a product title, keyword, category or image_url",
            missing=["product_info.title"],
        )
    categories = product_info.get("categories", []) or []
    if not isinstance(categories, list):
        categories = [categories]
    c1 = product_info.get("category_display_name_1", categories[0] if categories else product_info.get("category", ""))
    c2 = product_info.get("category_display_name_2", categories[1] if len(categories) > 1 else "")
    c3 = product_info.get("category_display_name_3", categories[2] if len(categories) > 2 else "")
    user_text = (
        f'主关键词：{product_info.get("main_keyword", "")}\n'
        f'其他搜索关键词：{product_info.get("keywords", "")}\n'
        f'产品标题：{product_info.get("product_name", product_info.get("title", ""))}\n'
        f'关键词对应的市场的一级分类：{c1}\n二级分类：{c2}\n三级分类：{c3}。以下为产品图片：'
    )
    content: list[dict] = [{"type": "text", "text": user_text}]
    if resolved_image:
        content.append({"type": "image_url", "image_url": {"url": resolved_image}})
    content.append({
        "type": "text",
        "text": "请根据以上图片和文字，判断该市场的产品的材质与是否容易低成本差异化改造。先给出理由，再给出最终结论。",
    })
    source_note = "" if resolved_image else (
        "\n\n本次没有提供图片。材质只能根据标题和关键词推断，必须明确说明推断与未知；"
        "不得声称观察到外观、结构或图片细节。"
    )
    try:
        result = llm_call(
            messages=[
                {"role": "system", "content": MATERIAL_PROMPT + source_note},
                {"role": "user", "content": content},
            ],
            json_schema=MaterialAssessmentOutput.model_json_schema(),
            model="pro", temperature=0.2,
        )
        return ok(data=parse_structured(result, MaterialAssessmentOutput).model_dump())
    except Exception as exc:
        return err(Code.ERROR_LLM, str(exc))
