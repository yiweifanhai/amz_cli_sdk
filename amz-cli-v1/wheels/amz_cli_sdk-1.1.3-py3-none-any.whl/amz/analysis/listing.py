"""Compatibility facade for the individual Product Listing capabilities."""

from __future__ import annotations

from amz.envelope import Result
from amz.infra.llm import chat_json, chat
from amz.analysis._compat import resolve_chat
from amz.schemas.analysis_inputs import (
    ListingAllocateInput, ListingMicroInsertInput, ListingPartRewriteInput, ListingRewriteInput,
)
from amz.schemas.listing import _ListingModel, ListingOutput, TextInsertionOutput, MicroInsertOutput, AllocationOutput, PartRewriteOutput
from amz.analysis.product.listing_rewrite import LISTING_REWRITE_PROMPT, _run_listing_rewrite
from amz.analysis.product.listing_insert import MICRO_INSERT_PROMPT, _run_listing_micro_insert
from amz.analysis.product.listing_allocate import LISTING_ALLOCATE_PROMPT, _run_listing_allocate
from amz.analysis.product.listing_part_rewrite import LISTING_PART_REWRITE_PROMPT, _run_listing_part_rewrite

_DEFAULT_CHAT = chat


def listing_rewrite(
    title: str,
    bullet_points: list[str],
    keywords: dict | None = None,
    price: str = "",
    image_url: str = "",
    feedback: str = "",
) -> Result:
    return _run_listing_rewrite(
        title=title, bullet_points=bullet_points, keywords=keywords, price=price, image_url=image_url, feedback=feedback,
        llm_call=chat_json,
    )


def listing_micro_insert(
    title: str = "",
    bullet_points: list[str] | None = None,
    insert_plan: dict | None = None,
    text: str = "",
    keywords: list[str] | None = None,
    feedback: str = "",
) -> Result:
    return _run_listing_micro_insert(
        title=title, bullet_points=bullet_points, insert_plan=insert_plan, text=text, keywords=keywords, feedback=feedback,
        llm_call=chat_json,
    )


def listing_allocate(
    listing: dict,
    missing_keywords: list[str],
    use_llm: bool = True,
) -> Result:
    return _run_listing_allocate(
        listing=listing, missing_keywords=missing_keywords, use_llm=use_llm,
        llm_call=chat_json,
    )


def listing_part_rewrite(
    product_title: str,
    part_label: str,
    current_text: str,
    keywords: list[dict],
    existing_keywords: list[str] | None = None,
    other_parts: dict | None = None,
    asin: str = "",
    price: str = "",
) -> Result:
    return _run_listing_part_rewrite(
        product_title=product_title, part_label=part_label, current_text=current_text, keywords=keywords, existing_keywords=existing_keywords, other_parts=other_parts, asin=asin, price=price,
        llm_call=resolve_chat(chat, default=_DEFAULT_CHAT, legacy_modules=('amz.infra.llm',)),
    )
