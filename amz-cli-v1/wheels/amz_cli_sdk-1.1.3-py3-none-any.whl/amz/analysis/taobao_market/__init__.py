"""Analysis capabilities owned by a Taobao Market."""
