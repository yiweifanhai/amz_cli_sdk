"""Taobao adapter for the shared market classification task."""
from pydantic import ValidationError
from amz.analysis._compat import resolve_chat_json
from amz.analysis.market.summary import classify_titles
from amz.envelope import Code, Result, err
from amz.infra.llm import chat_json
from amz.registry import capability
from amz.schemas.taobao_analysis import TaobaoClassifyInput, TaobaoMarketSummary


_DEFAULT_CHAT_JSON = chat_json


@capability(
    "analysis.taobao.market_classify",
    input_model=TaobaoClassifyInput,
    output_model=TaobaoMarketSummary,
    description="按解决方案分类淘宝商品，概述人群和场景，并保留商品 ID 与标题证据",
)
def market_classify(term: str, products: list[dict], model: str = "pro") -> Result:
    """Classify complete input only; no product fetching or Entity writes."""
    try:
        data = TaobaoClassifyInput(term=term, products=products, model=model)
    except ValidationError as exc:
        return err(Code.ERROR_PARAM, str(exc))
    result = classify_titles(data.term, data.products, data.model, platform="淘宝", llm_call=resolve_chat_json(
        chat_json, default=_DEFAULT_CHAT_JSON, legacy_modules=('amz.analysis.taobao', 'amz.analysis.market.taobao'),
    ))
    if result.code == Code.OK:
        result.data = TaobaoMarketSummary.model_validate(result.data).model_dump()
    return result
