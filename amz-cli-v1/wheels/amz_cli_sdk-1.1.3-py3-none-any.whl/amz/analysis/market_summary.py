"""Compatibility alias for :mod:`amz.analysis.market.summary`."""

import sys
from importlib import import_module

sys.modules[__name__] = import_module("amz.analysis.market.summary")
