"""Read-only provider overrides for historical Python import paths."""

import sys


def _resolve(current, *, default, legacy_modules: tuple[str, ...], attribute: str):
    if current is not default:
        return current
    for name in legacy_modules:
        module = sys.modules.get(name)
        candidate = getattr(module, attribute, default)
        if candidate is not default:
            return candidate
    return current


def resolve_chat_json(current, *, default, legacy_modules: tuple[str, ...]):
    """Prefer the current module override, then an already loaded old provider."""
    return _resolve(current, default=default, legacy_modules=legacy_modules, attribute="chat_json")


def resolve_chat(current, *, default, legacy_modules: tuple[str, ...]):
    """The same compatibility rule for historical plain-text model calls."""
    return _resolve(current, default=default, legacy_modules=legacy_modules, attribute="chat")
