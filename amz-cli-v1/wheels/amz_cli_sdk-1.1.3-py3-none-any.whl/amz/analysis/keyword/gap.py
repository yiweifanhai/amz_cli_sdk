"""Keyword gap analysis."""

from __future__ import annotations

from amz.envelope import Result
from amz.registry import capability
from amz.schemas.analysis_inputs import KeywordGapInput
from amz.schemas.keyword_analysis import KeywordGapOutput
from amz.calc.keyword import analyze_gap


@capability(
    "analysis.keyword.gap",
    description="兼容入口：确定性实现位于 calc.keyword.gap",
    input_model=KeywordGapInput,
    output_model=KeywordGapOutput,
)
def keyword_gap(
    keywords: list[dict],
    listing_text: dict,
) -> Result:
    """analysis.keyword.gap — 覆盖检查

    检查哪些关键词已在 listing 文本中出现，哪些缺失。

    Args:
        keywords: [{{term, grade}}, ...]
        listing_text: {{title, bullet_points: []}}
    """
    return analyze_gap(keywords=keywords, listing_text=listing_text)
