"""Keyword score analysis."""

from __future__ import annotations

from amz.envelope import Result, ok, err, Code
from amz.registry import capability
from amz.schemas.analysis_inputs import KeywordScoreInput
from amz.schemas.keyword_analysis import RelevanceOutput, KeywordScoreOutput
from amz.analysis._compat import _resolve
from .relevance import keyword_relevance, _product_text
from amz.calc.keyword import _normalize_keyword_row, score_keyword_rows

_DEFAULT_RELEVANCE = keyword_relevance


KEYWORD_SCORE_PROMPT = """你是 Amazon COSMO + Rufus 关键词评估专家。在 AI 时代，Listing 不再是简单的关键词堆砌，而是"Rufus 答案库"——每个关键词都要判断是否值得写入 Listing、放在哪个位置、以及优先级。

请对以下关键词进行多维度评分。

# 目标产品信息:
- 标题: {title}
- 描述: {features}

# 评分维度:

## relevanceScore (1-10): 与产品的相关性
- 10: 核心品类词/功能词，搜索该词的用户 100% 要找这类产品
- 7-9: 直接相关的功能/场景词
- 4-6: 间接相关，有一定关联
- 1-3: 弱相关或泛化词

## trafficScore (1-10): 搜索流量价值
- 基于提供的搜索量数据判断
- 10: 月搜索量极大，是品类核心流量入口
- 7-9: 月搜索量高，重要的流量来源
- 4-6: 中等搜索量
- 1-3: 低搜索量或长尾词

## conversionScore (1-10): 转化潜力
- 搜索该词的用户购买意图有多强？
- 10: 强购买意图（如精准功能词、规格词）
- 7-9: 明确购买意图
- 4-6: 有购买意图但不够明确
- 1-3: 信息查询意图为主

## competitionScore (1-10): 竞争友好度
- 注意：分数越高 = 竞争越低 = 越好
- 10: 几乎没有竞争，容易排名
- 7-9: 竞争较低
- 4-6: 中等竞争
- 1-3: 竞争激烈，头部垄断严重

## suggestedPosition: 建议埋词位置
- "title+bullet": 核心词，必须在标题+五点中出现（S级）
- "title": 重要品类词，需要在标题中出现
- "bullet": 功能/场景/痛点词，适合写在五点描述中
- "description": 长尾语义/叙事性场景词，适合产品描述或 A+
- "search_term": 补充性词汇，不适合前台但有搜索价值，放后台 Search Term
- "not_recommended": 与产品无关或价值太低，不建议使用

# 待评分关键词:
{keywords_text}

# 输出格式 (纯 JSON):
{{
  "scores": [
    {{"keyword": "词条", "relevanceScore": 8, "trafficScore": 7, "conversionScore": 6, "competitionScore": 7, "match": "perfect|high|partial|low", "grade": "S|A|B|C", "suggestedPosition": "bullet", "reason": "简短理由（15字以内）"}}
  ]
}}

注意:
- 必须为每个输入关键词都返回评分，不能遗漏
- reason 简洁（15字以内）
- 所有分数都是 1-10 的整数
- suggestedPosition 必须是 title+bullet/title/bullet/description/search_term/not_recommended 之一"""


@capability(
    "analysis.keyword.score",
    description="A10 四维混合评分（候选集合内百分位 + LLM 语义乘数）",
    input_model=KeywordScoreInput,
    output_model=KeywordScoreOutput,
)
def keyword_score(keywords: list[dict], product_info: dict | None = None) -> Result:
    """Score supplied candidates relative to this set and a concrete product."""
    if not isinstance(keywords, list):
        return err(Code.ERROR_PARAM, "keywords must be a list")
    if not keywords:
        return ok(data=KeywordScoreOutput(grade_distribution={"S": 0, "A": 0, "B": 0, "C": 0}).model_dump())
    if not _product_text(product_info):
        return err(Code.ERROR_MISSING_FIELDS, "product_info requires title, bullet_points or description", missing=["product_info"])
    if any(not isinstance(item, dict) for item in keywords):
        return err(Code.ERROR_PARAM, "keywords must contain objects")
    rows = [_normalize_keyword_row(item) for item in keywords]
    terms = [row["keyword"].strip() for row in rows]
    if any(not term for term in terms) or len({term.casefold() for term in terms}) != len(terms):
        return err(Code.ERROR_PARAM, "keywords require unique non-empty term or keyword values")
    for row, term in zip(rows, terms):
        row["keyword"] = term

    relevance_call = _resolve(keyword_relevance, default=_DEFAULT_RELEVANCE,
                              legacy_modules=("amz.analysis.keyword",), attribute="keyword_relevance")
    try:
        result = relevance_call(terms, product_info)
        if result.code != Code.OK:
            return result
        output = RelevanceOutput.model_validate(result.data)
        relevance_map = {}
        for item in output.results:
            key = item.keyword.strip().casefold()
            if key in relevance_map or item.match == "unknown":
                raise ValueError("duplicate or missing semantic judgment")
            relevance_map[key] = item.model_dump()
        if relevance_map.keys() != {term.casefold() for term in terms}:
            raise ValueError("semantic judgments do not cover the candidate set")
    except Exception as exc:
        return err(Code.ERROR_LLM, f"keyword scoring requires complete semantic judgments: {exc}")
    try:
        return ok(data=score_keyword_rows(rows, relevance_map))
    except (TypeError, ValueError) as exc:
        return err(Code.ERROR_PARAM, f"invalid keyword metrics: {exc}")
