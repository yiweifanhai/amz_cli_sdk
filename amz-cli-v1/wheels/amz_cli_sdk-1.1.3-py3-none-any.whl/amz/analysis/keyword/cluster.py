"""Keyword cluster analysis."""

from __future__ import annotations

import math

from amz.envelope import Result, ok, err, Code
from amz.registry import capability
from amz.schemas.analysis_inputs import KeywordClusterInput
from amz.schemas.keyword_analysis import KeywordCluster, KeywordClusterOutput
from amz.infra.llm import chat_json
from amz.analysis.base import require_json
from amz.analysis._compat import resolve_chat_json

_DEFAULT_CHAT_JSON = chat_json


CLUSTER_SEED_PROMPT = """You are clustering the top Amazon search keywords for the market "{main_keyword}".

These are the top-volume Amazon search terms shoppers actually type (keyword | monthly_searches):
{kw_list}

Task: Merge keywords that represent the SAME shopper intent into one seed cluster.
- Two keywords with the same intent but different wording (synonyms, word order, plural/singular, "X for Y" vs "Y X") MUST be merged.
- Two keywords with genuinely different intent stay in different clusters.
- Use search volume as a signal: large-volume keywords are real shopper demand, not noise. Do not split a cluster just because two phrasings differ.
- The cluster "name" MUST be copied verbatim from the highest-volume keyword inside that cluster (it acts as the canonical label).
- Mark "relevant_to_main": true if the cluster's intent is a sub-intent of "{main_keyword}" (the shopper would accept a product matching the main keyword). Mark false if the cluster drifts to a different product category.

Output format (STRICT JSON):
{{
  "clusters": [
    {{"name": "<verbatim highest-volume keyword>",
      "intent": "one-sentence intent description (<= 120 chars, no quotes/newlines)",
      "relevant_to_main": true,
      "keywords": ["kw1", "kw2"]}}
  ]
}}

Hard constraints:
- "name": MUST be one of the input keywords above, copied verbatim.
- "keywords": only strings copied EXACTLY from the input list.
- Each input keyword must appear in EXACTLY ONE cluster.
- The main keyword "{main_keyword}" MUST appear in exactly one cluster."""


CLUSTER_ATTACH_PROMPT = """You are assigning Amazon search keywords to existing seed clusters for the market "{main_keyword}".

Seed clusters (already finalized -- do NOT create new ones, do NOT rename):
{seed_block}

Long-tail keywords to assign (keyword | monthly_searches):
{kw_list}

Task: For each long-tail keyword, pick the ONE seed cluster whose intent best matches it.
- Match by shopper intent, not lexical similarity alone.
- A keyword belongs to the cluster a shopper typing it would most likely accept products from.
- If a keyword genuinely matches none of the seed clusters' intent, assign it to "_off_topic".

Output format (STRICT JSON):
{{
  "assignments": [
    {{"keyword": "<verbatim keyword from input>", "cluster": "<seed cluster name OR _off_topic>"}}
  ]
}}

Hard constraints:
- Every input long-tail keyword MUST appear exactly once.
- "keyword" copied verbatim from the input list.
- "cluster" MUST be one of the seed cluster names listed above, or "_off_topic"."""


@capability(
    "analysis.cluster.keywords",
    description="关键词意图聚类（两阶段，完整性校验）",
    input_model=KeywordClusterInput,
    output_model=KeywordClusterOutput,
    requires=["keyword.miner"],
)
def cluster_keywords(
    keywords: list[dict],
    main_keyword: str = "",
    seed_count: int = 30,
    batch_size: int = 50,
) -> Result:
    """Cluster only supplied candidates; every model assignment must be explicit."""
    if not isinstance(keywords, list):
        return err(Code.ERROR_PARAM, "keywords must be a list")
    if not keywords:
        return ok(data=KeywordClusterOutput().model_dump())
    if not isinstance(seed_count, int) or seed_count < 1 or not isinstance(batch_size, int) or batch_size < 1:
        return err(Code.ERROR_PARAM, "seed_count and batch_size must be positive")
    normalized: list[dict] = []
    seen_terms: set[str] = set()
    try:
        for row in keywords:
            if not isinstance(row, dict):
                raise ValueError("keywords must contain objects")
            term = str(row.get("term") or row.get("keyword") or "").strip()
            if not term or term.casefold() in seen_terms:
                raise ValueError("keywords require unique non-empty term or keyword values")
            if term == "_off_topic":
                raise ValueError("_off_topic is a reserved cluster name")
            volume = float(row.get("search_volume", row.get("searches", 0)) or 0)
            if not math.isfinite(volume) or volume < 0:
                raise ValueError("search_volume must be a non-negative finite number")
            seen_terms.add(term.casefold())
            normalized.append({"term": term, "search_volume": volume})
    except (TypeError, ValueError) as exc:
        return err(Code.ERROR_PARAM, str(exc))
    sorted_kws = sorted(normalized, key=lambda row: row["search_volume"], reverse=True)
    main_match = next((row for row in sorted_kws if row["term"].casefold() == main_keyword.strip().casefold()), None) if main_keyword else None
    if main_keyword and main_match is None:
        return err(Code.ERROR_PARAM, "main_keyword must belong to the candidate set")
    main_kw = main_match["term"] if main_match else sorted_kws[0]["term"]
    seeds = ([main_match] if main_match else []) + [
        row for row in sorted_kws if row is not main_match
    ][:seed_count - bool(main_match)]
    seed_volume = {row["term"]: row["search_volume"] for row in seeds}
    long_tail = [row for row in sorted_kws if row["term"] not in seed_volume]
    llm_call = resolve_chat_json(chat_json, default=_DEFAULT_CHAT_JSON, legacy_modules=("amz.analysis.keyword",))
    prompt = CLUSTER_SEED_PROMPT.format(main_keyword=main_kw, kw_list="\n".join(f'- {row["term"]} | {row["search_volume"]}' for row in seeds))
    try:
        raw = require_json(llm_call(prompt=prompt, model="pro", temperature=0.2, ttl_seconds=86400))
        if not isinstance(raw, dict) or not isinstance(raw.get("clusters"), list):
            raise ValueError("seed output requires a clusters array")
        clusters: list[dict] = []
        assigned: set[str] = set()
        for group in raw["clusters"]:
            if not isinstance(group, dict) or not isinstance(group.get("keywords"), list) or not group["keywords"]:
                raise ValueError("every seed cluster requires keyword members")
            members = group["keywords"]
            if any(not isinstance(term, str) or term not in seed_volume or term in assigned for term in members) or len(set(members)) != len(members):
                raise ValueError("seed members must belong to the input exactly once")
            if type(group.get("relevant_to_main")) is not bool:
                raise ValueError("seed relevance requires an explicit boolean judgment")
            if not isinstance(group.get("intent"), str) or not group["intent"].strip():
                raise ValueError("seed cluster requires a semantic intent")
            assigned.update(members)
            # Label choice is deterministic once the model supplied membership.
            clusters.append({
                "name": max(members, key=seed_volume.get), "intent": group["intent"],
                "relevant_to_main": group["relevant_to_main"], "keywords": list(members),
            })
        if assigned != seed_volume.keys():
            raise ValueError("model omitted seed keywords")
    except Exception as exc:
        return err(Code.ERROR_LLM, f"Stage 1 seed clustering failed: {exc}")

    cluster_map = {group["name"]: group for group in clusters}
    off_topic = {"name": "_off_topic", "intent": "Off-topic keywords", "keywords": [], "relevant_to_main": False}
    seed_block = "\n".join(f'- {group["name"]}: {group["intent"]} (keywords: {", ".join(group["keywords"][:5])})' for group in clusters)
    for start in range(0, len(long_tail), batch_size):
        batch = long_tail[start:start + batch_size]
        expected = {row["term"] for row in batch}
        prompt = CLUSTER_ATTACH_PROMPT.format(main_keyword=main_kw, seed_block=seed_block,
            kw_list="\n".join(f'- {row["term"]} | {row["search_volume"]}' for row in batch))
        try:
            raw = require_json(llm_call(prompt=prompt, model="lite", temperature=0.1, ttl_seconds=86400))
            if not isinstance(raw, dict) or not isinstance(raw.get("assignments"), list):
                raise ValueError("attach output requires an assignments array")
            assigned = set()
            for item in raw["assignments"]:
                if not isinstance(item, dict):
                    raise ValueError("assignment must be an object")
                term, name = item.get("keyword"), item.get("cluster")
                if not isinstance(term, str) or term not in expected or term in assigned:
                    raise ValueError("long-tail members must belong to this batch exactly once")
                if name != "_off_topic" and name not in cluster_map:
                    raise ValueError("assignment names an unknown cluster")
                target = off_topic if name == "_off_topic" else cluster_map[name]
                target["keywords"].append(term)
                assigned.add(term)
            if assigned != expected:
                raise ValueError("model omitted long-tail keywords")
        except Exception as exc:
            return err(Code.ERROR_LLM, f"Stage 2 keyword assignment failed: {exc}")
    if off_topic["keywords"]:
        clusters.append(off_topic)
    volumes = {row["term"]: row["search_volume"] for row in normalized}
    mapping = {term: group["name"] for group in clusters for term in group["keywords"]}
    output = KeywordClusterOutput(
        clusters=[KeywordCluster(**group, members_count=len(group["keywords"]),
            search_total=sum(volumes[term] for term in group["keywords"])) for group in clusters],
        keyword_to_cluster=mapping, total_assigned=len(mapping),
    )
    return ok(data=output.model_dump())
