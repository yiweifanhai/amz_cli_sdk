"""Validate prepared product rows and the references returned by market analyses."""
from __future__ import annotations

from amz.analysis.base import AnalysisContractError
from amz.envelope import Code, Result, err


def validate_rows(rows: list[dict], field: str) -> Result | None:
    if not isinstance(rows, list) or not rows:
        return err(Code.ERROR_MISSING_FIELDS, f"{field} requires prepared product rows", missing=[field])
    seen = set()
    for row in rows:
        if not isinstance(row, dict):
            return err(Code.ERROR_PARAM, f"{field} rows must be objects")
        asin = row.get("asin")
        if not isinstance(asin, str) or not asin.strip():
            return err(Code.ERROR_MISSING_FIELDS, f"{field} rows require an ASIN", missing=["asin"])
        key = asin.strip().upper()
        if key in seen:
            return err(Code.ERROR_PARAM, f"duplicate {field} product ASIN: {asin}")
        seen.add(key)
        if not isinstance(row.get(field), dict) or not row[field]:
            return err(Code.ERROR_MISSING_FIELDS, f"{asin} requires prepared {field}", missing=[field])
    return None


def normalize_references(points: list[dict], field: str, asins: list[str]) -> None:
    """Keep model references within the supplied sample and count unique products."""
    known = {asin.strip().upper(): asin.strip() for asin in asins}
    for point in points:
        values = []
        for asin in point.get(field, []):
            key = asin.strip().upper()
            if key not in known:
                raise AnalysisContractError(f"model returned an unknown product ASIN: {asin}")
            if known[key] not in values:
                values.append(known[key])
        point[field] = values
        if field == "asin_list":
            point["asin_cnt"] = len(values)
