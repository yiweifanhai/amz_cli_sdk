"""Compatibility alias for the Taobao Market title-classification capability."""

import sys
from importlib import import_module

sys.modules[__name__] = import_module("amz.analysis.taobao_market.classify")
