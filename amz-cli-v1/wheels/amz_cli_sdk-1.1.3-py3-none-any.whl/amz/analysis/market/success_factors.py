"""market_success_factors: analyze only the prepared market facts supplied by the caller."""
from __future__ import annotations
from amz.envelope import Result, Code, err
from amz.registry import capability
from amz.infra.llm import chat_json
from amz.analysis._compat import resolve_chat_json
from amz.analysis.market._inputs import validate_rows, normalize_references
from amz.analysis.market._output import _JSON_ONLY, _llm_output
from amz.schemas.market_analysis import SuccessFactorsOutput
from amz.schemas.analysis_inputs import MarketSuccessFactorsInput

_DEFAULT_CHAT_JSON = chat_json

SUCCESS_FACTORS_PROMPT = """你是一位资深的亚马逊产品专家，擅长解构头部产品的成功密码。

下面是某细分市场里销量/口碑领先的几个产品（Market Leaders）的创新点与竞争优势。请提炼出这个市场里值得参考的成功因子——可能是特定的产品特性、设计理念、材质选择、功能组合或定位策略，并归类汇总。

# 领先产品数据
{leaders}

# 输出 JSON（所有 value 用中文）：
{{
  "market_leaders_success_factors": [
    {{"factor_name": "成功因子名称", "description": "该因子如何帮助产品成功", "example_asins": ["ASIN"], "why_it_works": "为什么在市场上有效"}}
  ]
}}
""" + _JSON_ONLY


@capability(
    "analysis.market.success-factors",
    description="提炼市场领先产品的成功因子",
    input_model=MarketSuccessFactorsInput,
    output_model=SuccessFactorsOutput,
    requires=["analysis.voc.strengths"],
)
def market_success_factors(leaders: list[dict]) -> Result:
    """analysis.market.success-factors — 成功因子提炼

    将多个 Market Leader 的 VOC 分析结果（strengths）聚合，提炼共性成功因子。

    Args:
        leaders: [{{asin, strengths: {{summary, innovation_and_competitive_advantages: [...]}}}}, ...]
    """
    failure = validate_rows(leaders, "strengths")
    if failure is not None:
        return failure
    for item in leaders:
        strengths = item["strengths"]
        advantages = strengths.get("innovation_and_competitive_advantages", [])
        if not isinstance(advantages, list) or any(not isinstance(value, dict) for value in advantages):
            return err(Code.ERROR_PARAM, "strengths advantages must be a list of objects")
        if not strengths.get("summary") and not advantages:
            return err(Code.ERROR_MISSING_FIELDS, "leader strengths need a summary or advantages", missing=["strengths"])
    # 格式化领先产品数据
    lines = []
    for item in leaders:
        asin = item.get("asin", "unknown")
        strengths = item.get("strengths", {})
        summary = strengths.get("summary", "")
        advantages = strengths.get("innovation_and_competitive_advantages", [])
        adv_lines = "\n".join(
            f"  - {a.get('innovation_summary', '')}: {str(a.get('detail') or '')[:200]}"
            for a in advantages[:10]
        )
        lines.append(f"## {asin}\n核心定位: {summary}\n创新优势:\n{adv_lines}\n")

    prompt = SUCCESS_FACTORS_PROMPT.format(leaders="\n".join(lines))

    result = _llm_output(
        prompt, SuccessFactorsOutput,
        call_model=resolve_chat_json(chat_json, default=_DEFAULT_CHAT_JSON, legacy_modules=("amz.analysis.market_gap",)),
    )
    if result.code == Code.OK:
        try:
            normalize_references(result.data["market_leaders_success_factors"], "example_asins", [row["asin"] for row in leaders])
        except ValueError as exc:
            return err(Code.ERROR_LLM, str(exc))
    return result
