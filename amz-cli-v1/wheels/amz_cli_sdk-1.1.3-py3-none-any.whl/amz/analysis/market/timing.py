"""Market entry timing relative to the caller's date and preparation period."""
from __future__ import annotations
import calendar
from datetime import date
from amz.envelope import Code, Result, err, ok
from amz.infra.llm import chat_json
from amz.analysis._compat import resolve_chat_json
from amz.analysis.base import parse_structured
from amz.registry import capability
from amz.schemas.analysis_inputs import MarketTimingInput
from amz.schemas.demand import TimingOutput

_DEFAULT_CHAT_JSON = chat_json

def _add_months(value: date, months: int) -> date:
    month_index = value.month - 1 + months
    year = value.year + month_index // 12
    month = month_index % 12 + 1
    day = min(value.day, calendar.monthrange(year, month)[1])
    return date(year, month, day)

TIMING_PROMPT = """You are an Amazon market-entry timing analyst. Use common-sense product
understanding, not title keyword scanning and not invented sales data.

Current date: {current_date}
Expected FBA sellable date (current date + {preparation_months} months): {launch_date}
Default market: United States / Northern Hemisphere

Product title: {title}
Category: {category}
Features:\n{features}
Description: {description}
Optional supplied market signals (supporting evidence only):\n{market_data}

Method:
1. Explain product function.
2. Infer who uses it, in what weather/occasion, and what problem it solves.
3. From that use case infer concrete peak-demand months.
4. Compare the launch date with the demand window.
5. Classify seasonality: A strong seasonal, B holiday-bound, C weak seasonal, D non-seasonal.

Scoring:
- 0-40 STOP: peak has passed and next useful window is at least 6 months away.
- 41-55 CAUTION: tight launch or 3-5 months of inventory waiting.
- 56-75 GO: launch overlaps the rising-demand window.
- 76-100 GO: non-seasonal or perfectly timed before peak.

Return JSON only:
{{
  "block": "market_timing",
  "score": 0,
  "verdict": "GO|CAUTION|STOP",
  "verdict_reason": "one sentence",
  "details": {{
    "product_function": "...",
    "use_case_inference": "function -> situation -> concrete peak months",
    "seasonality_type": "A|B|C|D",
    "seasonality_label": "...",
    "peak_demand_window": "specific months",
    "launch_window": "specific month/year",
    "mismatch_reason": "why the windows match or mismatch"
  }}
}}"""

@capability(
    "analysis.market.timing",
    description="按参考日期与准备月数评估市场进入时机，默认准备3个月",
    input_model=MarketTimingInput,
    output_model=TimingOutput,
    requires=["keyword.trends"],
)
def market_timing(
    asin: str = "",
    keyword: str = "",
    market_data: dict | None = None,
    product_info: dict | None = None,
    current_date: str = "",
    preparation_months: int = 3,
) -> Result:
    product = product_info or {}
    if not isinstance(product, dict) or (market_data is not None and not isinstance(market_data, dict)):
        return err(Code.ERROR_PARAM, "product_info and market_data must be objects")
    if not keyword.strip() and not any(product.get(name) for name in ("title", "category", "description", "productDescription", "features", "bullet_points")):
        return err(Code.ERROR_MISSING_FIELDS, "timing requires product facts or a product keyword; an ASIN alone is insufficient", missing=["product_info or keyword"])
    if isinstance(preparation_months, bool) or not isinstance(preparation_months, int) or not 0 <= preparation_months <= 24:
        return err(Code.ERROR_PARAM, "preparation_months must be an integer from 0 to 24")
    try:
        today = date.fromisoformat(current_date) if current_date else date.today()
    except (TypeError, ValueError):
        return err(Code.ERROR_PARAM, "current_date must be YYYY-MM-DD")
    try:
        launch = _add_months(today, preparation_months)
    except (ValueError, OverflowError):
        return err(Code.ERROR_PARAM, "preparation period exceeds the supported date range")
    features = product.get("bullet_points", product.get("features", [])) or []
    if isinstance(features, str):
        features = [features]
    prompt = TIMING_PROMPT.format(
        current_date=today.isoformat(), launch_date=launch.isoformat(), preparation_months=preparation_months,
        title=product.get("title", keyword or asin or "unknown"),
        category=product.get("category", product.get("node_label_path", "unknown")),
        features="\n".join(str(item) for item in features[:10]),
        description=product.get("description", product.get("productDescription", "")),
        market_data="\n".join(f"{key}: {value}" for key, value in (market_data or {}).items()) or "none",
    )
    try:
        response = resolve_chat_json(chat_json, default=_DEFAULT_CHAT_JSON, legacy_modules=("amz.analysis.demand",))(
            prompt=prompt, json_schema=TimingOutput.model_json_schema(),
            model="lite", temperature=0.2,
        )
        output = parse_structured(response, TimingOutput)
        # launch_window 是事实字段，不允许模型改写成模糊文本。
        output.details.launch_window = launch.strftime("%Y-%m")
        return ok(data=output.model_dump())
    except Exception as exc:
        return err(Code.ERROR_LLM, str(exc))
