"""Shared synonym grouping for Market COSMO and the legacy aggregate API."""

from __future__ import annotations

from amz.analysis.base import AnalysisContractError, require_json
from amz.infra.llm import chat_json
from amz.schemas.cosmo import MergedTerm, TermGroup

COSMO_AGGREGATE_PROMPT = """You are an Amazon search synonym aggregation expert. Group the following terms from the same COSMO semantic field into synonym groups.

## Three Heuristic Rules (you MUST check all three before grouping):

1. **Intent Substitution Test**: If a user searches Term A and only receives products featuring Term B, would they be highly satisfied? If NO -> do NOT group.
   - Example: "yoga mat" and "exercise mat" -> YES (same product intent) -> group
   - Example: "non-toxic" and "eco-friendly" -> NO (different intent) -> do NOT group

2. **Mutually Exclusive Scenario Test**: Do the two terms target different specific pain points or user groups? If YES -> do NOT group.
   - Example: "indoor yoga" and "outdoor yoga" -> YES (different scenarios) -> do NOT group

3. **Parent-Child Rule**: Is Term A a specific subtype of Term B? If YES -> do NOT group (keep as separate standalone terms).
   - Example: "natural rubber" is a subtype of "rubber" -> do NOT group

## Representative term selection:
{target_product_hint}

## Terms to aggregate (all from the same COSMO field):
{terms_text}

## Output format (pure JSON only, no markdown):
{{
  "groups": [
    {{
      "representativeTerm": "yoga mat",
      "representativeTermCn": "瑜伽垫",
      "members": ["yoga mat", "exercise mat", "fitness mat"]
    }},
    {{
      "representativeTerm": "non-toxic",
      "representativeTermCn": "无毒",
      "members": ["non-toxic"]
    }}
  ]
}}

Rules:
- Every input term MUST appear in exactly one group's members list
- A standalone term is a group with only itself as a member
- Do not invent new terms
- representativeTermCn: concise Chinese translation of the representative term (2-6 characters preferred)"""


def group_terms(
    terms: list[dict], target_product: str = "", *, model: str = "lite",
    strict_members: bool = False, call_model=None,
) -> list[TermGroup]:
    """One synonym grouping implementation shared by old and Market entries."""
    fields: dict[str, list[dict]] = {}
    for term in terms:
        fields.setdefault(str(term.get("cosmo_field") or "unknown"), []).append(term)

    all_groups: list[TermGroup] = []
    for field_terms in fields.values():
        batches = [field_terms[index : index + 60] for index in range(0, len(field_terms), 60)]
        batch_groups: list[TermGroup] = []
        for batch in batches:
            batch_groups.extend(_aggregate_batch(
                batch, target_product, model=model, strict_members=strict_members,
                call_model=call_model,
            ))
        if len(batches) > 1 and len(batch_groups) > 1:
            batch_groups = _cross_batch_merge(
                batch_groups, target_product, model=model,
                strict_members=strict_members, call_model=call_model,
            )
        all_groups.extend(batch_groups)
    all_groups.sort(key=lambda group: (-group.count, -group.weighted_score, group.representative_term.lower()))
    return all_groups


def _group_stats(members: list[dict]) -> dict:
    asins = sorted({asin for member in members for asin in member.get("asins", [])})
    return {
        "count": sum(int(member.get("count", 0)) for member in members),
        "title_count": sum(int(member.get("title_count", 0)) for member in members),
        "bullet_points_count": sum(int(member.get("bullet_points_count", 0)) for member in members),
        "review_count": sum(int(member.get("review_count", 0)) for member in members),
        "image_description_count": sum(int(member.get("image_description_count", 0)) for member in members),
        "a_plus_count": sum(int(member.get("a_plus_count", 0)) for member in members),
        "weighted_score": sum(int(member.get("weighted_score", 0)) for member in members),
        "asins": asins,
    }


def _make_group(members: list[dict], representative: str, representative_cn: str = "") -> TermGroup:
    rep = next((item for item in members if item["term"].lower() == representative.lower()), members[0])
    synonyms = [item["term"] for item in members if item["term"].lower() != rep["term"].lower()]
    warnings = []
    if len(members) > 5:
        warnings.append("同义组超过 5 个成员，请人工复核")
    lowered = [str(item["term"]).lower().split() for item in members]
    for left_index, left in enumerate(lowered):
        for right_index in range(left_index + 1, len(lowered)):
            right = lowered[right_index]
            if len(left) == len(right):
                continue
            shorter, longer = (left, right) if len(left) < len(right) else (right, left)
            if len(longer) - len(shorter) <= 2 and all(word in longer for word in shorter):
                warnings.append(
                    f'"{members[left_index]["term"]}" 和 "{members[right_index]["term"]}" 可能是父子关系'
                )
    coverages = [len(item.get("asins", [])) for item in members]
    if len(members) > 1 and coverages and min(coverages) > 0 and max(coverages) / min(coverages) > 3:
        warnings.append("组内 ASIN 覆盖差异过大")
    return TermGroup(
        group_id=f"{rep['cosmo_field']}::{rep['term']}",
        representative_term=rep["term"], representative_term_cn=representative_cn,
        synonyms=synonyms, members=[MergedTerm.model_validate(item) for item in members],
        cosmo_category=rep["cosmo_category"], cosmo_field=rep["cosmo_field"],
        needs_review=bool(warnings), warnings=warnings, **_group_stats(members),
    )


def _aggregate_batch(
    terms: list[dict], target_product: str, *, model: str = "lite",
    strict_members: bool = False, call_model=None,
) -> list[TermGroup]:
    if not terms:
        return []
    if len(terms) == 1:
        return [_make_group(terms, terms[0]["term"])]
    terms_text = "\n".join(f'- "{item["term"]}" (count: {item.get("count", 0)})' for item in terms)
    hint = (
        f'choose the term that best matches the target product: "{target_product}"'
        if target_product else
        "choose the most generic, high-search-volume term (usually the shortest and most universal expression)"
    )
    prompt = COSMO_AGGREGATE_PROMPT.format(target_product_hint=hint, terms_text=terms_text)
    raw = require_json((call_model or chat_json)(prompt=prompt, model=model, temperature=0.2))
    llm_groups = raw.get("groups") if isinstance(raw, dict) else None
    if not isinstance(llm_groups, list) or not llm_groups:
        raise AnalysisContractError("COSMO grouping requires non-empty groups")
    lookup = {item["term"].lower(): item for item in terms}
    assigned: set[str] = set()
    groups: list[TermGroup] = []
    for raw_group in llm_groups:
        if not isinstance(raw_group, dict) or not isinstance(raw_group.get("members"), list) or not raw_group["members"]:
            raise AnalysisContractError("COSMO group requires a non-empty members list")
        members = []
        for member_name in raw_group.get("members", []):
            if not isinstance(member_name, str):
                raise AnalysisContractError("COSMO member must be an input term")
            key = str(member_name).lower()
            if key not in lookup or key in assigned:
                raise AnalysisContractError("COSMO group contains an unknown or repeated member")
            if key in lookup and key not in assigned:
                members.append(lookup[key])
                assigned.add(key)
        if members:
            groups.append(_make_group(
                members,
                str(raw_group.get("representativeTerm") or members[0]["term"]),
                str(raw_group.get("representativeTermCn") or ""),
            ))
    for key, term in lookup.items():
        if key not in assigned:
            if strict_members:
                raise AnalysisContractError("COSMO grouping omitted input members")
            restored = _make_group([term], term["term"])
            restored.needs_review = True
            restored.warnings.append("模型遗漏该术语；已保留为独立组，语义关系待复核")
            groups.append(restored)
    return groups


def _cross_batch_merge(
    groups: list[TermGroup], target_product: str, *, model: str = "lite",
    strict_members: bool = False, call_model=None,
) -> list[TermGroup]:
    representatives = []
    original = {}
    for group in groups:
        item = {
            "term": group.representative_term,
            "cosmo_category": group.cosmo_category,
            "cosmo_field": group.cosmo_field,
            **_group_stats([member.model_dump() for member in group.members]),
        }
        representatives.append(item)
        original[group.representative_term.lower()] = group
    cross = _aggregate_batch(
        representatives, target_product, model=model,
        strict_members=strict_members, call_model=call_model,
    )
    output: list[TermGroup] = []
    for cross_group in cross:
        source_groups = [original[member.term.lower()] for member in cross_group.members if member.term.lower() in original]
        if not source_groups:
            continue
        if len(source_groups) == 1:
            output.append(source_groups[0])
            continue
        # aggregate.ts 跨批时不信任 LLM 的代表词，而是选 count 最高的原组。
        primary = max(source_groups, key=lambda group: group.count)
        members = [member.model_dump() for source in source_groups for member in source.members]
        output.append(_make_group(
            members, primary.representative_term, primary.representative_term_cn
        ))
    return output

