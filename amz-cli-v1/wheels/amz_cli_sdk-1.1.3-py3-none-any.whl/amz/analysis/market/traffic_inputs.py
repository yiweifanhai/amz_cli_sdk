"""Formatting helpers shared by traffic-map market analyses."""
import math

def _product_lines(products: list[dict], limit: int = 50) -> str:
    lines = []
    for product in products[:limit]:
        keywords = product.get("top_keywords", product.get("keywords", [])) or []
        if isinstance(keywords, list):
            keywords = ", ".join(str(item) for item in keywords[:3])
        lines.append(
            f'- {product.get("asin", "")} | ${product.get("price", product.get("price_usd", "?"))} | '
            f'{str(product.get("title", ""))[:80]} | top_kws: {keywords or "-"} | '
            f'raw: {str(product.get("raw_text", product.get("description", "")))[:150]}'
        )
    return "\n".join(lines)


def _format_price_bands(price_bands: list[dict]) -> str:
    if not price_bands:
        return "none"
    lines = []
    for band in price_bands:
        label = band.get("label", "")
        low = band.get("lo", band.get("min", 0))
        high = band.get("hi", band.get("max"))
        high_text = "inf" if high is None or high == math.inf else high
        lines.append(f'- {label} (range: [${low}, ${high_text}))')
    return "\n".join(lines)


def _format_keyword_clusters(keyword_clusters: list[dict] | dict) -> str:
    clusters = keyword_clusters.get("clusters", []) if isinstance(keyword_clusters, dict) else keyword_clusters
    lines = []
    for cluster in clusters or []:
        samples = cluster.get("keywords", cluster.get("members", [])) or []
        lines.append(
            f'- {cluster.get("name", cluster.get("label", ""))}: '
            f'{str(cluster.get("intent") or "").strip()} | sample_kws: '
            f'{", ".join(str(item) for item in samples[:3])}'
        )
    return "\n".join(lines) if lines else "none"


def validate_market_inputs(main_keyword, price_bands, refinement_dimensions, keyword_clusters, products):
    from amz.envelope import Code, err
    if not isinstance(main_keyword, str) or not main_keyword.strip():
        return err(Code.ERROR_MISSING_FIELDS, "main_keyword is required", missing=["main_keyword"])
    if not isinstance(products, list) or not products:
        return err(Code.ERROR_MISSING_FIELDS, "sample products are required", missing=["products"])
    if any(not isinstance(item, dict) or not any(item.get(name) for name in ("title", "raw_text", "description")) for item in products):
        return err(Code.ERROR_MISSING_FIELDS, "each sample product needs title or detail facts", missing=["products.title or description"])
    if not isinstance(price_bands, list) or any(not isinstance(item, dict) for item in price_bands):
        return err(Code.ERROR_PARAM, "price_bands must be a list of objects")
    if not isinstance(refinement_dimensions, dict):
        return err(Code.ERROR_PARAM, "refinement_dimensions must be an object")
    clusters = keyword_clusters.get("clusters", []) if isinstance(keyword_clusters, dict) else keyword_clusters
    if not isinstance(clusters, list) or any(not isinstance(item, dict) for item in clusters):
        return err(Code.ERROR_PARAM, "keyword_clusters must contain a list of objects")
    return None
