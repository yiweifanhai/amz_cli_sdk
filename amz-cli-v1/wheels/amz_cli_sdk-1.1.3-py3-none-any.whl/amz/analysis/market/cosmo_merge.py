"""Compatibility capability for deterministic COSMO term merging."""

from amz.calc.cosmo import merge_cosmo_results
from amz.envelope import Result, ok
from amz.registry import capability
from amz.schemas.analysis_inputs import CalcCosmoMergeInput
from amz.schemas.cosmo import CosmoMergeOutput, MergedTerm


@capability(
    "analysis.cosmo.merge",
    description="兼容入口：确定性实现位于 calc.cosmo.merge",
    input_model=CalcCosmoMergeInput,
    output_model=CosmoMergeOutput,
    requires=["analysis.cosmo.extract"],
)
def cosmo_merge(cosmo_outputs: list[dict]) -> Result:
    """analysis.cosmo.merge — 跨 ASIN 合并统计

    纯客户端逻辑：将多个 ASIN 的 COSMO 结果合并，统计每个 term 的出现次数。
    不调 LLM。

    Args:
        cosmo_outputs: 多个 ASIN 的 cosmo_extract 输出
    """
    result = merge_cosmo_results(cosmo_outputs)
    terms = [MergedTerm.model_validate(term) for term in result.data["terms"]]
    return ok(data=CosmoMergeOutput(terms=terms, groups=terms).model_dump())
