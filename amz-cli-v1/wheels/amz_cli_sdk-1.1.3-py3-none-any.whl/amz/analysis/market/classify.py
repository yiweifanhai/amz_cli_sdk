"""Amazon adapter for the shared market solution classification task."""
from pydantic import ValidationError
from amz.analysis._compat import resolve_chat_json

from amz.analysis.market.summary import classify_titles
from amz.envelope import Code, Result, err
from amz.infra.llm import chat_json
from amz.registry import capability
from amz.schemas.amazon_analysis import AmazonClassifyInput, AmazonMarketSummary
from amz.schemas.market_summary import ProductTitle


_DEFAULT_CHAT_JSON = chat_json


@capability(
    "analysis.market.classify",
    input_model=AmazonClassifyInput,
    output_model=AmazonMarketSummary,
    description="按解决方案分类亚马逊商品，概述人群和场景，并保留 ASIN 与标题证据",
)
def market_classify(term: str, products: list[dict], model: str = "pro") -> Result:
    """Use supplied titles only; do not fetch products or write Entity fields."""
    try:
        data = AmazonClassifyInput(term=term, products=products, model=model)
    except ValidationError as exc:
        return err(Code.ERROR_PARAM, str(exc))
    titles = tuple(ProductTitle(item_id=p.asin, title=p.title) for p in data.products)
    result = classify_titles(data.term, titles, data.model, platform="亚马逊", llm_call=resolve_chat_json(
        chat_json, default=_DEFAULT_CHAT_JSON, legacy_modules=('amz.analysis.market',),
    ))
    if result.code == Code.OK:
        result.data = AmazonMarketSummary.model_validate(result.data).model_dump()
    return result
