"""Compatibility imports for COSMO capabilities now grouped by result owner."""

from amz.infra.llm import chat_json
from amz.schemas.cosmo import (
    _CosmoOutputModel,
    _CosmoDerivedModel,
    TermLocation,
    TermWithLocation,
    ProductEssence,
    FunctionalUtility,
    ContextualMapping,
    AudiencePsychographics,
    EcosystemEconomics,
    CosmoOutput,
    MergedTerm,
    CosmoMergeOutput,
    TermGroup,
    CosmoAggregateOutput,
    CosmoClassifyOutput,
    ProductCosmo,
)

from amz.analysis.product.cosmo import COSMO_EXTRACT_PROMPT, cosmo_extract
from amz.analysis.product.cosmo_classify import (
    cosmo_classify, _parse_suggested_position, _build_classify_prompt,
    _SUGGESTED_POSITIONS, _POSITION_LABELS,
)
from amz.analysis.market.cosmo_aggregate import cosmo_aggregate
from amz.analysis.market.cosmo_merge import cosmo_merge
from amz.analysis.market.grouping import (
    COSMO_AGGREGATE_PROMPT, _aggregate_batch, _cross_batch_merge, _group_stats,
    _make_group, group_terms as _group_terms,
)


def group_terms(terms, target_product="", *, model="lite", strict_members=False, call_model=None):
    """Forward the old caller hook to the shared grouping implementation."""
    return _group_terms(
        terms, target_product, model=model, strict_members=strict_members,
        call_model=call_model or chat_json,
    )
