"""Compatibility alias for :mod:`amz.analysis.product.voc`."""

import sys
from importlib import import_module

sys.modules[__name__] = import_module("amz.analysis.product.voc")
