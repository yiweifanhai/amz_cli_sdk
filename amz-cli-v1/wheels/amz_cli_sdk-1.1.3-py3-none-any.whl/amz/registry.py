"""
能力注册表：装饰器注册 + 能力发现 + 统一调用入口。

每个能力有 input_schema / output_schema（JSON Schema），
自动生成 MCP tool 定义与 OpenAPI。
"""

from __future__ import annotations

import inspect
import json
import time
import types
from collections.abc import Callable, Mapping
from typing import Any, Union, get_args, get_origin, get_type_hints

from pydantic import BaseModel, TypeAdapter, ValidationError, create_model

from amz.envelope import Result, Code, err, Meta
from amz.envelope import (
    AmzError,
    AuthError,
    LLMError,
    MissingFieldsError,
    NotFoundError,
    ParamError,
    RateLimitError,
    UpstreamError,
)


class CapabilityDef:
    """能力定义

    ``requires`` / ``requires_fields`` 是**声明式前置依赖**（非强制执行）：

    - ``requires``：本能力的语义输入通常由哪些能力产出（能力 ID 列表）。例如
      ``analysis.voc.weaknesses`` 需要 ``product.get`` + ``product.reviews`` 先取数；
      ``entity.product.weaknesses`` 则指向其级联的 ``entity.product.reviews`` 等。
    - ``requires_fields``：不映射为能力、但调用方需保证存在的字段名。例如
      ``entity.product.finance`` 需要基础对象上的 core 字段 ``price_usd`` 等。

    harness（CLI/MCP/Agent/skill）可据此在调用前静态看到依赖链，而非运行时撞错。
    """
    def __init__(
        self,
        id: str,
        fn: Callable,
        description: str = "",
        category: str = "",
        input_schema: dict | None = None,
        output_schema: dict | None = None,
        input_model: type[BaseModel] | None = None,
        output_model: type[BaseModel] | None = None,
        output_type: Any | None = None,
        requires: list[str] | tuple[str, ...] | None = None,
        requires_fields: list[str] | tuple[str, ...] | None = None,
    ):
        self.id = id
        self.fn = fn
        self.description = description
        self.category = category
        self.input_model = input_model or _infer_input_model(fn)
        self.input_schema = input_schema or (
            self.input_model.model_json_schema() if self.input_model is not None else {}
        )
        declared_output = output_type or output_model
        try:
            self.output_adapter = (
                TypeAdapter(declared_output) if declared_output is not None else None
            )
        except Exception:
            self.output_adapter = None
        self.output_schema = output_schema or (
            self.output_adapter.json_schema() if self.output_adapter is not None else {}
        )
        self.output_model = output_model
        self.output_type = declared_output
        # 最终 requires = 显式手写 ∪ 输入类型自动推导（去重、手写在前）。
        self.requires = _merge_requires(requires, _derive_requires(self.input_model))
        self.requires_fields = list(requires_fields or [])
        # 投影实体类型：从 input_model 的投影元数据自动派生（composite autowire 用）。
        self.entity_sources = _derive_entity_sources(self.input_model)

    def __call__(self, params: dict | None = None, **kwargs) -> Result:
        return self.fn(**(params or {}), **kwargs)


class Registry:
    """能力注册表"""

    def __init__(self):
        self._capabilities: dict[str, CapabilityDef] = {}

    def register(
        self,
        id: str,
        description: str = "",
        category: str = "",
        input_schema: dict | None = None,
        output_schema: dict | None = None,
        input_model: type[BaseModel] | None = None,
        output_model: type[BaseModel] | None = None,
        output_type: Any | None = None,
        requires: list[str] | tuple[str, ...] | None = None,
        requires_fields: list[str] | tuple[str, ...] | None = None,
    ):
        """装饰器注册能力

        ``requires`` / ``requires_fields`` 为声明式前置依赖，见
        :class:`CapabilityDef`。空值（缺省）表示叶子能力或无显式字段依赖。
        """

        def decorator(fn: Callable):
            self._capabilities[id] = CapabilityDef(
                id=id,
                fn=fn,
                description=description,
                category=category or _infer_category(id),
                input_schema=input_schema,
                output_schema=output_schema,
                input_model=input_model,
                output_model=output_model,
                output_type=output_type,
                requires=requires,
                requires_fields=requires_fields,
            )
            return fn

        return decorator

    def get(self, id: str) -> CapabilityDef | None:
        """获取能力定义"""
        return self._capabilities.get(id)

    def list_all(self) -> list[CapabilityDef]:
        """列出全部能力"""
        return sorted(self._capabilities.values(), key=lambda c: c.id)

    def list_by_category(self, category: str) -> list[CapabilityDef]:
        """按类别列出"""
        return [c for c in self._capabilities.values() if c.category == category]

    def invoke(
        self,
        id: str,
        params: Mapping[str, Any] | BaseModel | None = None,
        **kwargs,
    ) -> Result:
        """调用能力（顶层包装，异常 → Result）。

        调用前按 input_model 校验参数并做类型强制（"1"→1, "true"→True），
        缺失/类型错误直接返回 ERROR_PARAM，错误信息列出缺失字段与允许的键，
        便于 harness 学习正确调用方式。若当前上下文绑定了 Runtime（``amz task``），
        自动记录调用与结果文件。
        """
        cap = self._capabilities.get(id)
        if cap is None:
            return err(Code.ERROR_NOT_FOUND, f"unknown capability: {id}")

        if isinstance(params, BaseModel):
            merged = params.model_dump(mode="python")
        elif params is None:
            merged = {}
        elif isinstance(params, Mapping):
            merged = dict(params)
        else:
            return err(
                Code.ERROR_PARAM,
                f"params must be a mapping or Pydantic model, got {type(params).__name__}",
                capability=id,
            )
        merged.update(kwargs)

        result = self._invoke_inner(cap, merged)
        # 在 Runtime 记录之前验证完整信封，避免任务回执成功但结果文件无法解析。
        try:
            json.dumps(result.model_dump(), ensure_ascii=False, default=str, allow_nan=False)
        except (ValueError, TypeError) as exc:
            result = err(
                Code.ERROR_SERVER_INTERNAL,
                f"cannot encode capability result: {exc}",
                capability=id,
            )
        self._record_invoke(id, merged, result)
        return result

    def _invoke_inner(self, cap: CapabilityDef, merged: dict) -> Result:
        """校验 + 执行 + 异常 → Result（不包含 runtime 记录）。"""
        start = time.time()
        try:
            validation = self._validate_params(cap, merged)
            if validation is not None:
                return validation
            result = cap(params=merged)
            # 确保返回 Result
            if isinstance(result, Result):
                result.meta.capability = cap.id
                if result.meta.elapsed_ms == 0:
                    result.meta.elapsed_ms = (time.time() - start) * 1000
                return self._validate_output(cap, result)
            # 自动包装裸值
            wrapped = Result(
                code=Code.OK,
                data=result,
                meta=Meta(capability=cap.id, elapsed_ms=(time.time() - start) * 1000),
            )
            return self._validate_output(cap, wrapped)
        except ParamError as e:
            return err(Code.ERROR_PARAM, str(e), capability=cap.id)
        except AuthError as e:
            return err(Code.ERROR_AUTH, str(e), capability=cap.id)
        except NotFoundError as e:
            return err(Code.ERROR_NOT_FOUND, str(e), capability=cap.id)
        except UpstreamError as e:
            return err(Code.ERROR_UPSTREAM, str(e), hint=e.hint, capability=cap.id)
        except RateLimitError as e:
            return err(Code.ERROR_RATE_LIMIT, str(e), capability=cap.id)
        except LLMError as e:
            return err(Code.ERROR_LLM, str(e), capability=cap.id)
        except MissingFieldsError as e:
            return err(
                Code.ERROR_MISSING_FIELDS,
                "missing required fields: " + str(e),
                missing=e.fields,
                capability=cap.id,
            )
        except Exception as e:
            return err(
                Code.ERROR_SERVER_INTERNAL,
                f"[{cap.id}] unexpected: {e}",
                capability=cap.id,
            )

    def _record_invoke(self, cap_id: str, params: dict, result: Result) -> None:
        """若当前上下文有 Runtime，记录调用与结果文件（失败不影响调用结果）。"""
        from amz.infra.runtime import get_current

        rt = get_current()
        if rt is None:
            return
        try:
            rt.save_result(cap_id, result, params=params)
        except Exception:
            pass

    def capabilities_json(self) -> list[dict]:
        """导出能力目录 JSON（供 MCP / OpenAPI / Agent 使用）"""
        return [
            {
                "id": c.id,
                "category": c.category,
                "description": c.description,
                "requires": c.requires,
                "requires_fields": c.requires_fields,
                "entity_sources": c.entity_sources,
                "input_schema": c.input_schema,
                "output_schema": c.output_schema,
            }
            for c in self.list_all()
        ]

    def validate_requires(self) -> list[str]:
        """校验 ``requires`` 引用的完整性（需在全部能力注册完成后调用）。

        返回问题列表（空 = 通过）：悬空引用、自引用。注册期不强校验是因为
        discovery 按模块顺序注册，前置能力可能稍后才注册；由
        ``load_builtin_capabilities()`` 在收尾统一校验。
        """
        ids = {c.id for c in self.list_all()}
        issues: list[str] = []
        for cap in self.list_all():
            for ref in cap.requires:
                if ref == cap.id:
                    issues.append(f"{cap.id}: self-referential requires '{ref}'")
                elif ref not in ids:
                    issues.append(f"{cap.id}: dangling requires '{ref}'")
        return issues

    # ------------------------------------------------------------------
    # 输入校验（A3：schema 驱动校验 + 类型强制）
    # ------------------------------------------------------------------

    def _validate_params(self, cap: CapabilityDef, params: dict) -> Result | None:
        """按 input_model 校验并强制转换参数。

        校验通过时把强制转换后的参数写回 ``params``（类型强转：字符串数字 → 数字）。
        校验失败返回 ERROR_PARAM Result，成功返回 None。
        """
        model = cap.input_model
        if model is None:
            return None
        # 动态 composite 可用显式 input_schema 描述参数，而 input_model 只负责
        # extra 类型保留；普通能力两者字段一致。
        allowed_names = list(
            (cap.input_schema or {}).get("properties", {}).keys()
            or model.model_fields.keys()
        )
        allowed = set(allowed_names)
        unknown = sorted(set(params) - allowed)
        if unknown:
            return err(
                Code.ERROR_PARAM,
                "unknown fields: " + ", ".join(unknown)
                + " | allowed keys: " + ", ".join(allowed_names),
                capability=cap.id,
            )
        try:
            validated = model.model_validate(params)
        except ValidationError as exc:
            missing: list[str] = []
            invalid: list[str] = []
            for e in exc.errors():
                loc = ".".join(str(part) for part in e.get("loc", ()))
                if e.get("type") == "missing":
                    missing.append(loc)
                else:
                    invalid.append(f"{loc}: {e.get('msg', 'invalid')}")
            parts = []
            if missing:
                parts.append("missing required fields: " + ", ".join(sorted(set(missing))))
            if invalid:
                parts.append("invalid fields: " + "; ".join(invalid))
            allowed = list(model.model_fields.keys())
            message = "; ".join(parts)
            if allowed:
                message += f" | allowed keys: {', '.join(allowed)}"
            code = (
                Code.ERROR_MISSING_FIELDS
                if missing and cap.category in {"calc", "analysis"}
                else Code.ERROR_PARAM
            )
            return err(
                code,
                message,
                missing=sorted(set(missing)) if missing else [],
                capability=cap.id,
            )
        # 类型强转：把校验后的值写回（缺失参数补默认值，字符串数字转数字）
        params.clear()
        params.update(validated.model_dump(mode="python"))
        return None

    def _validate_output(self, cap: CapabilityDef, result: Result) -> Result:
        """按声明的 output type 校验并规范化成功结果。

        ``output_schema`` 不再只是文档：只要能力声明了 ``output_model`` 或
        ``output_type``，成功数据必须满足它。Entity bridge 使用 ``output_type``
        校验 list/scalar/嵌套 Entity 等非 BaseModel 根类型。
        """
        if result.code != Code.OK or cap.output_adapter is None:
            return result
        try:
            validated = cap.output_adapter.validate_python(result.data)
            data = cap.output_adapter.dump_python(validated, mode="python")
            return result.model_copy(update={"data": data})
        except ValidationError as exc:
            return err(
                Code.ERROR_SERVER_INTERNAL,
                f"[{cap.id}] output contract violation: {exc}",
                capability=cap.id,
            )


def _infer_category(id: str) -> str:
    """从能力 ID 推断类别"""
    prefix = id.split(".")[0]
    categories = {
        "product": "product",
        "keyword": "keyword",
        "market": "market",
        "supply": "supply",
        "category": "category",
        "ads": "ads",
        "calc": "calc",
        "analysis": "analysis",
        "infra": "infra",
        "selection": "selection",
        "risk": "risk",
        "content": "content",
        "profit": "profit",
    }
    return categories.get(prefix, "other")


def _infer_input_model(fn: Callable) -> type[BaseModel] | None:
    """从函数签名生成能力输入 Pydantic 模型（含默认值推导）。

    无法解析的第三方/前向类型会降级为 ``Any``，保证能力注册本身不会
    因 schema 生成失败而中断。
    """
    try:
        signature = inspect.signature(fn)
        try:
            hints = get_type_hints(fn)
        except Exception:
            hints = {}

        fields: dict[str, tuple[Any, Any]] = {}
        for name, parameter in signature.parameters.items():
            if parameter.kind in {
                inspect.Parameter.VAR_POSITIONAL,
                inspect.Parameter.VAR_KEYWORD,
            }:
                continue
            annotation = hints.get(name, parameter.annotation)
            if annotation is inspect.Parameter.empty:
                annotation = Any
            default = parameter.default
            if default is inspect.Parameter.empty:
                default = ...
            fields[name] = (annotation, default)

        model_name = "".join(part.title() for part in fn.__name__.split("_")) + "Input"
        return create_model(model_name, **fields)
    except Exception:
        return None


def _infer_input_schema(fn: Callable) -> dict:
    """从函数签名生成能力输入 JSON Schema（向后兼容包装）。"""
    model = _infer_input_model(fn)
    return model.model_json_schema() if model is not None else {"type": "object", "properties": {}}


def _unwrap_annotation(annotation: Any) -> Any:
    """剥掉 Optional/Union/list/dict/tuple 等外壳，返回内层类型（用于 provenance 查表）。

    - ``ProductInfoInput | None`` → ``ProductInfoInput``
    - ``list[ReviewItemInput]`` → ``ReviewItemInput``
    - ``dict[str, Any]`` / ``list[dict]`` / 标量 → 非 provenance 类型，原样返回（查不到即跳过）
    """
    if annotation is None or annotation is inspect.Parameter.empty:
        return None
    origin = get_origin(annotation)
    args = get_args(annotation)
    if origin in (Union, types.UnionType):
        non_none = [a for a in args if a is not type(None)]
        return _unwrap_annotation(non_none[0]) if len(non_none) == 1 else None
    if origin is not None and args:
        # 容器类型：取元素类型（list[X] / dict[K, V] / tuple[X, ...] → X）
        return _unwrap_annotation(args[0])
    return annotation


def _derive_requires(input_model: type[BaseModel] | None) -> list[str]:
    """从输入模型字段注解自动推导 ``requires``。

    只收录 provenance 表中「无歧义的叶子数据依赖」；provenance 未覆盖的类型
    （裸 dict / 标量 / 流程相关形状）不产生推导，交由能力显式声明。
    """
    if input_model is None:
        return []
    try:
        from amz.schemas.provenance import PROVENANCE
    except Exception:
        return []

    producers: list[str] = []
    for field_info in input_model.model_fields.values():
        base = _unwrap_annotation(field_info.annotation)
        if base is None:
            continue
        for producer in PROVENANCE.get(base, ()):
            if producer and producer not in producers:
                producers.append(producer)
    return producers


def _derive_entity_sources(input_model: type[BaseModel] | None) -> list[str]:
    """从 input_model 的投影元数据派生可投影的实体类型（entity_type 列表）。

    composite autowire 据此决定"该能力的输入可以从哪些实体自动投影"；
    没有投影元数据的能力返回空列表（不参与 autowire，走显式接线）。
    """
    if input_model is None:
        return []
    try:
        from amz.schemas.projection import collect_entity_sources
    except Exception:
        return []
    return collect_entity_sources(input_model)


def _merge_requires(
    explicit: list[str] | tuple[str, ...] | None,
    derived: list[str],
) -> list[str]:
    """合并显式手写与自动推导的 requires：手写在前，去重保序。"""
    merged: list[str] = []
    for item in list(explicit or []) + list(derived):
        if item and item not in merged:
            merged.append(item)
    return merged


# 全局注册表单例
registry = Registry()

# 便捷装饰器
capability = registry.register
