"""
任务编排：run_id 生成 + JSON 落盘读写。

统一 product_dev_v2 store.py / traffic_map store.py / market_selection_agent caching 的实现。
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from amz.infra.paths import cache_path, confined_path, validate_component


def generate_run_id() -> str:
    """生成唯一 run_id"""
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    return f"{ts}_{uuid.uuid4().hex[:8]}"


def get_store_dir() -> Path:
    """获取 store 目录"""
    d = cache_path("store")
    d.mkdir(parents=True, exist_ok=True)
    return d


def save(run_id: str, name: str, data: Any) -> dict:
    """infra.store.json save → {path}"""
    d = confined_path(get_store_dir(), validate_component(run_id, label="run_id"))
    path = confined_path(d, f"{validate_component(name, label='store name')}.json")
    d.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    return {"path": str(path)}


def load(run_id: str, name: str) -> dict:
    """infra.store.json load → {exists, data?}"""
    path = confined_path(get_store_dir(), validate_component(run_id, label="run_id"), f"{validate_component(name, label='store name')}.json")
    if not path.exists():
        return {"exists": False}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return {"exists": True, "data": data}
    except (json.JSONDecodeError, ValueError):
        return {"exists": False}


def list_runs() -> list[str]:
    """列出全部 run_id"""
    d = get_store_dir()
    if not d.exists():
        return []
    return sorted(
        [p.name for p in d.iterdir() if confined_path(d, p.name).is_dir()],
        reverse=True,
    )
