"""Prepare supplied image inputs for multimodal requests without cropping."""

from __future__ import annotations

import base64
from dataclasses import dataclass
from io import BytesIO
from urllib.parse import urlsplit

import httpx
from PIL import Image, ImageOps

MAX_IMAGE_BYTES = 20 * 1024 * 1024
MAX_IMAGE_PIXELS = 40_000_000
IMAGE_MAX_SIDE = 512
JPEG_QUALITY = 85


@dataclass(frozen=True)
class PreparedImage:
    data_url: str
    original_width: int
    original_height: int
    width: int
    height: int
    original_bytes: int
    image_bytes: int


def read_image(url: str) -> bytes:
    """Read an explicit HTTP(S) or base64 image input with a byte limit."""
    if url.startswith("data:image/"):
        header, separator, encoded = url.partition(",")
        if not separator or not header.endswith(";base64"):
            raise ValueError("Image data URL must use base64")
        if len(encoded) > ((MAX_IMAGE_BYTES + 2) // 3) * 4:
            raise ValueError("Image exceeds the 20 MiB limit")
        data = base64.b64decode(encoded, validate=True)
    else:
        if urlsplit(url).scheme not in {"http", "https"}:
            raise ValueError("Image must be an HTTP(S) URL or base64 image")
        data = bytearray()
        with httpx.stream("GET", url, timeout=30, follow_redirects=True) as response:
            response.raise_for_status()
            for chunk in response.iter_bytes():
                data.extend(chunk)
                if len(data) > MAX_IMAGE_BYTES:
                    raise ValueError("Image exceeds the 20 MiB limit")
        data = bytes(data)
    if not data or len(data) > MAX_IMAGE_BYTES:
        raise ValueError("Image is empty or exceeds the 20 MiB limit")
    return data


def prepare_image(url: str) -> PreparedImage:
    """Scale the complete image to at most 512 px per side; never enlarge it."""
    data = read_image(url)
    with Image.open(BytesIO(data)) as original:
        if original.width * original.height > MAX_IMAGE_PIXELS:
            raise ValueError("Image exceeds the 40 megapixel limit")
        if getattr(original, "n_frames", 1) != 1:
            raise ValueError("COSMO requires a single-frame image")
        picture = ImageOps.exif_transpose(original)
        original_width, original_height = picture.size
        picture.thumbnail((IMAGE_MAX_SIDE, IMAGE_MAX_SIDE), Image.Resampling.LANCZOS)
        # Flatten transparent images on white so text stays visible in JPEG.
        if "A" in picture.getbands() or "transparency" in picture.info:
            rgba = picture.convert("RGBA")
            picture = Image.new("RGB", rgba.size, "white")
            picture.paste(rgba, mask=rgba.getchannel("A"))
        else:
            picture = picture.convert("RGB")
        output = BytesIO()
        picture.save(output, format="JPEG", quality=JPEG_QUALITY, optimize=True)
        encoded = output.getvalue()
        return PreparedImage(
            data_url="data:image/jpeg;base64," + base64.b64encode(encoded).decode("ascii"),
            original_width=original_width, original_height=original_height,
            width=picture.width, height=picture.height,
            original_bytes=len(data), image_bytes=len(encoded),
        )
