"""
L0 基础设施层 — 纯工具，无业务依赖，无外部模块依赖。

设计原则
--------
- 每个模块自包含，可独立使用
- 不依赖 amz 其他子包（envelope/config 除外）
- HTTP/LLM 调用均含指数退避重试 + 缓存

模块清单
--------

============= ==============================================
模块          职责
============= ==============================================
cache         文件缓存（兼容 amz-api）+ SQLite 缓存
concurrent    并发池（async + ThreadPoolExecutor）
export        to_csv / to_excel 导出
http          httpx POST/GET + 指数退避重试 + QPS 限速 + 缓存
llm           豆包 Mini/Lite/Pro（doubao/ark 为同一服务）
              chat / chat-json + JSON 容错 4 级解析
parse         非结构化解析：weight/dims/bsr/date/price/pct/nation
store         run_id 生成 + JSON 落盘读写
============= ==============================================

用法::

    from amz.infra.llm import chat_json
    from amz.infra.store import generate_run_id, save, load
    from amz.infra.cache import get_cache, set_cache
"""
