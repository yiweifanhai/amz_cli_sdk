"""
Runtime 空间管理：一次任务的全局状态与中间文件索引。

每次任务 = 一个工作区目录 ``~/.cache/amz-cli/runs/{run_id}/``：

- ``manifest.json``：任务元数据（params / status / 时间线）+ 文件清单（files）
  + 能力调用记录（calls）
- ``results/{seq}_{capability}.json``：每次 ``registry.invoke`` 的 Result 落盘
- 实体缓存文件（``~/.cache/amz-cli/entities/...``）**不移动**，只在 manifest 中索引

进程内挂载：``with runtime_context(rt):`` 后，``registry.invoke`` 自动记录调用
与结果文件；``Entity.save`` 自动索引实体缓存文件。harness 通过 CLI 使用：
``amz task new / run / status / files / list / cleanup``。
"""

from __future__ import annotations

import contextvars
import json
import os
import tempfile
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from amz.infra.paths import PathBoundaryError, cache_path, confined_path, validate_component
from amz.infra.store import generate_run_id


_current: contextvars.ContextVar["Runtime | None"] = contextvars.ContextVar(
    "amz_runtime", default=None
)

MANIFEST_SCHEMA = "amz.task.manifest.v1"
RESULT_SCHEMA = "amz.result.v1"


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _runs_dir() -> Path:
    d = cache_path("runs")
    d.mkdir(parents=True, exist_ok=True)
    return d


class Runtime:
    """单次任务的工作区与文件索引。"""

    def __init__(self, run_id: str, name: str = "", params: dict | None = None):
        self.run_id = validate_component(run_id, label="run_id")
        self.name = name
        self.params = params or {}
        self.dir = confined_path(_runs_dir(), self.run_id)
        self.results_dir = confined_path(self.dir, "results")
        self._manifest_path = confined_path(self.dir, "manifest.json")
        self._lock = threading.RLock()

    # ------------------------------------------------------------------
    # 生命周期
    # ------------------------------------------------------------------

    @classmethod
    def begin(
        cls,
        name: str = "",
        params: dict | None = None,
        run_id: str | None = None,
    ) -> "Runtime":
        """创建新任务工作区。

        Args:
            name: 任务名（如 pipeline 名）。
            params: 任务参数。
            run_id: 可选显式 run_id；缺省用 ``generate_run_id()``。
                composite 传入确定性指纹，使「工作区即缓存」。
        """
        runtime = cls(run_id or generate_run_id(), name=name, params=params or {})
        runtime._write_manifest({
            "schema": MANIFEST_SCHEMA,
            "run_id": runtime.run_id,
            "name": runtime.name,
            "status": "running",
            "params": runtime.params,
            "created_at": _utc_now(),
            "updated_at": _utc_now(),
            "finished_at": None,
            "error": "",
            "files": [],
            "calls": [],
            "steps": {},
        })
        return runtime

    @classmethod
    def open(cls, run_id: str) -> "Runtime | None":
        """打开已有任务工作区（不存在返回 None）。"""
        manifest = _load_manifest(run_id)
        if manifest is None:
            return None
        return cls(
            run_id=run_id,
            name=manifest.get("name", ""),
            params=manifest.get("params", {}),
        )

    def _write_manifest(self, payload: dict) -> None:
        with self._lock:
            _validate_manifest(payload, self.run_id)
            self.dir = cache_path("runs", self.run_id)
            self._manifest_path = confined_path(self.dir, "manifest.json")
            self.dir.mkdir(parents=True, exist_ok=True)
            tmp_path: Path | None = None
            try:
                with tempfile.NamedTemporaryFile(
                    mode="w", encoding="utf-8", dir=self.dir,
                    prefix=".manifest.", suffix=".tmp", delete=False,
                ) as handle:
                    json.dump(payload, handle, ensure_ascii=False, indent=2, default=str)
                    handle.flush()
                    os.fsync(handle.fileno())
                    tmp_path = Path(handle.name)
                os.replace(tmp_path, self._manifest_path)
                tmp_path = None
            finally:
                if tmp_path is not None:
                    tmp_path.unlink(missing_ok=True)

    def _mutate(self, fn: Any) -> dict:
        """读 manifest → 变更 → 原子写回。"""
        with self._lock:
            payload = _load_manifest(self.run_id) or {
                "run_id": self.run_id, "name": self.name, "status": "running",
                "params": self.params, "files": [], "calls": [],
            }
            fn(payload)
            payload["updated_at"] = _utc_now()
            self._write_manifest(payload)
            return payload

    # ------------------------------------------------------------------
    # 记录
    # ------------------------------------------------------------------

    def record(self, kind: str, name: str, rel_path: str, schema: str = "", meta: dict | None = None) -> None:
        """登记一个中间文件（kind ∈ entity | result | cache | raw）。

        ``rel_path`` 统一相对 ``config.cache_dir``（如 ``entities/product/x.json``、
        ``runs/{run_id}/results/0001_x.json``），harness 按 cache_dir 解析。
        """
        path = _record_path(rel_path)
        rel_path = path.relative_to(cache_path()).as_posix()

        def apply(payload: dict) -> None:
            existing = {(f.get("kind"), f.get("path")) for f in payload["files"]}
            if (kind, rel_path) in existing:
                return  # 同一文件重复 save 不重复登记
            payload["files"].append({
                "kind": kind,
                "name": name,
                "path": rel_path,
                "schema": schema,
                "size": _file_size(path),
                "created_at": _utc_now(),
                "meta": meta or {},
            })

        self._mutate(apply)

    def record_call(self, capability: str, params: dict, code: str, elapsed_ms: float) -> str:
        """登记一次能力调用并返回结果文件相对路径（不落盘结果内容）。"""
        validate_component(capability, label="capability")
        manifest = self._manifest()
        seq = len(manifest.get("calls", [])) + 1
        rel_path = f"runs/{self.run_id}/results/{seq:04d}_{capability.replace('.', '_')}.json"

        def apply(payload: dict) -> None:
            payload["calls"].append({
                "seq": seq,
                "capability": capability,
                "params": _truncate(params, 4096),
                "code": code,
                "elapsed_ms": round(elapsed_ms, 1),
                "result_file": rel_path,
                "created_at": _utc_now(),
            })
            payload["files"].append({
                "kind": "result",
                "name": capability,
                "path": rel_path,
                "schema": RESULT_SCHEMA,
                "size": _file_size(_record_path(rel_path)),
                "created_at": _utc_now(),
                "meta": {"code": code, "elapsed_ms": round(elapsed_ms, 1)},
            })

        self._mutate(apply)
        return rel_path

    def save_result(self, capability: str, result: Any, params: dict | None = None) -> str:
        """把 Result 落盘到 runs/{run_id}/results/ 并登记，返回相对 cache_dir 的路径。"""
        validate_component(capability, label="capability")
        manifest = self._manifest()
        seq = len(manifest.get("calls", [])) + 1
        rel_path = f"runs/{self.run_id}/results/{seq:04d}_{capability.replace('.', '_')}.json"
        code = str(result.code.value) if hasattr(result, "code") else "OK"
        elapsed = result.meta.elapsed_ms if hasattr(result, "meta") else 0.0

        payload = _result_payload(result)
        path = _record_path(rel_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str, allow_nan=False), encoding="utf-8")
        size = _file_size(path)

        def apply(m: dict) -> None:
            m["calls"].append({
                "seq": seq,
                "capability": capability,
                "params": _truncate(params or {}, 4096),
                "code": code,
                "elapsed_ms": round(elapsed, 1),
                "result_file": rel_path,
                "created_at": _utc_now(),
            })
            m["files"].append({
                "kind": "result",
                "name": capability,
                "path": rel_path,
                "schema": RESULT_SCHEMA,
                "size": size,
                "created_at": _utc_now(),
                "meta": {"code": code, "elapsed_ms": round(elapsed, 1)},
            })

        self._mutate(apply)
        return rel_path

    def record_step(self, name: str, status: str, meta: dict | None = None) -> None:
        """登记一个编排步骤的状态（composite 等用），写入 manifest 的 ``steps`` 段。"""
        validate_component(name, label="step name")

        def apply(payload: dict) -> None:
            steps = payload.setdefault("steps", {})
            entry = dict(steps.get(name) or {})
            entry["status"] = status
            entry["updated_at"] = _utc_now()
            if meta:
                entry.update(meta)
            steps[name] = entry

        self._mutate(apply)

    def finish(self, success: bool, error: str = "") -> None:
        def apply(payload: dict) -> None:
            payload["status"] = "finished" if success else "failed"
            payload["error"] = error
            payload["finished_at"] = _utc_now()

        self._mutate(apply)

    # ------------------------------------------------------------------
    # 查询
    # ------------------------------------------------------------------

    def _manifest(self) -> dict:
        return _load_manifest(self.run_id) or {}

    def manifest(self) -> dict:
        return self._manifest()

    def files(self, kind: str | None = None) -> list[dict]:
        files = self._manifest().get("files", [])
        if kind:
            return [f for f in files if f.get("kind") == kind]
        return files

    # ------------------------------------------------------------------
    # 类级查询 / 清理
    # ------------------------------------------------------------------

    @classmethod
    def status(cls, run_id: str) -> dict | None:
        return _load_manifest(run_id)

    @classmethod
    def files_of(cls, run_id: str, kind: str | None = None) -> list[dict]:
        manifest = _load_manifest(run_id)
        if manifest is None:
            return []
        files = manifest.get("files", [])
        if kind:
            return [f for f in files if f.get("kind") == kind]
        return files

    @classmethod
    def list_runs(cls) -> list[dict]:
        d = _runs_dir()
        if not d.exists():
            return []
        runs = []
        for child in d.iterdir():
            child = confined_path(d, child.name)
            if not child.is_dir():
                continue
            manifest = _load_manifest(child.name)
            if manifest is None:
                continue
            runs.append({
                "run_id": child.name,
                "name": manifest.get("name", ""),
                "status": manifest.get("status", "unknown"),
                "created_at": manifest.get("created_at", ""),
                "files": len(manifest.get("files", [])),
                "calls": len(manifest.get("calls", [])),
            })
        return sorted(runs, key=lambda r: r.get("created_at", ""), reverse=True)

    @classmethod
    def cleanup(cls, older_than_hours: int = 168) -> list[str]:
        """删除超过 TTL 且已结束的任务工作区，返回删除的 run_id。"""
        from datetime import timedelta

        cutoff = datetime.now(timezone.utc) - timedelta(hours=older_than_hours)
        removed = []
        for run in cls.list_runs():
            if run.get("status") == "running":
                continue
            try:
                created = datetime.fromisoformat(
                    (run.get("created_at") or "").replace("Z", "+00:00")
                )
            except (ValueError, TypeError):
                continue
            if created < cutoff:
                target = confined_path(_runs_dir(), validate_component(run["run_id"], label="run_id"))
                import shutil

                shutil.rmtree(target, ignore_errors=True)
                removed.append(run["run_id"])
        return removed


# ---------------------------------------------------------------------------
# 模块级辅助
# ---------------------------------------------------------------------------


def _load_manifest(run_id: str) -> dict | None:
    path = confined_path(_runs_dir(), validate_component(run_id, label="run_id"), "manifest.json")
    if not path.exists():
        return None
    try:
        manifest = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, ValueError, OSError):
        return None
    _validate_manifest(manifest, run_id)
    return manifest


def _record_path(rel_path: str) -> Path:
    if not isinstance(rel_path, str) or Path(rel_path).is_absolute() or ":" in rel_path:
        raise PathBoundaryError("record path must be relative to cache.dir")
    normalized = rel_path.replace("\\", "/")
    if normalized.startswith("/"):
        raise PathBoundaryError("record path must be relative to cache.dir")
    return cache_path(normalized)


def _validate_manifest(manifest: dict, run_id: str) -> None:
    if not isinstance(manifest, dict) or manifest.get("run_id") != run_id:
        raise PathBoundaryError("manifest run_id does not match its directory")
    for item in manifest.get("files", []):
        _record_path(item.get("path"))
    for call in manifest.get("calls", []):
        if call.get("result_file"):
            _record_path(call["result_file"])
    for name in manifest.get("steps", {}):
        validate_component(name, label="step name")


def _file_size(path: Path) -> int:
    try:
        return path.stat().st_size
    except OSError:
        return 0


def _truncate(value: Any, limit: int) -> Any:
    """截断超长参数（避免 manifest 膨胀）。"""
    if isinstance(value, dict):
        return {k: _truncate(v, limit) for k, v in list(value.items())[:64]}
    if isinstance(value, (list, tuple)):
        return [_truncate(v, limit) for v in list(value)[:64]]
    if isinstance(value, str) and len(value) > limit:
        return value[:limit] + f"...<truncated {len(value) - limit} chars>"
    return value


def _result_payload(result: Any) -> dict:
    """把 Result 序列化为可落盘 dict。"""
    if hasattr(result, "model_dump"):
        try:
            return result.model_dump()
        except Exception:
            pass
    return {"code": getattr(result, "code", "OK"), "data": result}


# ---------------------------------------------------------------------------
# ContextVar 挂载
# ---------------------------------------------------------------------------


def get_current() -> Runtime | None:
    """当前上下文绑定的 Runtime（无则 None）。"""
    return _current.get()


def set_current(runtime: Runtime | None) -> contextvars.Token:
    """绑定当前上下文的 Runtime，返回 token（用于 reset）。"""
    return _current.set(runtime)


def reset_current(token: contextvars.Token) -> None:
    _current.reset(token)


class runtime_context:
    """上下文管理器：``with runtime_context(rt):`` 期间 invoke/save 自动记录。"""

    def __init__(self, runtime: Runtime):
        self.runtime = runtime
        self._token = None

    def __enter__(self) -> Runtime:
        self._token = set_current(self.runtime)
        return self.runtime

    def __exit__(self, exc_type, exc, tb) -> None:
        if self._token is not None:
            reset_current(self._token)
