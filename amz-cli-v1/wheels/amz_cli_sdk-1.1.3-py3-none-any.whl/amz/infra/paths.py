"""Shared filesystem boundaries for managed hosts and SDK storage."""

from __future__ import annotations

import os
import re
from pathlib import Path

from amz.config import config

MAX_COMPONENT_LENGTH = 180


class PathBoundaryError(ValueError):
    """A path or storage identifier leaves its configured boundary."""


def configured_root(path: str | Path) -> Path:
    """Keep the canonical managed root selected at bootstrap from drifting."""
    root = Path(path).expanduser()
    if config.is_managed and (not root.is_absolute() or root.resolve() != root):
        raise PathBoundaryError("configured root changed after bootstrap")
    return root


def validate_component(value: str, *, label: str = "identifier") -> str:
    """Accept one portable filename component, never a path or device name."""
    if (
        not isinstance(value, str)
        or len(value) > MAX_COMPONENT_LENGTH
        or not re.fullmatch(r"[\w][\w.-]*", value)
        or value.endswith(".")
        or value.split(".", 1)[0].upper()
        in {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(10)), *(f"LPT{i}" for i in range(10))}
    ):
        raise PathBoundaryError(f"invalid {label}: expected a single filename component")
    return value


def confined_path(root: str | Path, *parts: str | Path, must_exist: bool = False) -> Path:
    """Resolve a path under a trusted root, checking lexical and symlink escapes."""
    base = Path(os.path.abspath(Path(root).expanduser()))
    candidate = Path(os.path.abspath(base.joinpath(*parts)))
    if not candidate.is_relative_to(base):
        raise PathBoundaryError("path is outside its configured root")
    resolved_base = base.resolve()
    resolved = candidate.resolve(strict=must_exist)
    if not resolved.is_relative_to(resolved_base):
        raise PathBoundaryError("path resolves outside its configured root")
    return resolved


def resolve_workspace_path(path: str | Path, *, must_exist: bool = False) -> Path:
    """Resolve cwd-relative CLI paths, enforcing workspace_root in managed mode."""
    candidate = Path(path).expanduser()
    if not config.is_managed:
        return candidate.resolve(strict=must_exist)
    root = config.get("paths", "workspace_root")
    if not isinstance(root, str) or not Path(root).is_absolute():
        raise PathBoundaryError("managed paths.workspace_root must be an absolute path")
    absolute = Path(os.path.abspath(candidate))
    return confined_path(configured_root(root), absolute, must_exist=must_exist)


def cache_path(*parts: str | Path, must_exist: bool = False) -> Path:
    """Resolve SDK storage beneath cache.dir and the managed workspace."""
    root = resolve_workspace_path(configured_root(config.cache_dir))
    return confined_path(root, *parts, must_exist=must_exist)
