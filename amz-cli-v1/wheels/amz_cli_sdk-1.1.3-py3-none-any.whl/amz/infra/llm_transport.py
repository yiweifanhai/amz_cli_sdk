"""Stateless, non-streaming OpenAI-compatible LLM wire protocols."""

from __future__ import annotations

import math
from copy import deepcopy
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlsplit


@dataclass(frozen=True)
class RequestSpec:
    url: str
    headers: dict[str, str]
    body: dict[str, Any]
    timeout_s: float


def _number(value: Any, name: str, *, positive: bool = False) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{name} must be a finite number")
    if positive and value <= 0:
        raise ValueError(f"{name} must be positive")
    return float(value)


def effective_temperature(backend: dict, temperature: float | None) -> float | None:
    policy = backend.get("temperature_policy", {"mode": "caller"})
    if not isinstance(policy, dict):
        raise ValueError("temperature_policy must be an object")
    mode = policy.get("mode", "caller")
    if mode == "omit":
        return None
    if mode == "fixed":
        return _number(policy.get("value"), "temperature_policy.value")
    if mode != "caller":
        raise ValueError("temperature_policy.mode must be caller, fixed or omit")
    return None if temperature is None else _number(temperature, "temperature")


def _messages(messages: list[dict], *, responses: bool) -> list[dict]:
    if not isinstance(messages, list) or not messages:
        raise ValueError("messages must be a non-empty list")
    result = []
    for message in messages:
        if not isinstance(message, dict) or set(message) != {"role", "content"}:
            raise ValueError("messages must contain only role and content")
        role = message["role"]
        if role not in {"system", "developer", "user", "assistant"}:
            raise ValueError("unsupported message role")
        content = message["content"]
        if isinstance(content, str):
            if not content.strip():
                raise ValueError("message content must not be empty")
            result.append({"role": role, "content": content})
            continue
        if not isinstance(content, list) or not content:
            raise ValueError("message content must be text or non-empty content blocks")
        blocks = []
        for block in content:
            if not isinstance(block, dict):
                raise ValueError("invalid content block")
            if block.get("type") == "text" and set(block) == {"type", "text"}:
                if not isinstance(block["text"], str) or not block["text"].strip():
                    raise ValueError("text block must not be empty")
                blocks.append({"type": "input_text" if responses else "text", "text": block["text"]})
                continue
            if block.get("type") != "image_url" or set(block) != {"type", "image_url"}:
                raise ValueError("unsupported content block")
            image = block["image_url"]
            if not isinstance(image, dict) or "url" not in image or set(image) - {"url", "detail"}:
                raise ValueError("image_url must contain url and optional detail")
            url = image["url"]
            if not isinstance(url, str) or not url:
                raise ValueError("image_url.url must be a non-empty URL")
            parsed = urlsplit(url)
            if not ((parsed.scheme in {"http", "https"} and parsed.hostname) or url.startswith("data:image/")):
                raise ValueError("image_url.url must be HTTP(S) or an image data URL")
            if "detail" in image and image["detail"] not in {"auto", "low", "high", "original"}:
                raise ValueError("invalid image detail")
            if responses:
                converted = {"type": "input_image", "image_url": url}
                if "detail" in image:
                    converted["detail"] = image["detail"]
                blocks.append(converted)
            else:
                blocks.append({"type": "image_url", "image_url": dict(image)})
        result.append({"role": role, "content": blocks})
    return result


def strict_json_schema(schema: dict) -> dict:
    """Close typed Pydantic objects; reject schemas that require lossy guessing."""
    if not isinstance(schema, dict) or schema.get("type") != "object" or "anyOf" in schema:
        raise ValueError("json_schema mode requires an object root; use prompt mode for this schema")
    allowed = {
        "type", "properties", "required", "additionalProperties", "$defs", "$ref", "items",
        "anyOf", "enum", "const", "title", "description", "default", "pattern", "format",
        "multipleOf", "minimum", "maximum", "exclusiveMinimum", "exclusiveMaximum",
        "minItems", "maxItems",
    }
    types = {"object", "array", "string", "number", "integer", "boolean", "null"}

    def normalize(node: Any) -> dict:
        if not isinstance(node, dict) or set(node) - allowed:
            raise ValueError("unsupported strict JSON schema; use prompt mode")
        result = deepcopy(node)
        result.pop("default", None)
        declared = result.get("type")
        type_list = declared if isinstance(declared, list) else [declared] if declared is not None else []
        if any(not isinstance(value, str) or value not in types for value in type_list):
            raise ValueError("unsupported strict JSON schema type")
        if not type_list and not any(key in result for key in {"$ref", "anyOf"}):
            raise ValueError("untyped JSON schema is unsupported; use prompt mode")
        if "$ref" in result:
            ref = result["$ref"]
            if not isinstance(ref, str) or (ref != "#" and not ref.startswith("#/$defs/")):
                raise ValueError("strict JSON schema requires local definition references")
            target: Any = schema
            for part in ref.split("/")[1:]:
                if not isinstance(target, dict):
                    raise ValueError("unresolved strict JSON schema reference")
                target = target.get(part.replace("~1", "/").replace("~0", "~"))
            if not isinstance(target, dict):
                raise ValueError("unresolved strict JSON schema reference")
        if "const" in result:
            if "enum" in result:
                raise ValueError("combined const and enum are unsupported")
            result["enum"] = [result.pop("const")]
        if "object" in type_list:
            properties = result.get("properties")
            if not isinstance(properties, dict) or result.get("additionalProperties", False) is not False:
                raise ValueError("open-ended objects are unsupported in json_schema mode; use prompt mode")
            result["properties"] = {name: normalize(value) for name, value in properties.items()}
            result["additionalProperties"] = False
            result["required"] = list(properties)
        if "array" in type_list:
            result["items"] = normalize(result.get("items"))
        if "$defs" in result:
            if not isinstance(result["$defs"], dict):
                raise ValueError("invalid strict JSON schema definitions")
            result["$defs"] = {name: normalize(value) for name, value in result["$defs"].items()}
        if "anyOf" in result:
            if not isinstance(result["anyOf"], list) or not result["anyOf"]:
                raise ValueError("invalid strict JSON schema anyOf")
            result["anyOf"] = [normalize(value) for value in result["anyOf"]]
        return result

    return normalize(schema)


def build_request(
    backend: dict,
    model: str,
    messages: list[dict],
    temperature: float | None,
    *,
    json_output: bool = False,
    json_schema: dict | None = None,
) -> RequestSpec:
    mode = backend.get("api_mode", "chat_completions")
    if mode not in {"responses", "chat_completions"}:
        raise ValueError("api_mode must be responses or chat_completions")
    base_url = backend.get("base_url")
    if not isinstance(base_url, str):
        raise ValueError("base_url must be an HTTP(S) API root")
    parsed = urlsplit(base_url)
    if (parsed.scheme not in {"http", "https"} or not parsed.hostname
            or parsed.username or parsed.password or parsed.query or parsed.fragment):
        raise ValueError("base_url must be an HTTP(S) API root without credentials, query or fragment")
    base_url = base_url.rstrip("/")
    if base_url.endswith(("/responses", "/chat/completions")):
        raise ValueError("base_url must be the API root, not a complete endpoint")
    headers = backend.get("headers", {})
    if not isinstance(headers, dict) or any(
        not isinstance(k, str) or not k or not isinstance(v, str)
        or "\r" in k + v or "\n" in k + v
        for k, v in headers.items()
    ):
        raise ValueError("headers must contain valid string header names and values")
    headers = {key.lower(): value for key, value in headers.items()}
    if any(key in headers for key in {"host", "content-length", "content-type", "connection", "transfer-encoding"}):
        raise ValueError("headers may not override transport headers")
    api_key = backend.get("api_key", "")
    if not isinstance(api_key, str):
        raise ValueError("api_key must be a string")
    if api_key and "authorization" in headers:
        raise ValueError("configure api_key or an authorization header, not both")
    if not api_key and not headers:
        raise ValueError("API key or authentication headers are required")
    if api_key:
        headers["authorization"] = f"Bearer {api_key}"
    headers["content-type"] = "application/json"
    timeout = _number(backend.get("timeout_s", 120), "timeout_s", positive=True)
    body: dict[str, Any] = {"model": model, "stream": False, "store": False}
    is_responses = mode == "responses"
    body["input" if is_responses else "messages"] = _messages(messages, responses=is_responses)
    temp = effective_temperature(backend, temperature)
    if temp is not None:
        body["temperature"] = temp
    max_tokens = backend.get("max_output_tokens")
    if max_tokens is not None:
        if isinstance(max_tokens, bool) or not isinstance(max_tokens, int) or max_tokens <= 0:
            raise ValueError("max_output_tokens must be a positive integer")
        body["max_output_tokens" if is_responses else "max_completion_tokens"] = max_tokens
    effort = backend.get("reasoning_effort")
    if effort is not None:
        if not isinstance(effort, str) or not effort.strip():
            raise ValueError("reasoning_effort must be a non-empty string")
        body["reasoning" if is_responses else "reasoning_effort"] = {"effort": effort} if is_responses else effort
    json_mode = backend.get("json_mode", "prompt")
    if json_mode not in {"prompt", "json_schema"}:
        raise ValueError("json_mode must be prompt or json_schema")
    if json_output and json_mode == "json_schema":
        if json_schema is None:
            format_config = {"type": "json_object"}
        else:
            if not isinstance(json_schema, dict):
                raise ValueError("json_schema must be an object")
            schema_config = {"name": "amz_output", "strict": True, "schema": strict_json_schema(json_schema)}
            format_config = {"type": "json_schema", **schema_config} if is_responses else {
                "type": "json_schema", "json_schema": schema_config,
            }
        body["text" if is_responses else "response_format"] = {"format": format_config} if is_responses else format_config
    suffix = "responses" if is_responses else "chat/completions"
    return RequestSpec(f"{base_url}/{suffix}", headers, body, timeout)


def parse_response(data: Any, api_mode: str) -> dict:
    if not isinstance(data, dict):
        raise ValueError("LLM response must be a JSON object")
    if data.get("error"):
        raise ValueError("LLM returned an error")
    texts: list[str] = []
    if api_mode == "responses":
        if data.get("status") != "completed":
            raise ValueError("Responses result is not completed")
        output = data.get("output")
        if not isinstance(output, list):
            raise ValueError("Responses output must be a list")
        for item in output:
            if not isinstance(item, dict):
                raise ValueError("invalid Responses output item")
            if item.get("type") == "reasoning":
                continue
            if item.get("type") != "message" or item.get("role") != "assistant":
                raise ValueError("unsupported Responses output item")
            if item.get("status", "completed") != "completed":
                raise ValueError("Responses message is not completed")
            content = item.get("content")
            if not isinstance(content, list):
                raise ValueError("invalid Responses message content")
            for part in content:
                if not isinstance(part, dict):
                    raise ValueError("invalid Responses content part")
                if part.get("type") == "refusal":
                    raise ValueError("LLM refused the request")
                if part.get("type") != "output_text" or not isinstance(part.get("text"), str):
                    raise ValueError("unsupported Responses content part")
                texts.append(part["text"])
    elif api_mode == "chat_completions":
        choices = data.get("choices")
        if not isinstance(choices, list) or not choices or not isinstance(choices[0], dict):
            raise ValueError("Chat Completions response has no valid choice")
        choice = choices[0]
        if choice.get("finish_reason") != "stop":
            raise ValueError("Incomplete response: Chat Completions result did not finish normally")
        message = choice.get("message")
        if not isinstance(message, dict):
            raise ValueError("invalid Chat Completions message")
        if message.get("refusal"):
            raise ValueError("LLM refused the request")
        if not isinstance(message.get("content"), str):
            raise ValueError("Model returned no answer text")
        texts.append(message["content"])
    else:
        raise ValueError("unsupported response api_mode")
    text = "".join(texts)
    if not text.strip():
        raise ValueError("Model returned no answer text")
    result: dict[str, Any] = {"text": text}
    if isinstance(data.get("usage"), dict):
        result["usage"] = dict(data["usage"])
    return result
