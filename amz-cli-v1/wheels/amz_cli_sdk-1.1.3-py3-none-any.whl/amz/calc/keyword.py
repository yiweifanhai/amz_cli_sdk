"""
关键词计算：主力流量词筛选、关键词清洗、ABA 斜率特征。

吸收 amz_agent keyword-filter.py / new_release_process keyword_analysis.py /
market_selection_agent fit_rank_features.py / precheck_gate.py。
"""

from __future__ import annotations

import statistics
from bisect import bisect_right
import re
from typing import Any

from amz.envelope import Result, ok
from amz.registry import capability
from amz.schemas.analysis_inputs import CalcKeywordGapInput, CalcPrimaryKeywordsInput
from amz.schemas.data_outputs import KeywordGapOutput, PrimaryKeywordsOutput


def _keyword_matches(keyword: str, text: str) -> bool:
    """按 listing_agent 原规则匹配关键词。

    多词短语要求完整连续出现；单词使用边界匹配，避免 ``set`` 命中
    ``offset``。匹配不做词干化或“任一单词”放宽。
    """
    normalized = keyword.lower().strip()
    if not normalized:
        return False
    if " " in normalized:
        # listing_agent/gap-analysis.ts 的原实验就是不带边界的连续子串匹配。
        return normalized in text.lower()
    return re.search(rf"\b{re.escape(normalized)}\b", text, flags=re.IGNORECASE) is not None


@capability("calc.keyword.gap", description="Listing 的 S/A 关键词覆盖检查（确定性）", input_model=CalcKeywordGapInput, output_model=KeywordGapOutput)
def analyze_gap(keywords: list[dict], listing_text: dict) -> Result:
    """检查 S/A 关键词在 title/BP1-5 的精确覆盖位置。"""
    segments = [("title", str(listing_text.get("title", "")))]
    segments.extend(
        (f"bp{i + 1}", str(text))
        for i, text in enumerate(listing_text.get("bullet_points", [])[:5])
    )

    covered: list[dict] = []
    missing: list[dict] = []
    for item in keywords:
        grade = str(item.get("grade", "")).upper()
        if grade not in {"S", "A"}:
            continue
        term = str(item.get("term") or item.get("keyword") or "").strip()
        if not term:
            continue
        source = str(item.get("source") or "a10")
        found_in = [position for position, text in segments if _keyword_matches(term, text)]
        base = {"keyword": term, "grade": grade, "source": source}
        if found_in:
            covered.append({**base, "found_in": found_in})
        else:
            missing.append(base)
    return ok(data={"covered": covered, "missing": missing})


def filter_primary(items: list[dict]) -> dict:
    """calc.keyword.filter-primary

    从关键词反查结果中筛选主力流量词（3-8 个），
    按流量占比/PPC/自然占比排序。

    Returns:
        {primary: [{term, traffic_pct, ppc, natural_ratio}], coverage_pct, total_traffic_pct}
    """
    if not items:
        return {"primary": [], "coverage_pct": 0, "total_traffic_pct": 0}

    # 过滤掉缺失关键字段的
    valid = [
        it for it in items
        if it.get("term") and it.get("traffic_pct") is not None
    ]

    if not valid:
        return {"primary": [], "coverage_pct": 0, "total_traffic_pct": 0}

    # 按 traffic_pct 降序
    sorted_items = sorted(valid, key=lambda x: x.get("traffic_pct", 0) or 0, reverse=True)

    # 取累积流量占比 ≥ 80% 的词，最少 3 个，最多 8 个
    total_traffic = sum(it.get("traffic_pct", 0) or 0 for it in sorted_items)
    cumulative = 0.0
    primary = []

    for it in sorted_items:
        tp = it.get("traffic_pct", 0) or 0
        cumulative += tp
        primary.append({
            "term": it["term"],
            "traffic_pct": tp,
            "ppc": it.get("ppc"),
            "natural_ratio": it.get("natural_ratio"),
        })
        # 至少 3 个且达到 80% 覆盖
        if len(primary) >= 3 and (cumulative / total_traffic) >= 0.8 if total_traffic > 0 else True:
            break
        if len(primary) >= 8:
            break

    coverage = sum(p["traffic_pct"] for p in primary)
    coverage_pct = (coverage / total_traffic * 100) if total_traffic > 0 else 0

    return {
        "primary": primary,
        "coverage_pct": round(coverage_pct, 1),
        "total_traffic_pct": round(total_traffic, 1),
    }


def normalize_terms(
    terms: list[str],
    context: dict | None = None,
) -> dict:
    """calc.keyword.normalize

    关键词清洗/标准化：表头归一、品牌词过滤、禁用词过滤、主关键词提取。

    Returns:
        {normalized: [{term, cleaned, is_brand, is_banned, kept}]}
    """
    ctx = context or {}
    title = ctx.get("title", "")
    banned = ctx.get("banned_terms", [])

    # 从 title 提取品牌词（简单规则：title 第一个词通常是品牌）
    brand_words = set()
    if title:
        first_word = title.split()[0].lower().strip(",")
        if len(first_word) >= 2:
            brand_words.add(first_word)

    # 禁用词集合
    banned_set = {b.lower().strip() for b in banned}

    results = []
    for term in terms:
        cleaned = term.strip()
        if not cleaned:
            continue

        lowered = cleaned.lower()

        # 品牌词检测
        is_brand = any(bw in lowered for bw in brand_words)

        # 禁用词检测
        is_banned = any(bw in lowered for bw in banned_set)

        results.append({
            "term": term,
            "cleaned": cleaned,
            "is_brand": is_brand,
            "is_banned": is_banned,
            "kept": not is_brand and not is_banned,
        })

    return {"normalized": results}


def calculate_rank_slope(series: list[dict]) -> dict:
    """calc.keyword.rank-slope

    ABA rank 时间序列斜率分析：k1-k4 斜率、年化增长、突变/节日概率。

    Args:
        series: [{week: str, rank: int}, ...]

    Returns:
        {k1, k2, k3, k4, annual_growth, spike_prob, holiday_prob, emerging_score, verdict}
    """
    if len(series) < 4:
        return {
            "k1": None, "k2": None, "k3": None, "k4": None,
            "annual_growth": None, "spike_prob": None, "holiday_prob": None,
            "emerging_score": None, "verdict": "insufficient_data",
        }

    # 提取 rank 序列
    ranks = [s.get("rank") for s in series if s.get("rank") is not None]
    if len(ranks) < 4:
        return {
            "k1": None, "k2": None, "k3": None, "k4": None,
            "annual_growth": None, "spike_prob": None, "holiday_prob": None,
            "emerging_score": None, "verdict": "insufficient_data",
        }

    n = len(ranks)

    # k1: 最近 1 期变化率
    k1 = (ranks[-2] - ranks[-1]) / ranks[-2] * 100 if ranks[-2] > 0 else 0

    # k2: 最近 4 期平均变化率
    k2_vals = []
    for i in range(max(0, n - 5), n - 1):
        if ranks[i] > 0:
            k2_vals.append((ranks[i] - ranks[i + 1]) / ranks[i] * 100)
    k2 = statistics.mean(k2_vals) if k2_vals else 0

    # k3: 最近 8 期平均变化率
    k3 = k2  # 简化：数据不够 8 期复用

    # k4: 全序列趋势
    if len(ranks) >= 8:
        first_half = statistics.mean(ranks[:len(ranks)//2])
        second_half = statistics.mean(ranks[len(ranks)//2:])
        k4 = (first_half - second_half) / first_half * 100 if first_half > 0 else 0
    else:
        k4 = k2

    # 年化增长
    monthly_rate = k4 / 100  # rank 上升 = 增长（rank 变小 = 搜索频率变高 = 好）
    annual_growth = monthly_rate * 12 * 100

    # 突变概率（标准差异常）
    diffs = [ranks[i] - ranks[i + 1] for i in range(n - 1)]
    if len(diffs) >= 2:
        std = statistics.stdev(diffs)
        spike_prob = min(1.0, std / (statistics.mean([abs(d) for d in diffs]) + 0.01))
    else:
        spike_prob = 0

    # 节日概率简化
    holiday_prob = 0.1  # 后续接节日历表

    # 新兴得分
    emerging_score = (k2 * 0.5 + k4 * 0.3 + (1 - spike_prob) * 0.2)

    # 判定
    if k2 > 5:
        verdict = "rising"
    elif k2 < -5:
        verdict = "falling"
    elif spike_prob > 0.5:
        verdict = "spike"
    else:
        verdict = "stable"

    return {
        "k1": round(k1, 2),
        "k2": round(k2, 2),
        "k3": round(k3, 2),
        "k4": round(k4, 2),
        "annual_growth": round(annual_growth, 2) if annual_growth is not None else None,
        "spike_prob": round(spike_prob, 2),
        "holiday_prob": round(holiday_prob, 2),
        "emerging_score": round(emerging_score, 2),
        "verdict": verdict,
    }


@capability(
    "calc.keyword.primary",
    description="从标准化反查关键词中筛选 3-8 个主力流量词",
    input_model=CalcPrimaryKeywordsInput,
    output_model=PrimaryKeywordsOutput,
)
def extract_primary_keywords(items: list[dict]) -> dict:
    """筛选主力流量词；只接受标准 DTO，不读取或修改 Product Entity。

    输入百分比和输出百分比均为 ``0-100``。为平滑迁移，函数仍能读取旧的
    camelCase item，但会在函数入口立即转成唯一的 canonical 形状。
    """
    normalized = [_canonical_reverse_item(item) for item in (items or [])]
    normalized = [item for item in normalized if item["term"]]

    candidates = [
        _candidate(item)
        for item in normalized
        if _is_candidate(item, minimum_traffic_pct=3.0)
    ]
    candidates = [
        item for item in candidates
        if not (
            len(item["term"].split()) == 1
            and item["purchase_rate"] < 3.0
        )
    ]
    deduped = _dedupe_candidates(candidates)

    # 不足三个时只放宽流量阈值，不改变其他规则。
    if len(deduped) < 3:
        known = {item["term"].lower() for item in deduped}
        for item in normalized:
            if item["term"].lower() in known or item["traffic_pct"] < 2.0:
                continue
            if len(item["term"].split()) == 1 and item["purchase_rate"] < 3.0:
                continue
            candidate = _candidate(item)
            candidate["reasons"] = ["流量占比放宽至2%"]
            deduped.append(candidate)
            known.add(item["term"].lower())
            if len(deduped) >= 3:
                break

    primary = sorted(deduped, key=lambda item: item["traffic_pct"], reverse=True)[:8]
    total_traffic = sum(item["traffic_pct"] for item in primary)
    avg_ppc = sum(item["ppc"] for item in primary) / len(primary) if primary else 0.0
    avg_natural = (
        sum(item["natural_ratio"] for item in primary) / len(primary)
        if primary else 0.0
    )
    competition = (
        "竞争较低" if avg_ppc < 1.0
        else "竞争中等" if avg_ppc < 2.0
        else "竞争激烈"
    )
    health = (
        "健康" if avg_natural > 80
        else "中等" if avg_natural > 50
        else "广告依赖度高"
    )

    output_items = []
    for item in primary:
        rank = (
            f"#{item['rank_pos']}" if item["rank_page"] == 1
            else f"P{item['rank_page']}#{item['rank_pos']}"
            if item["rank_page"] and item["rank_pos"]
            else ""
        )
        output_items.append({
            "term": item["term"],
            "keyword_cn": item["keyword_cn"],
            "search_volume": item["search_volume"],
            "traffic_pct": round(item["traffic_pct"], 1),
            "purchase_rate": round(item["purchase_rate"], 1),
            "cvr": round(item["cvr"], 1),
            "cpa": round(item["cpa"], 2),
            "ppc": round(item["ppc"], 2),
            "top3_clicking_rate": round(item["top3_clicking_rate"], 1),
            "top3_conversion_rate": round(item["top3_conversion_rate"], 1),
            "trend": item["trend"],
            "rank": rank,
            "types": item["types"],
            "natural_ratio": round(item["natural_ratio"], 1),
            "synonyms": item.get("synonyms", []),
            "reasons": item["reasons"],
        })

    return {
        "primary_keywords": output_items,
        "analysis": {
            "total_traffic_pct": round(total_traffic, 1),
            "avg_ppc": round(avg_ppc, 2),
            "competition": competition,
            "avg_natural_ratio": round(avg_natural, 1),
            "health": health,
        },
    }


def _canonical_reverse_item(item: dict) -> dict:
    """兼容旧字段并立刻收敛到 canonical 0-100 DTO。"""
    rank_position = item.get("rankPosition") or {}
    canonical_rank = item.get("rank")
    return {
        "term": str(item.get("term") or item.get("keywords") or item.get("keyword") or "").strip(),
        "keyword_cn": str(item.get("keyword_cn") or item.get("keywordCn") or ""),
        "search_volume": int(item.get("search_volume") or item.get("searches") or 0),
        "traffic_pct": _canonical_pct(item, "traffic_pct", "trafficPercentage"),
        "purchase_rate": _canonical_pct(item, "purchase_rate", "purchaseRate"),
        "natural_ratio": _canonical_pct(item, "natural_ratio", "naturalRatio"),
        "ad_ratio": _canonical_pct(item, "ad_ratio", "adRatio"),
        "top3_clicking_rate": _canonical_pct(item, "top3_clicking_rate", "top3ClickingRate"),
        "top3_conversion_rate": _canonical_pct(item, "top3_conversion_rate", "top3ConversionRate"),
        "ppc": float(item.get("ppc") or item.get("exactPpc") or 0),
        "purchases": int(item.get("purchases") or 0),
        "clicks": int(item.get("clicks") or 0),
        "types": list(item.get("traffic_keyword_types") or item.get("trafficKeywordTypes") or []),
        "rank_page": int(rank_position.get("page") or (1 if canonical_rank else 0)),
        "rank_pos": int(rank_position.get("position") or canonical_rank or 0),
        "trend": list(item.get("trend") or item.get("searchesTrend") or []),
    }


def _canonical_pct(item: dict, canonical_key: str, legacy_key: str) -> float:
    value = item.get(canonical_key)
    if value is not None:
        return float(value or 0)
    raw = item.get(legacy_key)
    if raw is None:
        return 0.0
    if isinstance(raw, str):
        text = raw.strip().replace("%", "")
        try:
            value = float(text)
        except ValueError:
            return 0.0
        return value if "%" in raw or value > 1 else value * 100
    value = float(raw or 0)
    return value * 100 if 0 < value <= 1 else value


def _is_candidate(item: dict, minimum_traffic_pct: float) -> bool:
    return (
        item["traffic_pct"] >= minimum_traffic_pct
        or bool({"PRIMARY", "PRECISE"}.intersection(item["types"]))
        or (
            item["search_volume"] >= 20_000
            and item["rank_page"] == 1
            and 0 < item["rank_pos"] <= 20
        )
    )


def _candidate(item: dict) -> dict:
    cvr = item["purchases"] / item["clicks"] * 100 if item["clicks"] else 0.0
    cpa = item["ppc"] / (cvr / 100) if cvr > 0 else 0.0
    reasons = []
    if item["traffic_pct"] >= 3:
        reasons.append(f"流量占比{item['traffic_pct']:.1f}%")
    if {"PRIMARY", "PRECISE"}.intersection(item["types"]):
        reasons.append("官方标记")
    if item["search_volume"] >= 20_000 and item["rank_page"] == 1 and 0 < item["rank_pos"] <= 20:
        reasons.append("大搜索量+首页")
    return {**item, "cvr": cvr, "cpa": cpa, "reasons": reasons}


def _dedupe_candidates(candidates: list[dict]) -> list[dict]:
    deduped: list[dict] = []
    for candidate in sorted(candidates, key=lambda item: item["traffic_pct"], reverse=True):
        words = set(candidate["term"].lower().split())
        duplicate = next((
            kept for kept in deduped
            if words.issubset(set(kept["term"].lower().split()))
            or set(kept["term"].lower().split()).issubset(words)
        ), None)
        if duplicate is None:
            deduped.append(candidate)
        else:
            duplicate.setdefault("synonyms", []).append(candidate["term"])
    return deduped


def _value(data: dict, *names: str, default=None):
    for name in names:
        if data.get(name) is not None:
            return data[name]
    return default


def _number(value):
    try:
        return float(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def _normalize_keyword_row(item: dict) -> dict:
    nested_feature = item.get("feature")
    feature_missing = "feature" in item and not isinstance(nested_feature, dict)
    feature = nested_feature if isinstance(nested_feature, dict) else item
    searches = _number(_value(feature, "searches", "search_volume"))
    weekly_exposure = _number(_value(item, "weeklyExposureSum", "weekly_exposure_sum", "exposure"))
    asin_count = _number(_value(item, "asinCount", "asin_count"))
    return {
        "keyword": str(item.get("keyword") or item.get("term") or ""),
        "feature_missing": feature_missing,
        "searches": searches,
        "weekly_exposure": weekly_exposure,
        "purchase_rate": _number(_value(feature, "purchaseRate", "purchase_rate")),
        "cvr": _number(_value(feature, "cvr")),
        "purchases": _number(_value(feature, "purchases")),
        "supply_demand": _number(_value(feature, "supplyDemandRatio", "supply_demand_ratio")),
        "spr": _number(_value(feature, "cprExact", "spr", "cpr_exact")),
        "top3": _number(_value(feature, "top3ClickingRate", "top3_clicking_rate")),
        "asin_count": asin_count,
        "exposure_coverage": (
            min((weekly_exposure or 0) / searches, 1) if searches and searches > 0 else None
        ),
        "trend": _value(feature, "searchesTrend", "searches_trend", default=[]),
    }


def _percentile_to_score(percentile: float) -> float:
    percentile = min(100.0, max(0.0, percentile))
    segments = [(95, 10), (80, 8), (60, 6), (35, 4), (10, 2)]
    for index in range(len(segments) - 1):
        high_pct, high_score = segments[index]
        low_pct, low_score = segments[index + 1]
        if percentile >= low_pct:
            ratio = (percentile - low_pct) / (high_pct - low_pct)
            return min(10.0, max(1.0, low_score + ratio * (high_score - low_score)))
    return 1.0


def _percentile_lookup(values: list[float | None], reverse: bool = False):
    sorted_values = sorted(value for value in values if value is not None)

    def lookup(value: float | None) -> float | None:
        if value is None:
            return None
        if not sorted_values:
            return 5.0
        percentile = bisect_right(sorted_values, value) / len(sorted_values) * 100
        return _percentile_to_score(100 - percentile if reverse else percentile)

    return lookup


def _weighted_average(items: list[tuple[float | None, float]]) -> float:
    valid = [(value, weight) for value, weight in items if value is not None]
    if not valid:
        return 5.0
    total_weight = sum(weight for _value_, weight in valid)
    return sum(value * weight for value, weight in valid) / total_weight


def _trend_adjustment(trend: list[dict] | None) -> float:
    if not trend or len(trend) < 4:
        return 0
    values = [float(item.get("searches") or item.get("search") or 0) for item in trend]
    midpoint = len(values) // 2
    earlier = sum(values[:midpoint]) / max(1, midpoint)
    recent = sum(values[midpoint:]) / max(1, len(values) - midpoint)
    if earlier == 0:
        return 0
    change = (recent - earlier) / earlier
    if change > 1:
        return 1.0
    if change > 0.5:
        return 0.5
    if change > 0.2:
        return 0.3
    if change < -0.5:
        return -0.5
    if change < -0.2:
        return -0.3
    return 0


def score_keyword_rows(rows: list[dict], relevance_map: dict[str, dict]) -> dict:
    """Apply the existing relative score formula to explicit semantic judgments."""
    from amz.schemas.keyword_analysis import DimensionScores, ScoredKeyword, KeywordScoreOutput

    if any(relevance_map.get(row["keyword"].casefold(), {}).get("match")
           not in {"perfect", "high", "partial", "low"} for row in rows):
        raise ValueError("every candidate requires an explicit semantic match")
    lookups = {
        "searches": _percentile_lookup([row["searches"] for row in rows]),
        "exposure": _percentile_lookup([row["weekly_exposure"] for row in rows]),
        "purchase_rate": _percentile_lookup([row["purchase_rate"] for row in rows]),
        "cvr": _percentile_lookup([row["cvr"] for row in rows]),
        "purchases": _percentile_lookup([row["purchases"] for row in rows]),
        "supply_demand": _percentile_lookup([row["supply_demand"] for row in rows]),
        "spr": _percentile_lookup([row["spr"] for row in rows], reverse=True),
        "top3": _percentile_lookup([row["top3"] for row in rows], reverse=True),
        "asin_count": _percentile_lookup([row["asin_count"] for row in rows]),
        "exposure_coverage": _percentile_lookup([row["exposure_coverage"] for row in rows]),
    }
    multipliers = {
        "perfect": 1.3, "high": 1.0, "partial": 0.7,
        "low": 0.4,
    }
    scored: list[ScoredKeyword] = []
    distribution = {"S": 0, "A": 0, "B": 0, "C": 0}
    for row in rows:
        llm = relevance_map[row["keyword"].casefold()]
        match = llm["match"]
        relevance_base = _weighted_average([
            (lookups["asin_count"](row["asin_count"]), 0.5),
            (lookups["exposure_coverage"](row["exposure_coverage"]), 0.5),
        ])
        relevance = min(10, max(0, relevance_base * multipliers.get(match, 1.0)))
        if row["feature_missing"]:
            # scoring-engine.ts Task 3.9：feature 整体为 null 时三维固定中性 5 分。
            traffic = conversion = competition = 5.0
        else:
            traffic = _weighted_average([
                (lookups["searches"](row["searches"]), 0.6),
                (lookups["exposure"](row["weekly_exposure"]), 0.4),
            ])
            conversion = _weighted_average([
                (lookups["purchase_rate"](row["purchase_rate"]), 0.4),
                (lookups["cvr"](row["cvr"]), 0.4),
                (lookups["purchases"](row["purchases"]), 0.2),
            ])
            competition = _weighted_average([
                (lookups["supply_demand"](row["supply_demand"]), 0.4),
                (lookups["spr"](row["spr"]), 0.3),
                (lookups["top3"](row["top3"]), 0.3),
            ])
        trend = _trend_adjustment(row["trend"])
        score = round(min(10, max(0,
            relevance * 0.30 + traffic * 0.25 + conversion * 0.25 + competition * 0.20 + trend
        )), 1)
        grade = (
            "S" if score >= 8 else "A" if score >= 6 else "B" if score >= 4 else "C"
        )
        distribution[grade] += 1
        scored.append(ScoredKeyword(
            keyword=row["keyword"], score=score, grade=grade,
            dimension_scores=DimensionScores(
                relevance=round(relevance, 1), traffic=round(traffic, 1),
                conversion=round(conversion, 1), competition=round(competition, 1),
            ),
            trend_adjustment=trend, match_level=match,
            reason=str(llm.get("reason") or ""),
        ))
    average = round(sum(item.score for item in scored) / len(scored), 1) if scored else 0
    return KeywordScoreOutput(
        scored_keywords=scored, total_count=len(scored),
        grade_distribution=distribution, average_score=average,
    ).model_dump()
