"""
基础设施缓存：SQLite 键值缓存 + 兼容读取旧 amz-api 文件缓存。

统一 product_dev_v2、traffic_map、market_selection_agent、amz-api 的缓存实现。
"""

from __future__ import annotations

import json
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from amz.config import config


# ---------------------------------------------------------------------------
# 文件缓存（兼容 amz-api ~/.cache/amz-api/ 格式）
# ---------------------------------------------------------------------------

def _legacy_cache_dir(slug: str) -> Path | None:
    """amz-api 旧缓存目录"""
    if not config.reuse_legacy_cache:
        return None
    legacy = Path.home() / ".cache" / "amz-api" / slug
    return legacy if legacy.exists() else None


def _legacy_read(slug: str, key: str) -> dict | None:
    """读取 amz-api 旧文件缓存，返回 data 或 None"""
    d = _legacy_cache_dir(slug)
    if d is None:
        return None
    path = d / f"{key}.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, KeyError, ValueError):
        return None


def _get_cache_file(slug: str, key: str) -> Path:
    """获取 SDK 文件缓存路径"""
    d = config.cache_dir / "data" / slug
    d.mkdir(parents=True, exist_ok=True)
    return d / f"{key}.json"


def file_read(slug: str, key: str, ttl_hours: int) -> dict | None:
    """读取文件缓存（兼容 amz-api 旧目录），返回 data 字段或 None"""
    # 1. 先读 SDK 新缓存
    path = _get_cache_file(slug, key)
    if path.exists():
        try:
            cached = json.loads(path.read_text())
            cached_at = datetime.fromisoformat(cached["cached_at"].replace("Z", "+00:00"))
            if (datetime.now(timezone.utc) - cached_at).total_seconds() < ttl_hours * 3600:
                return cached["data"]
        except (json.JSONDecodeError, KeyError, ValueError):
            pass

    # 2. 兼容读旧 amz-api 缓存
    data = _legacy_read(slug, key)
    if data is not None:
        cached_at_str = data.get("cached_at", "")
        if cached_at_str:
            try:
                cached_at = datetime.fromisoformat(cached_at_str.replace("Z", "+00:00"))
                if (datetime.now(timezone.utc) - cached_at).total_seconds() < ttl_hours * 3600:
                    return data.get("data", data)
            except (ValueError, TypeError):
                pass
        # 如果无法解析时间，保守地返回数据
        return data.get("data", data)

    return None


def file_write(slug: str, key: str, ttl_hours: int, data: Any):
    """写入文件缓存"""
    path = _get_cache_file(slug, key)
    path.parent.mkdir(parents=True, exist_ok=True)
    cached = {
        "cached_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "ttl_hours": ttl_hours,
        "data": data,
    }
    path.write_text(json.dumps(cached, ensure_ascii=False))


# ---------------------------------------------------------------------------
# SQLite 缓存（infra.llm / analysis 共享）
# ---------------------------------------------------------------------------

_sqlite_conn: sqlite3.Connection | None = None


def _get_sqlite() -> sqlite3.Connection:
    global _sqlite_conn
    if _sqlite_conn is not None:
        return _sqlite_conn
    db_path = config.cache_dir / "cache.db"
    db_path.parent.mkdir(parents=True, exist_ok=True)
    _sqlite_conn = sqlite3.connect(str(db_path))
    _sqlite_conn.execute(
        "CREATE TABLE IF NOT EXISTS cache ("
        "  key TEXT PRIMARY KEY,"
        "  value TEXT,"
        "  expires_at REAL"
        ")"
    )
    _sqlite_conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_cache_expires ON cache(expires_at)"
    )
    _sqlite_conn.commit()
    return _sqlite_conn


def sqlite_get(key: str, ttl_seconds: int | None = None) -> dict | None:
    """SQLite 缓存读取"""
    conn = _get_sqlite()
    row = conn.execute(
        "SELECT value, expires_at FROM cache WHERE key = ?", (key,)
    ).fetchone()
    if row is None:
        return None
    value_str, expires_at = row
    if expires_at > 0 and time.time() > expires_at:
        return None
    try:
        return json.loads(value_str)
    except json.JSONDecodeError:
        return None


def sqlite_set(key: str, value: Any, ttl_seconds: int):
    """SQLite 缓存写入"""
    conn = _get_sqlite()
    expires_at = time.time() + ttl_seconds if ttl_seconds > 0 else 0
    conn.execute(
        "INSERT OR REPLACE INTO cache (key, value, expires_at) VALUES (?, ?, ?)",
        (key, json.dumps(value, ensure_ascii=False), expires_at),
    )
    conn.commit()


def sqlite_prune():
    """清理过期缓存"""
    conn = _get_sqlite()
    conn.execute("DELETE FROM cache WHERE expires_at > 0 AND expires_at < ?", (time.time(),))
    conn.commit()


# ---------------------------------------------------------------------------
# 统一缓存接口（infra.cache.get / set）
# ---------------------------------------------------------------------------

def get(key: str, ttl_seconds: int | None = None) -> dict | None:
    """infra.cache.get — 从 SQLite 缓存读取 {hit: bool, value?: json}"""
    result = sqlite_get(key, ttl_seconds)
    if result is None:
        return {"hit": False}
    return {"hit": True, "value": result}


def set(key: str, value: Any, ttl_seconds: int):
    """infra.cache.set — 写入 SQLite 缓存"""
    sqlite_set(key, value, ttl_seconds)
    return {"ok": True}
