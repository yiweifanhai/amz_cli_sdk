"""
非结构化文本解析器：重量、尺寸、BSR、日期、价格等字段的标准化解析。

吸收 product_dev_v2 / new_release_process / traffic_map 的解析逻辑。
所有解析函数：成功返回结构化对象，失败返回 None（不抛错）。
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any


# ---------------------------------------------------------------------------
# 重量解析
# ---------------------------------------------------------------------------

WEIGHT_UNITS = {
    "kg": 1000.0, "kilogram": 1000.0, "kilograms": 1000.0,
    "g": 1.0, "gram": 1.0, "grams": 1.0,
    "oz": 28.3495, "ounce": 28.3495, "ounces": 28.3495,
    "lb": 453.592, "lbs": 453.592, "pound": 453.592, "pounds": 453.592,
}

WEIGHT_PATTERN = re.compile(
    r"([\d,.]+)\s*(kg|kilogram|kilograms|g|gram|grams|oz|ounce|ounces|lb|lbs|pound|pounds)",
    re.IGNORECASE,
)


def parse_weight(text: str) -> dict | None:
    """解析重量字符串 → {value_grams, raw}"""
    if not text or not isinstance(text, str):
        return None
    text = text.strip()
    m = WEIGHT_PATTERN.search(text)
    if not m:
        # 尝试纯数字（默认 g）
        num = _parse_number(text)
        if num is not None:
            return {"value_grams": num, "raw": text}
        return None
    try:
        value = float(m.group(1).replace(",", ""))
        unit = m.group(2).lower()
        grams = value * WEIGHT_UNITS.get(unit, 1.0)
        return {"value_grams": round(grams, 1), "raw": text}
    except (ValueError, TypeError):
        return None


# ---------------------------------------------------------------------------
# 尺寸解析
# ---------------------------------------------------------------------------

DIMS_PATTERN = re.compile(r"([\d,.]+)")  # 提取数字
DIMS_SEP = re.compile(r"[\s]*[x×\*×]+[\s]*")  # 分隔符：x、×、*


def parse_dimensions(text: str) -> dict | None:
    """解析尺寸字符串 → {length_cm, width_cm, height_cm, raw}

    支持格式:
      "10 x 5 x 2 inches" / "25.4x12.7x5.1 cm" / "10.5\" x 7.3\" x 2.1\""
      "60\"L x 40\"W" (2D → height 取较小值近似)
    """
    if not text or not isinstance(text, str):
        return None
    text = text.strip()

    # 判断单位
    is_inch = bool(re.search(r'inch|"|\bin\b', text, re.IGNORECASE))

    # 按分隔符拆分
    parts = DIMS_SEP.split(text)
    if len(parts) < 2:
        return None

    nums = []
    for p in parts:
        m = DIMS_PATTERN.search(p)
        if m:
            try:
                nums.append(float(m.group(1).replace(",", "")))
            except ValueError:
                return None

    if len(nums) < 1:
        return None

    # 排序：最长 → length，最短 → height
    nums.sort(reverse=True)

    if len(nums) >= 3:
        length, width, height = nums[0], nums[1], nums[2]
    elif len(nums) == 2:
        length, width = nums[0], nums[1]
        height = nums[1]  # 2D 场景：厚度取较小值近似
    else:
        # 单维度（罕见）
        length = width = height = nums[0]

    if is_inch:
        length *= 2.54
        width *= 2.54
        height *= 2.54

    return {
        "length_cm": round(length, 1),
        "width_cm": round(width, 1),
        "height_cm": round(height, 1),
        "raw": text,
    }


# ---------------------------------------------------------------------------
# BSR 解析
# ---------------------------------------------------------------------------

BSR_PATTERN = re.compile(
    r"(?:Best Sellers? Rank|BSR)[:\s]*[#]?([\d,]+)\s*(?:in\s+)?(.+?)(?:\(|$|#|\d)",
    re.IGNORECASE,
)
BSR_SIMPLE = re.compile(r"#([\d,]+)\s+in\s+(.+)", re.IGNORECASE)


def parse_bsr(text: str) -> dict | None:
    """解析 BSR → {rank, category, raw}。多段时取 rank 最小的。"""
    if not text or not isinstance(text, str):
        return None

    text = text.strip()
    matches = BSR_PATTERN.findall(text)
    if not matches:
        matches = BSR_SIMPLE.findall(text)

    if not matches:
        return None

    best = None
    best_rank = float("inf")
    for rank_str, cat in matches:
        try:
            rank = int(rank_str.replace(",", ""))
            cat = cat.strip().rstrip(")")
            if rank < best_rank:
                best_rank = rank
                best = (rank, cat)
        except ValueError:
            continue

    if best is None:
        return None

    return {"rank": best[0], "category": best[1].strip(), "raw": text}


# ---------------------------------------------------------------------------
# 日期解析
# ---------------------------------------------------------------------------

DATE_FORMATS = [
    # ISO / 数字格式
    (re.compile(r"(\d{4})-(\d{1,2})-(\d{1,2})"), "{0}-{1:02d}-{2:02d}"),
    (re.compile(r"(\d{1,2})/(\d{1,2})/(\d{4})"), "{2}-{0:02d}-{1:02d}"),  # MM/DD/YYYY
    # 英文文本格式
    (re.compile(r"(?:on\s+)?(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{1,2}),?\s*(\d{4})", re.IGNORECASE), "month_name"),
]

MONTH_NAMES = {
    "january": 1, "february": 2, "march": 3, "april": 4, "may": 5, "june": 6,
    "july": 7, "august": 8, "september": 9, "october": 10, "november": 11, "december": 12,
}


def parse_date(text: str) -> dict | None:
    """解析日期字符串 → {date, raw}（date 为 ISO 格式 YYYY-MM-DD）"""
    if not text or not isinstance(text, str):
        return None
    text = text.strip()

    # ISO 格式
    m = DATE_FORMATS[0][0].search(text)
    if m:
        y, mon, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= mon <= 12 and 1 <= d <= 31:
            return {"date": f"{y:04d}-{mon:02d}-{d:02d}", "raw": text}

    # MM/DD/YYYY
    m = DATE_FORMATS[1][0].search(text)
    if m:
        mon, d, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= mon <= 12 and 1 <= d <= 31:
            return {"date": f"{y:04d}-{mon:02d}-{d:02d}", "raw": text}

    # 英文文本
    m = DATE_FORMATS[2][0].search(text)
    if m:
        mon = MONTH_NAMES.get(m.group(1).lower(), 0)
        d, y = int(m.group(2)), int(m.group(3))
        if mon and 1 <= d <= 31:
            return {"date": f"{y:04d}-{mon:02d}-{d:02d}", "raw": text}

    return None


# ---------------------------------------------------------------------------
# 价格解析
# ---------------------------------------------------------------------------

PRICE_PATTERN = re.compile(r"[\$£€]?\s*([\d,]+\.?\d*)")


def parse_price(text: str) -> float | None:
    """解析价格字符串 → float"""
    if text is None:
        return None
    if isinstance(text, (int, float)):
        return float(text)
    if not isinstance(text, str):
        return None
    text = text.strip()
    m = PRICE_PATTERN.search(text)
    if m:
        try:
            return float(m.group(1).replace(",", ""))
        except ValueError:
            return None
    return None


# ---------------------------------------------------------------------------
# 百分比解析
# ---------------------------------------------------------------------------

PCT_PATTERN = re.compile(r"([\d,.]+)\s*%?")


def parse_pct(text: str | float | int | None) -> float | None:
    """解析百分比 → float (0-100)。

    规则: 带 % 保留原值; 小数 (<1) 则 ×100。
    """
    if text is None:
        return None
    if isinstance(text, (int, float)):
        val = float(text)
        return val * 100 if 0 < val <= 1 else val
    if not isinstance(text, str):
        return None

    text = text.strip()
    is_pct = "%" in text
    m = PCT_PATTERN.search(text)
    if not m:
        return None
    try:
        val = float(m.group(1).replace(",", ""))
    except ValueError:
        return None

    if is_pct:
        return val
    return val * 100 if 0 < val <= 1 else val


# ---------------------------------------------------------------------------
# 数字 / 整数解析
# ---------------------------------------------------------------------------

def parse_int(text: str | int | None) -> int | None:
    """解析整数（去千分位）"""
    if text is None:
        return None
    if isinstance(text, int):
        return text
    if isinstance(text, float):
        return int(text)
    if not isinstance(text, str):
        return None
    text = text.strip()
    if not text:
        return None
    try:
        return int(text.replace(",", ""))
    except ValueError:
        return None


def parse_number(text: str) -> float | None:
    """通用数字解析"""
    if not text or not isinstance(text, str):
        return None
    try:
        return float(text.replace(",", "").strip())
    except ValueError:
        return None


# ---------------------------------------------------------------------------
# 国家名 → ISO alpha-2
# ---------------------------------------------------------------------------

COUNTRY_MAP: dict[str, str] = {
    "cn": "CN", "china": "CN", "中国": "CN",
    "us": "US", "united states": "US", "usa": "US", "美国": "US",
    "jp": "JP", "japan": "JP", "日本": "JP",
    "de": "DE", "germany": "DE", "德国": "DE",
    "gb": "GB", "uk": "GB", "united kingdom": "GB", "英国": "GB",
    "fr": "FR", "france": "FR", "法国": "FR",
    "kr": "KR", "korea": "KR", "south korea": "KR", "韩国": "KR",
    "in": "IN", "india": "IN", "印度": "IN",
    "ca": "CA", "canada": "CA", "加拿大": "CA",
    "au": "AU", "australia": "AU", "澳大利亚": "AU",
    "mx": "MX", "mexico": "MX", "墨西哥": "MX",
    "it": "IT", "italy": "IT", "意大利": "IT",
    "es": "ES", "spain": "ES", "西班牙": "ES",
    "br": "BR", "brazil": "BR", "巴西": "BR",
    "nl": "NL", "netherlands": "NL", "荷兰": "NL",
    "hk": "HK", "hong kong": "HK", "香港": "HK",
    "tw": "TW", "taiwan": "TW", "台湾": "TW",
    "vn": "VN", "vietnam": "VN", "越南": "VN",
    "tr": "TR", "turkey": "TR", "土耳其": "TR",
}


def parse_nation(text: str | None) -> str | None:
    """国家名 → ISO alpha-2 代码"""
    if not text or not isinstance(text, str):
        return None
    key = text.strip().lower()
    return COUNTRY_MAP.get(key)
