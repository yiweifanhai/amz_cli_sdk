"""
HTTP 客户端：POST/GET + 重试（退避）+ 可选响应缓存 + 限速（QPS）。

统一 product_dev_v2、traffic_map 各仓库的 HTTP 实现。
"""

from __future__ import annotations

import json
import time
from typing import Any

import httpx

from amz.envelope import Code, code_from_http, UpstreamError, RateLimitError, AuthError
from amz.infra.cache import sqlite_get, sqlite_set


# 端点级 QPS 限制
_qps_tracker: dict[str, list[float]] = {}  # endpoint → 最近请求时间戳列表


def _wait_qps(endpoint: str, qps: float):
    """按端点限速"""
    if qps <= 0:
        return
    now = time.time()
    timestamps = _qps_tracker.setdefault(endpoint, [])
    # 移除 1 秒前的记录
    timestamps[:] = [t for t in timestamps if now - t < 1.0]
    if len(timestamps) >= qps:
        sleep_time = 1.0 - (now - timestamps[0])
        if sleep_time > 0:
            time.sleep(sleep_time)
    timestamps.append(time.time())


def request(
    method: str,
    url: str,
    json_data: dict | None = None,
    headers: dict[str, str] | None = None,
    timeout: int = 10,
    retries: int = 3,
    retry_delay: float = 1.0,
    qps_sleep: float = 0,
    cache_ttl: int = 0,
    endpoint_key: str = "",
) -> dict:
    """infra.http.request

    返回:
      {status: int, json: object, from_cache: bool}
    """
    _headers = headers or {}
    cache_key = ""

    # 缓存
    if cache_ttl > 0:
        cache_key = f"http:{endpoint_key or url}:{_hash_body(json_data)}"
        cached = sqlite_get(cache_key, cache_ttl)
        if cached is not None:
            return {"status": 200, "json": cached, "from_cache": True}

    # 限速
    if qps_sleep > 0:
        _wait_qps(endpoint_key or url, qps_sleep)

    # 重试
    last_err: Exception | None = None
    last_status: int | None = None

    for attempt in range(retries):
        try:
            resp = httpx.request(
                method=method,
                url=url,
                json=json_data,
                headers=_headers,
                timeout=httpx.Timeout(timeout),
            )
            status = resp.status_code

            if status < 400:
                data = resp.json()
                # 写入缓存
                if cache_ttl > 0 and cache_key:
                    sqlite_set(cache_key, data, cache_ttl)
                return {"status": status, "json": data, "from_cache": False}

            # HTTP 错误
            last_status = status
            if status in (429, 502, 503, 504):
                # 可重试
                time.sleep(retry_delay * (2 ** attempt))
                continue
            # 4xx 不重试
            _raise_http_error(status, resp.text)

        except (httpx.TimeoutException, httpx.ConnectError, httpx.RemoteProtocolError) as e:
            last_err = e
            if attempt < retries - 1:
                time.sleep(retry_delay * (2 ** attempt))
            continue
        except Exception:
            raise

    # 重试耗尽
    if last_status:
        _raise_http_error(last_status, f"retries exhausted ({retries})")
    raise UpstreamError(
        source=url,
        status=None,
        message=f"HTTP {method} failed after {retries} attempts: {last_err}",
        hint="retries exhausted, check network or upstream",
    )


def _hash_body(body: dict | None) -> str:
    """请求体 hash 用于缓存 key"""
    import hashlib
    return hashlib.sha1(
        json.dumps(body or {}, sort_keys=True).encode()
    ).hexdigest()[:16]


def _raise_http_error(status: int, body: str):
    """HTTP 错误 → 业务异常"""
    msg = body[:200] if body else ""
    if status == 401:
        raise AuthError(f"HTTP 401: {msg}")
    if status == 429:
        raise RateLimitError(f"HTTP 429: {msg}")
    code = code_from_http(status)
    raise UpstreamError(source="http", status=status, message=f"HTTP {status}: {msg}")
