"""
文件导出：CSV / Excel。

吸收 market_selection_agent result_exporter.py、listing_agent excel 模块实现。
"""

from __future__ import annotations

import csv
import io
from pathlib import Path
from typing import Any


def to_csv(rows: list[dict], path: str, columns: list[str] | None = None) -> dict:
    """infra.util.csv → {path, row_count}

    每行是 dict，自动取 columns（未指定则用第一行的 keys）。
    """
    if not rows:
        Path(path).write_text("")
        return {"path": path, "row_count": 0}

    cols = columns or list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)

    return {"path": path, "row_count": len(rows)}


def to_excel(rows: list[dict], path: str, columns: list[str] | None = None) -> dict:
    """infra.util.excel → {path, row_count}

    需要 openpyxl 依赖（可选）。
    """
    try:
        from openpyxl import Workbook
    except ImportError:
        raise ImportError("openpyxl is required for Excel export. Install with: pip install openpyxl")

    if not rows:
        wb = Workbook()
        wb.active.title = "Data"
        wb.save(path)
        return {"path": path, "row_count": 0}

    cols = columns or list(rows[0].keys())
    wb = Workbook()
    ws = wb.active
    ws.title = "Data"

    # 表头
    for ci, col in enumerate(cols, 1):
        ws.cell(row=1, column=ci, value=col)

    # 数据
    for ri, row in enumerate(rows, 2):
        for ci, col in enumerate(cols, 1):
            ws.cell(row=ri, column=ci, value=row.get(col))

    wb.save(path)
    return {"path": path, "row_count": len(rows)}
