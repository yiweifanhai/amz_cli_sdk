"""
并发池：限流 + 进度回调 + 失败重试。

吸收 listing_agent concurrent.ts、market_selection_agent GraphRunner 的简化版逻辑。
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable, Coroutine
from typing import Any


async def run_concurrent(
    items: list[Any],
    worker: Callable[[Any], Coroutine[Any, Any, Any]],
    max_concurrency: int = 5,
    on_progress: Callable[[int, int], None] | None = None,
    fail_fast: bool = False,
) -> dict:
    """infra.util.concurrent

    Args:
        items: 待处理项列表
        worker: 异步处理函数 async fn(item) → result
        max_concurrency: 最大并发数
        on_progress: 进度回调 (done, total)
        fail_fast: 遇错即停

    Returns:
        {results: [...], errors: [{item, error}]}
    """
    semaphore = asyncio.Semaphore(max_concurrency)
    results = []
    errors = []
    done_count = 0

    async def process(item):
        nonlocal done_count
        async with semaphore:
            try:
                result = await worker(item)
                results.append(result)
            except Exception as e:
                errors.append({"item": item, "error": str(e)})
                if fail_fast:
                    raise
            finally:
                done_count += 1
                if on_progress:
                    on_progress(done_count, len(items))

    tasks = [process(item) for item in items]
    try:
        await asyncio.gather(*tasks)
    except Exception:
        pass  # fail_fast 时已经记录

    return {"results": results, "errors": errors}


def run_sync(
    items: list[Any],
    worker: Callable[[Any], Any],
    max_concurrency: int = 5,
    on_progress: Callable[[int, int], None] | None = None,
) -> dict:
    """同步版并发（使用 ThreadPoolExecutor）"""
    from concurrent.futures import ThreadPoolExecutor, as_completed

    results = []
    errors = []
    done_count = 0

    with ThreadPoolExecutor(max_workers=max_concurrency) as pool:
        futures = {pool.submit(worker, item): item for item in items}
        for future in as_completed(futures):
            item = futures[future]
            try:
                results.append(future.result())
            except Exception as e:
                errors.append({"item": item, "error": str(e)})
            done_count += 1
            if on_progress:
                on_progress(done_count, len(items))

    return {"results": results, "errors": errors}
