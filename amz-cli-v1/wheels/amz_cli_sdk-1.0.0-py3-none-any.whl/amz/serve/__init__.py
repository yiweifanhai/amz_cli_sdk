"""
接入层 — 把 SDK 能力暴露为外部可调用的协议端点。

- ``serve.http``：FastAPI REST 远程服务 + 可视化平台（SSE + 零依赖静态 viewer）
- ``serve.mcp``：MCP（Streamable HTTP），全部能力自动注册为 tools（后续阶段完善）

启动::

    amz serve http --port 8000 --host 0.0.0.0 [--no-auth]
    amz serve mcp  --port 8000 --host 0.0.0.0 [--no-auth]

用法::

    from amz.serve.http import create_app
    app = create_app(auth_token="")   # 空 token = 不鉴权
"""

from amz.serve.http import app, create_app

__all__ = ["create_app", "app"]
