/* amz-cli-sdk 静态 viewer —— 零依赖单页应用 */
"use strict";

const app = document.getElementById("app");
let currentStepStatus = {}; // run 视图的 step 状态缓存
let currentCaps = [];      // 能力目录缓存（跨视图复用）
let currentModule = "";    // 原子能力 tab 的架构层过滤（"" = 全部原子能力）
let currentCapabilityTests = [];
let selectedCapabilityId = "";
let currentEntityCatalog = null;
let currentEntityCaps = [];
let currentEntityChains = [];
let currentEntityDetail = null;
let currentEntityType = "";
let currentEntityIdentity = {};
let currentEntityRecordKey = "";
let currentAnalysisTests = [];

const ACCEPTED_VOC = {
  entries: [
    { id: "entity.product.voc", title: "完整 VOC", subtitle: "优势、痛点与使用洞察", tone: "primary" },
    { id: "entity.product.strengths", title: "创新优势", subtitle: "只分析 Listing 事实", tone: "strengths" },
    { id: "entity.product.weaknesses", title: "差评痛点", subtitle: "满意度、问题与未满足需求", tone: "weaknesses" },
    { id: "entity.product.use_insights", title: "使用洞察", subtitle: "场景、人群与购买动机", tone: "use" },
  ],
  atoms: [
    { id: "analysis.voc.strength-signals", title: "Strength signals", subtitle: "Listing → 创新优势" },
    { id: "analysis.voc.weakness-signals", title: "Weakness signals", subtitle: "评论 + Calc 上下文 → 痛点" },
    { id: "analysis.voc.use-signals", title: "Use signals", subtitle: "评论 → 场景、人群、动机" },
    { id: "calc.voc.satisfaction", title: "Satisfaction", subtitle: "全量评分汇总 → 确定性指标" },
  ],
};

/* ---------------- helpers ---------------- */

function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") node.className = v;
    else if (k === "text") node.textContent = v;
    else if (k.startsWith("on") && typeof v === "function") node.addEventListener(k.slice(2), v);
    else if (v !== null && v !== undefined) node.setAttribute(k, v);
  }
  for (const c of children) {
    if (c == null) continue;
    node.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
  }
  return node;
}

function token() { return localStorage.getItem("amz_token") || ""; }
function authHeaders() { const t = token(); return t ? { "X-API-Token": t } : {}; }

async function api(path, opts = {}) {
  const res = await fetch(path, {
    headers: { "Content-Type": "application/json", ...authHeaders() },
    ...opts,
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  if (!res.ok) {
    let detail = res.statusText;
    try { detail = JSON.stringify(await res.json()); } catch (e) {}
    throw new Error(`${res.status} ${detail}`);
  }
  return res.json();
}

function esc(s) {
  return String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
}

function badge(mode) {
  const label = { map: "map", reduce: "reduce", batch: "batch" }[mode] || mode;
  return el("span", { class: `badge ${mode}` }, label);
}

function statusDot(status) {
  return el("span", { class: `status ${status || "skipped"}` });
}

function fmtDate(value) {
  if (!value) return "—";
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? String(value) : d.toLocaleString("zh-CN", { hour12: false });
}

function fmtBytes(value) {
  const n = Number(value || 0);
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

function pill(status, text) {
  return el("span", { class: `pill ${status || "unknown"}`, text: text || status || "unknown" });
}

function metaItem(label, value) {
  return el("div", { class: "meta-item" },
    el("div", { class: "k", text: label }),
    el("div", { class: "v", text: String(value ?? "—") }));
}

/* ---------------- router ---------------- */

const routes = {
  "/entity": () => viewEntity(),
  "/analysis": () => viewAnalysis(),
  "/capabilities": () => viewCapabilities(),
  "/pipelines": () => viewPipelines(),
  "/runs": () => viewRuns(),
  "/builder": () => viewBuilder(),
};

function route() {
  const h = location.hash.replace(/^#/, "") || "/entity";
  const parts = h.split("/").filter(Boolean);
  document.querySelectorAll("nav button").forEach((b) =>
    b.classList.toggle("active", b.dataset.tab === parts[0])
  );
  app.innerHTML = '<p class="muted">加载中…</p>';
  const key = "/" + (parts[0] || "pipelines");
  try {
    if (parts[0] === "pipeline" && parts[1]) return viewPipeline(decodeURIComponent(parts[1]));
    if (parts[0] === "run" && parts[1]) return viewRun(decodeURIComponent(parts[1]));
    (routes[key] || viewPipelines)();
  } catch (e) {
    app.innerHTML = "";
    app.appendChild(el("div", { class: "card" }, el("h3", { text: "出错了" }), el("pre", { class: "json", text: String(e) })));
  }
}
window.addEventListener("hashchange", route);

// 异步渲染异常兜底：显示错误而非卡在「加载中…」（route() 的 try/catch 捕不到 async 异常）
window.addEventListener("unhandledrejection", (e) => {
  const reason = e.reason || e;
  const msg = (reason && reason.message) ? reason.message : String(reason);
  console.error("unhandledrejection:", reason);
  app.innerHTML = "";
  app.appendChild(el("div", { class: "card" },
    el("h3", { text: "出错了（异步）" }),
    el("pre", { class: "json", text: msg })));
});

// 导航按钮点击 → 改 hash → 触发 route()（此前缺失，tab 一直无法切换）
document.querySelectorAll("nav button").forEach((b) =>
  b.addEventListener("click", () => { location.hash = "#" + b.dataset.tab; })
);

/* ---------------- 已验收 Analysis / Product VOC 工作台 ---------------- */

function openCapabilityWorkbench(capabilityId) {
  currentModule = capabilityId.startsWith("calc.") ? "calc" : "analysis";
  sessionStorage.setItem("amz_cap_target", capabilityId);
  location.hash = "#capabilities";
}

function analysisAsin() {
  return (document.getElementById("analysis-voc-asin")?.value || "").trim();
}

function setAnalysisButtonsDisabled(disabled) {
  document.querySelectorAll("[data-voc-run]").forEach((button) => {
    button.disabled = disabled;
  });
}

async function viewAnalysis() {
  const [caps, tests] = await Promise.all([
    api("/api/capabilities"),
    api("/api/capability-tests?limit=50"),
  ]);
  currentCaps = caps;
  const acceptedIds = new Set(ACCEPTED_VOC.entries.map((item) => item.id));
  currentAnalysisTests = tests.filter((record) => acceptedIds.has(record.capability));
  const storedAsin = localStorage.getItem("amz_voc_asin") || "";

  app.innerHTML = "";
  app.appendChild(el("section", { class: "analysis-hero" },
    el("div", { class: "analysis-hero-copy" },
      el("div", { class: "row analysis-title-row" },
        el("span", { class: "analysis-kicker", text: "ACCEPTED ANALYSIS" }),
        pill("fresh", "VOC v1 已验收")),
      el("h2", { text: "Product VOC 洞察" }),
      el("p", { text: "输入一个 ASIN，Entity 会自动补齐 Listing、评论和全量评分汇总，再依次运行已验收的三个 VOC 原子能力。" })),
    el("div", { class: "analysis-flow" },
      el("span", { text: "Product" }),
      el("i", { text: "→" }),
      el("span", { text: "Calc" }),
      el("i", { text: "→" }),
      el("span", { text: "3× Analysis" }),
      el("i", { text: "→" }),
      el("span", { text: "Product.voc" }))));

  const workbench = el("section", { class: "analysis-workbench" },
    el("aside", { class: "card analysis-input-card" },
      el("div", { class: "analysis-card-heading" },
        el("div", {},
          el("span", { class: "eyebrow", text: "PRODUCT INPUT" }),
          el("h3", { text: "运行 VOC" })),
        el("span", { class: "layer-badge entity", text: "entity" })),
      el("label", { class: "analysis-field" },
        el("span", { text: "Amazon ASIN" }),
        el("input", {
          id: "analysis-voc-asin",
          value: storedAsin,
          placeholder: "例如 B0GYFRH1L9",
          autocomplete: "off",
          onkeydown: (event) => {
            if (event.key === "Enter") runAcceptedVoc("entity.product.voc");
          },
        })),
      el("label", { class: "voc-force" },
        el("input", { id: "analysis-voc-force", type: "checkbox" }),
        el("span", {},
          el("b", { text: "忽略当前 TTL，重新分析" }),
          el("small", { text: "会重新取数并调用 LLM，耗时和成本更高。" }))),
      el("p", { class: "analysis-runtime-note", text: "首次运行需要取商品详情和分星评论，完整三路分析可能持续数分钟。运行期间请不要重复提交。" }),
      el("div", { class: "voc-action-grid" })),
    el("div", { class: "analysis-main" },
      el("section", { class: "card accepted-contract" },
        el("div", { class: "analysis-card-heading" },
          el("div", {},
            el("span", { class: "eyebrow", text: "ACCEPTED CONTRACT" }),
            el("h3", { text: "本页使用的正式入口" })),
          el("code", { text: "entity.product.voc" })),
        el("div", { class: "contract-path" },
          el("div", {}, el("b", { text: "1" }), el("span", { text: "Listing 优势" }), el("code", { text: "strength-signals" })),
          el("div", {}, el("b", { text: "2" }), el("span", { text: "差评与需求" }), el("code", { text: "weakness-signals" })),
          el("div", {}, el("b", { text: "3" }), el("span", { text: "场景与人群" }), el("code", { text: "use-signals" }))),
        el("p", { class: "muted", text: "业务入口会经过 Entity 的依赖级联、TTL 和类型化写回。下方原子入口只用于调试明确的输入输出边界。" })),
      el("section", { id: "analysis-voc-result", class: "analysis-result-shell" },
        el("div", { class: "card analysis-empty" },
          el("span", { class: "analysis-empty-mark", text: "VOC" }),
          el("h3", { text: "等待运行" }),
          el("p", { class: "muted", text: "完整结果会按创新优势、差评痛点和使用洞察分区展示；底部仍保留原始 Result 信封。" })))));
  app.appendChild(workbench);

  const actions = workbench.querySelector(".voc-action-grid");
  for (const item of ACCEPTED_VOC.entries) {
    const available = caps.some((cap) => cap.id === item.id);
    actions.appendChild(el("button", {
      class: `voc-run-button ${item.tone}`,
      "data-voc-run": item.id,
      disabled: available ? null : "disabled",
      onclick: () => runAcceptedVoc(item.id),
    },
    el("b", { text: item.title }),
    el("span", { text: item.subtitle }),
    el("code", { text: available ? item.id : "能力未注册" })));
  }

  const atomSection = el("section", { class: "card accepted-atoms" },
    el("div", { class: "analysis-card-heading" },
      el("div", {},
        el("span", { class: "eyebrow", text: "ATOMIC LAB" }),
        el("h3", { text: "已验收原子能力" })),
      el("span", { class: "muted", text: "严格 DTO · 完整 schema" })),
    el("div", { class: "accepted-atom-grid" }));
  const atomGrid = atomSection.querySelector(".accepted-atom-grid");
  for (const item of ACCEPTED_VOC.atoms) {
    const cap = caps.find((candidate) => candidate.id === item.id);
    atomGrid.appendChild(el("article", { class: "accepted-atom" },
      el("div", { class: "accepted-atom-top" },
        el("span", { class: `layer-badge ${cap?.layer || "analysis"}`, text: cap?.layer || "analysis" }),
        pill(cap ? "fresh" : "missing", cap ? "已注册" : "缺失")),
      el("h4", { text: item.title }),
      el("p", { text: item.subtitle }),
      el("code", { text: item.id }),
      el("button", {
        class: "btn ghost compact",
        text: "打开原子测试",
        disabled: cap ? null : "disabled",
        onclick: () => openCapabilityWorkbench(item.id),
      })));
  }
  app.appendChild(atomSection);
  app.appendChild(el("section", { class: "card analysis-history" },
    el("div", { class: "analysis-card-heading" },
      el("div", {},
        el("span", { class: "eyebrow", text: "RUNTIME HISTORY" }),
        el("h3", { text: "最近的 VOC 运行" })),
      el("button", { class: "btn ghost compact", text: "刷新", onclick: () => viewAnalysis() })),
    el("div", { id: "analysis-history-list" })));
  renderAnalysisHistory();
}

async function runAcceptedVoc(capabilityId) {
  const asin = analysisAsin();
  const box = document.getElementById("analysis-voc-result");
  if (!asin) {
    box?.replaceChildren(el("div", { class: "card voc-failure" },
      el("h3", { text: "缺少 ASIN" }),
      el("p", { text: "请先输入商品 ASIN，再运行 VOC。" })));
    document.getElementById("analysis-voc-asin")?.focus();
    return;
  }
  localStorage.setItem("amz_voc_asin", asin);
  const forceRefresh = Boolean(document.getElementById("analysis-voc-force")?.checked);
  setAnalysisButtonsDisabled(true);
  if (box) {
    box.innerHTML = "";
    box.appendChild(el("div", { class: "card voc-running" },
      el("div", { class: "voc-spinner" }),
      el("div", {},
        el("h3", { text: capabilityId === "entity.product.voc" ? "正在运行完整 VOC" : "正在运行单路洞察" }),
        el("p", { class: "muted", text: `${asin} · 正在补齐依赖并调用能力。首次运行可能需要数分钟。` }),
        el("code", { text: capabilityId }))));
  }
  try {
    const record = await api(`/api/capability-tests/${encodeURIComponent(capabilityId)}`, {
      method: "POST",
      body: { asin, force_refresh: forceRefresh },
    });
    renderVocResult(record, box);
    currentAnalysisTests = [record, ...currentAnalysisTests.filter((item) => item.test_id !== record.test_id)].slice(0, 50);
    renderAnalysisHistory();
  } catch (error) {
    box?.replaceChildren(el("div", { class: "card voc-failure" },
      el("h3", { text: "请求失败" }),
      el("p", { text: error.message || String(error) })));
  } finally {
    setAnalysisButtonsDisabled(false);
  }
}

function normalizeVocData(capabilityId, data) {
  if (!data || typeof data !== "object") return {};
  if (capabilityId === "entity.product.strengths") return { strengths: data };
  if (capabilityId === "entity.product.weaknesses") return { weaknesses: data };
  if (capabilityId === "entity.product.use_insights") return { use_insights: data };
  return data;
}

function vocEvidence(text) {
  return text ? el("blockquote", { class: "voc-evidence", text }) : null;
}

function vocEmpty(text) {
  return el("div", { class: "voc-list-empty", text });
}

function renderVocStrengths(data) {
  const section = el("section", { class: "card voc-result-section strengths" },
    el("div", { class: "voc-section-heading" },
      el("div", {}, el("span", { class: "eyebrow", text: "LISTING SIGNALS" }), el("h3", { text: "创新优势" })),
      el("span", { class: "layer-badge analysis", text: "strengths" })),
    data?.summary ? el("p", { class: "voc-lead", text: data.summary }) : null,
    el("div", { class: "voc-signal-list" }));
  const list = section.querySelector(".voc-signal-list");
  const items = data?.innovation_and_competitive_advantages || [];
  if (!items.length) list.appendChild(vocEmpty("没有识别出足够明确的创新优势。"));
  for (const item of items) {
    const validation = item.user_validated === true ? "用户已验证" : item.user_validated === false ? "用户未验证" : "待评论验证";
    list.appendChild(el("article", { class: "voc-signal-card" },
      el("div", { class: "voc-item-title" },
        el("b", { text: item.innovation_summary || "未命名优势" }),
        el("span", { class: "voc-tag", text: item.innovation_type || "其他" })),
      el("p", { text: item.detail || "—" }),
      el("div", { class: "voc-item-meta", text: validation }),
      item.user_evidence ? vocEvidence(item.user_evidence) : null));
  }
  return section;
}

function renderVocWeaknesses(data) {
  const context = data?.satisfaction_context || {};
  const section = el("section", { class: "card voc-result-section weaknesses" },
    el("div", { class: "voc-section-heading" },
      el("div", {}, el("span", { class: "eyebrow", text: "REVIEW SIGNALS" }), el("h3", { text: "差评痛点与未满足需求" })),
      el("span", { class: "layer-badge analysis", text: "weaknesses" })),
    el("div", { class: "voc-satisfaction" },
      metaItem("整体评分", context.product_rating ?? "—"),
      metaItem("好评占比", `${context.positive_pct ?? 0}%`),
      metaItem("差评占比", `${context.negative_pct ?? 0}%`),
      metaItem("全量评论", context.total_reviews ?? 0)),
    context.assessment ? el("p", { class: "voc-assessment", text: context.assessment }) : null,
    el("div", { class: "voc-subsection" },
      el("div", { class: "voc-subheading" }, el("h4", { text: "主要痛点" }), el("span", { text: `${data?.top_issues?.length || 0} 项` })),
      el("div", { class: "voc-signal-list issues" })),
    el("div", { class: "voc-subsection" },
      el("div", { class: "voc-subheading" }, el("h4", { text: "未满足需求" }), el("span", { text: `${data?.unmet_needs?.length || 0} 项` })),
      el("div", { class: "voc-signal-list needs" })),
    data?.balanced_assessment ? el("div", { class: "voc-balanced" },
      el("b", { text: "平衡结论" }), el("p", { text: data.balanced_assessment })) : null);

  const issues = section.querySelector(".voc-signal-list.issues");
  const issueItems = data?.top_issues || [];
  if (!issueItems.length) issues.appendChild(vocEmpty("当前样本没有形成明确的高置信痛点。"));
  for (const item of issueItems) {
    issues.appendChild(el("article", { class: "voc-signal-card" },
      el("div", { class: "voc-item-title" },
        el("b", { text: item.pain_point || "未命名痛点" }),
        el("span", { class: `voc-severity ${(item.severity || "low").toLowerCase()}`, text: item.severity || "Low" })),
      el("div", { class: "voc-item-meta", text: `${item.issue_type || "—"} · ${item.ratio || `${item.cnt || 0}/${item.total_referenced || 0}`}` }),
      vocEvidence(item.evidence),
      item.dialectical_note && item.dialectical_note !== "无"
        ? el("p", { class: "voc-note", text: `辩证说明：${item.dialectical_note}` }) : null));
  }

  const needs = section.querySelector(".voc-signal-list.needs");
  const needItems = data?.unmet_needs || [];
  if (!needItems.length) needs.appendChild(vocEmpty("当前样本没有形成明确的未满足需求。"));
  for (const item of needItems) {
    needs.appendChild(el("article", { class: "voc-signal-card" },
      el("div", { class: "voc-item-title" },
        el("b", { text: item.unmet_need || "未命名需求" }),
        el("span", { class: `voc-severity ${(item.impact || "low").toLowerCase()}`, text: item.impact || "Low" })),
      item.description ? el("p", { text: item.description }) : null,
      el("div", { class: "voc-item-meta", text: item.ratio || `${item.cnt || 0}/${item.total_referenced || 0}` }),
      vocEvidence(item.evidence)));
  }
  return section;
}

function renderVocUseInsights(data) {
  const section = el("section", { class: "card voc-result-section use" },
    el("div", { class: "voc-section-heading" },
      el("div", {}, el("span", { class: "eyebrow", text: "BEHAVIOR SIGNALS" }), el("h3", { text: "使用洞察" })),
      el("span", { class: "layer-badge analysis", text: "use insights" })),
    el("div", { class: "voc-use-columns" }));
  const columns = section.querySelector(".voc-use-columns");
  const groups = [
    ["使用场景", data?.use_scenarios || [], "scenario", "frequency"],
    ["用户画像", data?.user_personas || [], "persona", "traits"],
    ["购买动机", data?.purchase_motivations || [], "motivation", "decision_factor_type"],
  ];
  for (const [title, items, mainKey, detailKey] of groups) {
    const column = el("div", { class: "voc-use-column" },
      el("div", { class: "voc-subheading" }, el("h4", { text: title }), el("span", { text: `${items.length} 项` })),
      el("div", { class: "voc-signal-list" }));
    const list = column.querySelector(".voc-signal-list");
    if (!items.length) list.appendChild(vocEmpty("信号不足"));
    for (const item of items) {
      list.appendChild(el("article", { class: "voc-signal-card compact" },
        el("div", { class: "voc-item-title" },
          el("b", { text: item[mainKey] || "—" }),
          el("span", { class: "voc-tag", text: item[detailKey] || "—" })),
        el("div", { class: "voc-item-meta", text: `${item.mentioned_by ?? 0} 人提及` }),
        vocEvidence(item.evidence)));
    }
    columns.appendChild(column);
  }
  return section;
}

function renderVocResult(record, box) {
  if (!box) return;
  const output = record?.output || {};
  const meta = output.meta || {};
  box.innerHTML = "";
  if (output.code !== "OK") {
    box.appendChild(el("div", { class: "card voc-failure" },
      el("div", { class: "voc-section-heading" },
        el("div", {}, el("span", { class: "eyebrow", text: "RUN FAILED" }), el("h3", { text: "VOC 运行未完成" })),
        pill("stale", output.code || record.code || "ERROR")),
      el("p", { class: "result-message", text: output.message || "能力返回失败" }),
      meta.hint ? el("p", { text: `建议：${meta.hint}` }) : null,
      (meta.missing || []).length ? el("p", { text: `缺失字段：${meta.missing.join(", ")}` }) : null,
      el("details", {}, el("summary", { text: "查看完整 Result" }), el("pre", { class: "json", text: JSON.stringify(output, null, 2) }))));
    return;
  }

  const data = normalizeVocData(record.capability, output.data);
  box.appendChild(el("div", { class: "card voc-result-header" },
    el("div", { class: "voc-result-title" },
      el("div", {}, el("span", { class: "eyebrow", text: "ANALYSIS COMPLETE" }), el("h3", { text: "VOC 洞察结果" })),
      pill("fresh", output.code)),
    el("div", { class: "meta-grid" },
      metaItem("ASIN", record.input?.asin || "—"),
      metaItem("运行能力", record.capability || "—"),
      metaItem("耗时", `${Math.round(record.wall_elapsed_ms || meta.elapsed_ms || 0)} ms`),
      metaItem("缓存命中", meta.from_cache ? "是" : "否"),
      metaItem("本次写回", (meta.enriched || []).join(", ") || "—"))));
  if (data.strengths) box.appendChild(renderVocStrengths(data.strengths));
  if (data.weaknesses) box.appendChild(renderVocWeaknesses(data.weaknesses));
  if (data.use_insights) box.appendChild(renderVocUseInsights(data.use_insights));
  if (!data.strengths && !data.weaknesses && !data.use_insights) {
    box.appendChild(el("div", { class: "card analysis-empty" },
      el("h3", { text: "结果为空" }),
      el("p", { class: "muted", text: "能力成功返回，但没有可展示的 VOC 分支。" })));
  }
  box.appendChild(el("details", { class: "card voc-raw" },
    el("summary", { text: "原始 Result 信封 / 调试信息" }),
    el("pre", { class: "json", text: JSON.stringify(output, null, 2) }),
    el("div", { class: "muted mono", text: `test_id: ${record.test_id || "—"}` })));
}

function renderAnalysisHistory() {
  const box = document.getElementById("analysis-history-list");
  if (!box) return;
  box.innerHTML = "";
  if (!currentAnalysisTests.length) {
    box.appendChild(el("p", { class: "muted", text: "还没有 VOC 运行记录。完成一次分析后，可在这里重新查看完整输入和输出。" }));
    return;
  }
  const table = el("table", {},
    el("thead", {}, el("tr", {},
      el("th", { text: "ASIN / Capability" }),
      el("th", { text: "结果" }),
      el("th", { text: "耗时" }),
      el("th", { text: "完成时间" }),
      el("th", { text: "操作" }))),
    el("tbody"));
  const body = table.querySelector("tbody");
  for (const record of currentAnalysisTests.slice(0, 20)) {
    body.appendChild(el("tr", {},
      el("td", {},
        el("b", { class: "mono", text: record.input?.asin || "—" }),
        el("div", { class: "muted mono", text: record.capability })),
      el("td", {}, pill(record.status === "passed" ? "fresh" : "stale", record.code || record.status)),
      el("td", { text: `${Math.round(record.elapsed_ms || 0)} ms` }),
      el("td", { text: fmtDate(record.finished_at || record.created_at) }),
      el("td", {}, el("button", { class: "btn ghost compact", text: "查看结果", onclick: () => openAnalysisHistory(record) }))));
  }
  box.appendChild(el("div", { class: "table-wrap" }, table));
}

async function openAnalysisHistory(summary) {
  try {
    const record = summary.output ? summary : await api(`/api/capability-tests/${encodeURIComponent(summary.test_id)}`);
    const input = document.getElementById("analysis-voc-asin");
    if (input && record.input?.asin) input.value = record.input.asin;
    renderVocResult(record, document.getElementById("analysis-voc-result"));
    document.getElementById("analysis-voc-result")?.scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (error) {
    alert("读取 VOC 记录失败: " + error.message);
  }
}

/* ---------------- 按类型组织的 Entity 数据 / 方法工作台 ---------------- */

async function viewEntity() {
  const [catalog, capabilities, chains] = await Promise.all([
    api("/api/entities?limit=500"),
    api("/api/capabilities"),
    api("/api/entity-chains"),
  ]);
  currentEntityCatalog = catalog;
  currentEntityCaps = capabilities.filter((cap) => cap.layer === "entity");
  currentEntityChains = chains;
  currentEntityDetail = null;
  app.innerHTML = "";
  app.appendChild(el("div", { class: "page-heading" },
    el("div", {},
      el("h2", { text: "Entity 类型工作台" }),
      el("p", { class: "muted", text: "先选择实体类型，再在同一个工作台中查看该类型的身份、实例、全部字段、TTL 状态和所有 public 方法。" })),
    el("button", { class: "btn ghost", text: "刷新数据", onclick: () => viewEntity() })));

  const s = catalog.summary || {};
  app.appendChild(el("div", { class: "meta-grid summary-strip" },
    metaItem("Entity 类型", s.registered_types || 0),
    metaItem("缓存实体", s.records || 0),
    metaItem("Fresh lazy 字段", s.fresh_fields || 0),
    metaItem("Stale lazy 字段", s.stale_fields || 0),
    metaItem("未填充 lazy 字段", s.missing_fields || 0),
    metaItem("可测试 Entity 方法", currentEntityCaps.length),
    metaItem("级联测试场景", currentEntityChains.length),
  ));

  const entityOrder = ["product", "keyword", "market", "review"];
  const orderedTypes = [...(catalog.types || [])].sort((a, b) => {
    const ai = entityOrder.indexOf(a.entity_type);
    const bi = entityOrder.indexOf(b.entity_type);
    return (ai < 0 ? entityOrder.length : ai) - (bi < 0 ? entityOrder.length : bi);
  });
  app.appendChild(el("div", { class: "entity-type-tabs", id: "entity-type-tabs" },
    ...orderedTypes.map((type) => {
      const methodCount = currentEntityCaps.filter((cap) => cap.id.startsWith(`entity.${type.entity_type}.`)).length;
      return el("button", {
        class: "entity-type-tab",
        "data-entity-type": type.entity_type,
        onclick: () => selectEntityType(type.entity_type),
      },
      el("div", { class: "entity-type-tab-title" },
        el("b", { text: type.model }),
        el("span", { class: "mono muted", text: type.entity_type })),
      el("div", { class: "entity-type-tab-metrics" },
        el("span", { text: `${type.record_count || 0} 个实例` }),
        el("span", { text: `${type.model_fields?.length || 0} 个字段` }),
        el("span", { text: `${methodCount} 个方法` })));
    })));
  app.appendChild(el("div", { id: "entity-type-workbench" }));

  const types = orderedTypes;
  const initialType = types.some((type) => type.entity_type === currentEntityType)
    ? currentEntityType
    : (types[0]?.entity_type || "");
  selectEntityType(initialType);
}

function entityIdentityDefaults(type) {
  const defaults = { marketplace: "US", category: "", mode: "mid", star_filter: "all", max_pages: 1 };
  return Object.fromEntries((type?.identity_fields || []).map((name) => [name, defaults[name] ?? ""]));
}

function selectEntityType(entityType) {
  const type = (currentEntityCatalog?.types || []).find((item) => item.entity_type === entityType);
  const workbench = document.getElementById("entity-type-workbench");
  if (!workbench) return;
  document.querySelectorAll(".entity-type-tab").forEach((node) =>
    node.classList.toggle("selected", node.dataset.entityType === entityType));
  workbench.innerHTML = "";
  if (!type) {
    workbench.appendChild(el("div", { class: "card empty-state" },
      el("b", { text: "当前没有已注册的 Entity 类型" })));
    return;
  }

  currentEntityType = entityType;
  currentEntityDetail = null;
  const records = (currentEntityCatalog?.records || []).filter((record) => record.entity_type === entityType);
  const initialRecord = records[0] || null;
  currentEntityRecordKey = initialRecord?.cache_key || "";
  currentEntityIdentity = { ...entityIdentityDefaults(type), ...(initialRecord?.identity || {}) };
  const methodCount = currentEntityCaps.filter((cap) => cap.id.startsWith(`entity.${entityType}.`)).length;

  workbench.appendChild(el("section", { class: "card entity-type-overview" },
    el("div", { class: "grow" },
      el("div", { class: "row entity-type-title" },
        el("h2", { text: type.model }),
        el("span", { class: "layer-badge entity", text: entityType })),
      el("p", { class: "muted", text: `这个工作台只处理 ${type.model}：身份字段、缓存实例、实体数据和可调用方法不会与其他 Entity 混在一起。` })),
    el("div", { class: "entity-type-stats" },
      metaItem("身份字段", type.identity_fields?.length || 0),
      metaItem("全部字段", type.model_fields?.length || 0),
      metaItem("Lazy 字段", type.lazy_fields?.length || 0),
      metaItem("Public 方法", methodCount))));

  workbench.appendChild(el("div", { class: "entity-workbench-grid" },
    el("aside", { class: "card entity-instance-panel" },
      el("h3", { text: "身份 / 实例" }),
      el("p", { class: "muted", text: "输入一个实体身份，可将它自动带入该类型的所有方法。也可以直接选择已有缓存实例。" }),
      el("div", { class: "entity-identity-form", id: "entity-identity-form" },
        ...(type.identity_fields || []).map((name) => el("label", { class: "entity-identity-field" },
          el("span", { text: name }),
          el("input", {
            "data-identity-field": name,
            type: name === "max_pages" ? "number" : "text",
            min: name === "max_pages" ? "1" : null,
            value: currentEntityIdentity[name] ?? "",
          })))),
      el("button", { class: "btn identity-use", text: "以此身份测试所有方法", onclick: () => useEntityIdentity(type) }),
      el("div", { class: "instance-list-heading" },
        el("b", { text: "缓存实例" }),
        el("span", { class: "muted", id: "entity-match-count" })),
      el("input", { id: "entity-search", placeholder: `搜索 ${type.model} 身份或 cache id…`, oninput: () => renderEntityRecords(type) }),
      el("div", { class: "record-list", id: "entity-records" })),
    el("div", { class: "entity-data-methods" },
      el("section", { class: "card entity-detail", id: "entity-detail" }),
      el("section", { class: "card entity-method-lab", id: "entity-method-lab" }))));

  renderEntityRecords(type);
  if (initialRecord) showEntityDetail(initialRecord);
  else {
    renderEntityDataPanel(type, null, currentEntityIdentity);
    renderEntityMethodLab(entityType, currentEntityIdentity, type.lazy_fields || []);
  }
}

function collectEntityIdentity(type) {
  const identity = {};
  for (const name of type.identity_fields || []) {
    const raw = document.querySelector(`[data-identity-field="${name}"]`)?.value ?? "";
    identity[name] = name === "max_pages" && raw !== "" ? Number(raw) : raw;
  }
  return identity;
}

function useEntityIdentity(type) {
  currentEntityIdentity = collectEntityIdentity(type);
  currentEntityDetail = null;
  currentEntityRecordKey = "";
  document.querySelectorAll(".record-card").forEach((node) => node.classList.remove("selected"));
  renderEntityDataPanel(type, null, currentEntityIdentity);
  renderEntityMethodLab(type.entity_type, currentEntityIdentity, type.lazy_fields || []);
  document.getElementById("entity-detail")?.scrollIntoView({ behavior: "smooth", block: "start" });
}

function renderEntityRecords(type) {
  const q = (document.getElementById("entity-search")?.value || "").trim().toLowerCase();
  const rows = (currentEntityCatalog?.records || []).filter((record) => {
    if (record.entity_type !== type.entity_type) return false;
    const haystack = `${record.entity_type} ${record.cache_id} ${record.cache_key} ${record.identity_label} ${JSON.stringify(record.identity)}`.toLowerCase();
    return !q || haystack.includes(q);
  });
  const counter = document.getElementById("entity-match-count");
  if (counter) counter.textContent = `${rows.length} 条缓存记录`;
  const box = document.getElementById("entity-records");
  if (!box) return;
  box.innerHTML = "";
  if (!rows.length) {
    box.appendChild(el("div", { class: "empty-state" },
      el("b", { text: `没有匹配的 ${type.model} 缓存` }),
      el("p", { class: "muted", text: "仍可使用上方身份输入，直接测试这个 Entity 类型的所有方法。" })));
    return;
  }
  for (const record of rows) {
    const lc = record.lazy_counts || {};
    box.appendChild(el("button", {
      class: "record-card",
      "data-cache-key": record.cache_key,
      onclick: () => showEntityDetail(record),
    },
    el("div", { class: "record-title" },
      el("b", { text: record.identity_label || record.cache_id }),
      pill(record.status, record.status)),
    el("div", { class: "muted mono", text: record.cache_id || record.cache_key }),
    el("div", { class: "record-metrics" },
      el("span", { text: `字段 ${record.field_counts?.populated || 0}/${record.field_counts?.total || 0}` }),
      el("span", { class: "fresh-text", text: `fresh ${lc.fresh || 0}` }),
      el("span", { class: "stale-text", text: `stale ${lc.stale || 0}` }),
      el("span", { class: "muted", text: `missing ${lc.missing || 0}` })),
    el("div", { class: "muted record-time", text: fmtDate(record.saved_at) })));
  }
}

async function showEntityDetail(record) {
  if (record.entity_type !== currentEntityType) selectEntityType(record.entity_type);
  currentEntityRecordKey = record.cache_key;
  document.querySelectorAll(".record-card").forEach((node) =>
    node.classList.toggle("selected", node.dataset.cacheKey === record.cache_key));
  const box = document.getElementById("entity-detail");
  if (!box) return;
  box.innerHTML = '<p class="muted">读取 Entity 缓存…</p>';
  try {
    const detail = await api(`/api/entities/${encodeURIComponent(record.entity_type)}/${encodeURIComponent(record.cache_key)}`);
    if (currentEntityType !== record.entity_type || currentEntityRecordKey !== record.cache_key) return;
    currentEntityDetail = detail;
    currentEntityIdentity = detail.identity || {};
    for (const [name, value] of Object.entries(currentEntityIdentity)) {
      const input = document.querySelector(`[data-identity-field="${name}"]`);
      if (input) input.value = value ?? "";
    }
    const type = (currentEntityCatalog?.types || []).find((item) => item.entity_type === detail.entity_type);
    renderEntityDataPanel(type, detail, detail.identity || {});
    renderEntityMethodLab(detail.entity_type, detail.identity || {}, detail.lazy_fields || []);
  } catch (e) {
    box.innerHTML = "";
    box.appendChild(el("p", { class: "muted", text: "读取失败: " + e.message }));
  }
}

function hasEntityValue(value) {
  if (value === null || value === undefined || value === "") return false;
  if (Array.isArray(value)) return value.length > 0;
  if (typeof value === "object") return Object.keys(value).length > 0;
  return true;
}

function schemaTypeLabel(schema = {}) {
  if (schema.type) return Array.isArray(schema.type) ? schema.type.join(" | ") : schema.type;
  if (schema.$ref) return schema.$ref.split("/").pop();
  if (schema.anyOf) return schema.anyOf.map((item) => schemaTypeLabel(item)).filter(Boolean).join(" | ");
  return "—";
}

function renderEntityFieldTable(type, detail, identity) {
  const values = { ...(identity || {}), ...(detail?.fields || {}) };
  const lazyByField = new Map((detail?.lazy_fields || type?.lazy_fields || []).map((field) => [field.field, field]));
  const properties = detail?.model_schema?.properties || {};
  const table = el("table", { class: "entity-field-table" },
    el("thead", {}, el("tr", {},
      el("th", { text: "字段" }),
      el("th", { text: "类型" }),
      el("th", { text: "数据状态" }),
      el("th", { text: "当前值" }))),
    el("tbody"));
  const body = table.querySelector("tbody");
  for (const field of type?.model_fields || []) {
    const value = values[field];
    const lazy = lazyByField.get(field);
    const status = lazy?.status || (hasEntityValue(value) ? "core" : "empty");
    const serialized = hasEntityValue(value)
      ? (typeof value === "string" ? value : JSON.stringify(value, null, 2))
      : "—";
    body.appendChild(el("tr", {},
      el("td", {},
        el("b", { class: "mono", text: field }),
        (type.identity_fields || []).includes(field) ? el("div", { class: "identity-label", text: "IDENTITY" }) : null),
      el("td", { class: "muted", text: schemaTypeLabel(properties[field]) }),
      el("td", {}, pill(status, status)),
      el("td", {}, el("pre", { class: "field-value", text: serialized }))));
  }
  return el("div", { class: "table-wrap" }, table);
}

function renderEntityDataPanel(type, detail, identity = {}) {
  const box = document.getElementById("entity-detail");
  if (!box || !type) return;
  box.innerHTML = "";
  box.appendChild(el("div", { class: "entity-detail-head" },
    el("div", { class: "grow" },
      el("div", { class: "row", style: "align-items:center;" },
        el("h2", { text: detail?.identity_label || `${type.model} 数据` }),
        detail ? pill(detail.status, detail.status) : pill("empty", "未载入缓存")),
      el("div", { class: "muted mono", text: detail ? `${detail.entity_type} · ${detail.cache_id}` : JSON.stringify(identity) })),
    el("button", { class: "btn", text: "测试该类型方法", onclick: () => focusEntityMethodLab(type.entity_type, identity) })));

  box.appendChild(el("div", { class: "meta-grid detail-meta" },
    metaItem("实体类型", type.model),
    metaItem("保存时间", detail ? fmtDate(detail.saved_at) : "—"),
    metaItem("缓存大小", detail ? fmtBytes(detail.size_bytes) : "—"),
    metaItem("已填字段", detail ? `${detail.field_counts?.populated || 0}/${detail.field_counts?.total || 0}` : `0/${type.model_fields?.length || 0}`)));

  if (type.entity_type === "product") {
    box.appendChild(renderProductVocPanel(detail, identity));
  }
  if (["product", "keyword"].includes(type.entity_type)) {
    box.appendChild(renderParentMarketPanel(type.entity_type, detail, identity));
  }

  box.appendChild(el("div", { class: "section-heading" },
    el("h3", { text: "全部字段数据" }),
    el("span", { class: "muted", text: `${type.model_fields?.length || 0} 个模型字段；身份、core 与 lazy 数据统一查看` })));
  box.appendChild(renderEntityFieldTable(type, detail, identity));
  box.appendChild(el("div", { class: "section-heading" },
    el("h3", { text: "Lazy 字段 / 原子能力状态" }),
    el("span", { class: "muted", text: "每个 lazy 字段都对应一个可单独调用、可单独测试的 entity.* 方法" })));
  box.appendChild(renderLazyTable(detail?.lazy_fields || type.lazy_fields || [], detail || { identity }));

  box.appendChild(el("div", { class: "raw-data-grid" },
    el("details", { open: Boolean(detail) },
      el("summary", { text: "Entity fields（底层实体字段）" }),
      el("pre", { class: "json", text: JSON.stringify(detail?.fields || identity, null, 2) })),
    el("details", {},
      el("summary", { text: "result_data（能力原始 Result.data）" }),
      el("pre", { class: "json", text: JSON.stringify(detail?.result_data || {}, null, 2) })),
    el("details", {},
      el("summary", { text: "TTL / fetch key 元数据" }),
      el("pre", { class: "json", text: JSON.stringify({ fetched_at: detail?.fetched_at || {}, fetch_keys: detail?.fetch_keys || {} }, null, 2) })),
    detail ? el("details", {},
      el("summary", { text: "Pydantic model schema" }),
      el("pre", { class: "json", text: JSON.stringify(detail.model_schema, null, 2) })) : null));
}

function renderProductVocPanel(detail, identity = {}) {
  const fields = detail?.fields || {};
  const asin = identity.asin || fields.asin || "";
  const branchState = [
    ["strengths", "创新优势"],
    ["weaknesses", "差评痛点"],
    ["use_insights", "使用洞察"],
  ];
  const complete = branchState.filter(([field]) => hasEntityValue(fields[field]) || hasEntityValue(fields.voc?.[field])).length;
  const satisfaction = fields.voc?.weaknesses?.satisfaction_context || fields.weaknesses?.satisfaction_context || {};
  return el("section", { class: "product-voc-panel" },
    el("div", { class: "product-voc-panel-head" },
      el("div", { class: "grow" },
        el("div", { class: "row product-voc-title" },
          el("h3", { text: "Product VOC 洞察" }),
          el("span", { class: "layer-badge analysis", text: "accepted analysis" })),
        el("p", { class: "muted", text: "从当前 Product 直接运行三路已验收 VOC；完整结果会类型化写回 Product.voc。" })),
      el("button", {
        class: "btn voc-open-button",
        text: complete ? "查看 / 重新运行" : "打开 Analysis 工作台",
        onclick: () => {
          if (asin) localStorage.setItem("amz_voc_asin", asin);
          location.hash = "#analysis";
        },
      })),
    el("div", { class: "product-voc-status" },
      ...branchState.map(([field, label]) => el("div", {},
        pill(hasEntityValue(fields[field]) || hasEntityValue(fields.voc?.[field]) ? "fresh" : "missing", label),
        el("span", { text: hasEntityValue(fields[field]) || hasEntityValue(fields.voc?.[field]) ? "已生成" : "待运行" }))),
      el("div", {},
        el("b", { text: satisfaction.rating_label || "满意度待计算" }),
        el("span", { text: satisfaction.total_reviews ? `${satisfaction.total_reviews} 条全量评论` : `${complete}/3 路完成` }))));
}

function renderParentMarketPanel(entityType, detail, identity = {}) {
  const marketValue = detail?.fields?.market;
  const marketTerm = marketValue?.term || marketValue?.keyword || "尚未获取";
  const parentLabel = entityType === "keyword" ? "Keyword" : "Product";
  const ids = [
    [`${entityType}-market-object`, "Market 对象", "获取关联 Market"],
    [`${entityType}-market-stats`, "Market Stats", "市场统计"],
    [`${entityType}-market-profile`, "Market Profile", "八维画像"],
    [`${entityType}-market-opportunity`, "Market Opportunity", "机会与缺口"],
    [`${entityType}-market-full`, "全部 Market 数据", "完整级联"],
  ];
  const panel = el("section", { class: "product-market-panel" },
    el("div", { class: "product-market-panel-head" },
      el("div", { class: "grow" },
        el("div", { class: "row product-market-title" },
          el("h3", { text: `${parentLabel} 的 Market 关联能力` }),
          el("span", { class: "layer-badge entity", text: `${parentLabel} → Market` })),
        el("p", { class: "muted", text: `直接从当前 ${parentLabel} 测试 Market 对象及其 Stats、Profile、Opportunity，不需要先切换到 Market 类型。` })),
      el("div", { class: "market-current" },
        el("span", { class: "muted", text: "当前 Market" }),
        el("b", { class: "mono", text: marketTerm }))),
    el("div", { class: "product-market-actions" }));
  const actions = panel.querySelector(".product-market-actions");
  for (const [chainId, title, subtitle] of ids) {
    const chain = currentEntityChains.find((item) => item.id === chainId);
    actions.appendChild(el("button", {
      class: "product-market-action",
      disabled: chain ? null : "disabled",
      onclick: () => {
        if (!chain) return;
        openEntityChainTest(chain, identity);
        document.getElementById("entity-chain-runner")?.scrollIntoView({ behavior: "smooth", block: "start" });
      },
    },
    el("b", { text: title }),
    el("span", { text: subtitle }),
    el("code", { text: chain ? `${chain.steps.length} step${chain.steps.length > 1 ? "s" : ""}` : "不可用" })));
  }
  return panel;
}

function renderLazyTable(fields, detail) {
  const table = el("table", { class: "lazy-table" },
    el("thead", {}, el("tr", {},
      el("th", { text: "字段 / 能力" }),
      el("th", { text: "状态" }),
      el("th", { text: "来源与依赖" }),
      el("th", { text: "TTL / 获取时间" }),
      el("th", { text: "操作" }))),
    el("tbody"));
  const body = table.querySelector("tbody");
  for (const field of fields) {
    const status = field.status || "missing";
    body.appendChild(el("tr", {},
      el("td", {}, el("b", { text: field.field }), el("div", { class: "muted mono", text: field.capability })),
      el("td", {}, pill(status, status)),
      el("td", {},
        el("div", { text: field.source || "—" }),
        el("div", { class: "muted", text: (field.depends || []).length ? `硬依赖: ${field.depends.join(", ")}` : "无硬依赖" }),
        (field.optional_depends || []).length
          ? el("div", { class: "optional-deps", text: `可选依赖: ${field.optional_depends.join(", ")}` }) : null,
        (field.invalidates_on || []).length
          ? el("div", { class: "observer-deps", text: `缓存观察: ${field.invalidates_on.join(", ")}` }) : null),
      el("td", {},
        el("div", { text: `${field.ttl_hours}h · v${field.version || "1"}` }),
        el("div", { class: "muted", text: field.fetched_at ? fmtDate(field.fetched_at) : "尚未获取" })),
      el("td", {}, el("button", { class: "btn ghost compact", text: "测试", onclick: () => openEntityMethodTest(field.capability, detail.identity || {}) }))));
  }
  if (!fields.length) {
    body.appendChild(el("tr", {}, el("td", { colspan: "5", class: "muted", text: "该 Entity 没有 lazy 字段" })));
  }
  return el("div", { class: "table-wrap" }, table);
}

function entityMethodKind(lazyField) {
  const source = String(lazyField?.source || "").toLowerCase();
  if (["voc", "strengths", "weaknesses", "use_insights"].includes(lazyField?.field)) return "analysis";
  if (source.includes("analysis.")) return "analysis";
  if (source.startsWith("/") || source === "aba_file") return "fetch";
  return "compute";
}

function entityMethodKindLabel(kind) {
  return { fetch: "取数方法", compute: "计算 / 聚合方法", analysis: "分析方法" }[kind] || kind;
}

function renderEntityMethodLab(entityType, identity = {}, lazyFields = []) {
  const box = document.getElementById("entity-method-lab");
  if (!box) return;
  const type = (currentEntityCatalog?.types || []).find((item) => item.entity_type === entityType);
  const caps = currentEntityCaps
    .filter((cap) => cap.id.startsWith(`entity.${entityType}.`))
    .sort((a, b) => a.id.localeCompare(b.id));
  const lazyByCapability = new Map((lazyFields.length ? lazyFields : type?.lazy_fields || [])
    .map((field) => [field.capability, field]));
  const groups = { fetch: [], compute: [], analysis: [] };
  for (const cap of caps) {
    const lazy = lazyByCapability.get(cap.id) || {};
    groups[entityMethodKind(lazy)].push({ cap, lazy });
  }

  box.innerHTML = "";
  box.appendChild(el("div", { class: "entity-method-heading" },
    el("div", { class: "grow" },
      el("h2", { text: `${type?.model || entityType || "Entity"} 方法测试` }),
      el("p", { class: "muted", text: `${caps.length} 个 public Entity 方法；每次调用都走实体 lazy、依赖级联、TTL 与统一 Result 契约。` })),
    el("div", { class: "identity-summary" },
      ...Object.entries(identity || {}).map(([key, value]) =>
        el("span", { class: "identity-chip", text: `${key}: ${value ?? ""}` })))));

  renderEntityChainCatalog(box, entityType, identity);

  if (!caps.length) {
    box.appendChild(el("p", { class: "muted", text: "该 Entity 当前没有注册为 public capability 的方法。" }));
    return;
  }

  const catalog = el("div", { class: "entity-method-groups" });
  for (const kind of ["fetch", "compute", "analysis"]) {
    const items = groups[kind];
    if (!items.length) continue;
    const section = el("section", { class: `method-group ${kind}` },
      el("div", { class: "method-group-title" },
        el("h3", { text: entityMethodKindLabel(kind) }),
        el("span", { class: "muted", text: `${items.length} 个` })),
      el("div", { class: "method-card-list" }));
    const list = section.querySelector(".method-card-list");
    for (const { cap, lazy } of items) {
      const deps = [...(cap.requires || []), ...(cap.requires_fields || []).map((name) => `field:${name}`)];
      const optional = (lazy.optional_depends || []).map((name) => `optional:${name}`);
      list.appendChild(el("button", {
        class: "entity-method-card",
        "data-method-id": cap.id,
        onclick: () => openEntityMethodTest(cap, identity),
      },
      el("div", { class: "method-card-top" },
        el("b", { text: cap.id.split(".").slice(2).join(".") }),
        pill(lazy.status || "missing", lazy.status || "可测试")),
      el("div", { class: "muted method-source", text: lazy.source || cap.description || "—" }),
      el("div", { class: "method-deps", text: [...deps, ...optional].length ? `依赖 ${[...deps, ...optional].join(" → ")}` : "无前置依赖" })));
    }
    catalog.appendChild(section);
  }
  box.appendChild(catalog);
  box.appendChild(el("div", { class: "entity-method-runner", id: "entity-method-runner" }));
  const firstVisible = groups.fetch[0]?.cap || groups.compute[0]?.cap || groups.analysis[0]?.cap || caps[0];
  openEntityMethodTest(firstVisible, identity, false);
}

function renderEntityChainCatalog(box, entityType, identity = {}) {
  const chains = currentEntityChains.filter((chain) => chain.entity_type === entityType);
  if (!chains.length) return;
  const section = el("section", { class: "entity-chain-lab" },
    el("div", { class: "section-heading chain-heading" },
      el("div", {},
        el("h3", { text: "级联能力测试" }),
        el("p", { class: "muted", text: "一次运行跨 Entity 的完整路径，并逐步查看依赖补齐、缓存与 Result。" })),
      el("span", { class: "layer-badge entity", text: `${chains.length} scenarios` })),
    el("div", { class: "entity-chain-cards" }),
    el("div", { class: "entity-chain-runner", id: "entity-chain-runner" }));
  const cards = section.querySelector(".entity-chain-cards");
  for (const chain of chains) {
    cards.appendChild(el("button", {
      class: "entity-chain-card",
      "data-chain-id": chain.id,
      onclick: () => openEntityChainTest(chain, identity),
    },
    el("div", { class: "chain-card-head" },
      el("b", { text: chain.name }),
      el("span", { text: `${chain.steps?.length || 0} 步` })),
    el("p", { class: "muted", text: chain.description || "" }),
    el("div", { class: "chain-path" },
      ...(chain.steps || []).map((step, index) => el("span", {
        text: `${index ? "→ " : ""}${step.capability.split(".").slice(1).join(".")}`,
      })))));
  }
  box.appendChild(section);
}

function openEntityChainTest(chain, identity = {}) {
  const runner = document.getElementById("entity-chain-runner");
  if (!runner) return;
  document.querySelectorAll(".entity-chain-card").forEach((node) =>
    node.classList.toggle("selected", node.dataset.chainId === chain.id));
  runner.innerHTML = "";
  runner.appendChild(el("div", { class: "method-runner-head" },
    el("div", { class: "grow" },
      el("h3", { text: chain.name }),
      el("p", { class: "muted", text: chain.description || "" })),
    el("span", { class: "layer-badge entity", text: "cascade" })));
  runner.appendChild(el("ol", { class: "chain-step-preview" },
    ...(chain.steps || []).map((step) => el("li", {},
      el("b", { text: step.label }),
      el("code", { text: step.capability }),
      (step.requires || []).length
        ? el("span", { class: "muted", text: `自动依赖 ${step.requires.join(" → ")}` }) : null))));
  runner.appendChild(el("h4", { text: "级联输入" }));
  runner.appendChild(el("div", { id: "entity-chain-form" }));
  runner.appendChild(el("div", { class: "row method-actions" },
    el("button", { class: "btn", text: "运行完整级联", onclick: () => invokeEntityChain(chain) }),
    el("button", { class: "btn ghost", id: "entity-chain-reset", text: "重置参数", onclick: () => renderParamForm(chain, {
      wrapId: "entity-chain-form", jsonId: "entity-chain-input", resetId: "entity-chain-reset", seed: identity,
    }) }),
    el("span", { class: "muted", text: "force_refresh=true 会逐步跳过 lazy TTL" })));
  runner.appendChild(el("textarea", { id: "entity-chain-input", class: "test-input-json", spellcheck: "false" }));
  runner.appendChild(el("div", { id: "entity-chain-result" }));
  renderParamForm(chain, {
    wrapId: "entity-chain-form",
    jsonId: "entity-chain-input",
    resetId: "entity-chain-reset",
    seed: identity,
  });
  runner.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

async function invokeEntityChain(chain) {
  const input = document.getElementById("entity-chain-input");
  const box = document.getElementById("entity-chain-result");
  let params = {};
  try { params = JSON.parse(input?.value || "{}"); }
  catch (e) {
    box?.replaceChildren(el("p", { class: "result-message", text: "Input 不是合法 JSON: " + e.message }));
    return;
  }
  if (!box) return;
  box.innerHTML = '<p class="muted">级联运行中…会按顺序拉取依赖并保留每一步完整结果。</p>';
  try {
    const result = await api(`/api/entity-chains/${encodeURIComponent(chain.id)}/run`, { method: "POST", body: params });
    renderEntityChainResult(result, box);
  } catch (e) {
    box.replaceChildren(el("p", { class: "result-message", text: "级联运行失败: " + e.message }));
  }
}

function renderEntityChainResult(result, box) {
  box.innerHTML = "";
  box.appendChild(el("div", { class: "chain-result-head" },
    el("div", { class: "grow" },
      el("h3", { text: "级联测试结果" }),
      el("div", { class: "muted mono", text: `run_id: ${result.run_id || "未持久化"}` })),
    pill(result.success ? "fresh" : "stale", result.status)));
  box.appendChild(el("div", { class: "meta-grid detail-meta" },
    metaItem("完成步骤", `${result.completed_steps}/${result.total_steps}`),
    metaItem("总耗时", `${Math.round(result.elapsed_ms || 0)} ms`),
    metaItem("测试记录", result.persisted ? "已保存" : "未保存"),
    metaItem("Market 身份", result.resolved_identities?.market?.term || "—")));

  const timeline = el("div", { class: "chain-result-steps" });
  for (const step of result.steps || []) {
    const output = step.output || {};
    const meta = output.meta || {};
    timeline.appendChild(el("article", { class: `chain-result-step ${step.status}` },
      el("div", { class: "chain-step-marker", text: String(step.index) }),
      el("div", { class: "chain-step-content" },
        el("div", { class: "chain-step-title" },
          el("div", {}, el("b", { text: step.label }), el("code", { text: step.capability })),
          pill(step.status === "passed" ? "fresh" : "stale", output.code || step.status)),
        output.message ? el("div", { class: "result-message", text: output.message }) : null,
        el("div", { class: "chain-step-meta" },
          el("span", { text: `${Math.round(step.elapsed_ms || 0)} ms` }),
          el("span", { text: `缓存: ${meta.from_cache ? "命中" : "未命中"}` }),
          el("span", { text: `enriched: ${(meta.enriched || []).join(", ") || "—"}` }),
          el("span", { text: `upstream: ${meta.upstream || "—"}` })),
        el("div", { class: "chain-step-io" },
          el("details", {}, el("summary", { text: "Input" }), el("pre", { class: "json", text: JSON.stringify(step.input || {}, null, 2) })),
          el("details", { open: step.status !== "passed" }, el("summary", { text: "完整 Result" }), el("pre", { class: "json", text: JSON.stringify(output, null, 2) }))))));
  }
  box.appendChild(timeline);
  box.appendChild(el("div", { class: "row", style: "margin-top:12px;" },
    el("button", { class: "btn ghost", text: "刷新 Entity 字段与 TTL", onclick: () => viewEntity() })));
}

function focusEntityMethodLab(entityType, identity) {
  renderEntityMethodLab(entityType, identity || {}, currentEntityDetail?.lazy_fields || []);
  document.getElementById("entity-method-lab")?.scrollIntoView({ behavior: "smooth", block: "start" });
}

function openEntityMethodTest(capOrId, identity = {}, shouldScroll = true) {
  const cap = typeof capOrId === "string"
    ? currentEntityCaps.find((item) => item.id === capOrId)
    : capOrId;
  const runner = document.getElementById("entity-method-runner");
  if (!runner || !cap) return;
  document.querySelectorAll(".entity-method-card").forEach((node) =>
    node.classList.toggle("selected", node.dataset.methodId === cap.id));

  const required = cap.input_schema?.required || [];
  runner.innerHTML = "";
  runner.appendChild(el("div", { class: "method-runner-head" },
    el("div", { class: "grow" },
      el("div", { class: "row", style: "align-items:center;" },
        el("h3", { text: cap.id }),
        el("span", { class: "layer-badge entity", text: "entity" })),
      el("p", { class: "muted", text: cap.description || "" })),
    el("button", { class: "btn ghost compact", text: "回到方法列表", onclick: () => document.querySelector(`[data-method-id="${cap.id}"]`)?.scrollIntoView({ behavior: "smooth", block: "center" }) })));

  const dependencies = [...(cap.requires || []), ...(cap.requires_fields || []).map((name) => `entity field: ${name}`)];
  runner.appendChild(el("div", { class: "method-contract-summary" },
    el("div", {}, el("b", { text: "必填参数" }), el("span", { text: required.length ? required.join(", ") : "无" })),
    el("div", {}, el("b", { text: "自动依赖" }), el("span", { text: dependencies.length ? dependencies.join(" → ") : "无" }))));

  runner.appendChild(el("div", { class: "contract-grid" },
    el("details", {},
      el("summary", { text: "Input schema" }),
      el("pre", { class: "json", text: JSON.stringify(cap.input_schema, null, 2) })),
    el("details", {},
      el("summary", { text: "Output schema" }),
      el("pre", { class: "json", text: JSON.stringify(cap.output_schema, null, 2) }))));
  runner.appendChild(el("h3", { text: "方法输入" }));
  runner.appendChild(el("div", { id: "entity-method-form" }));
  runner.appendChild(el("div", { class: "row method-actions" },
    el("button", { class: "btn", text: "运行该 Entity 方法", onclick: () => invokeEntityMethod(cap) }),
    el("button", { class: "btn ghost", id: "entity-method-reset", text: "重置参数", onclick: () => renderParamForm(cap, {
      wrapId: "entity-method-form", jsonId: "entity-method-input", resetId: "entity-method-reset", seed: identity,
    }) }),
    el("span", { class: "muted", text: "force_refresh=true 可跳过当前 lazy TTL" })));
  runner.appendChild(el("textarea", { id: "entity-method-input", class: "test-input-json", spellcheck: "false" }));
  runner.appendChild(el("div", { id: "entity-method-result" }));
  renderParamForm(cap, {
    wrapId: "entity-method-form",
    jsonId: "entity-method-input",
    resetId: "entity-method-reset",
    seed: identity,
  });
  if (shouldScroll) runner.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

async function invokeEntityMethod(cap) {
  const input = document.getElementById("entity-method-input");
  const box = document.getElementById("entity-method-result");
  let params = {};
  try { params = JSON.parse(input?.value || "{}"); }
  catch (e) {
    if (box) box.replaceChildren(el("p", { class: "result-message", text: "Input 不是合法 JSON: " + e.message }));
    return;
  }
  if (!box) return;
  box.innerHTML = '<p class="muted">Entity 方法运行中…取数方法首次可能需要 10–30 秒，分析方法还会调用 LLM。</p>';
  try {
    const record = await api(`/api/capability-tests/${encodeURIComponent(cap.id)}`, { method: "POST", body: params });
    renderCapabilityTestResult(record, box);
    box.appendChild(el("div", { class: "row", style: "margin-top:10px;" },
      el("button", { class: "btn ghost", text: "刷新 Entity 缓存状态", onclick: () => viewEntity() })));
  } catch (e) {
    box.innerHTML = "";
    box.appendChild(el("p", { class: "result-message", text: "运行失败: " + e.message }));
  }
}

/* ---------------- 原子能力浏览 + 调用 ---------------- */

async function viewCapabilities() {
  const [caps, tests] = await Promise.all([
    api("/api/capabilities"),
    api("/api/capability-tests?limit=30"),
  ]);
  currentCaps = caps;
  currentCapabilityTests = tests;
  const atomic = caps.filter((c) => c.atomic !== false);
  const layerCounts = atomic.reduce((acc, cap) => {
    acc[cap.layer] = (acc[cap.layer] || 0) + 1;
    return acc;
  }, {});
  app.innerHTML = "";
  app.appendChild(el("h2", { text: "原子能力测试" }));
  app.appendChild(el("p", { class: "muted", text: `${atomic.length} 个原子能力全部由运行时 Registry 动态同步；选择能力后按 input_schema 生成输入，测试结果完整保留 input 与 Result output。` }));
  app.appendChild(el("div", { class: "meta-grid summary-strip" },
    metaItem("全部原子能力", atomic.length),
    metaItem("Entity", layerCounts.entity || 0),
    metaItem("Calc", layerCounts.calc || 0),
    metaItem("Analysis", layerCounts.analysis || 0),
    metaItem("Data", layerCounts.data || 0)));

  const toolbar = el("div", { class: "row", style: "margin-bottom:12px; align-items:center;" },
    el("input", { id: "cap-search2", placeholder: "搜索能力 id / 描述…", style: "max-width:340px;", oninput: () => renderCapList(caps) }),
    el("div", { class: "chips", id: "cap-chips" }),
  );
  const chips = toolbar.querySelector("#cap-chips");
  for (const [m, label] of [["", "全部原子"], ["entity", "Entity"], ["calc", "Calc"], ["analysis", "Analysis"], ["data", "Data"], ["composite", "Composite（非原子）"]]) {
    chips.appendChild(el("button", { class: "chip" + (m === currentModule ? " active" : ""), "data-module": m, text: label,
      onclick: () => {
        currentModule = m;
        chips.querySelectorAll(".chip").forEach((b) => b.classList.toggle("active", b.dataset.module === m));
        renderCapList(caps);
      } }));
  }
  app.appendChild(toolbar);

  const grid = el("div", { class: "builder" });
  grid.appendChild(el("div", { class: "card", id: "cap-list2", style: "max-height:640px; overflow:auto;" }));
  grid.appendChild(el("div", { id: "cap-detail" }));
  app.appendChild(grid);
  app.appendChild(el("div", { class: "card", style: "margin-top:16px;" },
    el("div", { class: "row", style: "align-items:center;" },
      el("h3", { class: "grow", text: "最近的原子能力测试" }),
      el("span", { class: "muted", text: "测试记录保存在 Runtime 工作区" })),
    el("div", { id: "cap-test-history" })));

  const target = sessionStorage.getItem("amz_cap_target") || "";
  const seedRaw = sessionStorage.getItem("amz_cap_seed") || "";
  sessionStorage.removeItem("amz_cap_target");
  sessionStorage.removeItem("amz_cap_seed");
  let seed = null;
  try { seed = seedRaw ? JSON.parse(seedRaw) : null; } catch (e) { seed = null; }
  if (target) document.getElementById("cap-search2").value = target;
  renderCapList(caps);
  renderCapabilityTestHistory();
  const exact = caps.find((cap) => cap.id === target);
  if (exact) showCapDetail(exact, seed);
}

function renderCapList(caps) {
  const q = (document.getElementById("cap-search2")?.value || "").toLowerCase();
  const list = document.getElementById("cap-list2");
  if (!list) return;
  list.innerHTML = "";
  const rows = caps.filter((c) =>
    (currentModule ? c.layer === currentModule : c.atomic !== false) &&
    (!q || c.id.toLowerCase().includes(q) || (c.description || "").toLowerCase().includes(q)));
  for (const c of rows.slice(0, 300)) {
    list.appendChild(el("button", { class: "cap-row" + (c.id === selectedCapabilityId ? " selected" : ""), "data-cap-id": c.id, onclick: () => showCapDetail(c) },
      el("div", { class: "row", style: "align-items:center;" }, el("b", { text: c.id }), el("span", { class: `layer-badge ${c.layer}`, text: c.layer || c.category || "other" })),
      el("div", { class: "muted", style: "font-size:12px;", text: (c.description || "").slice(0, 90) }),
    ));
  }
  if (!rows.length) list.appendChild(el("p", { class: "muted", text: "无匹配能力" }));
}

/* ---- schema 驱动参数表单（calc/analysis 免手写嵌套 JSON） ---- */

// 共用输入模型的示例数据：命中 $ref 的字段自动预填，可直接改值调用
const SAMPLE_INPUTS = {
  ProductVocListing: {
    asin: "B0D1XAMPLE00",
    title: "Portable Blender USB Rechargeable 6 Blades 400ml",
    bullet_points: ["6-blade stainless steel", "USB-C rechargeable", "400ml leak-proof cup"],
    details: "容量:400ml | 功率:120W | 电池:2000mAh",
    description: "Portable blender for smoothies, juice and protein shakes.",
    brand: "NutriGo",
    product_rating: 4.6,
    count_ratings: 1250,
  },
  ProductVocReview: {
    review_id: "R-VOC-001",
    rating: 5,
    title: "Great for office use",
    text: "Blends frozen fruit smoothly, is easy to clean, and the battery lasts all week.",
    date: "2026-06-01",
    country: "US",
    verified: true,
    user_name: "Customer A",
    images: [],
  },
  VocSatisfactionMetrics: {
    positive_pct: 91,
    negative_pct: 4,
    total_reviews: 1250,
    product_rating: 4.6,
    rating_label: "高满意度",
  },
  ReviewSummary: {
    fiveStar: { percentage: 76 },
    fourStar: { percentage: 15 },
    threeStar: { percentage: 5 },
    twoStar: { percentage: 2 },
    oneStar: { percentage: 2 },
    countRatings: 1250,
  },
  ProductInfoInput: {
    asin: "B0D1XAMPLE00",
    title: "Portable Blender USB Rechargeable 6 Blades 400ml",
    brand: "NutriGo",
    bullet_points: ["6-blade 304 stainless steel, 15s smoothie", "USB-C rechargeable, 10+ blends per charge", "400ml BPA-free cup, leak-proof lid", "IPX5 waterproof, easy to clean"],
    description: "Portable blender for smoothies, juice and protein shakes. 380g, fits in a backpack. Quiet motor with safety lock.",
    full_description: "NutriGo portable blender crushes ice and frozen fruit in 15 seconds. USB-C charging, 10 blends per charge, 400ml BPA-free cup.",
    details: "容量:400ml | 功率:120W | 电池:2000mAh | 材质:ABS+304不锈钢",
    product_information: { "Capacity": "400ml", "Power": "120W", "Battery": "2000mAh" },
    image_url: "https://example.com/pb01.jpg",
    main_image_url: "https://example.com/pb01-main.jpg",
  },
  ReviewItemInput: {
    rating: 5, title: "Great for office use",
    text: "Blends frozen fruit smoothly, easy to clean, battery lasts a week of daily use.",
    date: "2024-06-01", country: "US", verified: true, user_name: "Customer A",
  },
  KeywordItemInput: {
    term: "portable blender", keyword: "portable blender",
    search_volume: 124000, ppc: 0.86, click_rate: 0.42, conversion_rate: 0.12,
    traffic_pct: 0.55, grade: "A", source: "miner",
  },
  GoogleTrendsInput: {
    target_avg: 68, baseline_avg: 45, compare_index: 1.51, cagr_3y: 0.18,
    trend_direction: "上升", trends_ok: true, yearly: [62, 66, 71, 74], yoy: 0.09,
  },
  MaterialAnalysisInput: {
    easy_to_develop_mark: true, material_reason: "ABS 外壳 + 304 不锈钢刀头，公模成熟",
    material_conclusion: "可开发", easy_to_develop_reason: "供应链成熟，开模成本低",
  },
  PriceBandInput: { label: "20-30", min: 20, max: 30, count: 120 },
  ListingTextInput: { title: "Portable Blender USB Rechargeable", bullet_points: ["6-blade stainless steel", "400ml BPA-free cup"] },
};

// 解析 $ref / anyOf，得到可渲染的叶子 schema
function effectiveSchema(s, defs) {
  let cur = s || {};
  for (let i = 0; i < 8; i++) {
    if (cur.$ref) {
      cur = (defs || {})[String(cur.$ref).replace(/^#\/\$defs\//, "")] || {};
      continue;
    }
    if (Array.isArray(cur.anyOf) && cur.anyOf.length) {
      const cand = cur.anyOf.filter((x) => x && x.type !== "null");
      cur = cand.length ? cand[0] : cur.anyOf[0];
      continue;
    }
    break;
  }
  return cur || {};
}

// $ref 命中 SAMPLE_INPUTS 时返回示例（含数组场景）
function sampleFor(raw, defs) {
  let cur = raw || {};
  for (let i = 0; i < 8; i++) {
    if (cur.$ref) {
      const name = String(cur.$ref).replace(/^#\/\$defs\//, "");
      if (SAMPLE_INPUTS[name]) return { name, obj: SAMPLE_INPUTS[name] };
      cur = (defs || {})[name] || {};
      continue;
    }
    if (Array.isArray(cur.anyOf) && cur.anyOf.length) {
      const cand = cur.anyOf.filter((x) => x && x.type !== "null");
      cur = cand.length ? cand[0] : cur.anyOf[0];
      continue;
    }
    break;
  }
  return null;
}

function fieldNode(key, raw, defs, required, path, sampleObj, context) {
  const full = path ? `${path}.${key}` : key;
  const s = effectiveSchema(raw, defs);
  const type = s.type;
  const desc = s.description || "";
  const sample = sampleObj && sampleObj[key] !== undefined ? sampleObj[key] : undefined;
  const wrap = el("div", { class: "pfield" + (required ? " req" : "") });
  const label = el("label", { text: key, title: desc });

  // 对象：有 properties → 嵌套表单；无 properties（自由 dict）→ JSON 编辑
  if (type === "object") {
    const props = s.properties || {};
    if (Object.keys(props).length) {
      const defsRef = sampleFor(raw, defs);
      const childSample = defsRef ? defsRef.obj : (typeof sample === "object" && sample && !Array.isArray(sample) ? sample : null);
      const group = el("details", { class: "pgroup" },
        el("summary", { text: key + (desc ? ` · ${desc}` : "") }),
        el("div", { class: "pgroup-body" }));
      if (Object.keys(props).length <= 6) group.open = true;
      for (const k of Object.keys(props)) {
        group.querySelector(".pgroup-body").appendChild(fieldNode(k, props[k], defs, (s.required || []).includes(k), full, childSample, context));
      }
      wrap.appendChild(label);
      wrap.appendChild(group);
      return wrap;
    }
    const input = el("textarea", { "data-param": full, "data-kind": "json-array", class: "pjson", text: JSON.stringify(sample || {}, null, 2), spellcheck: "false" });
    input.addEventListener("input", () => syncInvokeJson(context.formId, context.jsonId));
    wrap.appendChild(label);
    wrap.appendChild(input);
    return wrap;
  }

  // 数组：items 为已知示例类型 / 对象 → JSON 编辑；string 数组 → 每行一个
  if (type === "array") {
    const items = effectiveSchema(s.items, defs);
    const itemsSample = sampleFor(s.items, defs);
    let input;
    if (itemsSample) {
      input = el("textarea", { "data-param": full, "data-kind": "json-array", class: "pjson", text: JSON.stringify([itemsSample.obj], null, 2), spellcheck: "false" });
    } else if (items.type === "object" || (items.properties && Object.keys(items.properties).length)) {
      input = el("textarea", { "data-param": full, "data-kind": "json-array", class: "pjson", text: "[\n  {}\n]", spellcheck: "false" });
    } else {
      input = el("textarea", { "data-param": full, "data-kind": "lines", text: Array.isArray(sample) ? sample.join("\n") : "" });
    }
    input.addEventListener("input", () => syncInvokeJson(context.formId, context.jsonId));
    wrap.appendChild(label);
    wrap.appendChild(input);
    return wrap;
  }

  // 标量
  const def = sample !== undefined ? sample : (s.default !== undefined ? s.default : raw.default);
  const hasDefault = sample !== undefined || Object.prototype.hasOwnProperty.call(s, "default") || Object.prototype.hasOwnProperty.call(raw, "default");
  const omitEmpty = !required && (!hasDefault || def === null);
  let input;
  if (type === "boolean") {
    input = el("select", { "data-param": full, "data-kind": "bool", "data-omit-empty": omitEmpty ? "true" : "false" },
      el("option", { value: "", text: "（不填）" }),
      el("option", { value: "true", text: "true" }),
      el("option", { value: "false", text: "false" }));
    if (def !== undefined && def !== null) input.value = String(def);
  } else if (type === "number" || type === "integer") {
    input = el("input", { "data-param": full, "data-kind": "number", "data-omit-empty": omitEmpty ? "true" : "false", type: "number", step: "any", value: def != null ? def : "" });
  } else {
    input = el("input", { "data-param": full, "data-kind": "text", "data-omit-empty": omitEmpty ? "true" : "false", value: def != null ? String(def) : "" });
  }
  input.addEventListener("input", () => syncInvokeJson(context.formId, context.jsonId));
  wrap.appendChild(label);
  wrap.appendChild(input);
  return wrap;
}

function renderParamForm(cap, options = {}) {
  const context = {
    formId: options.wrapId || "invoke-form-wrap",
    jsonId: options.jsonId || "invoke-params",
  };
  const schema = cap.input_schema || {};
  const wrap = document.getElementById(context.formId);
  if (!wrap) return;
  wrap.innerHTML = "";
  const props = schema.properties || {};
  const keys = Object.keys(props);
  if (keys.length) {
    const form = el("div", { class: "pform" });
    for (const k of keys) {
      form.appendChild(fieldNode(k, props[k], schema.$defs || {}, (schema.required || []).includes(k), "", options.seed || null, context));
    }
    wrap.appendChild(form);
    const usedSample = Object.keys(SAMPLE_INPUTS).some((n) => (schema.$defs || {})[n]);
    if (usedSample) {
      wrap.appendChild(el("p", { class: "muted", style: "font-size:12px; margin-top:8px;", text: "已预填示例数据，可直接调用或修改。" }));
    }
  } else {
    wrap.appendChild(el("p", { class: "muted", text: "该能力无参数" }));
  }
  const resetBtn = document.getElementById(options.resetId || "invoke-reset");
  if (resetBtn) resetBtn.style.display = keys.length ? "" : "none";
  syncInvokeJson(context.formId, context.jsonId);
}

function collectParams(formId = "invoke-form-wrap") {
  const params = {};
  const form = document.getElementById(formId);
  if (!form) return params;
  form.querySelectorAll("[data-param]").forEach((inp) => {
    const path = inp.dataset.param.split(".");
    const kind = inp.dataset.kind;
    let val;
    if (kind === "json-array") {
      const t = inp.value.trim();
      val = t ? JSON.parse(t) : [];
    } else if (kind === "lines") {
      val = inp.value.split("\n").map((s) => s.trim()).filter(Boolean);
    } else if (kind === "bool") {
      val = inp.value === "" ? null : inp.value === "true";
    } else if (kind === "number") {
      val = inp.value === "" ? null : Number(inp.value);
    } else {
      val = inp.value;
    }
    if (inp.dataset.omitEmpty === "true" && (val === "" || val === null)) return;
    let obj = params;
    for (let i = 0; i < path.length - 1; i++) {
      if (typeof obj[path[i]] !== "object" || obj[path[i]] === null) obj[path[i]] = {};
      obj = obj[path[i]];
    }
    obj[path[path.length - 1]] = val;
  });
  return params;
}

function syncInvokeJson(formId = "invoke-form-wrap", jsonId = "invoke-params") {
  const ta = document.getElementById(jsonId);
  if (!ta) return;
  try { ta.value = JSON.stringify(collectParams(formId), null, 2); } catch (e) { /* JSON 编辑区非法时保留用户输入 */ }
}

function requireLinks(cap) {
  // 前置依赖：可点击跳转到对应能力；来源是后端声明式的 requires（单一事实来源）。
  const reqs = (cap.requires || []).filter(Boolean);
  if (!reqs.length) return null;
  const items = reqs.map((id) => {
    const target = (currentCaps || []).find((c) => c.id === id);
    if (!target) return el("code", { text: id });
    return el("a", { href: "#", text: id, onclick: (e) => { e.preventDefault(); showCapDetail(target); } });
  });
  return el("div", { class: "row", style: "flex-wrap:wrap; gap:6px; align-items:center; margin-bottom:10px;" },
    el("b", { text: "前置依赖：" }), ...items);
}

function showCapDetail(cap, seed = null) {
  selectedCapabilityId = cap.id;
  document.querySelectorAll(".cap-row").forEach((node) =>
    node.classList.toggle("selected", node.dataset.capId === cap.id));
  const d = document.getElementById("cap-detail");
  d.innerHTML = "";
  const required = ((cap.input_schema && cap.input_schema.required) || []).join(", ") || "无必填";

  const children = [
    el("div", { class: "row", style: "align-items:center;" },
      el("h3", { class: "grow", text: cap.id }),
      el("span", { class: `layer-badge ${cap.layer}`, text: cap.layer || cap.category || "other" })),
    el("p", { class: "muted", text: cap.description || "" }),
  ];
  const reqLinks = requireLinks(cap);
  if (reqLinks) children.push(reqLinks);
  const reqFields = (cap.requires_fields || []).filter(Boolean).join(", ");
  if (reqFields) {
    children.push(el("p", { class: "muted", text: "需基础对象字段：" + reqFields }));
  }
  children.push(
    el("p", { class: "muted", text: `必填参数：${required}` }),
    el("div", { class: "contract-grid" },
      el("details", {},
        el("summary", { text: "Input schema" }),
        el("pre", { class: "json", text: JSON.stringify(cap.input_schema, null, 2) })),
      el("details", {},
        el("summary", { text: "Output schema" }),
        el("pre", { class: "json", text: JSON.stringify(cap.output_schema, null, 2) }))),
    el("h4", { text: "测试输入" }),
    el("div", { id: "invoke-form-wrap" }),
    el("div", { class: "row", style: "margin-top:8px; align-items:center;" },
      el("button", { class: "btn", text: "运行原子测试", onclick: () => invokeCap(cap) }),
      el("button", { class: "btn ghost", text: "重置参数", id: "invoke-reset", onclick: () => renderParamForm(cap, { seed }) }),
    ),
    el("div", { class: "muted", style: "font-size:12px; margin-top:8px;", text: "表单按 input_schema 自动生成；下方 JSON 是最终测试 input，可直接编辑。" }),
    el("textarea", { id: "invoke-params", class: "test-input-json" }),
    el("div", { id: "invoke-result", style: "margin-top:10px;" }),
  );

  d.appendChild(el("div", { class: "card" }, ...children));
  renderParamForm(cap, { seed });
}

async function invokeCap(cap) {
  let params = {};
  try { params = JSON.parse(document.getElementById("invoke-params").value || "{}"); }
  catch (e) { alert("参数不是合法 JSON: " + e.message); return; }
  const box = document.getElementById("invoke-result");
  box.innerHTML = '<p class="muted">测试运行中… Entity/Data 首次取数可能需要 10–30 秒。</p>';
  try {
    const record = await api(`/api/capability-tests/${encodeURIComponent(cap.id)}`, { method: "POST", body: params });
    renderCapabilityTestResult(record, box);
    currentCapabilityTests = [record, ...currentCapabilityTests.filter((item) => item.test_id !== record.test_id)].slice(0, 30);
    renderCapabilityTestHistory();
  } catch (e) {
    box.innerHTML = "";
    box.appendChild(el("p", { class: "muted", text: "测试失败: " + e }));
  }
}

function renderCapabilityTestResult(record, box) {
  if (!box) return;
  const output = record.output || {};
  const meta = output.meta || {};
  box.innerHTML = "";
  box.appendChild(el("div", { class: "test-result" },
    el("div", { class: "row", style: "align-items:center;" },
      el("h3", { class: "grow", text: "测试结果" }),
      pill(record.status === "passed" ? "fresh" : "stale", output.code || record.code || record.status)),
    output.message ? el("div", { class: "result-message", text: output.message }) : null,
    el("div", { class: "meta-grid detail-meta" },
      metaItem("Capability", record.capability),
      metaItem("耗时", `${Math.round(meta.elapsed_ms || record.elapsed_ms || 0)} ms`),
      metaItem("缓存命中", meta.from_cache ? "是" : "否"),
      metaItem("Upstream", meta.upstream || "—"),
      metaItem("本次 Enriched", (meta.enriched || []).join(", ") || "—"),
      metaItem("缺失依赖", (meta.missing || []).join(", ") || "—")),
    el("div", { class: "io-grid" },
      el("section", {},
        el("h4", { text: "Input（本次测试输入）" }),
        el("pre", { class: "json io-json", text: JSON.stringify(record.input || {}, null, 2) })),
      el("section", {},
        el("h4", { text: "Output（完整 Result 信封）" }),
        el("pre", { class: "json io-json", text: JSON.stringify(output, null, 2) }))),
    el("div", { class: "muted mono", text: `test_id: ${record.test_id || "—"}` })));
}

function renderCapabilityTestHistory() {
  const box = document.getElementById("cap-test-history");
  if (!box) return;
  box.innerHTML = "";
  if (!currentCapabilityTests.length) {
    box.appendChild(el("p", { class: "muted", text: "还没有测试记录。选择上方任一能力运行后，input/output 会保存在这里。" }));
    return;
  }
  const table = el("table", {},
    el("thead", {}, el("tr", {},
      el("th", { text: "Capability" }),
      el("th", { text: "结果" }),
      el("th", { text: "耗时" }),
      el("th", { text: "时间" }),
      el("th", { text: "Input / Output" }))),
    el("tbody"));
  const body = table.querySelector("tbody");
  for (const record of currentCapabilityTests) {
    body.appendChild(el("tr", {},
      el("td", { class: "mono", text: record.capability }),
      el("td", {}, pill(record.status === "passed" ? "fresh" : "stale", record.code || record.status)),
      el("td", { text: `${Math.round(record.elapsed_ms || 0)} ms` }),
      el("td", { text: fmtDate(record.created_at) }),
      el("td", {}, el("button", { class: "btn ghost compact", text: "查看", onclick: () => openCapabilityTest(record) }))));
  }
  box.appendChild(el("div", { class: "table-wrap" }, table));
}

async function openCapabilityTest(summary) {
  try {
    const record = summary.output ? summary : await api(`/api/capability-tests/${encodeURIComponent(summary.test_id)}`);
    const cap = currentCaps.find((item) => item.id === record.capability);
    if (cap) {
      showCapDetail(cap);
      const input = document.getElementById("invoke-params");
      if (input) input.value = JSON.stringify(record.input || {}, null, 2);
      renderCapabilityTestResult(record, document.getElementById("invoke-result"));
      document.getElementById("cap-detail")?.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  } catch (e) {
    alert("读取测试记录失败: " + e.message);
  }
}

/* ---------------- pipelines ---------------- */

async function viewPipelines() {
  const list = await api("/api/pipelines");
  app.innerHTML = "";
  app.appendChild(el("h2", { text: "Pipelines" }));
  if (!list.length) {
    app.appendChild(el("p", { class: "muted", text: "没有发现 pipeline（放到 ~/.amz/composite/ 或设 AMZ_COMPOSITE_DIR）" }));
    return;
  }
  for (const p of list) {
    app.appendChild(el("div", { class: "card" },
      el("div", { class: "row" },
        el("div", { class: "grow" },
          el("h3", { text: p.name }),
          el("div", { class: "muted", text: p.description || "" }),
          el("div", { class: "muted", text: `${p.category || "-"} · v${p.version} · ${p.steps} steps` })),
        el("a", { href: `#/pipeline/${encodeURIComponent(p.name)}`, text: "打开 DAG →" })),
    ));
  }
}

/* ---------------- pipeline DAG ---------------- */

async function viewPipeline(name) {
  const dag = await api(`/api/pipelines/${encodeURIComponent(name)}`);
  const layers = topoLayers(dag.nodes, dag.edges);
  app.innerHTML = "";
  app.appendChild(el("h2", { text: dag.name }));
  app.appendChild(el("p", { class: "muted", text: dag.description || "" }));

  const runBtn = el("button", { class: "btn", text: "▶ 运行", onclick: () => showRunForm(dag) });
  app.appendChild(runBtn);

  const dagBox = el("div", { class: "dag" });
  for (let i = 0; i < layers.length; i++) {
    const layer = el("div", { class: "dag-layer" });
    for (const nodeName of layers[i]) {
      const node = dag.nodes.find((n) => n.name === nodeName);
      layer.appendChild(dagNodeCard(node, dag));
    }
    dagBox.appendChild(layer);
    if (i < layers.length - 1) {
      dagBox.appendChild(el("div", { class: "muted", style: "margin:-14px 0 18px 8px;", text: "↓" }));
    }
  }
  app.appendChild(dagBox);

  const detail = el("div", { id: "node-detail" });
  app.appendChild(detail);
}

function dagNodeCard(node, dag) {
  return el("div", { class: "dag-node", onclick: () => showNodeDetail(node, dag) },
    el("div", { class: "node-name" }, node.name),
    badge(node.mode),
    el("div", { class: "node-cap", text: node.capability || "(custom fn)" }),
    node.description ? el("div", { class: "muted", text: node.description }) : null,
  );
}

function topoLayers(nodes, edges) {
  const nameSet = new Set(nodes.map((n) => n.name));
  const inDeg = {}; const dep = {};
  nodes.forEach((n) => { inDeg[n.name] = 0; dep[n.name] = []; });
  edges.forEach((e) => { if (nameSet.has(e.from) && nameSet.has(e.to)) { inDeg[e.to]++; dep[e.from].push(e.to); } });
  const layers = [];
  let queue = nodes.filter((n) => inDeg[n.name] === 0).map((n) => n.name);
  while (queue.length) {
    layers.push(queue.slice());
    const next = [];
    for (const n of queue) for (const m of dep[n]) if (--inDeg[m] === 0) next.push(m);
    queue = next;
  }
  return layers;
}

function showNodeDetail(node, dag) {
  const d = document.getElementById("node-detail");
  d.innerHTML = "";
  d.appendChild(el("div", { class: "card" },
    el("h3", { text: `步骤：${node.name}` }),
    kv("capability", node.capability || "(custom fn)"),
    kv("mode", node.mode),
    kv("depends", (node.depends || []).join(", ") || "-"),
    node.mode !== "batch" ? kv("item_key / map_from", `${node.item_key || "-"} / ${node.map_from || "-"}`) : null,
    kv("concurrency", String(node.concurrency ?? 5)),
    kv("ttl_hours", String(node.ttl_hours ?? 24)),
    node.description ? kv("description", node.description) : null,
    node.output_schema ? kv("output_schema", JSON.stringify(node.output_schema)) : null,
  ));
}

function showRunForm(dag) {
  const form = el("div", { class: "card", id: "run-form" },
    el("h3", { text: "运行参数（JSON）" }),
    el("textarea", { id: "run-params", text: JSON.stringify(exampleParams(dag), null, 2) }),
    el("div", { class: "row", style: "margin-top:8px;" },
      el("button", { class: "btn", text: "启动", onclick: startRun(dag) }),
      el("button", { class: "btn ghost", text: "取消", onclick: () => document.getElementById("run-form")?.remove() }),
    ),
  );
  app.prepend(form);
}

function exampleParams(dag) {
  const p = {};
  for (const n of dag.nodes) {
    if (n.map_from === "params" && n.item_key) {
      const key = n.list_key || n.item_key + "s";
      p[key] = [];
    }
  }
  return p;
}

async function startRun(dag) {
  let params = {};
  try { params = JSON.parse(document.getElementById("run-params").value || "{}"); } catch (e) {
    alert("参数不是合法 JSON: " + e.message); return;
  }
  const r = await api("/api/runs", { method: "POST", body: { pipeline: dag.name, params } });
  location.hash = `#/run/${encodeURIComponent(r.run_id)}`;
}

function kv(k, v) {
  return el("div", { class: "kv" }, el("label", { text: k }), el("div", { text: v }));
}

/* ---------------- runs ---------------- */

async function viewRuns() {
  const runs = await api("/api/runs");
  app.innerHTML = "";
  app.appendChild(el("h2", { text: "Runs" }));
  if (!runs.length) { app.appendChild(el("p", { class: "muted", text: "暂无运行记录" })); return; }
  for (const r of runs) {
    app.appendChild(el("div", { class: "card row" },
      el("div", { class: "grow" },
        el("a", { href: `#/run/${encodeURIComponent(r.run_id)}`, text: r.run_id }),
        el("div", { class: "muted", text: `${r.name || ""} · ${r.status} · ${r.created_at || ""}` }),
        el("div", { class: "muted", text: `${r.files} files · ${r.calls} calls` })),
      statusDot(r.status === "finished" ? "ok" : r.status === "failed" ? "failed" : "running"),
    ));
  }
}

async function viewRun(runId) {
  currentStepStatus = {};
  app.innerHTML = "";
  app.appendChild(el("h2", { text: "Run" }));
  app.appendChild(el("p", { class: "muted" }, el("code", { text: runId })));

  const body = el("div", { id: "run-body" });
  app.appendChild(body);

  // 首次加载 manifest
  let manifest;
  try { manifest = await api(`/api/runs/${encodeURIComponent(runId)}`); }
  catch (e) { body.appendChild(el("p", { class: "muted", text: "加载失败: " + e })); return; }
  renderManifest(body, manifest);

  // 实时进度（EventSource 不能带自定义 header，token 走查询参数）
  const qs = token() ? `?token=${encodeURIComponent(token())}` : "";
  const es = new EventSource(`/api/runs/${encodeURIComponent(runId)}/events${qs}`);
  es.onmessage = async (msg) => {
    let ev = {};
    try { ev = JSON.parse(msg.data); } catch (e) {}
    if (ev.step) currentStepStatus[ev.step] = ev.status;
    refreshStepStatus();
    if (ev.type === "run.done" || ev.type === "run.failed") {
      es.close();
      try { renderManifest(body, await api(`/api/runs/${encodeURIComponent(runId)}`)); } catch (e) {}
    }
  };
}

function renderManifest(body, m) {
  body.innerHTML = "";
  const meta = el("div", { class: "meta-grid" },
    metaItem("status", m.status || "?"),
    metaItem("pipeline", m.name || "-"),
    metaItem("created", (m.created_at || "").slice(11, 19)),
    metaItem("calls", String((m.calls || []).length)),
    metaItem("files", String((m.files || []).length)),
  );
  if (m.error) meta.appendChild(metaItem("error", m.error));
  body.appendChild(meta);

  if (m.params && Object.keys(m.params).length) {
    body.appendChild(el("div", { class: "card" },
      el("h3", { text: "参数" }), el("pre", { class: "json", text: JSON.stringify(m.params, null, 2) })));
  }

  const steps = m.steps || {};
  const grid = el("div", { class: "row", id: "steps-grid" });
  for (const [name, s] of Object.entries(steps)) {
    grid.appendChild(el("div", { class: "card step-card", "data-step": name, style: "min-width:160px; cursor:pointer;", onclick: () => viewStep(runIdOf(m), name) },
      el("div", { class: "row" }, statusDot(s.status), el("b", { text: name })),
      el("div", { class: "muted", text: `${s.elapsed_ms != null ? Math.round(s.elapsed_ms) + "ms" : ""}` }),
    ));
  }
  if (!Object.keys(steps).length) grid.appendChild(el("p", { class: "muted", text: "（等待 step 完成…）" }));
  body.appendChild(grid);
  body._runId = runIdOf(m);
}

function runIdOf(m) { return m.run_id || body._runId || location.hash.split("/").pop(); }

function metaItem(k, v) {
  return el("div", { class: "meta-item" }, el("div", { class: "k", text: k }), el("div", { class: "v", text: v }));
}

function refreshStepStatus() {
  document.querySelectorAll(".step-card").forEach((card) => {
    const name = card.dataset.step;
    const status = currentStepStatus[name];
    if (!status) return;
    const dot = card.querySelector(".status");
    if (dot) dot.className = `status ${status}`;
    card.classList.add(status);
  });
}

async function viewStep(runId, step) {
  const art = await api(`/api/runs/${encodeURIComponent(runId)}/steps/${encodeURIComponent(step)}`);
  const box = el("div", { class: "card", id: "step-detail" },
    el("div", { class: "row" },
      el("h3", { text: `步骤产物：${step}` }),
      el("button", { class: "btn ghost", text: "× 关闭", onclick: () => document.getElementById("step-detail")?.remove() }),
    ),
  );
  // meta
  const meta = el("div", { class: "meta-grid" },
    metaItem("status", art.status),
    metaItem("elapsed_ms", Math.round(art.elapsed_ms || 0) + "ms"),
    metaItem("from_cache", String(!!(art.meta && art.meta.from_cache))),
  );
  if (art.meta && art.meta.upstream) meta.appendChild(metaItem("upstream", art.meta.upstream));
  if (art.meta && art.meta.usage && Object.keys(art.meta.usage).length)
    meta.appendChild(metaItem("usage", JSON.stringify(art.meta.usage)));
  if (art.meta && art.meta.error) meta.appendChild(metaItem("error", art.meta.error));
  box.appendChild(meta);

  if (art.inputs && Object.keys(art.inputs).length)
    box.appendChild(el("div", { class: "card" }, el("h3", { text: "输入快照" }), el("pre", { class: "json", text: JSON.stringify(art.inputs, null, 2) })));

  box.appendChild(el("div", { class: "card" }, el("h3", { text: "输出" }), renderValue(art.data, art.renderer)));

  const old = document.getElementById("step-detail");
  if (old) old.replaceWith(box); else document.getElementById("run-body").appendChild(box);
  box.scrollIntoView({ behavior: "smooth" });
}

/* ---------------- data renderers ---------------- */

function renderValue(data, renderer) {
  if (data == null) return el("p", { class: "muted", text: "(empty)" });
  if (renderer === "table") return renderTable(data);
  if (renderer === "text") return el("div", { class: "text-block", text: String(data) });
  if (renderer === "list") return renderList(data);
  return el("pre", { class: "json", text: JSON.stringify(data, null, 2) });
}

function renderTable(data) {
  const items = (data && data.items) || [];
  const cols = [];
  const seen = new Set();
  for (const it of items) for (const k of Object.keys(it || {})) if (!seen.has(k)) { seen.add(k); cols.push(k); }
  if (!cols.length) return el("p", { class: "muted", text: "(空表格)" });
  const table = el("table");
  table.appendChild(el("tr", {}, ...cols.map((c) => el("th", { text: c }))));
  for (const it of items.slice(0, 200)) {
    table.appendChild(el("tr", {}, ...cols.map((c) => {
      const v = it[c];
      return el("td", {}, (v != null && typeof v === "object") ? JSON.stringify(v) : String(v ?? ""));
    })));
  }
  return el("div", { class: "table-wrap" }, table);
}

function renderList(data) {
  return el("ul", {}, ...data.slice(0, 200).map((it) => el("li", { text: typeof it === "object" ? JSON.stringify(it) : String(it) })));
}

/* ---------------- builder ---------------- */

async function viewBuilder() {
  const caps = await api("/api/capabilities");
  app.innerHTML = "";
  app.appendChild(el("h2", { text: "建流器（声明式 spec）" }));

  const grid = el("div", { class: "builder" });

  // 左：积木目录
  const palette = el("div", { class: "card" },
    el("h3", { text: "积木目录" }),
    el("input", { id: "cap-search", placeholder: "搜索能力…", oninput: () => renderPalette(caps) }),
    el("div", { id: "cap-list", style: "max-height:560px; overflow:auto; margin-top:8px;" }),
  );

  // 右：spec 编辑
  const editor = el("div", { class: "card" },
    el("div", { class: "kv" }, el("label", { text: "name" }), el("input", { id: "spec-name", value: "my_pipeline" })),
    el("div", { class: "kv" }, el("label", { text: "description" }), el("input", { id: "spec-desc", value: "" })),
    el("div", { class: "kv" }, el("label", { text: "category" }), el("input", { id: "spec-cat", value: "" })),
    el("h3", { text: "steps" }),
    el("div", { id: "step-list" }),
    el("div", { class: "row", style: "margin:8px 0;" },
      el("button", { class: "btn ghost", text: "+ 添加空步骤", onclick: () => addStepRow(null) }),
    ),
    el("h3", { text: "spec JSON（预览）" }),
    el("textarea", { id: "spec-json", oninput: () => syncFromJson() }),
    el("div", { class: "row", style: "margin-top:8px;" },
      el("button", { class: "btn", text: "保存", onclick: saveSpec }),
    ),
    el("div", { id: "save-msg", class: "muted", style: "margin-top:8px;" }),
  );

  grid.appendChild(palette);
  grid.appendChild(editor);
  app.appendChild(grid);
  renderPalette(caps);
  addStepRow(null);
  syncToJson();
}

function renderPalette(caps) {
  const q = (document.getElementById("cap-search")?.value || "").toLowerCase();
  const list = document.getElementById("cap-list");
  list.innerHTML = "";
  const rows = caps.filter((c) => !q || c.id.includes(q) || (c.description || "").includes(q)).slice(0, 100);
  for (const c of rows) {
    list.appendChild(el("div", { class: "card", style: "padding:8px; margin-bottom:6px; cursor:pointer;", onclick: () => addStepRow(c) },
      el("div", { class: "node-cap", text: c.id }),
      el("div", { class: "muted", style: "font-size:12px;", text: (c.description || "").slice(0, 60) }),
    ));
  }
}

function addStepRow(cap) {
  const list = document.getElementById("step-list");
  const row = el("div", { class: "card step-row", "data-step": "1" },
    el("div", { class: "kv" }, el("label", { text: "name" }), el("input", { class: "f-name", value: cap ? cap.id.split(".").pop() : "step" })),
    el("div", { class: "kv" }, el("label", { text: "capability" }), el("input", { class: "f-cap", value: cap ? cap.id : "" })),
    el("div", { class: "kv" }, el("label", { text: "mode" }), el("select", { class: "f-mode" },
      el("option", { value: "batch", text: "batch" }), el("option", { value: "map", text: "map" }), el("option", { value: "reduce", text: "reduce" }))),
    el("div", { class: "kv" }, el("label", { text: "item_key" }), el("input", { class: "f-itemkey", value: "" })),
    el("div", { class: "kv" }, el("label", { text: "map_from" }), el("input", { class: "f-mapfrom", value: "params" })),
    el("div", { class: "kv" }, el("label", { text: "depends（逗号）" }), el("input", { class: "f-depends", value: "" })),
    el("div", { class: "kv" }, el("label", { text: "description" }), el("input", { class: "f-desc", value: "" })),
    el("button", { class: "btn danger", style: "justify-self:start;", text: "删除", onclick: () => { row.remove(); syncToJson(); } }),
  );
  list.appendChild(row);
  row.querySelectorAll("input,select").forEach((i) => i.addEventListener("input", syncToJson));
  syncToJson();
}

function collectSpec() {
  const steps = [...document.querySelectorAll(".step-row")].map((row) => {
    const g = (c) => row.querySelector(c).value;
    const depends = g(".f-depends").split(",").map((s) => s.trim()).filter(Boolean);
    const s = {
      name: g(".f-name"), capability: g(".f-cap") || null,
      mode: g(".f-mode"), description: g(".f-desc"),
    };
    if (s.mode !== "batch") { s.item_key = g(".f-itemkey"); s.map_from = g(".f-mapfrom") || undefined; }
    if (depends.length) s.depends = depends;
    return s;
  });
  return {
    name: document.getElementById("spec-name").value || "my_pipeline",
    description: document.getElementById("spec-desc").value,
    category: document.getElementById("spec-cat").value,
    version: "v1",
    steps,
  };
}

function syncToJson() {
  const ta = document.getElementById("spec-json");
  if (ta) ta.value = JSON.stringify(collectSpec(), null, 2);
}

function syncFromJson() {
  const ta = document.getElementById("spec-json");
  if (!ta) return;
  try {
    const spec = JSON.parse(ta.value);
    if (spec.name) document.getElementById("spec-name").value = spec.name;
    if (spec.description != null) document.getElementById("spec-desc").value = spec.description;
    if (spec.category != null) document.getElementById("spec-cat").value = spec.category;
  } catch (e) {}
}

async function saveSpec() {
  const spec = JSON.parse(document.getElementById("spec-json").value);
  const msg = document.getElementById("save-msg");
  try {
    const r = await api(`/api/pipelines/${encodeURIComponent(spec.name)}/spec`, { method: "POST", body: spec });
    msg.textContent = `已保存并注册：${r.capability}`;
    msg.className = "muted";
  } catch (e) {
    msg.textContent = "保存失败: " + e.message;
    msg.className = "muted";
  }
}

/* ---------------- boot ---------------- */

const tokenInput = document.getElementById("token");
if (tokenInput) {
  tokenInput.value = token();
  tokenInput.addEventListener("change", () => {
    localStorage.setItem("amz_token", tokenInput.value.trim());
    api("/api/health").then((h) => {
      const s = document.getElementById("health");
      if (s) s.textContent = `${h.atomic_capabilities ?? h.capabilities} atomic · ${h.entity_capabilities ?? 0} entity ✓`;
    }).catch(() => {
      const s = document.getElementById("health");
      if (s) s.textContent = "鉴权失败";
    });
  });
}

api("/api/health").then((h) => {
  const s = document.getElementById("health");
  if (s) s.textContent = `${h.atomic_capabilities ?? h.capabilities} atomic · ${h.entity_capabilities ?? 0} entity`;
}).catch(() => {});

route();
