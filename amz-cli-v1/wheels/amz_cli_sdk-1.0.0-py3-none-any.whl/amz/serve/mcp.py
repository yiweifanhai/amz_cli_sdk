"""
MCP 接入层：把 registry 能力暴露为 MCP tools（Streamable HTTP，远程服务模式）。

消费者（Claude Code / Codex / DSH）零安装接入：

    # 服务端：amz serve mcp --port 8000
    # 消费者（Claude Code）：
    claude mcp add amz --transport http https://your-host/mcp

全部能力的 input/output schema 直接映射为 MCP tool 的 inputSchema。
tool 名用下划线（MCP 命名限制），原始能力 ID 保留在 description 里。
"""

from __future__ import annotations

import json

from mcp.server.fastmcp import FastMCP

from amz import __version__


def _tool_name(cap_id: str) -> str:
    """MCP tool 名只允许 [a-zA-Z0-9_-]：点 → 下划线。"""
    return cap_id.replace(".", "_")


def _tool_description(cap: object) -> str:
    lines = [
        cap.description,
        "",
        f"能力 ID: {cap.id}（返回统一 Result JSON：code/message/data/meta）",
    ]
    requires = getattr(cap, "requires", None) or []
    if requires:
        lines.append(f"前置依赖（先调用这些能力取数）: {', '.join(requires)}")
    fields = getattr(cap, "requires_fields", None) or []
    if fields:
        lines.append(f"需保证存在的字段: {', '.join(fields)}")
    return "\n".join(lines)


def create_mcp() -> FastMCP:
    """构建 MCP server：全部注册能力 → tools。"""
    from amz import registry

    mcp = FastMCP(
        "amz",
        instructions=(
            "amz-cli-sdk 远程能力。每个工具对应一个原子能力（data/calc/analysis/entity），"
            "参数见 inputSchema，返回统一 Result JSON：code=OK 表示成功，"
            "ERROR_PARAM 修正参数重试，ERROR_UPSTREAM 看 meta.hint。"
        ),
    )

    for cap in registry.list_all():
        tool_name = _tool_name(cap.id)

        def _make_handler(cap_id: str, schema: dict):
            """按 input_schema 生成带真实参数签名的 handler。

            FastMCP 从函数签名推导参数校验模型；schema 已由能力 input_model 声明，
            这里用同名参数 + Any 注解让校验通过，客户端看到的仍是完整 schema。
            """
            props = schema.get("properties", {}) if schema else {}
            required = set(schema.get("required", []) or []) if schema else set()
            arg_parts = []
            # 必填参数必须在可选参数之前，否则生成 def 会 SyntaxError
            # （parameter without a default follows parameter with a default）。
            for name in props:
                if name in required:
                    arg_parts.append(f"{name}: 'Any'")
            for name in props:
                if name not in required:
                    arg_parts.append(f"{name}: 'Any' = None")
            sig = ", ".join(arg_parts)
            ns = {"_CAP_ID": cap_id, "json": json}
            exec(
                "async def handler(" + sig + "):\n"
                "    from amz import registry as _r\n"
                "    _params = {name: value for name, value in locals().items()\n"
                "               if not name.startswith('_') and value is not None}\n"
                "    result = _r.invoke(_CAP_ID, _params)\n"
                "    return json.dumps(result.model_dump(mode='json'), ensure_ascii=False)\n",
                ns,
            )
            return ns["handler"]

        handler = _make_handler(cap.id, cap.input_schema)
        handler.__name__ = tool_name
        handler.__doc__ = _tool_description(cap)
        # 用能力已声明的 input_model schema 覆盖客户端可见的参数定义
        tool = mcp._tool_manager.add_tool(
            handler,
            name=tool_name,
            description=_tool_description(cap),
        )
        if cap.input_schema:
            tool.parameters = cap.input_schema

    return mcp


def create_asgi_app(auth_token: str = "") -> object:
    """构建可被 uvicorn 托管的 ASGI 应用（含可选 X-API-Token 鉴权）。

    FastMCP 的 streamable-http 端点默认挂载在 ``/mcp``。
    """
    mcp = create_mcp()
    app = mcp.streamable_http_app()

    if not auth_token:
        return app

    # 轻量 ASGI 中间件：校验 X-API-Token（放行 /mcp 之外的 OPTIONS 等预检）
    async def auth_app(scope, receive, send):
        if scope["type"] not in ("http",):
            await app(scope, receive, send)
            return
        headers = {k.decode().lower(): v.decode() for k, v in scope.get("headers", [])}
        if headers.get("x-api-token") != auth_token:
            from starlette.responses import JSONResponse as _JR

            response = _JR({"detail": "invalid or missing X-API-Token"}, status_code=401)
            await response(scope, receive, send)
            return
        await app(scope, receive, send)

    return auth_app
