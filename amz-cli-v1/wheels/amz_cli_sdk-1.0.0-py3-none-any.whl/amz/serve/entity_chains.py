"""Inspectable multi-Entity test chains for the local Viewer.

The chains deliberately invoke the public ``entity.*`` capabilities instead of
reaching into implementation methods.  This makes the Viewer exercise the same
identity loading, lazy dependency resolution, TTL and Result contracts used by
CLI/MCP callers.
"""

from __future__ import annotations

from time import perf_counter
from typing import Any

from amz.envelope import Code
from amz.registry import registry


_CHAIN_SPECS: dict[str, dict[str, Any]] = {
    "product-market-object": {
        "name": "获取 Product.market",
        "entity_type": "product",
        "description": "从 Product 身份获取 Market 对象；主力关键词不可用时自动回退到 ASIN。",
        "root_capability": "entity.product.market",
        "steps": [
            ("entity.product.market", "获取 Product.market", "root"),
        ],
    },
    "product-market-stats": {
        "name": "Product → Market Stats",
        "entity_type": "product",
        "description": "获取 Product.market 后读取市场价格、评分、评论、垄断度与卖家统计。",
        "root_capability": "entity.product.market_stats",
        "steps": [
            ("entity.product.market_stats", "Product 直接获取 Market Stats", "root"),
        ],
    },
    "product-market-profile": {
        "name": "Product → Market Profile",
        "entity_type": "product",
        "description": "获取 Product.market、Stats，并生成八维市场画像。",
        "root_capability": "entity.product.market_profile",
        "steps": [
            ("entity.product.market_profile", "Product 直接获取 Market Profile", "root"),
        ],
    },
    "product-market-opportunity": {
        "name": "Product → Market Opportunity",
        "entity_type": "product",
        "description": "获取 Product.market、Stats，并计算市场缺口与机会分。",
        "root_capability": "entity.product.market_opportunity",
        "steps": [
            ("entity.product.market_opportunity", "Product 直接获取 Market Opportunity", "root"),
        ],
    },
    "product-market-full": {
        "name": "Product → Market 全链路",
        "entity_type": "product",
        "description": "从 ASIN 尽力补主力关键词，建立 Market，并依次获取 Stats、Profile 与 Opportunity。",
        "root_capability": "entity.product.market",
        "steps": [
            ("entity.product.market", "建立 Product.market", "root"),
            ("entity.product.market_stats", "Product 获取 Market Stats", "root"),
            ("entity.product.market_profile", "Product 获取 Market Profile", "root"),
            ("entity.product.market_opportunity", "Product 获取 Market Opportunity", "root"),
        ],
    },
    "product-finance-core": {
        "name": "Product core → Finance",
        "entity_type": "product",
        "description": "用身份对象运行 Finance；缺少 core 时自动刷新价格、尺寸与重量。",
        "root_capability": "entity.product.finance",
        "steps": [
            ("entity.product.finance", "补齐 core 并计算 Finance", "root"),
        ],
    },
    "keyword-market-object": {
        "name": "获取 Keyword.market",
        "entity_type": "keyword",
        "description": "从 Keyword 身份获取对应的 Market 对象，不提前计算市场统计。",
        "root_capability": "entity.keyword.market",
        "steps": [
            ("entity.keyword.market", "获取 Keyword.market", "root"),
        ],
    },
    "keyword-market-stats": {
        "name": "Keyword → Market Stats",
        "entity_type": "keyword",
        "description": "直接从 Keyword 获取市场价格、评分、评论、垄断度与卖家统计。",
        "root_capability": "entity.keyword.market_stats",
        "steps": [
            ("entity.keyword.market_stats", "Keyword 直接获取 Market Stats", "root"),
        ],
    },
    "keyword-market-profile": {
        "name": "Keyword → Market Profile",
        "entity_type": "keyword",
        "description": "直接从 Keyword 自动级联 Market、Stats，并生成八维市场画像。",
        "root_capability": "entity.keyword.market_profile",
        "steps": [
            ("entity.keyword.market_profile", "Keyword 直接获取 Market Profile", "root"),
        ],
    },
    "keyword-market-opportunity": {
        "name": "Keyword → Market Opportunity",
        "entity_type": "keyword",
        "description": "直接从 Keyword 自动级联 Market、Stats，并计算市场缺口与机会分。",
        "root_capability": "entity.keyword.market_opportunity",
        "steps": [
            ("entity.keyword.market_opportunity", "Keyword 直接获取 Market Opportunity", "root"),
        ],
    },
    "keyword-market-full": {
        "name": "Keyword → Market 全链路",
        "entity_type": "keyword",
        "description": "从 Keyword 建立对应 Market，并继续获取完整市场统计、画像与机会。",
        "root_capability": "entity.keyword.market",
        "steps": [
            ("entity.keyword.market", "建立 Keyword.market", "root"),
            ("entity.keyword.market_stats", "Keyword 获取 Market Stats", "root"),
            ("entity.keyword.market_profile", "Keyword 获取 Market Profile", "root"),
            ("entity.keyword.market_opportunity", "Keyword 获取 Market Opportunity", "root"),
        ],
    },
    "market-full": {
        "name": "Market 完整数据链",
        "entity_type": "market",
        "description": "以 term 为身份依次拉取 Products，并计算 Stats、Profile 与 Opportunity。",
        "root_capability": "entity.market.stats",
        "steps": [
            ("entity.market.stats", "拉取 Products 并计算 Stats", "root"),
            ("entity.market.profile", "获取 Market Profile", "root"),
            ("entity.market.opportunity", "获取 Market Opportunity", "root"),
        ],
    },
}


def entity_chain_catalog(entity_type: str = "") -> list[dict[str, Any]]:
    """Return Viewer metadata for the supported multi-step Entity scenarios."""
    rows: list[dict[str, Any]] = []
    for chain_id, spec in _CHAIN_SPECS.items():
        if entity_type and spec["entity_type"] != entity_type:
            continue
        root = registry.get(spec["root_capability"])
        steps = []
        for capability_id, label, _scope in spec["steps"]:
            capability = registry.get(capability_id)
            steps.append({
                "capability": capability_id,
                "label": label,
                "requires": list(capability.requires) if capability else [],
                "requires_fields": list(capability.requires_fields) if capability else [],
            })
        rows.append({
            "id": chain_id,
            "name": spec["name"],
            "entity_type": spec["entity_type"],
            "description": spec["description"],
            "input_schema": root.input_schema if root else {"type": "object", "properties": {}},
            "steps": steps,
            "path": [step["capability"] for step in steps],
        })
    return rows


def run_entity_chain(chain_id: str, params: dict[str, Any]) -> dict[str, Any]:
    """Run one declared chain and return every intermediate Result envelope."""
    spec = _CHAIN_SPECS.get(chain_id)
    if spec is None:
        raise KeyError(f"unknown entity chain: {chain_id}")

    root_params = dict(params or {})
    market_identity = {
        key: root_params.get(key, default)
        for key, default in (("term", ""), ("marketplace", "US"), ("category", ""))
    }
    steps: list[dict[str, Any]] = []
    chain_started = perf_counter()

    for capability_id, label, scope in spec["steps"]:
        source = root_params if scope == "root" else {
            **market_identity,
            "force_refresh": bool(root_params.get("force_refresh", False)),
        }
        step_input = _capability_input(capability_id, source)
        started = perf_counter()
        result = registry.invoke(capability_id, step_input)
        capability = registry.get(capability_id)
        step = {
            "index": len(steps) + 1,
            "label": label,
            "capability": capability_id,
            "status": "passed" if result.code == Code.OK else "failed",
            "input": step_input,
            "requires": list(capability.requires) if capability else [],
            "requires_fields": list(capability.requires_fields) if capability else [],
            "elapsed_ms": round((perf_counter() - started) * 1000, 1),
            "output": result.model_dump(mode="json"),
        }
        steps.append(step)

        if result.code != Code.OK:
            break
        if capability_id in {"entity.product.market", "entity.keyword.market"}:
            extracted = _market_identity(result.data)
            if extracted:
                market_identity = extracted

    success = len(steps) == len(spec["steps"]) and all(
        step["status"] == "passed" for step in steps
    )
    return {
        "chain_id": chain_id,
        "name": spec["name"],
        "entity_type": spec["entity_type"],
        "status": "passed" if success else "failed",
        "success": success,
        "input": root_params,
        "resolved_identities": {
            "root": _root_identity(spec["entity_type"], root_params),
            "market": market_identity if market_identity.get("term") else None,
        },
        "completed_steps": len(steps),
        "total_steps": len(spec["steps"]),
        "elapsed_ms": round((perf_counter() - chain_started) * 1000, 1),
        "steps": steps,
    }


def _capability_input(capability_id: str, source: dict[str, Any]) -> dict[str, Any]:
    capability = registry.get(capability_id)
    if capability is None:
        return dict(source)
    allowed = set((capability.input_schema.get("properties") or {}).keys())
    return {key: value for key, value in source.items() if key in allowed}


def _market_identity(data: Any) -> dict[str, Any] | None:
    if not isinstance(data, dict):
        return None
    candidate = data.get("market") if isinstance(data.get("market"), dict) else data
    term = candidate.get("term") or candidate.get("keyword")
    if not term:
        return None
    return {
        "term": str(term),
        "marketplace": str(candidate.get("marketplace") or "US"),
        "category": str(candidate.get("category") or ""),
    }


def _root_identity(entity_type: str, params: dict[str, Any]) -> dict[str, Any]:
    names = {
        "product": ("asin",),
        "keyword": ("marketplace", "category", "term"),
        "market": ("marketplace", "category", "term"),
        "review": ("asin", "mode", "star_filter", "max_pages"),
    }.get(entity_type, ())
    return {name: params.get(name) for name in names if name in params}
