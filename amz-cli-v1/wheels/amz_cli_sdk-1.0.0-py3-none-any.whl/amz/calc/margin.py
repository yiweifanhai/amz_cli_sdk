"""
FBA 毛利率计算：佣金 + FBA 费 + 头程 + 采购 → 毛利/毛利率/保本价。

吸收 amz_agent fba-margin-calc.py / new_release_process run.py step1 实现。
"""

from __future__ import annotations

from datetime import date, datetime

from amz.calc.fba import calculate_fee
from amz.registry import capability
from amz.schemas.analysis_inputs import CalcMarginInput
from amz.schemas.data_outputs import MarginOutput


# 头程物流成本估算（人民币/kg，运营报价口径）。
# 计算时按 CNY_PER_USD 汇率折算为美元（参考 market_selection_agent profit_calculator）。
SHIPPING_COST_PER_KG: dict[str, float] = {
    "slow": 8.0,       # 慢船
    "fast": 12.0,      # 快船
    "air": 30.0,       # 空运
    "express": 45.0,   # 快递
}

# 人民币兑美元汇率（人民币/美元），用于把 RMB 头程单价折算为 USD
CNY_PER_USD: float = 7.0


@capability(
    "calc.fba.margin",
    description="毛利率计算（佣金 + FBA + 头程 + 采购，含 M1/M2 分层利润）",
    input_model=CalcMarginInput,
    output_model=MarginOutput,
)
def calculate_margin(
    selling_price: float,
    pkg_weight_g: float = 0,
    pkg_dims_cm: tuple[float, float, float] | None = None,
    shipping_method: str = "fast",
    purchase_price: float | None = None,
    referral_rate: float = 0.15,
    cpc: float | None = None,
    cvr: float | None = None,
    product_type: str | None = None,
    fulfillment_date: date | datetime | str | None = None,
    include_fuel_surcharge: bool = True,
    fba_fee_usd: float | None = None,
    exchange_rate: float = CNY_PER_USD,
) -> dict:
    """calc.fba.margin — 毛利率计算（含 M1/M2 分层利润）

    M1 = (price - FBA - 头程 - 佣金) / price          … 平台费用后利润率（不含采购成本和广告）
    M2 = (price - FBA - 头程 - 佣金 - CPA) / price    … 平台+广告后利润率（不含采购成本）
         其中 CPA = cpc / cvr

    Args:
        selling_price: 售价 ($)
        pkg_weight_g: 包装重量 (g)
        pkg_dims_cm: 包装尺寸 (length, width, height)
        shipping_method: 头程方式 slow/fast/air/express
        purchase_price: 采购价 ($)，未知则计算不含采购价的毛利
        referral_rate: 佣金率 (默认 15%)
        cpc: 单次点击成本 ($)，来自关键词 exactPpc 均值，用于 M2
        cvr: 转化率 (0-1)，来自关键词 purchases/clicks，用于 M2
        product_type: non_apparel/apparel/dangerous_goods（及兼容别名）
        fulfillment_date: FBA 出库日期，用于选择旺季费率和附加费
        include_fuel_surcharge: 是否应用生效日期后的 3.5% 燃油物流附加费
        fba_fee_usd: 已知的 FBA 配送费；传入时跳过本地 FBA 查表
        exchange_rate: 人民币兑美元汇率（人民币/美元），头程单价为 RMB，
            按该汇率折算为 $（默认 7.0）

    Returns:
        {referral_fee, fba_fee, shipping_cost, purchase_price, total_cost,
         gross_profit, gross_margin_pct, break_even_price,
         m1_margin_pct, m2_margin_pct, cpa, cpc, cvr}
    """
    if exchange_rate <= 0:
        raise ValueError("exchange_rate must be > 0")

    # 1. 佣金
    referral_fee = min(selling_price * referral_rate, 30.0)  # 下限也按比例

    # 2. FBA 费
    if fba_fee_usd is not None:
        if fba_fee_usd < 0:
            raise ValueError("fba_fee_usd must be non-negative")
        fba_fee = float(fba_fee_usd)
    elif pkg_dims_cm and pkg_weight_g > 0:
        l, w, h = pkg_dims_cm
        fee_result = calculate_fee(
            pkg_weight_g,
            l,
            w,
            h,
            product_type,
            selling_price=selling_price,
            fulfillment_date=fulfillment_date,
            include_fuel_surcharge=include_fuel_surcharge,
        )
        fba_fee = fee_result["fee_usd"]
    else:
        raise ValueError(
            "accurate FBA fees require pkg_weight_g and pkg_dims_cm; "
            "pass fba_fee_usd when the fee is already known"
        )

    # 3. 头程物流（单价为 RMB/kg，按汇率折算为 USD）
    rate_per_kg = SHIPPING_COST_PER_KG.get(shipping_method, SHIPPING_COST_PER_KG["fast"])
    shipping_cost = (
        rate_per_kg * (pkg_weight_g / 1000) / exchange_rate if pkg_weight_g > 0 else 0
    )

    # 4. 汇总
    pp = purchase_price or 0.0
    total_cost = referral_fee + fba_fee + shipping_cost + pp
    gross_profit = selling_price - total_cost
    gross_margin_pct = (gross_profit / selling_price * 100) if selling_price > 0 else 0
    break_even_price = total_cost / (1 - referral_rate) if referral_rate < 1 else total_cost

    # 5. M1 = (price - FBA - 头程 - 佣金) / price
    if selling_price > 0:
        m1_margin_pct = round(
            (selling_price - referral_fee - fba_fee - shipping_cost) / selling_price * 100, 1
        )
    else:
        m1_margin_pct = None

    # 6. M2 = (price - FBA - 头程 - 佣金 - CPA) / price, CPA = cpc / cvr
    m2_margin_pct = None
    cpa = None
    if cpc is not None and cvr is not None and cvr > 0:
        cpa = round(cpc / cvr, 2)
        if selling_price > 0:
            m2_margin_pct = round(
                (selling_price - referral_fee - fba_fee - shipping_cost - cpa) / selling_price * 100, 1
            )

    return {
        "referral_fee": round(referral_fee, 2),
        "fba_fee": round(fba_fee, 2),
        "shipping_cost": round(shipping_cost, 2),
        "purchase_price": pp,
        "total_cost": round(total_cost, 2),
        "gross_profit": round(gross_profit, 2),
        "gross_margin_pct": round(gross_margin_pct, 1),
        "break_even_price": round(break_even_price, 2),
        "m1_margin_pct": m1_margin_pct,
        "m2_margin_pct": m2_margin_pct,
        "cpa": cpa,
        "cpc": cpc,
        "cvr": cvr,
    }
