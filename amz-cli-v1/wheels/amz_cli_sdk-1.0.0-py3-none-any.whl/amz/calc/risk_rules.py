"""
风险评估确定性规则引擎。

从 composite/risk.py 提取，供 agent 和编排器调用。
所有函数纯数据入、纯数据出，不调 LLM、不调 IO。
"""

from __future__ import annotations
import re

# ============================================================================
# 知识库
# ============================================================================

_REGULATION_RULES: list[dict] = [
    {
        "regulation": "CPSIA",
        "name_cn": "儿童产品安全",
        "triggers": ["children", "kid", "baby", "infant", "toddler", "toy", "child", "nursery"],
        "requirement": "第三方测试(CPSC认可实验室) + CPC证书 + 追踪标签",
        "cost_estimate": "$1,000–$5,000",
        "severity": "high",
    },
    {
        "regulation": "FDA",
        "name_cn": "食品/药品/化妆品/医疗器械",
        "triggers": ["food", "supplement", "vitamin", "cosmetic", "cream", "lotion", "serum",
                     "medical", "health", "oral", "skin care", "makeup", "dietary"],
        "requirement": "设施注册 + 标签合规 + GMP; 医疗器械需510(k)",
        "cost_estimate": "$1,000–$100,000+",
        "severity": "high",
    },
    {
        "regulation": "FCC",
        "name_cn": "电子/无线设备",
        "triggers": ["bluetooth", "wifi", "wireless", "rf", "radio", "electronic", "usb",
                     "charger", "battery", "rechargeable", "led", "digital", "smart"],
        "requirement": "FCC ID(有意发射器) 或 合规声明(无意发射器)",
        "cost_estimate": "$1,000–$15,000",
        "severity": "high",
    },
    {
        "regulation": "EPA",
        "name_cn": "农药/抗菌产品",
        "triggers": ["antibacterial", "antimicrobial", "disinfectant", "pesticide", "mold",
                     "mildew", "repellent", "insect", "sterilize", "sanitize"],
        "requirement": "FIFRA 注册",
        "cost_estimate": "$10,000–$50,000+",
        "severity": "high",
    },
    {
        "regulation": "UL/ETL",
        "name_cn": "电气安全认证",
        "triggers": ["plug", "ac power", "outlet", "charger adapter", "power supply",
                     "voltage", "watt", "electric", "corded"],
        "requirement": "NRTL 安全认证(UL/ETL/CSA)",
        "cost_estimate": "$5,000–$30,000",
        "severity": "high",
    },
    {
        "regulation": "DOT/NHTSA",
        "name_cn": "汽车/交通安全",
        "triggers": ["car", "vehicle", "automotive", "helmet", "seat belt", "tire",
                     "headlight", "brake", "motorcycle", "trailer"],
        "requirement": "FMVSS 合规 + DOT 标志",
        "cost_estimate": "视产品而定",
        "severity": "medium",
    },
    {
        "regulation": "Prop 65",
        "name_cn": "加州65号提案",
        "triggers": [],  # 几乎所有实体产品适用
        "requirement": "警告标签(如含列明化学物质); 测试费 $200–$500",
        "cost_estimate": "$200–$500",
        "severity": "low",
    },
    {
        "regulation": "Textiles",
        "name_cn": "纺织品/服装法规",
        "triggers": ["fabric", "textile", "cotton", "polyester", "clothing", "apparel",
                     "bedding", "curtain", "towel", "blanket", "pillow", "sheet",
                     "sleepwear", "pajama", "garment", "wear"],
        "requirement": "FTC 标签(成分/产地/护理) + 阻燃测试(儿童睡衣)",
        "cost_estimate": "$500–$3,000",
        "severity": "medium",
    },
    {
        "regulation": "Batteries/Hazmat",
        "name_cn": "电池/危险品",
        "triggers": ["lithium", "li-ion", "battery powered", "rechargeable battery",
                     "aerosol", "spray", "flammable", "perfume", "nail polish",
                     "compressed", "chemical", "hazardous"],
        "requirement": "UN38.3 测试 + SDS + FBA Hazmat Review",
        "cost_estimate": "$2,000–$5,000/电池型号",
        "severity": "high",
    },
    {
        "regulation": "MoCRA",
        "name_cn": "化妆品现代化法规",
        "triggers": ["cosmetic", "makeup", "skincare", "lotion", "cream", "serum",
                     "shampoo", "conditioner", "deodorant", "perfume", "nail",
                     "lipstick", "foundation", "powder", "beauty"],
        "requirement": "FDA设施注册 + 产品备案 + cGMP + 不良事件报告",
        "cost_estimate": "$2,000–$10,000",
        "severity": "high",
    },
    {
        "regulation": "Dietary Supplements",
        "name_cn": "膳食补充剂",
        "triggers": ["supplement", "vitamin", "mineral", "herbal", "protein powder",
                     "amino acid", "probiotic", "enzyme", "dietary", "nutrition"],
        "requirement": "cGMP + TIC第三方认证(2026起全品类) + COA",
        "cost_estimate": "$5,000–$20,000+",
        "severity": "high",
    },
]

_CATEGORY_GATING: dict[str, dict] = {
    "high": {
        "label": "高门槛",
        "categories": [
            "grocery", "gourmet food", "topicals", "fine jewelry", "watches",
            "streaming media", "collectible coins", "dietary supplements",
            "baby products", "toys & games",
        ],
        "score_impact": 0,
    },
    "medium": {
        "label": "中等门槛",
        "categories": [
            "automotive", "powersports", "health", "personal care",
            "beauty", "clothing", "accessories",
        ],
        "score_impact": 6,
    },
    "open": {
        "label": "开放",
        "categories": [
            "home", "kitchen", "tools", "home improvement", "office products",
            "patio", "lawn", "garden", "arts", "crafts", "sewing",
            "industrial", "scientific", "sports", "outdoors",
            "books", "camera", "photo", "cell phones", "accessories",
            "musical instruments", "software", "video games",
        ],
        "score_impact": 10,
    },
}

_KNOWN_MAJOR_BRANDS: set[str] = {
    "nike", "apple", "samsung", "chanel", "adidas", "gopro", "sony", "dyson",
    "bose", "3m", "lego", "disney", "marvel", "nintendo", "sanrio", "warner",
    "hasbro", "mattel", "stanley", "yeti", "coleman", "dewalt", "milwaukee",
    "makita", "bosch", "kitchenaid", "oxo", "pyrex", "fiskars", "crayola",
    "fisher-price", "graco", "brita", "keurig", "nespresso", "dyson",
    "roomba", "irobot", "nest", "ring", "fitbit", "garmin", "bose",
    "beats", "jbl",
}

_OPERATIONAL_BENCHMARKS: dict = {
    "return_rate": {
        "low_categories": ["books", "media", "consumables", "pet consumables", "beauty", "simple tools"],
        "mid_categories": ["home improvement", "shoes", "jewelry"],
        "high_categories": ["clothing", "electronics", "furniture", "auto parts"],
    },
    "review_barrier": {"low": 100, "mid": 500, "high": 1000},
    "cn_seller_threshold": {"green": 60, "yellow": 80, "red": 80},
    "market_size": {"large": 100000, "medium": 30000, "small": 10000},
    "monopoly": {"green": 40, "yellow": 60, "red": 60},
}

_IP_DENSE_CATEGORIES: set[str] = {
    "electronics", "phone", "accessories", "kitchen", "tools",
    "toys", "games", "sports", "outdoors", "pet", "gadget",
}

_PROHIBITED_KEYWORDS: list[str] = [
    "cbd", "marijuana", "cannabis", "tobacco", "vape", "weapon",
    "gun", "firearm", "ammunition", "explosive",
]

_HAZMAT_KEYWORDS: list[str] = [
    "lithium", "battery", "rechargeable", "flammable", "aerosol",
    "spray", "magnetic", "compressed", "chemical", "perfume",
]


# ============================================================================
# 公共 API
# ============================================================================

def check_regulation_triggers(text: str) -> list[dict]:
    """基于产品文本做关键词匹配，返回适用法规列表。

    Args:
        text: 产品标题 + 描述 + 类目等拼接文本

    Returns:
        [{regulation, name_cn, applicable, requirement, cost_estimate, severity, match_type, matched_keywords?}]
    """
    text_lower = text.lower()
    matches: list[dict] = []
    for rule in _REGULATION_RULES:
        if not rule["triggers"]:
            matches.append({
                "regulation": rule["regulation"],
                "name_cn": rule["name_cn"],
                "applicable": True,
                "requirement": rule["requirement"],
                "cost_estimate": rule["cost_estimate"],
                "severity": rule["severity"],
                "match_type": "always",
            })
            continue
        matched = [t for t in rule["triggers"] if t in text_lower]
        if matched:
            matches.append({
                "regulation": rule["regulation"],
                "name_cn": rule["name_cn"],
                "applicable": True,
                "requirement": rule["requirement"],
                "cost_estimate": rule["cost_estimate"],
                "severity": rule["severity"],
                "match_type": "keyword",
                "matched_keywords": matched,
            })
    return matches


def compute_compliance_score(regulation_matches: list[dict]) -> dict:
    """基于法规匹配结果计算合规评分。

    评分标准（对齐 SKILL.md）：
    - 无合规要求 → 10
    - 仅 Prop 65 → 9
    - 需要任何认证/测试 → 0 (STOP)

    Returns:
        {score, stop, score_reason, risk_level, blocking_items}
    """
    non_prop65 = [m for m in regulation_matches if m["regulation"] != "Prop 65"]
    if not non_prop65:
        score = 9 if any(m["regulation"] == "Prop 65" for m in regulation_matches) else 10
        return {
            "score": score,
            "stop": False,
            "score_reason": "无合规认证要求，普通消费品" if score == 10 else "仅需 Prop 65 警告标签",
            "risk_level": "GREEN",
            "blocking_items": [],
        }

    blocking = [m for m in non_prop65 if m["severity"] == "high"]
    return {
        "score": 0,
        "stop": True,
        "score_reason": f"需要 {'/'.join(m['regulation'] for m in non_prop65)} 认证",
        "risk_level": "RED",
        "blocking_items": [
            {"regulation": m["regulation"], "requirement": m["requirement"], "cost": m["cost_estimate"]}
            for m in non_prop65
        ],
    }


def check_category_gating(category_text: str) -> dict:
    """检查类目准入门槛。

    Returns:
        {level, label, matched_category, score, stop}
    """
    text_lower = category_text.lower()
    for level, info in _CATEGORY_GATING.items():
        for cat in info["categories"]:
            if cat in text_lower:
                return {
                    "level": level,
                    "label": info["label"],
                    "matched_category": cat,
                    "score": info["score_impact"],
                    "stop": info["score_impact"] == 0,
                }
    return {"level": "unknown", "label": "未知", "matched_category": "", "score": 8, "stop": False}


def check_brand_risk(brand: str) -> dict:
    """检查品牌是否属于知名大品牌。

    Returns:
        {is_major_brand, risk, detail}
    """
    brand_lower = brand.lower().strip()
    is_major = any(b in brand_lower for b in _KNOWN_MAJOR_BRANDS)
    return {
        "is_major_brand": is_major,
        "risk": "high" if is_major else "low",
        "detail": f"知名品牌 {brand}" if is_major else f"非知名品牌 {brand}",
    }


def check_ip_density(category_text: str) -> str:
    """判断类目的 IP 密集程度。

    Returns:
        "高" | "中"
    """
    cat_lower = category_text.lower()
    return "高" if any(c in cat_lower for c in _IP_DENSE_CATEGORIES) else "中"


def check_prohibited_signals(text: str) -> list[str]:
    """检查禁售信号。

    Returns:
        匹配到的禁售关键词列表
    """
    text_lower = text.lower()
    return [kw for kw in _PROHIBITED_KEYWORDS if kw in text_lower]


def check_hazmat_signals(text: str) -> list[str]:
    """检查 FBA Hazmat 信号。

    Returns:
        匹配到的危险品关键词列表
    """
    text_lower = text.lower()
    return [kw for kw in _HAZMAT_KEYWORDS if kw in text_lower]


def score_operational_dimension(dim_name: str, value: float, context: dict | None = None) -> dict:
    """对单个运营维度做确定性评分。

    Args:
        dim_name: return_rate | monopoly | review_barrier | cn_share | market_size | new_product
        value: 该维度的数值
        context: 补充上下文（如 {"category": "electronics"}）

    Returns:
        {score, level, detail}
    """
    ctx = context or {}

    if dim_name == "return_rate":
        category = ctx.get("category", "").lower()
        low_cats = _OPERATIONAL_BENCHMARKS["return_rate"]["low_categories"]
        high_cats = _OPERATIONAL_BENCHMARKS["return_rate"]["high_categories"]
        if any(c in category for c in low_cats):
            threshold_low, threshold_high = 5, 8
        elif any(c in category for c in high_cats):
            threshold_low, threshold_high = 15, 25
        else:
            threshold_low, threshold_high = 8, 15

        if value <= threshold_low:
            return {"score": 8, "level": "GREEN", "detail": f"退货率 {value}% ≤ {threshold_low}%"}
        elif value <= threshold_high:
            return {"score": 5, "level": "YELLOW", "detail": f"退货率 {value}% 在 {threshold_low}%-{threshold_high}% 之间"}
        else:
            return {"score": 2, "level": "RED", "detail": f"退货率 {value}% > {threshold_high}%"}

    elif dim_name == "monopoly":
        thresholds = _OPERATIONAL_BENCHMARKS["monopoly"]
        if value < thresholds["green"]:
            return {"score": 8, "level": "GREEN", "detail": f"CR {value}% < {thresholds['green']}% 分散市场"}
        elif value < thresholds["yellow"]:
            return {"score": 5, "level": "YELLOW", "detail": f"CR {value}% 在 {thresholds['green']}%-{thresholds['yellow']}% 中度集中"}
        else:
            return {"score": 2, "level": "RED", "detail": f"CR {value}% > {thresholds['red']}% 高度垄断"}

    elif dim_name == "review_barrier":
        thresholds = _OPERATIONAL_BENCHMARKS["review_barrier"]
        if value < thresholds["low"]:
            return {"score": 8, "level": "GREEN", "detail": f"平均 {value:.0f} 条评论，低门槛"}
        elif value < thresholds["high"]:
            return {"score": 5, "level": "YELLOW", "detail": f"平均 {value:.0f} 条评论，中等门槛"}
        else:
            return {"score": 2, "level": "RED", "detail": f"平均 {value:.0f} 条评论，极高门槛"}

    elif dim_name == "cn_share":
        thresholds = _OPERATIONAL_BENCHMARKS["cn_seller_threshold"]
        if value < thresholds["green"]:
            return {"score": 8, "level": "GREEN", "detail": f"中国卖家 {value}% < {thresholds['green']}%"}
        elif value < thresholds["yellow"]:
            return {"score": 5, "level": "YELLOW", "detail": f"中国卖家 {value}% 在 {thresholds['green']}%-{thresholds['yellow']}%"}
        else:
            return {"score": 2, "level": "RED", "detail": f"中国卖家 {value}% > {thresholds['red']}%"}

    elif dim_name == "market_size":
        thresholds = _OPERATIONAL_BENCHMARKS["market_size"]
        if value >= thresholds["large"]:
            return {"score": 8, "level": "GREEN", "detail": f"月营收 ${value:,.0f}，大市场"}
        elif value >= thresholds["medium"]:
            return {"score": 6, "level": "GREEN", "detail": f"月营收 ${value:,.0f}，中等市场"}
        elif value >= thresholds["small"]:
            return {"score": 4, "level": "YELLOW", "detail": f"月营收 ${value:,.0f}，小市场"}
        else:
            return {"score": 2, "level": "RED", "detail": f"月营收 ${value:,.0f}，微型市场"}

    elif dim_name == "new_product":
        if value > 10:
            return {"score": 8, "level": "GREEN", "detail": f"新品占比 {value}%，市场活跃接受新品"}
        elif value > 5:
            return {"score": 5, "level": "YELLOW", "detail": f"新品占比 {value}%，有机会但有门槛"}
        else:
            return {"score": 2, "level": "RED", "detail": f"新品占比 {value}%，市场被老品锁死"}

    return {"score": 0, "level": "UNKNOWN", "detail": f"未知维度 {dim_name}，不在确定性规则覆盖范围内"}


def parse_cost_estimate(cost_str: str) -> int:
    """解析费用字符串为数值（取中位数）。

    "$1,000–$5,000" → 3000
    "$200–$500" → 350
    """
    nums = re.findall(r'[\d,]+', cost_str.replace(",", ""))
    if not nums:
        return 0
    values = [int(n) for n in nums]
    return sum(values) // len(values)


def platform_reason(category_check: dict, prohibited: list[str], brand: dict) -> str:
    """生成平台准入原因说明。"""
    parts: list[str] = []
    if prohibited:
        parts.append(f"禁售信号: {', '.join(prohibited)}")
    if category_check["stop"]:
        parts.append(f"高门槛类目: {category_check['matched_category']}")
    elif category_check["level"] != "open":
        parts.append(f"{category_check['label']}类目: {category_check['matched_category']}")
    if brand["is_major_brand"]:
        parts.append(f"知名品牌: {brand['detail']}")
    if not parts:
        parts.append("无平台限制")
    return "; ".join(parts)
