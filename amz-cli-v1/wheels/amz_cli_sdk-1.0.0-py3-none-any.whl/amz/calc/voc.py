"""Product VOC 的确定性统计。"""

from __future__ import annotations

from typing import Any

from amz.registry import capability
from amz.schemas.voc import (
    ProductVocReview,
    ReviewSummary,
    VocSatisfactionContext,
    VocSatisfactionInput,
    VocSatisfactionMetrics,
    VocWeaknessSignalsOutput,
    VocWeaknessesOutput,
)


def _rating_value(value: Any) -> float | None:
    if value in (None, ""):
        return None
    try:
        rating = float(str(value).split()[0])
    except (TypeError, ValueError, IndexError):
        return None
    return rating if 0 < rating <= 5 else None


def _summary_rating(summary: ReviewSummary) -> float | None:
    shares = (
        (5, summary.five_star.percentage),
        (4, summary.four_star.percentage),
        (3, summary.three_star.percentage),
        (2, summary.two_star.percentage),
        (1, summary.one_star.percentage),
    )
    total_share = sum(share for _, share in shares)
    if total_share <= 0:
        return None
    return sum(star * share for star, share in shares) / total_share


@capability(
    "calc.voc.satisfaction",
    description="根据全量星级分布计算产品满意度上下文",
    input_model=VocSatisfactionInput,
    output_model=VocSatisfactionMetrics,
)
def calculate_satisfaction(
    reviews: list[ProductVocReview] | None = None,
    review_summary: ReviewSummary | None = None,
    star_ratios: ReviewSummary | None = None,
    total_reviews: int | None = None,
    product_rating: float | str | None = None,
) -> VocSatisfactionMetrics:
    """计算满意度；不取数、不调用 LLM、不读取 Entity。"""
    review_items = [
        item if isinstance(item, ProductVocReview) else ProductVocReview.model_validate(item)
        for item in (reviews or [])
    ]
    raw_summary = review_summary or star_ratios
    summary = (
        raw_summary
        if isinstance(raw_summary, ReviewSummary)
        else ReviewSummary.model_validate(raw_summary)
        if raw_summary is not None
        else None
    )

    if summary is not None:
        positive_pct = round(
            summary.five_star.percentage + summary.four_star.percentage
        )
        negative_pct = round(
            summary.one_star.percentage + summary.two_star.percentage
        )
    else:
        positive_pct = 0
        negative_pct = 0

    if total_reviews is not None:
        resolved_total = total_reviews
    elif summary is not None and summary.total_reviews is not None:
        resolved_total = summary.total_reviews
    else:
        resolved_total = len(review_items)

    resolved_rating = _rating_value(product_rating)
    if resolved_rating is None and summary is not None:
        resolved_rating = _summary_rating(summary)
    if resolved_rating is not None:
        resolved_rating = round(resolved_rating, 2)

    if resolved_rating is None:
        rating_label = "未知评分"
    elif resolved_rating >= 4.5:
        rating_label = "高满意度"
    elif resolved_rating >= 4.0:
        rating_label = "中等满意度"
    else:
        rating_label = "低满意度"

    return VocSatisfactionMetrics(
        positive_pct=max(0, min(100, positive_pct)),
        negative_pct=max(0, min(100, negative_pct)),
        total_reviews=resolved_total,
        product_rating=resolved_rating,
        rating_label=rating_label,
    )


def merge_weakness_signals(
    signals: VocWeaknessSignalsOutput | dict,
    satisfaction: VocSatisfactionMetrics | dict,
) -> VocWeaknessesOutput:
    """确定性合并弱点语义信号与满意度指标。"""
    signal_model = (
        signals
        if isinstance(signals, VocWeaknessSignalsOutput)
        else VocWeaknessSignalsOutput.model_validate(signals)
    )
    satisfaction_model = (
        satisfaction
        if isinstance(satisfaction, VocSatisfactionMetrics)
        else VocSatisfactionMetrics.model_validate(satisfaction)
    )
    return VocWeaknessesOutput(
        satisfaction_context=VocSatisfactionContext(
            **satisfaction_model.model_dump(),
            assessment=signal_model.satisfaction_assessment,
        ),
        top_issues=signal_model.top_issues,
        unmet_needs=signal_model.unmet_needs,
        balanced_assessment=signal_model.balanced_assessment,
    )
