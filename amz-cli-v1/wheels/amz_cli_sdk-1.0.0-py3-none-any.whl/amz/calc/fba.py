"""US FBA 2026 fulfillment fee calculation.

The rate card and size-tier rules in this module follow Amazon's 2026 US FBA
fulfillment-fee documentation.  All dimensions are accepted in centimetres
and all weights in grams; the Amazon rules themselves are evaluated in inches
and pounds.

fba 参考文档[https://sellercentral.amazon.com/help/hub/reference/external/GABBX6GZPA8MSZGW?initialSessionID=130-5326013-9106749&ld=ELUSSOA-www.doubao.com&pageName=US%3ASD%3AFBA-main&ldStackingCodes=ELUSSOA-www.doubao.com](https://sellercentral.amazon.com/help/hub/reference/external/GABBX6GZPA8MSZGW?initialSessionID=130-5326013-9106749&ld=ELUSSOA-www.doubao.com&pageName=US%3ASD%3AFBA-main&ldStackingCodes=ELUSSOA-www.doubao.com)
"""

from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal, ROUND_CEILING, ROUND_HALF_UP
from math import isfinite

from amz.registry import capability
from amz.schemas.analysis_inputs import CalcFeeInput
from amz.schemas.data_outputs import FeeOutput


GRAMS_PER_POUND = Decimal("453.59237")
CENTIMETRES_PER_INCH = Decimal("2.54")
OUNCES_PER_POUND = Decimal("16")
DIMENSIONAL_WEIGHT_DIVISOR = Decimal("139")

FEE_SCHEDULE_START = date(2026, 1, 15)
PEAK_SEASON_START = date(2026, 10, 15)
FEE_SCHEDULE_END = date(2027, 1, 14)
FUEL_SURCHARGE_START = date(2026, 4, 17)
FUEL_SURCHARGE_RATE = Decimal("0.035")

_CENT = Decimal("0.01")
_PRICE_BAND_INDEX = {"under_10": 0, "10_to_50": 1, "over_50": 2}
_PRICE_BAND_LABEL = {
    "under_10": "<$10",
    "10_to_50": "$10-$50",
    "over_50": ">$50",
}


# Each fee tuple is ordered as: (<$10, $10-$50, >$50).
# For standard sizes, ``tiers`` contains the fee at each upper weight bound.
# Formula tiers contain (base fees, included weight, interval, increment).
FBA_RATE_TABLE: dict[str, dict[str, dict]] = {
    "non_apparel": {
        "non_peak": {
            "small_standard": (
                (2.43, 3.32, 3.58),
                (2.49, 3.42, 3.68),
                (2.56, 3.45, 3.71),
                (2.66, 3.54, 3.80),
                (2.77, 3.68, 3.94),
                (2.82, 3.78, 4.04),
                (2.92, 3.91, 4.17),
                (2.95, 3.96, 4.22),
            ),
            "large_standard": (
                (2.91, 3.73, 3.99),
                (3.13, 3.95, 4.21),
                (3.38, 4.20, 4.46),
                (3.78, 4.60, 4.86),
                (4.22, 5.04, 5.30),
                (4.60, 5.42, 5.68),
                (4.75, 5.57, 5.83),
                (5.00, 5.82, 6.08),
                (5.10, 5.92, 6.18),
                (5.28, 6.10, 6.36),
                (5.44, 6.26, 6.52),
                (5.85, 6.67, 6.93),
            ),
            "large_standard_over_3": ((6.15, 6.97, 7.23), 3.0, 0.25, 0.08),
            "small_bulky": ((6.78, 7.55, 7.55), 1.0, 1.0, 0.38),
            "large_bulky": ((8.58, 9.35, 9.35), 1.0, 1.0, 0.38),
            "extra_large_0_50": ((25.56, 26.33, 26.33), 1.0, 1.0, 0.38),
            "extra_large_50_70": ((36.55, 37.32, 37.32), 51.0, 1.0, 0.75),
            "extra_large_70_150": ((50.55, 51.32, 51.32), 71.0, 1.0, 0.75),
            "extra_large_150_plus": ((194.18, 194.95, 194.95), 151.0, 1.0, 0.19),
        },
        "peak": {
            "small_standard": (
                (2.62, 3.51, 3.77),
                (2.68, 3.61, 3.87),
                (2.76, 3.65, 3.91),
                (2.86, 3.74, 4.00),
                (2.98, 3.89, 4.15),
                (3.03, 3.99, 4.25),
                (3.14, 4.13, 4.39),
                (3.17, 4.18, 4.44),
            ),
            "large_standard": (
                (3.15, 3.97, 4.23),
                (3.39, 4.21, 4.47),
                (3.66, 4.48, 4.74),
                (4.07, 4.89, 5.15),
                (4.52, 5.34, 5.60),
                (4.91, 5.73, 5.99),
                (5.07, 5.89, 6.15),
                (5.33, 6.15, 6.41),
                (5.47, 6.29, 6.55),
                (5.67, 6.49, 6.75),
                (5.84, 6.66, 6.92),
                (6.26, 7.08, 7.34),
            ),
            "large_standard_over_3": ((6.69, 7.51, 7.77), 3.0, 0.25, 0.08),
            "small_bulky": ((7.82, 8.59, 8.59), 1.0, 1.0, 0.38),
            "large_bulky": ((9.62, 10.39, 10.39), 1.0, 1.0, 0.38),
            "extra_large_0_50": ((28.29, 29.06, 29.06), 1.0, 1.0, 0.38),
            "extra_large_50_70": ((39.36, 40.13, 40.13), 51.0, 1.0, 0.75),
            "extra_large_70_150": ((54.97, 55.74, 55.74), 71.0, 1.0, 0.75),
            "extra_large_150_plus": ((202.69, 203.46, 203.46), 151.0, 1.0, 0.19),
        },
    },
    "apparel": {
        "non_peak": {
            "small_standard": (
                (2.62, 3.51, 3.77),
                (2.64, 3.54, 3.80),
                (2.68, 3.59, 3.85),
                (2.81, 3.69, 3.95),
                (3.00, 3.91, 4.17),
                (3.10, 4.09, 4.35),
                (3.20, 4.20, 4.46),
                (3.30, 4.25, 4.51),
            ),
            "large_standard": (
                (3.48, 4.30, 4.56),
                (3.68, 4.50, 4.76),
                (3.90, 4.72, 4.98),
                (4.35, 5.17, 5.43),
                (5.05, 5.87, 6.13),
                (5.22, 6.04, 6.30),
                (5.32, 6.14, 6.40),
                (5.43, 6.25, 6.51),
                (5.78, 6.60, 6.86),
                (5.90, 6.72, 6.98),
                (5.95, 6.77, 7.03),
                (6.08, 6.90, 7.16),
            ),
            "large_standard_over_3": ((6.15, 6.97, 7.23), 3.0, 0.5, 0.16),
            "small_bulky": ((6.78, 7.55, 7.55), 1.0, 1.0, 0.38),
            "large_bulky": ((8.58, 9.35, 9.35), 1.0, 1.0, 0.38),
            "extra_large_0_50": ((25.56, 26.33, 26.33), 1.0, 1.0, 0.38),
            "extra_large_50_70": ((36.55, 37.32, 37.32), 51.0, 1.0, 0.75),
            "extra_large_70_150": ((50.55, 51.32, 51.32), 71.0, 1.0, 0.75),
            "extra_large_150_plus": ((194.18, 194.95, 194.95), 151.0, 1.0, 0.19),
        },
        "peak": {
            "small_standard": (
                (2.85, 3.74, 4.00),
                (2.87, 3.77, 4.03),
                (2.93, 3.84, 4.10),
                (3.06, 3.94, 4.20),
                (3.27, 4.18, 4.44),
                (3.37, 4.36, 4.62),
                (3.49, 4.49, 4.75),
                (3.59, 4.54, 4.80),
            ),
            "large_standard": (
                (3.79, 4.61, 4.87),
                (4.00, 4.82, 5.08),
                (4.23, 5.05, 5.31),
                (4.69, 5.51, 5.77),
                (5.42, 6.24, 6.50),
                (5.59, 6.41, 6.67),
                (5.71, 6.53, 6.79),
                (5.82, 6.64, 6.90),
                (6.22, 7.04, 7.30),
                (6.34, 7.16, 7.42),
                (6.41, 7.23, 7.49),
                (6.54, 7.36, 7.62),
            ),
            "large_standard_over_3": ((6.82, 7.64, 7.90), 3.0, 0.5, 0.16),
            "small_bulky": ((7.82, 8.59, 8.59), 1.0, 1.0, 0.38),
            "large_bulky": ((9.62, 10.39, 10.39), 1.0, 1.0, 0.38),
            "extra_large_0_50": ((28.29, 29.06, 29.06), 1.0, 1.0, 0.38),
            "extra_large_50_70": ((39.36, 40.13, 40.13), 51.0, 1.0, 0.75),
            "extra_large_70_150": ((54.97, 55.74, 55.74), 71.0, 1.0, 0.75),
            "extra_large_150_plus": ((202.69, 203.46, 203.46), 151.0, 1.0, 0.19),
        },
    },
    "dangerous_goods": {
        "non_peak": {
            "small_standard": (
                (3.40, 4.29, 4.55),
                (3.43, 4.36, 4.62),
                (3.48, 4.37, 4.63),
                (3.55, 4.43, 4.69),
                (3.64, 4.55, 4.81),
                (3.65, 4.61, 4.87),
                (3.73, 4.72, 4.98),
                (3.77, 4.78, 5.04),
            ),
            "large_standard": (
                (3.73, 4.55, 4.81),
                (3.94, 4.76, 5.02),
                (4.17, 4.99, 5.25),
                (4.37, 5.19, 5.45),
                (4.82, 5.64, 5.90),
                (5.20, 6.02, 6.28),
                (5.35, 6.17, 6.43),
                (5.49, 6.31, 6.57),
                (5.56, 6.38, 6.64),
                (5.74, 6.56, 6.82),
                (5.90, 6.72, 6.98),
                (6.31, 7.13, 7.39),
            ),
            "large_standard_over_3": ((6.61, 7.43, 7.69), 3.0, 0.25, 0.08),
            "small_bulky": ((7.50, 8.27, 8.27), 1.0, 1.0, 0.38),
            "large_bulky": ((9.30, 10.07, 10.07), 1.0, 1.0, 0.38),
            "extra_large_0_50": ((27.67, 28.44, 28.44), 1.0, 1.0, 0.38),
            "extra_large_50_70": ((39.76, 40.53, 40.53), 51.0, 1.0, 0.75),
            "extra_large_70_150": ((57.68, 58.45, 58.45), 71.0, 1.0, 0.75),
            "extra_large_150_plus": ((218.76, 219.53, 219.53), 151.0, 1.0, 0.19),
        },
        "peak": {
            "small_standard": (
                (3.74, 4.63, 4.89),
                (3.80, 4.73, 4.99),
                (3.88, 4.77, 5.03),
                (3.98, 4.86, 5.12),
                (4.10, 5.01, 5.27),
                (4.14, 5.10, 5.36),
                (4.25, 5.24, 5.50),
                (4.32, 5.33, 5.59),
            ),
            "large_standard": (
                (4.32, 5.14, 5.40),
                (4.56, 5.38, 5.64),
                (4.82, 5.64, 5.90),
                (5.04, 5.86, 6.12),
                (5.51, 6.33, 6.59),
                (5.91, 6.73, 6.99),
                (6.08, 6.90, 7.16),
                (6.24, 7.06, 7.32),
                (6.33, 7.15, 7.41),
                (6.53, 7.35, 7.61),
                (6.70, 7.52, 7.78),
                (7.12, 7.94, 8.20),
            ),
            "large_standard_over_3": ((7.51, 8.33, 8.59), 3.0, 0.25, 0.08),
            "small_bulky": ((9.06, 9.83, 9.83), 1.0, 1.0, 0.38),
            "large_bulky": ((10.86, 11.63, 11.63), 1.0, 1.0, 0.38),
            "extra_large_0_50": ((31.71, 32.48, 32.48), 1.0, 1.0, 0.38),
            "extra_large_50_70": ((43.86, 44.63, 44.63), 51.0, 1.0, 0.75),
            "extra_large_70_150": ((64.04, 64.81, 64.81), 71.0, 1.0, 0.75),
            "extra_large_150_plus": ((230.84, 231.61, 231.61), 151.0, 1.0, 0.19),
        },
    },
}


_CATEGORY_ALIASES = {
    "non_apparel": "non_apparel",
    "non-apparel": "non_apparel",
    "standard": "non_apparel",
    "apparel": "apparel",
    "clothing": "apparel",
    "dangerous_goods": "dangerous_goods",
    "dangerous-goods": "dangerous_goods",
    "hazmat": "dangerous_goods",
}

_SMALL_STANDARD_MAX_OZ = tuple(Decimal(str(value)) for value in (2, 4, 6, 8, 10, 12, 14, 16))
_LARGE_STANDARD_MAX_LB = tuple(
    Decimal(str(value))
    for value in (0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 2.25, 2.5, 2.75, 3)
)


def _as_positive_decimal(name: str, value: float) -> Decimal:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(value) or value <= 0:
        raise ValueError(f"{name} must be a positive finite number")
    return Decimal(str(value))


def _normalise_category(product_type: str | None) -> str:
    if product_type is None:
        return "non_apparel"
    key = product_type.strip().lower().replace(" ", "_")
    try:
        return _CATEGORY_ALIASES[key]
    except KeyError as exc:
        allowed = "non_apparel, apparel/clothing, dangerous_goods/hazmat"
        raise ValueError(f"unsupported product_type {product_type!r}; expected {allowed}") from exc


def _normalise_date(value: date | datetime | str | None) -> date:
    if value is None:
        result = date.today()
    elif isinstance(value, datetime):
        result = value.date()
    elif isinstance(value, date):
        result = value
    elif isinstance(value, str):
        try:
            result = date.fromisoformat(value)
        except ValueError as exc:
            raise ValueError("fulfillment_date must use YYYY-MM-DD") from exc
    else:
        raise TypeError("fulfillment_date must be a date, datetime, ISO date string, or None")

    if not FEE_SCHEDULE_START <= result <= FEE_SCHEDULE_END:
        raise ValueError(
            "the bundled FBA rate card only covers "
            f"{FEE_SCHEDULE_START.isoformat()} through {FEE_SCHEDULE_END.isoformat()}"
        )
    return result


def _price_band(selling_price: Decimal) -> str:
    if selling_price < Decimal("10"):
        return "under_10"
    if selling_price <= Decimal("50"):
        return "10_to_50"
    return "over_50"


def _dimensional_weight_lb(
    longest_in: Decimal,
    median_in: Decimal,
    shortest_in: Decimal,
    *,
    bulky_minimums: bool,
) -> Decimal:
    if bulky_minimums:
        median_in = max(median_in, Decimal("2"))
        shortest_in = max(shortest_in, Decimal("2"))
    return longest_in * median_in * shortest_in / DIMENSIONAL_WEIGHT_DIVISOR


def _determine_size_tier(
    unit_weight_lb: Decimal,
    longest_in: Decimal,
    median_in: Decimal,
    shortest_in: Decimal,
    dimensional_weight_lb: Decimal,
    bulky_dimensional_weight_lb: Decimal,
) -> tuple[str, Decimal, Decimal, bool]:
    """Return tier, fee weight, tier-determination weight, and overmax flag."""
    length_plus_girth = longest_in + Decimal("2") * (median_in + shortest_in)
    standard_shipping_weight = max(unit_weight_lb, dimensional_weight_lb)

    if (
        standard_shipping_weight <= Decimal("1")
        and longest_in <= Decimal("15")
        and median_in <= Decimal("12")
        and shortest_in <= Decimal("0.75")
    ):
        # Amazon charges small-standard fees using unit weight only.
        return "small_standard", unit_weight_lb, standard_shipping_weight, False

    if (
        standard_shipping_weight <= Decimal("20")
        and longest_in <= Decimal("18")
        and median_in <= Decimal("14")
        and shortest_in <= Decimal("8")
    ):
        return "large_standard", standard_shipping_weight, standard_shipping_weight, False

    bulky_shipping_weight = max(unit_weight_lb, bulky_dimensional_weight_lb)
    if (
        bulky_shipping_weight <= Decimal("50")
        and longest_in <= Decimal("37")
        and median_in <= Decimal("28")
        and shortest_in <= Decimal("20")
        and length_plus_girth <= Decimal("130")
    ):
        return "small_bulky", bulky_shipping_weight, bulky_shipping_weight, False

    if (
        bulky_shipping_weight <= Decimal("50")
        and longest_in <= Decimal("59")
        and median_in <= Decimal("33")
        and shortest_in <= Decimal("33")
        and length_plus_girth <= Decimal("130")
    ):
        return "large_bulky", bulky_shipping_weight, bulky_shipping_weight, False

    if bulky_shipping_weight <= Decimal("50"):
        tier = "extra_large_0_50"
    elif bulky_shipping_weight <= Decimal("70"):
        tier = "extra_large_50_70"
    elif bulky_shipping_weight <= Decimal("150"):
        tier = "extra_large_70_150"
    else:
        tier = "extra_large_150_plus"

    is_overmax = tier != "extra_large_150_plus" and (
        longest_in > Decimal("96") or length_plus_girth > Decimal("130")
    )
    fee_weight = unit_weight_lb if tier == "extra_large_150_plus" else bulky_shipping_weight
    return tier, fee_weight, bulky_shipping_weight, is_overmax


def _interval_count(weight_lb: Decimal, included_lb: Decimal, interval_lb: Decimal) -> int:
    excess = weight_lb - included_lb
    if excess <= 0:
        return 0
    return int((excess / interval_lb).to_integral_value(rounding=ROUND_CEILING))


def _base_fee(
    rate_table: dict,
    size_tier: str,
    shipping_weight_lb: Decimal,
    price_index: int,
) -> Decimal:
    if size_tier == "small_standard":
        shipping_weight_oz = shipping_weight_lb * OUNCES_PER_POUND
        for limit, fees in zip(_SMALL_STANDARD_MAX_OZ, rate_table[size_tier], strict=True):
            if shipping_weight_oz <= limit:
                return Decimal(str(fees[price_index]))
        raise ValueError("small-standard shipping weight exceeds 16 oz")

    if size_tier == "large_standard" and shipping_weight_lb <= Decimal("3"):
        for limit, fees in zip(_LARGE_STANDARD_MAX_LB, rate_table[size_tier], strict=True):
            if shipping_weight_lb <= limit:
                return Decimal(str(fees[price_index]))
        raise ValueError("large-standard shipping weight could not be placed in a rate tier")

    rate_key = "large_standard_over_3" if size_tier == "large_standard" else size_tier
    fees, included, interval, increment = rate_table[rate_key]
    intervals = _interval_count(
        shipping_weight_lb,
        Decimal(str(included)),
        Decimal(str(interval)),
    )
    return Decimal(str(fees[price_index])) + Decimal(str(increment)) * intervals


@capability(
    "calc.fba.fee",
    description="US FBA 2026 配送费查表（4 size tier + 燃油附加费）",
    input_model=CalcFeeInput,
    output_model=FeeOutput,
)
def calculate_fee(
    weight_grams: float,
    length_cm: float,
    width_cm: float,
    height_cm: float,
    product_type: str | None = None,
    *,
    selling_price: float,
    fulfillment_date: date | datetime | str | None = None,
    include_fuel_surcharge: bool = True,
) -> dict:
    """Calculate a 2026 US FBA fulfillment fee.

    Args:
        weight_grams: Packaged unit weight in grams.
        length_cm: One packaged dimension in centimetres; order is irrelevant.
        width_cm: One packaged dimension in centimetres; order is irrelevant.
        height_cm: One packaged dimension in centimetres; order is irrelevant.
        product_type: ``non_apparel`` (default), ``apparel``/``clothing``, or
            ``dangerous_goods``/``hazmat``.
        selling_price: Item price in USD. Exactly $10 and $50 use the $10-$50
            rate band.
        fulfillment_date: Date the shipment leaves the fulfillment centre.
            Defaults to today and must be covered by the bundled 2026 card.
        include_fuel_surcharge: Apply the 3.5% surcharge for shipments on or
            after April 17, 2026.

    Returns:
        A fee breakdown including base fee, fuel surcharge, size tier,
        category, price band, season, and weights used.

    Notes:
        SIPP discounts/additional charges and the separate Overmax handling
        fee are not included. ``is_overmax`` identifies units that need the
        separate Overmax calculation.
    """
    unit_weight_g = _as_positive_decimal("weight_grams", weight_grams)
    dimensions_cm = sorted(
        (
            _as_positive_decimal("length_cm", length_cm),
            _as_positive_decimal("width_cm", width_cm),
            _as_positive_decimal("height_cm", height_cm),
        ),
        reverse=True,
    )
    price = _as_positive_decimal("selling_price", selling_price)
    category = _normalise_category(product_type)
    ship_date = _normalise_date(fulfillment_date)
    season = "peak" if ship_date >= PEAK_SEASON_START else "non_peak"
    price_band = _price_band(price)

    longest_in, median_in, shortest_in = (
        value / CENTIMETRES_PER_INCH for value in dimensions_cm
    )
    unit_weight_lb = unit_weight_g / GRAMS_PER_POUND
    dimensional_weight_lb = _dimensional_weight_lb(
        longest_in, median_in, shortest_in, bulky_minimums=False
    )
    bulky_dimensional_weight_lb = _dimensional_weight_lb(
        longest_in, median_in, shortest_in, bulky_minimums=True
    )

    size_tier, fee_weight_lb, tier_weight_lb, is_overmax = _determine_size_tier(
        unit_weight_lb,
        longest_in,
        median_in,
        shortest_in,
        dimensional_weight_lb,
        bulky_dimensional_weight_lb,
    )
    rate_table = FBA_RATE_TABLE[category][season]
    base_fee = _base_fee(
        rate_table,
        size_tier,
        fee_weight_lb,
        _PRICE_BAND_INDEX[price_band],
    ).quantize(_CENT, rounding=ROUND_HALF_UP)

    surcharge_applies = include_fuel_surcharge and ship_date >= FUEL_SURCHARGE_START
    total_fee = (
        base_fee * (Decimal("1") + FUEL_SURCHARGE_RATE)
        if surcharge_applies
        else base_fee
    ).quantize(_CENT, rounding=ROUND_HALF_UP)
    surcharge = total_fee - base_fee

    dim_weight_for_tier = (
        dimensional_weight_lb
        if size_tier in {"small_standard", "large_standard"}
        else bulky_dimensional_weight_lb
    )
    return {
        "fee_usd": float(total_fee),
        "base_fee_usd": float(base_fee),
        "fuel_surcharge_usd": float(surcharge),
        "fuel_surcharge_rate_pct": 3.5 if surcharge_applies else 0.0,
        "size_tier": size_tier,
        "weight_used_g": round(float(fee_weight_lb * GRAMS_PER_POUND), 1),
        "unit_weight_g": round(float(unit_weight_g), 1),
        "dimensional_weight_g": round(float(dim_weight_for_tier * GRAMS_PER_POUND), 1),
        "tier_weight_g": round(float(tier_weight_lb * GRAMS_PER_POUND), 1),
        "is_oversized": size_tier not in {"small_standard", "large_standard"},
        "is_overmax": is_overmax,
        "category": category,
        "price_band": _PRICE_BAND_LABEL[price_band],
        "season": season,
        "fulfillment_date": ship_date.isoformat(),
        "rate_year": 2026,
    }
