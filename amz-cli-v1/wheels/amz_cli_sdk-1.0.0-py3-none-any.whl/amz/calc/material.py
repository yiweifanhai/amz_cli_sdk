"""新品材质门槛的确定性判定。"""

from __future__ import annotations

from amz.envelope import Result, ok
from amz.registry import capability
from amz.schemas.analysis_inputs import CalcMaterialEligibilityInput
from amz.schemas.data_outputs import MaterialEligibilityOutput


@capability("calc.material.eligibility", description="按材质与可开发性结果执行门槛判定", input_model=CalcMaterialEligibilityInput, output_model=MaterialEligibilityOutput)
def material_eligibility(material_analysis: dict) -> Result:
    easy = material_analysis.get("easy_to_develop_mark", False)
    if isinstance(easy, str):
        easy = easy.strip().lower() == "true"
    reason = str(material_analysis.get("material_reason") or "")
    conclusion = str(material_analysis.get("material_conclusion") or "")
    easy_reason = str(material_analysis.get("easy_to_develop_reason") or "")
    if "液体" in reason:
        passed, fail_reason = False, "产品包含液体，涉及安全性检查和检疫流程"
    elif "电子产品" in conclusion:
        passed, fail_reason = False, "产品属于电子产品，涉及复杂生产工艺"
    elif not easy:
        passed, fail_reason = False, f"产品不易改造: {easy_reason}".strip()
    else:
        passed, fail_reason = True, ""
    return ok(data={"material_passed": passed, "material_fail_reason": fail_reason})
