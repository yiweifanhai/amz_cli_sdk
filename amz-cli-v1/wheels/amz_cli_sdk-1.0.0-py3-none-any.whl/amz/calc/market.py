"""
市场画像统计：从竞品列表聚合 → 价格/评分/新品占比/垄断度/卖家结构。

吸收 new_release_process build_dashboard_data.py + amz_agent market-profile.py。
同时也是 market.snapshot 的降级实现。
"""

from __future__ import annotations

import statistics
from datetime import datetime, timezone
from typing import Any

from amz.registry import capability
from amz.schemas.analysis_inputs import (
    CalcMarketOpportunityInput,
    CalcMarketProfileInput,
    CalcMarketStatsInput,
)
from amz.schemas.data_outputs import (
    MarketOpportunityOutput,
    MarketProfileOutput,
    MarketStatsOutput,
)


@capability(
    "calc.market.stats",
    description="从标准化竞品列表计算价格、评分、评论、垄断度与卖家统计",
    input_model=CalcMarketStatsInput,
    output_model=MarketStatsOutput,
)
def calculate_stats(items: list[dict]) -> dict:
    """calc.market.stats

    从 competitors 列表生成市场画像统计。

    Args:
        items: 来自 competing-lookup 的标准化 item 列表，
               每个 item 含 price_usd, rating, count_review, listing_date, brand,
               seller_nation, monthly_sales 等。

    Returns:
        {price, rating, listing_date, reviews, monopoly, sellers, aplus_video_pct, return_rate?}
    """
    if not items:
        return _empty_stats()

    n = len(items)

    # -- 价格 --
    prices = [it.get("price_usd") for it in items if it.get("price_usd")]
    price_sorted = sorted(prices) if prices else []

    price_stats = {
        "p25": _percentile(price_sorted, 25),
        "p50": _percentile(price_sorted, 50),
        "p75": _percentile(price_sorted, 75),
        "band_count": len(_price_bands(prices)),
        "bands": _price_bands_full(prices, n),
    }

    # -- 评分 --
    ratings = [it.get("rating") for it in items if it.get("rating") is not None]
    rating_stats = {
        "avg": round(statistics.mean(ratings), 2) if ratings else None,
        "dist": _rating_distribution(ratings),
    }

    # -- 上架日期 --
    dates = [
        it.get("listing_date") for it in items
        if it.get("listing_date") and isinstance(it.get("listing_date"), str)
    ]
    now = datetime.now(timezone.utc)
    months_since = []
    for d in dates:
        try:
            dt = datetime.fromisoformat(d.replace("Z", "+00:00"))
            months_since.append((now - dt).days / 30.44)
        except (ValueError, TypeError):
            pass

    new_pct = sum(1 for m in months_since if m <= 12) / len(months_since) * 100 if months_since else None
    listing_date_stats = {
        "median_months": round(statistics.median(months_since), 1) if months_since else None,
        "new_release_pct": round(new_pct, 1) if new_pct is not None else None,
    }

    # -- 评论数 --
    reviews = [it.get("count_review") for it in items if it.get("count_review") is not None]
    reviews_stats = {
        "median": int(statistics.median(reviews)) if reviews else None,
        "count_dist": _reviews_distribution(reviews),
    }

    # -- 垄断度 --
    brands = [it.get("brand", "") or "Unknown" for it in items]
    brand_counts: dict[str, int] = {}
    for b in brands:
        brand_counts[b] = brand_counts.get(b, 0) + 1

    sorted_brands = sorted(brand_counts.values(), reverse=True)
    cr10 = sum(sorted_brands[:10]) / n * 100 if sorted_brands else None
    cr20 = sum(sorted_brands[:20]) / n * 100 if sorted_brands else None
    top_brand_share = sorted_brands[0] / n * 100 if sorted_brands else None

    monopoly_stats = {
        "cr10": round(cr10, 1) if cr10 is not None else None,
        "cr20": round(cr20, 1) if cr20 is not None else None,
        "top_brand_share": round(top_brand_share, 1) if top_brand_share is not None else None,
    }

    # -- 卖家结构 --
    nations = [it.get("seller_nation", "") or "Unknown" for it in items]
    cn_count = sum(1 for na in nations if na == "CN")
    amz_count = sum(1 for na in nations if na.lower() in ("amazon", "amz", "us") or "amazon" in na.lower())

    seller_stats = {
        "total": n,
        "cn_pct": round(cn_count / n * 100, 1),
        "amazon_pct": round(amz_count / n * 100, 1),
    }

    return {
        "price": price_stats,
        "rating": rating_stats,
        "listing_date": listing_date_stats,
        "reviews": reviews_stats,
        "monopoly": monopoly_stats,
        "sellers": seller_stats,
        "aplus_video_pct": None,   # 需额外端点支持
        "return_rate": None,       # 需额外端点支持
    }


def lookup_return_rate(keyword: str = "") -> dict:
    """calc.market.return-rate

    退货率品类查表 — 基于关键词子串匹配品类默认费率。
    当前为简化版，后续可接入实际退货率数据源。

    Returns:
        {refund_rate_pct, peer_avg_pct, risk: low|medium|high}
    """
    default_rates = {
        "clothing": (20.0, 15.0, "high"),
        "shoes": (18.0, 14.0, "high"),
        "electronics": (8.0, 6.0, "medium"),
        "home": (6.0, 5.0, "low"),
        "kitchen": (5.0, 4.0, "low"),
        "toys": (7.0, 5.5, "medium"),
        "sports": (6.5, 5.0, "medium"),
        "beauty": (4.0, 3.0, "low"),
        "default": (8.0, 6.0, "medium"),
    }

    metric = default_rates["default"]
    kw = keyword.lower()
    for cat, val in default_rates.items():
        if cat in kw:
            metric = val
            break

    refund_rate, peer_avg, risk = metric
    return {
        "refund_rate_pct": refund_rate,
        "peer_avg_pct": peer_avg,
        "risk": risk,
    }


@capability(
    "calc.market.profile",
    description="把市场统计重组为稳定的 8 维画像",
    input_model=CalcMarketProfileInput,
    output_model=MarketProfileOutput,
)
def calculate_profile(stats: dict, keyword: str = "") -> dict:
    """calc.market.profile

    将 stats 重组为 8 维市场画像结构。纯数据变换，无业务规则。

    Returns:
        {keyword, dimensions: {price, rating, reviews, monopoly, sellers, listing_date, aplus_video, return_rate}}
    """
    return {
        "keyword": keyword,
        "dimensions": {
            "price": stats.get("price", {}),
            "rating": stats.get("rating", {}),
            "reviews": stats.get("reviews", {}),
            "monopoly": stats.get("monopoly", {}),
            "sellers": stats.get("sellers", {}),
            "listing_date": stats.get("listing_date", {}),
            "aplus_video": stats.get("aplus_video_pct"),
            "return_rate": stats.get("return_rate"),
        },
        "overall_score": _profile_completeness_score(stats),
    }


@capability(
    "calc.market.opportunity",
    description="根据市场统计执行确定性机会评分",
    input_model=CalcMarketOpportunityInput,
    output_model=MarketOpportunityOutput,
)
def calculate_opportunity_score(stats: dict, keyword: str = "") -> dict:
    """calc.market.opportunity

    基于市场 stats 计算机会评分。确定性规则引擎。

    Returns:
        {keyword, opportunity_score, gaps, proposals}
    """
    opportunity_score = 60.0  # 基准分

    monopoly = stats.get("monopoly", {})
    if monopoly.get("cr10") is not None and monopoly["cr10"] < 50:
        opportunity_score += 15

    sellers = stats.get("sellers", {})
    cn_pct = sellers.get("cn_pct") if isinstance(sellers, dict) else None
    if cn_pct is not None and cn_pct > 30:
        opportunity_score -= 10

    return {
        "keyword": keyword,
        "opportunity_score": opportunity_score,
        "gaps": [],
        "proposals": [],
    }


def _profile_completeness_score(stats: dict) -> float:
    """画像数据完整度（0-100），避免把缺失数据误写成业务质量分。"""
    checks = (
        bool((stats.get("price") or {}).get("bands")),
        (stats.get("rating") or {}).get("avg") is not None,
        (stats.get("reviews") or {}).get("median") is not None,
        (stats.get("monopoly") or {}).get("cr10") is not None,
        (stats.get("sellers") or {}).get("total", 0) > 0,
        (stats.get("listing_date") or {}).get("median_months") is not None,
        stats.get("aplus_video_pct") is not None,
        stats.get("return_rate") is not None,
    )
    return round(sum(checks) / len(checks) * 100, 1)


# ============================================================================
# 内部工具
# ============================================================================

def _percentile(sorted_data: list, p: int) -> float | None:
    """计算百分位数"""
    if not sorted_data:
        return None
    idx = int(len(sorted_data) * p / 100)
    return sorted_data[min(idx, len(sorted_data) - 1)]


def _price_bands(prices: list[float]) -> list[dict]:
    """价格分桶"""
    if not prices:
        return []
    min_p = min(prices)
    max_p = max(prices)
    if max_p == min_p:
        return [{"label": f"${min_p:.0f}", "min": min_p, "max": max_p, "count": len(prices)}]

    step = (max_p - min_p) / 4
    bands = []
    for i in range(4):
        lo = min_p + step * i
        hi = min_p + step * (i + 1)
        cnt = sum(1 for p in prices if lo <= p <= hi)
        bands.append({"label": f"${lo:.0f}-${hi:.0f}", "min": round(lo, 2), "max": round(hi, 2), "count": cnt})
    return bands


def _price_bands_full(prices: list[float], n: int) -> list[dict]:
    """价格分桶 + 占比"""
    bands = _price_bands(prices)
    for b in bands:
        b["share_pct"] = round(b["count"] / n * 100, 1) if n > 0 else 0
    return bands


def _rating_distribution(ratings: list[float]) -> dict[str, int]:
    """评分分布"""
    dist = {"5": 0, "4": 0, "3": 0, "2": 0, "1": 0}
    for r in ratings:
        bucket = str(min(5, max(1, int(r))))
        dist[bucket] = dist.get(bucket, 0) + 1
    return dist


def _reviews_distribution(reviews: list[int]) -> dict[str, int]:
    """评论数分布"""
    dist = {"<100": 0, "100-500": 0, "500-2000": 0, "2000+": 0}
    for r in reviews:
        if r < 100:
            dist["<100"] += 1
        elif r < 500:
            dist["100-500"] += 1
        elif r < 2000:
            dist["500-2000"] += 1
        else:
            dist["2000+"] += 1
    return dist


def _empty_stats() -> dict:
    return {
        "price": {"p25": None, "p50": None, "p75": None, "band_count": 0, "bands": []},
        "rating": {"avg": None, "dist": {}},
        "listing_date": {"median_months": None, "new_release_pct": None},
        "reviews": {"median": None, "count_dist": {}},
        "monopoly": {"cr10": None, "cr20": None, "top_brand_share": None},
        "sellers": {"total": 0, "cn_pct": None, "amazon_pct": None},
        "aplus_video_pct": None,
        "return_rate": None,
    }
