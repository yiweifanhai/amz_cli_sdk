"""流量地图 ASIN 的确定性维度。"""

from __future__ import annotations

from amz.envelope import Result, ok
from amz.registry import capability
from amz.schemas.analysis_inputs import CalcTrafficCodeInput
from amz.schemas.data_outputs import TrafficCodeOutput


def assign_price_band(price: float | None, bands: list[dict]) -> str:
    if price is None or not bands:
        return "unknown"
    try:
        value = float(price)
    except (TypeError, ValueError):
        return "unknown"
    for band in bands:
        low = float(band.get("lo", 0) or 0)
        high = band.get("hi")
        if high is None or value < float(high):
            if value >= low:
                return str(band.get("label") or "unknown")
    return str(bands[-1].get("label") or "unknown")


def assign_rating_band(rating: float | None) -> str:
    if rating is None:
        return "unknown"
    try:
        value = float(rating)
    except (TypeError, ValueError):
        return "unknown"
    if value < 3.5:
        return "< 3.5"
    if value < 4.0:
        return "3.5-4.0"
    if value < 4.5:
        return "4.0-4.5"
    return "> 4.5"


def assign_brand_origin(seller_nation: str | None) -> str:
    if not seller_nation:
        return "unknown"
    return "CN" if seller_nation.upper() == "CN" else "non-CN"


@capability("calc.traffic.code-dimensions", description="价格带、评分带和品牌来源确定性打标", input_model=CalcTrafficCodeInput, output_model=TrafficCodeOutput)
def code_dimensions(product: dict, price_bands: list[dict]) -> Result:
    return ok(data={
        "price_band": assign_price_band(product.get("price"), price_bands),
        "rating_band": assign_rating_band(product.get("rating")),
        "brand_origin": assign_brand_origin(product.get("seller_nation", product.get("sellerNation"))),
    })
