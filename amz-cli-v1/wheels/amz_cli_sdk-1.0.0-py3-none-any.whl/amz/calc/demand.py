"""需求评估的确定性打分。数据获取由 data/entities 层负责。"""

from __future__ import annotations

from amz.envelope import Result, ok
from amz.registry import capability
from amz.schemas.analysis_inputs import CalcDemandScoreInput
from amz.schemas.data_outputs import DemandScoreOutput


@capability("calc.demand.score", description="基于已获取趋势与市场数据计算需求分", input_model=CalcDemandScoreInput, output_model=DemandScoreOutput)
def score_demand(
    keyword: str,
    google_trends: dict,
    amazon_trend: dict | None = None,
    market_data: dict | None = None,
) -> Result:
    """复刻 amz-demand-assessment 的红蓝海、趋势与 STOP 规则。"""
    gt = google_trends or {}
    target_avg = float(gt.get("target_avg") or 0)
    baseline_avg = float(gt.get("baseline_avg") or 0)
    compare_index = float(
        gt.get("compare_index")
        if gt.get("compare_index") is not None
        else (target_avg / baseline_avg * 100 if baseline_avg > 0 else 0)
    )
    cagr = float(gt.get("cagr_3y") or 0)
    trend_direction = str(gt.get("trend_direction") or "未知")
    trends_ok = bool(gt.get("trends_ok", target_avg > 0 or baseline_avg > 0))

    if not trends_ok or compare_index < 1:
        blue_red_score, rating = 1, "需求太小" if trends_ok else "数据缺失"
    elif compare_index <= 5:
        blue_red_score, rating = 5, "小蓝海"
    elif compare_index <= 10:
        blue_red_score, rating = 4, "大蓝海"
    else:
        blue_red_score, rating = 2, "红海"

    if not trends_ok:
        trend_score = 1
    elif cagr > 30:
        trend_score = 5
    elif cagr > 10:
        trend_score = 4
    elif cagr >= 0:
        trend_score = 3
    else:
        trend_score = 2

    amazon = amazon_trend or None
    external_decline = cagr < 0 and trend_direction in {"下降", "declining"}
    amazon_yoy = amazon.get("yoy_pct") if amazon else None
    internal_decline = (
        float(amazon_yoy) < -10 if amazon_yoy is not None else external_decline
    )
    invalid_or_red = compare_index > 10 or compare_index < 1
    stop = external_decline and internal_decline and invalid_or_red

    market = market_data or {}
    monthly_revenue = market.get("monthly_avg_revenue_usd")
    if monthly_revenue is None:
        market_size = None
    elif float(monthly_revenue) > 100_000:
        market_size = "大市场"
    elif float(monthly_revenue) > 30_000:
        market_size = "中等市场"
    elif float(monthly_revenue) > 10_000:
        market_size = "小市场"
    else:
        market_size = "微型市场"

    data = {
        "keyword": keyword,
        "compare_index": round(compare_index, 2),
        "bluered_rating": rating,
        "target_avg": target_avg,
        "baseline_avg": baseline_avg,
        "yearly": gt.get("yearly", {}),
        "yoy": gt.get("yoy", {}),
        "cagr_3y": cagr,
        "trend_direction": trend_direction,
        "slope_pct": float(gt.get("slope_pct") or 0),
        "has_seasonality": bool(gt.get("has_seasonality", False)),
        "peak_month": gt.get("peak_month"),
        "season_ratio": float(gt.get("season_ratio") or 1),
        "amazon_trend": amazon,
        "search_purchase_ratio_permille": market.get("search_purchase_ratio_permille"),
        "monthly_avg_revenue_usd": monthly_revenue,
        "market_size_rating": market_size,
    }
    return ok(data={
        "block": "demand",
        "score": blue_red_score + trend_score,
        "stop": stop,
        "stop_reason": (
            "站外趋势下降 + 站内搜索下降 + 红海无细分/需求不成立" if stop else None
        ),
        "score_breakdown": {
            "bluered_sub_score": blue_red_score,
            "trend_sub_score": trend_score,
            "reason": f"{rating}(ratio={compare_index:.2f}) + {trend_direction}(CAGR={cagr}%)",
        },
        "data": data,
    })
