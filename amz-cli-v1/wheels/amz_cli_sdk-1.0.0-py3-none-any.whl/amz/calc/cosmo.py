"""COSMO 确定性合并与位置权重计算。"""

from __future__ import annotations

from amz.envelope import Result, ok
from amz.registry import capability
from amz.schemas.analysis_inputs import CalcCosmoMergeInput
from amz.schemas.data_outputs import CalcCosmoMergeOutput


POSITION_WEIGHTS = {
    "title": 5,
    "bulletPoints": 3,
    "review": 2,
    "imageDescription": 1,
    "aPlus": 1,
}

TERM_FIELDS = {
    "product_essence": ("is_a_description", "used_as", "made_of"),
    "functional_utility": ("used_to", "capable_of", "used_for_func"),
    "contextual_mapping": ("used_for_eve", "used_on", "used_in_loc", "used_in_body"),
    "audience_psychographics": (
        "used_for_aud", "used_by", "xis_a", "xinterested_in", "xwant",
        "lifestyle_symbol_of",
    ),
    "ecosystem_economics": ("used_with",),
}


def compute_weighted_score(item: dict) -> int:
    return sum(
        int(item.get(count_field, 0) or 0) * POSITION_WEIGHTS[location]
        for location, count_field in (
            ("title", "title_count"),
            ("bulletPoints", "bullet_points_count"),
            ("review", "review_count"),
            ("imageDescription", "image_description_count"),
            ("aPlus", "a_plus_count"),
        )
    )


@capability("calc.cosmo.merge", description="跨 ASIN COSMO 结果确定性合并", input_model=CalcCosmoMergeInput, output_model=CalcCosmoMergeOutput, requires=["analysis.cosmo.extract"])
def merge_cosmo_results(cosmo_outputs: list[dict]) -> Result:
    """按 ``term + category + field`` 合并，完整保留五类位置统计。"""
    merged: dict[tuple[str, str, str], dict] = {}
    for raw in cosmo_outputs:
        asin = str(raw.get("asin") or "unknown")
        cosmo = raw.get("cosmo") if isinstance(raw.get("cosmo"), dict) else raw
        for category, fields in TERM_FIELDS.items():
            section = cosmo.get(category, {}) or {}
            for field in fields:
                for term_item in section.get(field, []) or []:
                    if isinstance(term_item, dict):
                        term = str(term_item.get("term") or "").strip()
                        location = term_item.get("location", {}) or {}
                    else:
                        term = str(term_item).strip()
                        location = {}
                    if not term:
                        continue
                    key = (term.lower(), category, field)
                    entry = merged.setdefault(key, {
                        "term": term,
                        "cosmo_category": category,
                        "cosmo_field": field,
                        "count": 0,
                        "title_count": 0,
                        "bullet_points_count": 0,
                        "review_count": 0,
                        "image_description_count": 0,
                        "a_plus_count": 0,
                        "asins": [],
                        "weighted_score": 0,
                    })
                    entry["count"] += 1
                    if asin not in entry["asins"]:
                        entry["asins"].append(asin)
                    for location_name, count_field in (
                        ("title", "title_count"),
                        ("bulletPoints", "bullet_points_count"),
                        ("review", "review_count"),
                        ("imageDescription", "image_description_count"),
                        ("aPlus", "a_plus_count"),
                    ):
                        if location.get(location_name):
                            entry[count_field] += 1
                    entry["weighted_score"] = compute_weighted_score(entry)

    # 与 merge.ts 一致：只按 count 降序；Python 排序稳定，平分时保留首次出现顺序。
    terms = sorted(merged.values(), key=lambda item: -item["count"])
    return ok(data={"terms": terms})
