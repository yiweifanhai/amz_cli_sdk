"""
L1 确定性计算层 — 纯函数，无 LLM 依赖，无 IO。

设计原则
--------
- 只接收字段值或标准 DTO，不接收 Entity，不自动触发 data fetch
- 数据不全就返回错误或跳过，不当隐形触发者
- 不关心缓存和状态管理——这些由 entities 层处理
- 计算结果可被 entities lazy 字段通过 ``_writeback()`` 引用

模块清单
--------

============= ==============================================
模块          职责
============= ==============================================
fba           FBA 费率查表（4 tier）
finance       资金效率（4 渠道 ROI/日回报）
keyword       filter_primary / normalize_terms / rank_slope
margin        毛利率（佣金 + FBA + 头程 + 采购）
market        市场画像聚合（价格/评分/新品/垄断/卖家结构）+ 退货率
pricing       价格带分桶 + 缺口
product       新品判定 + 生命周期阶段
risk_rules    风险评估规则引擎（法规触发/类目门槛/品牌/运营 benchmark）
============= ==============================================

用法::

    from amz.calc.margin import calculate_margin
    from amz.calc.fba import calculate_fee
"""

from amz.calc.fba import calculate_fee
from amz.calc.finance import calculate_return_on_capital
from amz.calc.keyword import extract_primary_keywords
from amz.calc.margin import calculate_margin
from amz.calc.market import (
    calculate_opportunity_score,
    calculate_profile,
    calculate_stats,
)
from amz.calc.voc import calculate_satisfaction, merge_weakness_signals

__all__ = [
    "calculate_fee",
    "calculate_margin",
    "calculate_return_on_capital",
    "extract_primary_keywords",
    "calculate_stats",
    "calculate_profile",
    "calculate_opportunity_score",
    "calculate_satisfaction",
    "merge_weakness_signals",
]
