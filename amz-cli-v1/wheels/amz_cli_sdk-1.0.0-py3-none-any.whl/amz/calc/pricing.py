"""
价格带分桶：分析价格分布，识别价格带缺口。

吸收 traffic_map price band 逻辑 + product_dev_v2 价格带缺口。
"""

from __future__ import annotations


def calculate_bands(prices: list[float], band_count: int = 4) -> dict:
    """calc.pricing.band

    Args:
        prices: 价格列表
        band_count: 分桶数

    Returns:
        {bands: [{label, min, max, count, share_pct}], gaps: [{below, above, gap_size}]}
    """
    if not prices or len(prices) < 2:
        return {"bands": [], "gaps": []}

    sorted_prices = sorted(prices)
    min_p = sorted_prices[0]
    max_p = sorted_prices[-1]

    if max_p == min_p:
        return {
            "bands": [{
                "label": f"${min_p:.0f}",
                "min": min_p, "max": max_p,
                "count": len(prices),
                "share_pct": 100.0,
            }],
            "gaps": [],
        }

    n = len(prices)
    step = (max_p - min_p) / band_count

    bands = []
    for i in range(band_count):
        lo = min_p + step * i
        hi = min_p + step * (i + 1) if i < band_count - 1 else max_p
        cnt = sum(1 for p in prices if lo <= p <= hi)
        bands.append({
            "label": f"${lo:.0f}-${hi:.0f}",
            "min": round(lo, 2),
            "max": round(hi, 2),
            "count": cnt,
            "share_pct": round(cnt / n * 100, 1),
        })

    # 价格带缺口：相邻两带之间 count=0 的
    gaps = []
    for i in range(len(bands) - 1):
        if bands[i]["count"] == 0 or bands[i + 1]["count"] == 0:
            gap_size = bands[i + 1]["min"] - bands[i]["max"]
            if gap_size > 0:
                gaps.append({
                    "below": bands[i]["label"],
                    "above": bands[i + 1]["label"],
                    "gap_size": round(gap_size, 2),
                })

    return {"bands": bands, "gaps": gaps}
