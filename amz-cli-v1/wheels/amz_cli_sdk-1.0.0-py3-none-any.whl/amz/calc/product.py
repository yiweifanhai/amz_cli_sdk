"""
产品指标计算：新品判定、生命周期阶段。

吸收 traffic_map product_metrics.py 实现。
"""

from __future__ import annotations

from datetime import datetime, timezone


def calculate_metrics(
    listing_date: str | None = None,
    monthly_sales: int | None = None,
    launch_date: str | None = None,
) -> dict:
    """calc.product.metrics

    产品生命周期指标：上架月数、新品判定、已验证新品判定。

    Returns:
        {months_since_listing, is_new, is_verified_new, stage}
    """
    now = datetime.now(timezone.utc)

    # 上架月数
    months_since = None
    ld = listing_date or launch_date
    if ld:
        try:
            dt = datetime.fromisoformat(ld.replace("Z", "+00:00"))
            months_since = (now - dt).days / 30.44
        except (ValueError, TypeError):
            pass

    # 新品判定（≤6 月）
    is_new = months_since is not None and months_since <= 6

    # 已验证新品判定
    is_verified_new = False
    if is_new and monthly_sales:
        if months_since <= 3 and monthly_sales > 10000:
            is_verified_new = True
        elif months_since <= 6 and monthly_sales > 20000:
            is_verified_new = True

    # 生命周期阶段
    stage = "mature"
    if months_since is not None:
        if months_since <= 6:
            stage = "new"
        elif months_since <= 24:
            stage = "growth"
        else:
            stage = "mature"

    return {
        "months_since_listing": round(months_since, 1) if months_since is not None else None,
        "is_new": is_new,
        "is_verified_new": is_verified_new,
        "stage": stage,
    }
