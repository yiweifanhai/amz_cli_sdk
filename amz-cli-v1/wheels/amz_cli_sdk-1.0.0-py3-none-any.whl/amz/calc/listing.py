"""Listing 的确定性文本工具。"""

from __future__ import annotations

import re

from amz.envelope import Result, ok
from amz.registry import capability
from amz.schemas.data_outputs import WordDiffOutput


@capability("calc.listing.word-diff", description="按词和空白计算 Listing LCS 差异", output_model=WordDiffOutput)
def word_diff(old_text: str, new_text: str) -> Result:
    """复刻 Listing UI 的 LCS word diff，返回 equal/added/removed 段。"""
    old_words = [part for part in re.split(r"(\s+)", old_text) if part]
    new_words = [part for part in re.split(r"(\s+)", new_text) if part]
    rows, cols = len(old_words), len(new_words)
    dp = [[0] * (cols + 1) for _ in range(rows + 1)]
    for i in range(1, rows + 1):
        for j in range(1, cols + 1):
            if old_words[i - 1] == new_words[j - 1]:
                dp[i][j] = dp[i - 1][j - 1] + 1
            else:
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1])
    stack = []
    i, j = rows, cols
    while i or j:
        if i and j and old_words[i - 1] == new_words[j - 1]:
            stack.append({"text": old_words[i - 1], "type": "equal"})
            i -= 1
            j -= 1
        elif j and (not i or dp[i][j - 1] >= dp[i - 1][j]):
            stack.append({"text": new_words[j - 1], "type": "added"})
            j -= 1
        else:
            stack.append({"text": old_words[i - 1], "type": "removed"})
            i -= 1
    stack.reverse()
    merged = []
    for segment in stack:
        if merged and merged[-1]["type"] == segment["type"]:
            merged[-1]["text"] += segment["text"]
        else:
            merged.append(segment)
    return ok(data={"segments": merged})
