"""内置能力发现。

集中维护需要通过导入触发 ``@capability`` 的模块，SDK、CLI 与测试共用，
避免只有 CLI 能看到完整注册表。
"""

from __future__ import annotations

from importlib import import_module


_BUILTIN_MODULES = (
    "amz.data.product",
    "amz.data.keyword",
    "amz.data.market",
    "amz.data.supply",
    "amz.data.category",
    "amz.data.search",
    "amz.data.ads",
    "amz.calc.fba",
    "amz.calc.margin",
    "amz.calc.finance",
    "amz.calc.cosmo",
    "amz.calc.demand",
    "amz.calc.keyword",
    "amz.calc.market",
    "amz.calc.traffic",
    "amz.calc.listing",
    "amz.calc.material",
    "amz.calc.voc",
    "amz.analysis.voc",
    "amz.analysis.keyword",
    "amz.analysis.listing",
    "amz.analysis.innovation",
    "amz.analysis.demand",
    "amz.analysis.cosmo",
    "amz.analysis.market_gap",
    "amz.analysis.traffic",
)


def load_builtin_capabilities() -> None:
    """幂等导入所有内置能力模块。"""
    for module_name in _BUILTIN_MODULES:
        import_module(module_name)
    # 实体 lazy getter 注册为能力（幂等；需在 data/calc/analysis 导入后执行）
    from amz.entities.bridge import register_entity_capabilities

    register_entity_capabilities()
    # composite 能力（validate/compile/scaffold）+ 已发现 pipeline 注册为 composite.<name>
    import_module("amz.composite.capabilities")
    from amz.composite import register_pipelines

    register_pipelines()

    # 依赖完整性校验：全部注册完成后统一检查 requires 引用。
    from amz.registry import registry

    issues = registry.validate_requires()
    if issues:
        raise RuntimeError(
            "capability requires validation failed:\n  " + "\n  ".join(issues)
        )
