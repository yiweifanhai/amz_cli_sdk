"""
composite 原子能力：validate / compile / scaffold。

这三者是 harness（Claude Code 等）创作 composite 的确定性工具：

- ``composite.validate`` — 校验 PipelineSpec（结构化 + 能力存在性），自检循环用
- ``composite.compile`` — 校验后写盘 ``spec.json`` + 生成 ``pipeline.py``，并注册进 registry
- ``composite.scaffold`` — 生成空模板（起始骨架）

自然语言 → spec 的**推理**由 harness 经 ``agents/composite-authoring/SKILL.md`` 完成；
这里只提供确定性落地工具，不在 SDK 内调 LLM。
"""

from __future__ import annotations

import json
import os
from pathlib import Path

from amz.envelope import Code, Result, err, ok
from amz.registry import capability
from amz.composite.spec import PipelineSpec


def _target_base(target_dir: str = "") -> Path:
    """确定 pipeline 落盘根目录：显式 > AMZ_COMPOSITE_DIR > 用户目录。"""
    if target_dir:
        return Path(target_dir).expanduser()
    env = os.environ.get("AMZ_COMPOSITE_DIR")
    if env:
        return Path(env).expanduser()
    return Path(os.path.expanduser("~/.amz/composite"))


def _coerce(spec) -> PipelineSpec:
    """dict 或 PipelineSpec → PipelineSpec。"""
    return spec if isinstance(spec, PipelineSpec) else PipelineSpec(**spec)


# 输出 schema（满足「每个能力必须有结构化 output_schema」的约定）
_VALIDATE_OUTPUT = {
    "type": "object",
    "properties": {
        "valid": {"type": "boolean"},
        "errors": {"type": "array", "items": {"type": "string"}},
        "spec": {"type": "object", "additionalProperties": True},
    },
}
_COMPILE_OUTPUT = {
    "type": "object",
    "properties": {
        "name": {"type": "string"},
        "capability": {"type": "string"},
        "path": {"type": "string"},
        "python_code": {"type": "string"},
        "registered": {"type": "boolean"},
    },
}
_SCAFFOLD_OUTPUT = {
    "type": "object",
    "properties": {
        "name": {"type": "string"},
        "path": {"type": "string"},
        "next": {"type": "string"},
    },
}


# ---------------------------------------------------------------------------
# validate
# ---------------------------------------------------------------------------

@capability(
    "composite.validate",
    description="校验 PipelineSpec：结构化校验 + 能力 ID 存在性校验，返回 errors 列表",
    category="composite",
    output_schema=_VALIDATE_OUTPUT,
)
def validate_spec(spec: PipelineSpec) -> Result:
    """``{spec}`` → ``{valid, errors, spec}``。"""
    try:
        p = _coerce(spec)
    except Exception as e:
        return err(Code.ERROR_PARAM, f"invalid PipelineSpec: {e}")

    errors = p.validate(check_capabilities=True)
    return ok(data={"valid": not errors, "errors": errors, "spec": p.model_dump()})


# ---------------------------------------------------------------------------
# compile
# ---------------------------------------------------------------------------

@capability(
    "composite.compile",
    description="校验并落地 PipelineSpec：写 spec.json + 生成 pipeline.py + 注册为 composite.<name>",
    category="composite",
    output_schema=_COMPILE_OUTPUT,
)
def compile_spec(spec: PipelineSpec, target_dir: str = "") -> Result:
    """``{spec, target_dir?}`` → ``{name, path, python_code, registered, errors?}``。

    校验失败返回 ``code=ERROR_PARAM`` 且 ``data.errors`` 列出错误（不落盘）。
    """
    try:
        p = _coerce(spec)
    except Exception as e:
        return err(Code.ERROR_PARAM, f"invalid PipelineSpec: {e}")

    errors = p.validate(check_capabilities=True)
    if errors:
        return err(
            Code.ERROR_PARAM,
            "spec validation failed",
            data={"errors": errors, "spec": p.model_dump()},
        )

    base = _target_base(target_dir)
    d = base / p.name
    d.mkdir(parents=True, exist_ok=True)

    (d / "spec.json").write_text(
        json.dumps(p.model_dump(), ensure_ascii=False, indent=2, default=str),
        encoding="utf-8",
    )
    python_code = p.to_python()
    (d / "pipeline.py").write_text(python_code, encoding="utf-8")

    # 注册进 registry（幂等）
    from amz.composite import register_pipeline

    cap_id = register_pipeline(p)

    return ok(
        data={
            "name": p.name,
            "capability": cap_id,
            "path": str(d),
            "python_code": python_code,
            "registered": True,
        }
    )


# ---------------------------------------------------------------------------
# scaffold
# ---------------------------------------------------------------------------

@capability(
    "composite.scaffold",
    description="生成新 pipeline 空模板（spec.json + pipeline.py 骨架）到用户 composite 目录",
    category="composite",
    output_schema=_SCAFFOLD_OUTPUT,
)
def scaffold(name: str, category: str = "", description: str = "") -> Result:
    """``{name, category?, description?}`` → ``{name, path}``。"""
    if not name or not name.replace("_", "").replace("-", "").isalnum():
        return err(Code.ERROR_PARAM, f"invalid pipeline name: {name!r}")

    base = _target_base("")
    d = base / name
    d.mkdir(parents=True, exist_ok=True)

    spec = PipelineSpec(
        name=name,
        description=description or f"{name} — 待补充描述",
        category=category or "",
        version="v1",
        params_schema={"type": "object", "properties": {}},
        steps=[],
    )
    (d / "spec.json").write_text(
        json.dumps(spec.model_dump(), ensure_ascii=False, indent=2, default=str),
        encoding="utf-8",
    )
    (d / "pipeline.py").write_text(
        _scaffold_py(name, description or name), encoding="utf-8"
    )

    return ok(data={"name": name, "path": str(d), "next": "编辑 spec.json 或 pipeline.py"})


def _scaffold_py(name: str, description: str) -> str:
    return f'''"""
{description}

手写模板：直接声明 Pipeline；或编辑同目录 spec.json 走声明式路径。
"""
from amz.composite.base import Pipeline, Step

PIPELINE = Pipeline(
    name={name!r},
    description={description!r},
    category="",
    version="v1",
    steps=[
        # Step("fetch", capability="product.get", mode="map",
        #      item_key="asin", map_from="params"),
    ],
)
'''
