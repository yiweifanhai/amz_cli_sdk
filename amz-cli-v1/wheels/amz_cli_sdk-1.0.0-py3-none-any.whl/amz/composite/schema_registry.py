"""
schema_registry — 步骤产物 schema 解析与渲染器推断。

把 ``schema_ref`` 解析为 (JSON Schema, renderer_hint)。renderer_hint 由产物形状
推导，供通用 viewer 按 schema 选渲染组件，做到零手写 viewer：

- ``table`` — ``{"items": [dict, ...]}``（逐项记录 → 表格）
- ``list``  — 裸列表
- ``text``  — 字符串（LLM 文本 / 摘要 → 文本块）
- ``json``  — dict 或其他（→ JSON 树）
- ``empty`` — None / 空
"""

from __future__ import annotations

from typing import Any


def resolve_output_schema(step: Any, pipeline_name: str) -> tuple[str, dict | None]:
    """解析步骤输出 schema，返回 ``(schema_ref, json_schema_or_none)``。

    优先级：显式 ``output_schema`` > capability 的 ``output_schema`` > None。
    ``step`` 是 ``base.Step`` 或 ``spec.StepSpec``（都有 capability/output_schema/name）。
    """
    explicit = getattr(step, "output_schema", None)
    if explicit:
        return f"{pipeline_name}.{getattr(step, 'name', 'step')}.v1", explicit

    capability = getattr(step, "capability", None)
    if capability:
        from amz.registry import registry

        cap = registry.get(capability)
        if cap is not None and cap.output_schema:
            return f"{capability}.output", cap.output_schema

    return f"{pipeline_name}.{getattr(step, 'name', 'step')}.v1", None


def infer_renderer(data: Any, schema: dict | None = None) -> str:
    """由产物形状推断渲染器类型（schema 仅作辅助，主判据是 data 本身）。"""
    if data is None:
        return "empty"

    if isinstance(data, str):
        return "text"

    if isinstance(data, list):
        return "list"

    if isinstance(data, dict):
        items = data.get("items")
        if isinstance(items, list):
            # 空列表或全 dict 元素 → 表格（保持结构稳定）；含非 dict 元素 → 列表
            if items and not all(isinstance(x, dict) for x in items):
                return "list"
            return "table"
        if "items" in data:
            return "table"
        return "json"

    # 数字 / 布尔等标量 → 文本
    return "text"


def table_columns(data: Any) -> list[str]:
    """从 ``{"items": [dict,...]}`` 提取并集列名，供表格渲染。"""
    items = None
    if isinstance(data, dict):
        items = data.get("items")
    if not isinstance(items, list):
        return []
    cols: list[str] = []
    seen: set[str] = set()
    for it in items:
        if isinstance(it, dict):
            for k in it.keys():
                if k not in seen:
                    seen.add(k)
                    cols.append(k)
    return cols
