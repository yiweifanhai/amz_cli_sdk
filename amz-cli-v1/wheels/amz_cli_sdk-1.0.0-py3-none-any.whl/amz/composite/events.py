"""
composite 事件流 — PipelineRunner 进度事件的类型化定义。

``PipelineRunner.run(..., on_event=cb)`` 按顺序发射以下事件类型：

- ``run.started``     — run 开始（含 pipeline/run_id/params 摘要）
- ``step.started``    — 某步开始执行
- ``step.item.done``  — map 模式单个 item 完成
- ``step.done``       — 某步完成（含 elapsed_ms / status）
- ``step.failed``     — 某步失败（含 error）
- ``run.done``        — run 结束（含 success / elapsed_ms）

事件为 Pydantic 模型，可 JSON 序列化，供 CLI 实时打印、FastAPI SSE、静态 viewer 消费。
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

EventType = Literal[
    "run.started",
    "step.started",
    "step.item.done",
    "step.done",
    "step.failed",
    "run.done",
]


class RunEvent(BaseModel):
    """单条进度事件。"""

    type: EventType
    run_id: str
    pipeline: str = ""
    step: str = ""
    item: str = ""            # map 模式的 item_key 值
    status: str = ""          # ok | failed | skipped | cached | running
    elapsed_ms: float = 0.0
    error: str = ""
    detail: dict[str, Any] = Field(default_factory=dict)

    def to_sse(self) -> str:
        """序列化为 SSE ``data:`` 行（不含换行注入）。"""
        import json

        payload = json.dumps(self.model_dump(), ensure_ascii=False, default=str)
        return f"data: {payload}\n\n"


def event(
    type_: EventType,
    run_id: str,
    pipeline: str = "",
    step: str = "",
    item: str = "",
    status: str = "",
    elapsed_ms: float = 0.0,
    error: str = "",
    detail: dict[str, Any] | None = None,
) -> RunEvent:
    """便捷构造事件。``detail`` 为附加信息（如 params 摘要）。"""
    return RunEvent(
        type=type_,
        run_id=run_id,
        pipeline=pipeline,
        step=step,
        item=item,
        status=status,
        elapsed_ms=elapsed_ms,
        error=error,
        detail=detail or {},
    )
