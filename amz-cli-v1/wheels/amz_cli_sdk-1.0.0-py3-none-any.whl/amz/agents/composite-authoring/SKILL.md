# Composite Authoring — 把一段流程变成固定 Workflow

目标：把用户用**自然语言描述的一段固定流程**，编译成一个可执行的 composite
pipeline（SOP），并落盘到 `~/.amz/composite/`。

你是 LLM，本 skill 只提供「怎么把话翻译成 spec」的知识；确定性落地由
`composite.validate` / `composite.compile` 两个工具完成，不要在 SDK 内再调 LLM。

## 核心心智模型：三种积木模式

每条 pipeline 的步骤不外乎三种：

| 模式 | 含义 | 函数/能力输入 | 产出 |
|---|---|---|---|
| `map` | 对列表逐项执行同一操作，并发 | 每项 `item` + 匹配到的依赖项 | `{"items": [...], "meta": {total, ok, failed}}` |
| `reduce` | 收集上游全部 item，聚合为一份 | 全部 item + 依赖 data | 单份 dict |
| `batch` | 单次调用，不拆分 | run 参数 + 依赖 data | 单份 dict |

**绝大多数 SOP 步骤是 `map`**：给一个列表 → 逐项处理 → 产出列表。框架自动处理
并发 + item 路由（`item_key` 匹配），你只需声明数据流。

## 创作流程

1. **选积木**：`amz capabilities` 看能力目录（id + description + input/output schema）。
2. **看语法**：`amz composite spec-schema` 打印 `PipelineSpec` 的 JSON Schema。
3. **写 spec**：在 `~/.amz/composite/<name>/spec.json` 写声明式描述（见下）。
4. **自检**：`amz composite validate <spec.json>` → 有 error 就改。
5. **落地**：`amz composite compile <spec.json>` → 生成 `pipeline.py` + 注册能力。
6. **运行**：`amz composite run <name> --param asins=B0X,B0Y`（或 `registry.invoke("composite.<name>", {...})`）。

## spec.json 结构

```json
{
  "name": "product_analysis",
  "description": "一批 ASIN → 市场分析报告",
  "category": "product",
  "version": "v1",
  "params_schema": {"type": "object", "properties": {"asins": {"type": "array", "items": {"type": "string"}}}},
  "steps": [
    {
      "name": "product_info",
      "capability": "product.get",
      "mode": "map",
      "item_key": "asin",
      "map_from": "params",
      "list_key": "asins",
      "concurrency": 5,
      "ttl_hours": 24,
      "description": "逐 ASIN 抓详情"
    }
  ]
}
```

### StepSpec 关键字段

| 字段 | 必填 | 说明 |
|---|---|---|
| `name` | ✅ | 步骤名（也是 artifact 名） |
| `capability` | 见下 | registry 能力 ID；与手写 `fn` 二选一（spec 里只能写 capability） |
| `mode` | — | `batch`(默认) / `map` / `reduce` |
| `item_key` | map 时 | map 匹配 item 的字段（如 `asin`） |
| `map_from` | map/reduce 时 | 从哪取列表：`"params"` 或上游步骤名；默认 `depends[0]` |
| `list_key` | — | `map_from="params"` 时参数里的列表键（默认 `item_key + "s"`） |
| `depends` | — | 依赖的步骤名列表 |
| `inputs` | — | 显式端口绑定（capability 步骤把上游数据喂进哪） |
| `description` | — | 这块干什么（可视化展示用，建议写） |
| `concurrency` | — | map 并发数（默认 5） |
| `optional` | — | 失败是否阻断（默认 false） |
| `ttl_hours` | — | 产物缓存小时（默认 24） |

`capability` 步骤：输入参数默认 `map` = 当前 item、`batch/reduce` = run 参数；跨步骤
取数用 `inputs`：

```json
{
  "name": "voc",
  "capability": "analysis.voc.strengths",
  "mode": "map",
  "item_key": "asin",
  "map_from": "product_info",
  "depends": ["product_info", "reviews"],
  "inputs": {
    "product_info": {"source": "product_info"},
    "reviews": {"source": "reviews", "field": "items"}
  }
}
```

`inputs` 里 `source` 是上游步骤名或 `"params"`；`field` 取该上游产物的某个字段；
`source="params"` 时用 `key` 指定参数键。

## 校验规则（validate 会拦的错）

- 步骤名唯一；`depends` / `map_from` 必须指向存在的步骤（或 `"params"`）
- `map` 必须有 `item_key`；`map`/`reduce` 必须有 `map_from` 或 `depends`
- `capability` 必须在 registry 里存在（`amz capabilities` 能看到）
- 不能有环

## Few-shot 示例

### 例 1：一批 ASIN 抓详情 + 评论（纯数据 map）

```json
{
  "name": "batch_enrich",
  "description": "一批 ASIN → 详情 + 评论",
  "category": "product",
  "steps": [
    {"name": "details", "capability": "product.get", "mode": "map", "item_key": "asin", "map_from": "params", "concurrency": 5},
    {"name": "reviews", "capability": "product.reviews", "mode": "map", "item_key": "asin", "map_from": "params", "concurrency": 3}
  ]
}
```

### 例 2：详情 → 单品 VOC → 市场聚合（map + reduce）

```json
{
  "name": "product_voc_flow",
  "description": "详情→评论→单品VOC→市场报告",
  "category": "product",
  "steps": [
    {"name": "info", "capability": "product.get", "mode": "map", "item_key": "asin", "map_from": "params"},
    {"name": "reviews", "capability": "product.reviews", "mode": "map", "item_key": "asin", "map_from": "params"},
    {"name": "voc", "capability": "analysis.voc.strengths", "mode": "map", "item_key": "asin", "map_from": "info",
     "depends": ["info", "reviews"],
     "inputs": {"product_info": {"source": "info"}, "reviews": {"source": "reviews", "field": "items"}}},
    {"name": "report", "capability": "analysis.market.success-factors", "mode": "reduce", "map_from": "voc",
     "depends": ["voc"], "inputs": {"leaders": {"source": "voc"}}}
  ]
}
```

## 注意事项

- **能力 ID 必须是 `amz capabilities` 里真实存在的**；拿不准就先查目录再写。
- `analysis.*` 能力通常需要结构化 dict 输入，用 `inputs` 把上游产物字段喂对（见例 2）。
- 拿不准某能力要什么输入时，看 `amz capabilities --id <capability_id>` 的 input_schema。
- 写完一定先 `validate` 再 `compile`，compile 对非法 spec 会拒绝落盘并回 errors。
