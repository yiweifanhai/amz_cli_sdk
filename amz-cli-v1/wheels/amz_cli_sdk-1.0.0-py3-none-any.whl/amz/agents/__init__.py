"""
L3 Agent 层 — 知识密集型 Subagent，编排由 LLM 实时决策。

核心定位：与 composite 的最大区别不在「步骤内部是否调 LLM」，而在「步骤间的编排由谁决定」。
Agent 的下一步做什么、条件判断、是否循环重试，全部由 LLM 在运行时动态决定。

与 composite/ 的区别
--------------------
- **composite**：编排关系固定（SOP 预声明），步骤内部可调 LLM。同输入必定同路径，100% 可复现
- **agents**：编排由 LLM 实时决策（选步骤/判条件/做循环），步骤内部也可调 LLM。同输入可能不同路径

互相调用：
  - agent 可以把 composite 当黑盒工具调用（输入确定、输出格式固定、SOP 确定）
  - composite 内部某个 step 也可以调 agent（步骤位置固定，但需要 agent 做复杂判断）

目录约定
--------
每个 agent 一个子目录::

    agents/{name}/
        SKILL.md          # Agent 定义（必需）— 领域知识 + 判断流程
        {name}.py         # Agent 专属工具脚本（可选）
        result.json       # 上次运行缓存（运行时生成）

Agent 可以调用 L0-L2 所有原子能力（data/calc/analysis），也可调其他 agent 组成复合流程。

已安装的 Agent
--------------

================== ==============================================
Agent              说明
================== ==============================================
risk-entry         准入风险评估（合规+平台），458 行领域知识
risk-ip            IP 风险评估（专利/商标/版权），299 行领域知识
risk-operational   运营风险评估（9 维分析），369 行领域知识
================== ==============================================

用法::

    # 通过 registry 统一入口
    result = registry.invoke("agent.risk.entry", {"asin": "B0XXXX"})

    # 获取 SKILL.md 路径供 Claude 读取
    from amz.agents import get_agent_skill
    skill_path = get_agent_skill("risk-entry")
"""

from pathlib import Path

_AGENTS_DIR = Path(__file__).parent


def list_agents() -> list[str]:
    """列出所有已安装的 agent 名称。"""
    agents = []
    for d in _AGENTS_DIR.iterdir():
        if d.is_dir() and (d / "SKILL.md").exists():
            agents.append(d.name)
    return sorted(agents)


def get_agent_skill(agent_name: str) -> str | None:
    """获取 agent 的 SKILL.md 路径。"""
    skill_path = _AGENTS_DIR / agent_name / "SKILL.md"
    if skill_path.exists():
        return str(skill_path)
    return None
