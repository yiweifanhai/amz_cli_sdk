"""
统一返回信封（Envelope）：所有 SDK 能力统一返回 Result{code, message, data, meta}。

对应 sellersprite OpenAPI 格式，SDK 侧归一化所有上游响应。
"""

from __future__ import annotations

import time
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field


class Code(str, Enum):
    """统一错误码"""
    OK = "OK"
    ERROR_PARAM = "ERROR_PARAM"              # 参数校验失败
    ERROR_AUTH = "ERROR_AUTH"                # 认证失败（401）
    ERROR_NOT_FOUND = "ERROR_NOT_FOUND"      # 资源不存在（404）
    ERROR_UPSTREAM = "ERROR_UPSTREAM"        # 上游服务异常（502/503/重试耗尽/空响应）
    ERROR_RATE_LIMIT = "ERROR_RATE_LIMIT"    # 限流（429）
    ERROR_LLM = "ERROR_LLM"                  # LLM 调用失败（超时/降级耗尽）
    ERROR_MISSING_FIELDS = "ERROR_MISSING_FIELDS"  # Calc/Analysis 输入字段不完整
    ERROR_CACHE_MISS = "ERROR_CACHE_MISS"    # 缓存未命中
    ERROR_SERVER_INTERNAL = "ERROR_SERVER_INTERNAL"  # SDK 内部异常


class Meta(BaseModel):
    """Result 元信息"""
    capability: str = ""
    version: str = ""
    elapsed_ms: float = 0.0
    from_cache: bool = False
    upstream: str = ""          # 实际数据源标识（如 "sellersprite", "aggregate"）
    hint: str = ""              # 降级建议
    usage: dict[str, Any] = Field(default_factory=dict)  # LLM tokens/成本
    enriched: list[str] = Field(default_factory=list)    # 本次 enrich 的字段
    missing: list[str] = Field(default_factory=list)     # 缺失的依赖字段


class Result(BaseModel):
    """统一返回信封"""
    code: Code
    message: str = ""
    data: Any = None
    meta: Meta = Field(default_factory=Meta)

    model_config = {"arbitrary_types_allowed": True}


def ok(data: Any = None, **meta_kwargs) -> Result:
    """构造成功结果"""
    meta = Meta(**meta_kwargs) if meta_kwargs else Meta()
    return Result(code=Code.OK, data=data, meta=meta)


def err(code: Code, message: str = "", data: Any = None, **meta_kwargs) -> Result:
    """构造错误结果"""
    meta = Meta(**meta_kwargs) if meta_kwargs else Meta()
    return Result(code=code, message=message, data=data, meta=meta)


# ---------------------------------------------------------------------------
# 业务异常（能力内部抛出，顶层 capability() 包装为 Result）
# ---------------------------------------------------------------------------

class AmzError(Exception):
    """SDK 业务异常基类"""


class ParamError(AmzError):
    """参数校验异常 → Code.ERROR_PARAM"""


class AuthError(AmzError):
    """认证异常 → Code.ERROR_AUTH"""


class NotFoundError(AmzError):
    """资源不存在 → Code.ERROR_NOT_FOUND"""


class UpstreamError(AmzError):
    """上游服务异常 → Code.ERROR_UPSTREAM"""
    def __init__(self, source: str, status: int | None, message: str, hint: str = ""):
        super().__init__(message)
        self.source = source
        self.status = status
        self.hint = hint


class RateLimitError(AmzError):
    """限流异常 → Code.ERROR_RATE_LIMIT"""


class LLMError(AmzError):
    """LLM 调用异常 → Code.ERROR_LLM"""
    def __init__(self, provider: str, model: str, cause: str):
        super().__init__(f"[{provider}/{model}] {cause}")
        self.provider = provider
        self.model = model
        self.cause = cause


class MissingFieldsError(AmzError):
    """Calc/Analysis 所需的已物化字段不完整。"""

    def __init__(self, *fields: str):
        self.fields = [field for field in fields if field]
        super().__init__(", ".join(self.fields))


# ---------------------------------------------------------------------------
# HTTP 状态码 → Code 映射
# ---------------------------------------------------------------------------

HTTP_CODE_MAP: dict[int, Code] = {
    400: Code.ERROR_PARAM,
    401: Code.ERROR_AUTH,
    403: Code.ERROR_UPSTREAM,       # 上游禁用
    404: Code.ERROR_NOT_FOUND,
    422: Code.ERROR_PARAM,
    429: Code.ERROR_RATE_LIMIT,
    500: Code.ERROR_UPSTREAM,
    502: Code.ERROR_UPSTREAM,
    503: Code.ERROR_UPSTREAM,
    504: Code.ERROR_UPSTREAM,
}


def code_from_http(status: int) -> Code:
    """HTTP 状态码 → 信封错误码"""
    return HTTP_CODE_MAP.get(status, Code.ERROR_UPSTREAM)
