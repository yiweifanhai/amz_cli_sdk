"""
能力 I/O 的显式 JSON Schema 声明。

背景
----
``registry._infer_input_model`` 只能从函数签名推导出标量参数的 schema；
对 ``dict`` / ``list[dict]`` 参数会退化为裸 ``{"type": "object"}``，harness
无法知道要传哪些字段。本包为这些能力提供**显式输入模型**（``analysis_inputs``）
与 **data/calc 层缺失的输出模型**（``data_outputs``），挂载到
``@capability(input_model=..., output_model=...)`` 后：

- ``amz capabilities`` 导出的目录携带完整、结构化的 I/O schema
- ``registry.invoke()`` 按 schema 做输入校验与类型强制

约定
----
- 所有模型 ``extra="allow"``：schema 只做形状声明，不拦截真实数据里多出的字段
- 所有字段有默认值：data 层返回的 dict 缺字段时不炸（模型仅用于声明/文档）
- 输出模型不参与数据校验，仅用于生成 JSON Schema 与 harness 文档
"""

from amz.schemas.data_outputs import (
    AdsFunnelOutput,
    CategorySearchOutput,
    CategoryTreeOutput,
    CompetingItemOutput,
    CompetitorsOutput,
    KeywordMinerItemOutput,
    KeywordMinerOutput,
    KeywordReverseItemOutput,
    KeywordReverseOutput,
    KeywordTrendsOutput,
    NrPageOutput,
    ProductInfoOutput,
    ProductSearchOutput,
    RefinementsOutput,
    ReviewItemOutput,
    ReviewsOutput,
    RufusOutput,
    SnapshotOutput,
    SupplySearchOutput,
    WebSearchOutput,
    # calc 层输出
    CalcCosmoMergeOutput,
    DemandScoreOutput,
    KeywordGapOutput,
    MaterialEligibilityOutput,
    TrafficCodeOutput,
    WordDiffOutput,
)
from amz.schemas.analysis_inputs import (
    CalcCosmoMergeInput,
    CalcDemandScoreInput,
    CalcKeywordGapInput,
    CalcMaterialEligibilityInput,
    CalcTrafficCodeInput,
    ClassifyAsinInput,
    CompareInnovationInput,
    CosmoClassifyInput,
    CosmoExtractInput,
    DemandAssessInput,
    DimensionInput,
    GoogleTrendsInput,
    MaterialAnalysisInput,
    RefinementDimensionsInput,
    KeywordClusterInput,
    KeywordGapInput,
    KeywordItemInput,
    KeywordRelevanceInput,
    KeywordScoreInput,
    ListingAllocateInput,
    ListingMicroInsertInput,
    ListingPartRewriteInput,
    ListingRewriteInput,
    ListingTextInput,
    MarketGapInput,
    MarketProposalsInput,
    MarketSuccessFactorsInput,
    MarketTimingInput,
    MaterialAssessInput,
    PriceBandInput,
    ProductInfoInput,
    ReviewItemInput,
    TrafficAnalysisInput,
    VocInput,
    VocStrengthsInput,
    VocWeaknessesInput,
)
from amz.schemas.voc import (
    InnovationAdvantage,
    ProductVoc,
    ProductVocListing,
    ProductVocReview,
    PurchaseMotivation,
    ReviewStarShare,
    ReviewSummary,
    UnmetNeed,
    UseScenario,
    UserPersona,
    VocIssue,
    VocSatisfactionContext,
    VocSatisfactionInput,
    VocSatisfactionMetrics,
    VocStrengthsAnalysisInput,
    VocStrengthsOutput,
    VocUseInsightsAnalysisInput,
    VocUseInsightsOutput,
    VocWeaknessSignalsInput,
    VocWeaknessSignalsOutput,
    VocWeaknessesOutput,
)

__all__ = [
    # data 层输出
    "ProductInfoOutput", "CompetingItemOutput", "CompetitorsOutput",
    "SnapshotOutput", "KeywordReverseItemOutput", "KeywordReverseOutput",
    "KeywordMinerItemOutput", "KeywordMinerOutput", "KeywordTrendsOutput",
    "CategoryTreeOutput", "CategorySearchOutput", "SupplySearchOutput",
    "AdsFunnelOutput", "WebSearchOutput", "ReviewItemOutput", "ReviewsOutput",
    "RufusOutput", "RefinementsOutput", "NrPageOutput", "ProductSearchOutput",
    # calc 层输出
    "CalcCosmoMergeOutput", "DemandScoreOutput", "KeywordGapOutput",
    "MaterialEligibilityOutput", "TrafficCodeOutput", "WordDiffOutput",
    # 共享输入形状
    "ProductInfoInput", "ReviewItemInput", "KeywordItemInput",
    "ListingTextInput", "PriceBandInput", "DimensionInput",
    "RefinementDimensionsInput", "GoogleTrendsInput", "MaterialAnalysisInput",
    # 能力级输入模型
    "VocInput", "VocStrengthsInput", "VocWeaknessesInput",
    "CosmoExtractInput", "MaterialAssessInput", "CompareInnovationInput",
    "KeywordRelevanceInput", "KeywordGapInput", "ListingAllocateInput",
    "ClassifyAsinInput", "TrafficAnalysisInput",
    "CalcDemandScoreInput", "CalcKeywordGapInput",
    "CalcMaterialEligibilityInput", "CalcTrafficCodeInput", "CalcCosmoMergeInput",
    "CosmoClassifyInput", "KeywordScoreInput", "KeywordClusterInput",
    "ListingRewriteInput", "ListingMicroInsertInput", "ListingPartRewriteInput",
    "DemandAssessInput", "MarketTimingInput",
    "MarketSuccessFactorsInput", "MarketGapInput", "MarketProposalsInput",
    # Product VOC 公共模型
    "ProductVocListing", "ProductVocReview", "ReviewStarShare", "ReviewSummary",
    "VocSatisfactionInput", "VocSatisfactionMetrics", "VocSatisfactionContext",
    "VocStrengthsAnalysisInput", "VocWeaknessSignalsInput",
    "VocUseInsightsAnalysisInput", "InnovationAdvantage", "VocStrengthsOutput",
    "VocIssue", "UnmetNeed", "VocWeaknessSignalsOutput",
    "VocWeaknessesOutput", "UseScenario",
    "UserPersona", "PurchaseMotivation", "VocUseInsightsOutput", "ProductVoc",
]
