"""
输入类型 → 产出能力 的 provenance 表（依赖的单一事实来源）。

背景
----
``analysis.*`` / ``calc.*`` 是纯函数：语义输入由调用方保证。这些语义输入
（product_info / reviews / 趋势 / 竞品列表…）在 ``analysis_inputs`` 里已有
结构化类型。本表把「输入形状类型」映射到「产出该形状的 canonical 能力」，
``registry.register()`` 据此**自动推导**能力的 ``requires``，新人加能力时
只要复用这些类型，依赖就会自动带出，不会漏标。

约定
----
- 键是**输入形状类型**（Pydantic 模型类），值是产出它的能力 ID 列表。
- 只收录**无歧义的叶子数据依赖**。同一形状在不同流程里由不同能力产出时
  （如 ``KeywordItemInput`` 在 score/gap/cluster 里语义不同），**不收录**，
  由该能力显式写 ``requires``。
- ``requires`` 是「建议前置」，非强制执行；最终 ``requires`` =
  显式手写 ∪ 自动推导（去重、手写在前）。
"""

from __future__ import annotations

from amz.schemas.analysis_inputs import (
    GoogleTrendsInput,
    ListingTextInput,
    MaterialAnalysisInput,
    ProductInfoInput,
    RefinementDimensionsInput,
    ReviewItemInput,
)
from amz.schemas.data_outputs import CompetingItemOutput

# 键 = 输入形状类型；值 = 产出该形状的 canonical 能力 ID。
PROVENANCE: dict[type, list[str]] = {
    ProductInfoInput: ["product.get"],
    ReviewItemInput: ["product.reviews"],
    ListingTextInput: ["product.get"],
    RefinementDimensionsInput: ["product.refinements"],
    GoogleTrendsInput: ["keyword.trends"],
    MaterialAnalysisInput: ["analysis.material.assess"],
    CompetingItemOutput: ["market.competitors"],
}

# 有意不收录（同一形状的产出能力随流程变化，必须由能力显式声明 requires）：
#   KeywordItemInput  —— score(←keyword.miner) / gap(←keyword.score) / cluster(←keyword.miner)
#   PriceBandInput     —— 上游价格带透传，无单一 canonical 产出
#   DimensionInput     —— 由 analysis.asin.discover-dimensions 产出，但作为输入时语义为「已选维度」
