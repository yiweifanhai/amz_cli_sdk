"""
类型驱动投影：Entity / dict → 能力 InputModel（composite 零胶水的基础设施）。

设计
----
每个能力通过 ``input_model`` 声明自己的最小输入形状。本模块让这个声明
**自解释**：字段上用 ``json_schema_extra`` 标注投影来源——

- ``entity_field="attr"`` —— 从投影源对象的属性（dict 则为键）取值
- ``projection="method"``  —— 调用投影源对象的**无参方法**做取值/类型转换
  （逃生口，用于 dict→tuple 这类需要转换的字段）
- 模型级 ``json_schema_extra={"entity_source": "product"}`` —— 声明主投影
  实体类型（``Entity.entity_type``），供 registry 派生与 composite autowire 消歧

投影器 ``project()`` 是唯一的实现（``Entity.project_to()`` 只是转发）：

- **只读**：只取 ``src`` 上的值，绝不触发 enrich / fetch。字段不全就返回
  ``None``（必填字段取不到）或跳过（可选字段取不到），补齐依赖永远由调用方
  （entities 包装层 / composite 显式步骤）负责。
- **递归**：BaseModel 类型字段自动对同一 ``src`` 递归投影；``list[Model]``
  字段逐项投影，投影失败的项丢弃。
- **纯派生物**：registry 注册期扫描元数据派生 ``entity_sources``，没有第二张
  手写映射表。
"""

from __future__ import annotations

import types
from typing import Any, Union, get_args, get_origin

from pydantic import BaseModel

# 投影元数据键（写在 input_model 字段 / 模型的 json_schema_extra 里）
ENTITY_FIELD = "entity_field"
PROJECTION = "projection"
ENTITY_SOURCE = "entity_source"


def model_entity_sources(model: type[BaseModel]) -> list[str]:
    """模型级 ``entity_source``（写在 ``model_config.json_schema_extra``）。"""
    cfg = getattr(model, "model_config", None)
    raw = cfg.get("json_schema_extra") if cfg is not None else None
    extra = dict(raw or {})
    src = extra.get(ENTITY_SOURCE, [])
    if isinstance(src, str):
        return [src]
    return [s for s in (src or []) if isinstance(s, str)]


def collect_entity_sources(model: type[BaseModel]) -> list[str]:
    """收集模型级 + 字段级（含嵌套模型）的 entity_source，去重保序。"""
    found: list[str] = []
    for s in model_entity_sources(model):
        if s not in found:
            found.append(s)
    for info in model.model_fields.values():
        extra = dict(info.json_schema_extra or {})
        src = extra.get(ENTITY_SOURCE)
        for s in ([src] if isinstance(src, str) else (src or [])):
            if s and s not in found:
                found.append(s)
        inner = _unwrap_optional(info.annotation)
        nested = _nested_model(inner)
        if nested is not None:
            for s in collect_entity_sources(nested):
                if s not in found:
                    found.append(s)
    return found


def has_projection_hints(model: type[BaseModel]) -> bool:
    """该输入模型是否带任何投影元数据（含嵌套模型）。"""
    if model_entity_sources(model):
        return True
    for info in model.model_fields.values():
        if _field_hints(info):
            return True
        nested = _nested_model(_unwrap_optional(info.annotation))
        if nested is not None and has_projection_hints(nested):
            return True
    return False


def project(src: Any, input_cls: type[BaseModel]) -> dict | None:
    """从 ``src`` 按 ``input_cls`` 的投影元数据构造输入 dict。

    Args:
        src: 投影源 —— Entity 实例或 dict（SDK 字段名空间）；``None`` 直接失败。
        input_cls: 能力的 input_model。

    Returns:
        投影出的输入 dict（只含投影到的字段）；**必填字段投影不到时返回
        None**（表示"该源不可投影"，调用方决定报错还是先 enrich）。可选
        字段投影不到则跳过，留给 params / 默认值。
    """
    if src is None:
        return None
    out: dict[str, Any] = {}
    for name, info in input_cls.model_fields.items():
        hints = _field_hints(info)
        explicit = bool(hints)
        nested_model = _nested_model(_unwrap_optional(info.annotation))
        if not explicit and nested_model is None:
            continue  # 无投影元数据 → 留给 params / 默认值

        value: Any = None
        if hints.get(PROJECTION):
            value = _call_projection(src, hints[PROJECTION])
        elif hints.get(ENTITY_FIELD):
            value = _get_value(src, hints[ENTITY_FIELD])
        elif nested_model is not None:
            # BaseModel 类型字段且无显式元数据 → 对同一 src 递归投影
            value = project(src, nested_model)

        if value is None:
            if info.is_required() and explicit:
                return None  # 声明了来源却取不到，且必填 → 不可投影
            continue
        value = _coerce_nested(value, info.annotation)
        if value is None:
            if info.is_required():
                return None
            continue
        out[name] = value
    return out


# ---------------------------------------------------------------------------
# 内部工具
# ---------------------------------------------------------------------------


def _field_hints(info: Any) -> dict[str, str]:
    """取字段上投影相关的 json_schema_extra 条目。"""
    extra = dict(getattr(info, "json_schema_extra", None) or {})
    return {k: extra[k] for k in (ENTITY_FIELD, PROJECTION) if extra.get(k)}


def _get_value(src: Any, name: str) -> Any:
    if isinstance(src, dict):
        return src.get(name)
    return getattr(src, name, None)


def _call_projection(src: Any, method_name: str) -> Any:
    if isinstance(src, dict):
        return None  # dict 源不支持方法投影
    fn = getattr(src, method_name, None)
    if not callable(fn):
        return None
    try:
        return fn()
    except Exception:
        return None  # 转换失败视同"字段不可用"，由调用方决定报错/补齐


def _unwrap_optional(annotation: Any) -> Any:
    origin = get_origin(annotation)
    args = get_args(annotation)
    if origin in (Union, types.UnionType):
        non_none = [a for a in args if a is not type(None)]
        if len(non_none) == 1:
            return non_none[0]
    return annotation


def _nested_model(annotation: Any) -> type[BaseModel] | None:
    """注解是（或包含）BaseModel 子类时返回它：``X`` / ``list[X]`` → X。"""
    if isinstance(annotation, type) and issubclass(annotation, BaseModel):
        return annotation
    origin = get_origin(annotation)
    args = get_args(annotation)
    if origin is not None and args:
        elem = args[0]
        if isinstance(elem, type) and issubclass(elem, BaseModel):
            return elem
    return None


def _coerce_nested(value: Any, annotation: Any) -> Any:
    """把投影出的值适配到注解形状：BaseModel 递归投影、list[Model] 逐项投影。"""
    inner = _unwrap_optional(annotation)
    nested = _nested_model(inner)
    if nested is None:
        return value
    origin = get_origin(inner)
    if origin is None:
        # X 直接类型：已是实例 → 保留；否则（dict/对象）递归投影
        if isinstance(value, nested):
            return value
        return project(value, nested)
    # list[X] / tuple[X, ...]：逐项投影，失败项丢弃
    if not isinstance(value, (list, tuple)):
        return value  # 类型不符，交给校验层报错
    items: list[Any] = []
    for v in value:
        if isinstance(v, nested):
            items.append(v)
            continue
        p = project(v, nested)
        if p is not None:
            items.append(p)
    return items
