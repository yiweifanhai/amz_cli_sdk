"""Analysis 原子能力的共享输出契约。

LLM provider 只负责生成文本；Analysis 层负责判断结构化结果是否真的可用。
空对象、空数组或缺失 ``json`` 不得被 Pydantic 默认值伪装成成功结果。
"""

from __future__ import annotations

from typing import Any, TypeVar

from pydantic import BaseModel


AnalysisOutput = TypeVar("AnalysisOutput", bound=BaseModel)


class AnalysisContractError(ValueError):
    """LLM 响应不满足 Analysis 原子能力契约。"""


def require_json(response: Any, *, allow_empty: bool = False) -> Any:
    """从 ``chat_json`` 响应中提取非空 JSON。"""
    if not isinstance(response, dict) or "json" not in response:
        raise AnalysisContractError("LLM response is missing the 'json' payload")
    raw = response["json"]
    if not isinstance(raw, (dict, list)):
        raise AnalysisContractError(
            f"LLM JSON payload must be object or array, got {type(raw).__name__}"
        )
    if not allow_empty and not raw:
        raise AnalysisContractError("LLM returned an empty JSON payload")
    return raw


def parse_structured(
    response: Any,
    output_model: type[AnalysisOutput],
    *,
    allow_empty: bool = False,
) -> AnalysisOutput:
    """提取并校验一个 Pydantic 结构化输出。"""
    raw = require_json(response, allow_empty=allow_empty)
    if not isinstance(raw, dict):
        raise AnalysisContractError(
            f"{output_model.__name__} requires a JSON object"
        )
    return output_model.model_validate(raw)
