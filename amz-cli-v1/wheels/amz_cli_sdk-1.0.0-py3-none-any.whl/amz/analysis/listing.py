"""
Listing 生成：全量改写 / 微插入 / 位置分配 / 局部改写。

吸收 listing_agent lib/llm/prompts 实现。
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from amz.envelope import Result, ok, err, Code
from amz.registry import capability
from amz.infra.llm import chat_json
from amz.analysis.base import parse_structured
from amz.schemas.analysis_inputs import (
    ListingAllocateInput,
    ListingMicroInsertInput,
    ListingPartRewriteInput,
    ListingRewriteInput,
)


class _ListingModel(BaseModel):
    model_config = ConfigDict(extra="ignore")


class ListingOutput(_ListingModel):
    """全量 Listing 改写输出。"""

    title: str  # 改写后的标题
    bullet_points: list[str] = Field(default_factory=list)  # 改写后的五点描述


class TextInsertionOutput(_ListingModel):
    """单文本微插入输出。"""

    text: str  # 插入后的完整文本
    inserted: list[str] = Field(default_factory=list)  # 实际插入的片段列表


class MicroInsertOutput(_ListingModel):
    """联合契约：兼容完整 Listing 与旧版单文本微插入。"""

    title: str | None = None  # 插入后的标题（完整 Listing 模式）
    bullet_points: list[str] = Field(default_factory=list)  # 插入后的五点（完整 Listing 模式）
    text: str | None = None  # 插入后的文本（单文本模式）
    inserted: list[str] = Field(default_factory=list)  # 实际插入的片段列表


class AllocationOutput(_ListingModel):
    """关键词到 Listing 各位置的分配结果。"""

    title: list[str] = Field(default_factory=list)  # 分配给标题的关键词
    bp1: list[str] = Field(default_factory=list)  # 分配给卖点 1 的关键词
    bp2: list[str] = Field(default_factory=list)  # 分配给卖点 2 的关键词
    bp3: list[str] = Field(default_factory=list)  # 分配给卖点 3 的关键词
    bp4: list[str] = Field(default_factory=list)  # 分配给卖点 4 的关键词
    bp5: list[str] = Field(default_factory=list)  # 分配给卖点 5 的关键词
    unassigned: list[str] = Field(default_factory=list)  # 未分配（不建议埋入）的关键词


class PartRewriteOutput(_ListingModel):
    """局部改写输出。"""

    text: str  # 局部改写后的文本


def _json_output(prompt: str, output_model: type[_ListingModel], model: str, temperature: float) -> Result:
    try:
        result = chat_json(
            prompt=prompt, json_schema=output_model.model_json_schema(),
            model=model, temperature=temperature,
        )
        parsed = parse_structured(result, output_model)
        return ok(data=parsed.model_dump())
    except Exception as exc:
        return err(Code.ERROR_LLM, str(exc))


# ---------------------------------------------------------------------------
# 全量改写（对齐 listing-rewrite.ts）
# ---------------------------------------------------------------------------

LISTING_REWRITE_PROMPT = """# Role: Amazon Listing 优化改写专家

# Task:
基于现有产品 Listing 和关键词分析结果，对 Listing 进行优化改写。
保留原文的优点和准确信息，同时融入关键词提升搜索排名。

# 原始 Listing:
**标题**: {old_title}
**五点描述**:
{old_bullets}
**价格**: {price}

# 关键词分析结果（按优先级分层）:
### S 级关键词（必须出现在标题中）:
{s_keywords}
### A 级关键词（优先在标题或首条 Bullet Point 中）:
{a_keywords}
### B 级关键词（分散融入 Bullet Points）:
{b_keywords}
### C 级关键词（可选融入，不勉强）:
{c_keywords}

# 改写规范:

1. **改写原则**:
   - 基于原文改写，不是从零生成
   - 保留原文中准确的产品信息和卖点
   - 自然融入关键词，不影响可读性和语义通顺
   - 改写幅度适中：有明显优化但不面目全非

2. **标题规范**:
   - 长度 150-200 字符
   - 首字母大写（介词和冠词除外）
   - 不使用特殊字符（!@#$%）
   - 不包含促销词（Best, Cheapest, #1）
   - 品牌名保留在最前面
   - S 级关键词必须自然融入标题

3. **五点描述规范**:
   - 每条以大写关键词短语开头
   - 每条 200-250 字符
   - 突出一个核心卖点
   - A 级关键词优先融入前两条
   - B 级关键词分散在各条中
   - 使用具体数据和描述

4. **关键词融入策略**:
   - S 级：必须出现在标题中
   - A 级：优先在标题或首条 Bullet Point 中
   - B 级：分散融入五点描述
   - C 级：自然契合时融入，不勉强

# 输出格式 (纯 JSON):
```json
{{
  "title": "改写后的标题",
  "bullet_points": [
    "KEYWORD PHRASE - Description of benefit 1",
    "KEYWORD PHRASE - Description of benefit 2",
    "KEYWORD PHRASE - Description of benefit 3",
    "KEYWORD PHRASE - Description of benefit 4",
    "KEYWORD PHRASE - Description of benefit 5"
  ]
}}
```"""


# ---------------------------------------------------------------------------
# 微插入（对齐 listing-micro-insert.ts）
# ---------------------------------------------------------------------------

MICRO_INSERT_PROMPT = """# Role: Amazon Listing 微调编辑器

你是一个精准的文本微调编辑器，不是创作者。你的任务是将指定关键词自然融入 Listing 文本，做最小幅度的改动。

# 插入计划:
{insert_plan}

# 硬约束（必须遵守）:
1. **只修改需要插入关键词的部分**，其余文本保持原样一字不差
2. **不要改变任何 Bullet 的主题和核心卖点**
3. **不要删除已有的关键词**
4. **每条 Bullet 的改动不超过 15 个单词**
5. **保持每条 Bullet 不超过 250 字符**
6. **Title 不超过 200 字符**
7. 没有被分配关键词的 Bullet，原文照抄不动

# 插入技巧:
- 将关键词融入现有句子，替换同义表述或扩展描述
- 如果原文说 "cooking tools"，可以改为 "cooking tools and baking utensils"
- 优先在句尾或并列结构处插入
- 保持语法正确和自然流畅

# 输出格式 (纯 JSON):
```json
{{
  "title": "修改后的完整标题",
  "bullet_points": [
    "BP1 文本（修改后或原文）",
    "BP2 文本",
    "BP3 文本",
    "BP4 文本",
    "BP5 文本"
  ]
}}
```"""


# ---------------------------------------------------------------------------
# 位置分配（对齐 listing-allocate.ts — LLM 版本）
# ---------------------------------------------------------------------------

LISTING_ALLOCATE_PROMPT = """# Role: Amazon Listing 关键词位置分配助手

# Task:
将以下缺失关键词分配到 Listing 的最佳位置（Title 或 BP1-5），基于语义相关性。

# 当前 Listing:
**Title**: {title}
{bullets_text}

# 待分配的缺失关键词:
{keywords}

# 分配规则:
1. 基于每条 Bullet 的主题/卖点，将关键词分配到语义最相关的位置
2. 每条 Bullet Point 最多分配 3 个关键词（避免单条过度修改）
3. Title 只分配最重要的核心词（一般 1-2 个）
4. 如果某个词无法合理分配到任何位置，放入 unassigned
5. 尽量均匀分散，不要把大量词堆到同一条

# 输出格式 (纯 JSON):
```json
{{
  "title": ["分配到标题的词"],
  "bp1": ["分配到BP1的词"],
  "bp2": ["分配到BP2的词"],
  "bp3": ["分配到BP3的词"],
  "bp4": ["分配到BP4的词"],
  "bp5": ["分配到BP5的词"],
  "unassigned": ["无合适位置的词"]
}}
```"""


# ---------------------------------------------------------------------------
# 局部改写（对齐 listing-part-rewrite.ts — 新增能力）
# ---------------------------------------------------------------------------

LISTING_PART_REWRITE_PROMPT = """# Role: Amazon Listing 微调编辑器

你是一个精准的文本微调编辑器，不是创作者。你的任务是将指定关键词**插入**到现有文本中，做**最小幅度**的改动。

# 产品信息
- 原始标题: {product_title}

# 当前要微调的部分: {part_label}
{current_text}

# 需要插入的关键词:
{keywords_text}

# 该部分已有的关键词（按重要性排序，不要删除或移动它们）:
{existing_keywords}

# Listing 其他部分（参考）:
{other_parts}

# 硬约束（必须遵守）:
1. **只在需要插入关键词的位置做改动**，其余文本保持原样一字不差
2. **不要删除已有的关键词**，不要改变已有关键词的顺序和位置
3. **改动不超过 {max_change} 个单词**——只增加或替换必要的少量词
4. **{part_label}不超过 {max_chars} 字符**
5. **越重要的关键词放越靠前的位置**
6. **语法正确、英文流畅**

# 插入技巧:
- 融入现有句子结构，替换同义表述或在并列结构处扩展
- 优先在逗号后、并列结构处、句尾插入
- 如果原文说 "leather case"，可以改为 "leather case holder" 来插入 "holder"
- 不要重新组织句子结构，保持原文的表述框架

# 输出:
直接输出微调后的{part_label}文本，不要加任何前缀、标签或解释。只输出纯文本。"""


# ---------------------------------------------------------------------------
# 能力注册
# ---------------------------------------------------------------------------

@capability(
    "analysis.listing.rewrite",
    description="Listing 全量改写（基于关键词分层策略）",
    input_model=ListingRewriteInput,
    output_model=ListingOutput,
    requires=["product.get"],
)
def listing_rewrite(
    title: str,
    bullet_points: list[str],
    keywords: dict | None = None,
    price: str = "",
    image_url: str = "",
    feedback: str = "",
) -> Result:
    """analysis.listing.rewrite — 全量改写

    Args:
        title: 原标题
        bullet_points: 原五点描述
        keywords: {{S: [...], A: [...], B: [...], C: [...]}} 关键词分层
        price: 价格
        image_url: 产品图（暂未使用）
    """
    kw = keywords or {"S": [], "A": [], "B": [], "C": []}

    prompt = LISTING_REWRITE_PROMPT.format(
        old_title=title,
        old_bullets="\n".join(f"{i+1}. {bp}" for i, bp in enumerate(bullet_points)),
        s_keywords=", ".join(kw.get("S", [])) or "无",
        a_keywords=", ".join(kw.get("A", [])) or "无",
        b_keywords=", ".join(kw.get("B", [])) or "无",
        c_keywords=", ".join(kw.get("C", [])) or "无",
        price=price or "unknown",
    )

    if feedback:
        prompt += f"\n\n# 用户修改意见（基于上次结果继续调整）\n{feedback}"
    return _json_output(prompt, ListingOutput, model="pro", temperature=0.4)


@capability(
    "analysis.listing.micro-insert",
    description="在文本中自然插入关键词（微插入，最小改动）",
    input_model=ListingMicroInsertInput,
    output_model=MicroInsertOutput,
    requires=["product.get"],
)
def listing_micro_insert(
    title: str = "",
    bullet_points: list[str] | None = None,
    insert_plan: dict | None = None,
    text: str = "",
    keywords: list[str] | None = None,
    feedback: str = "",
) -> Result:
    """analysis.listing.micro-insert — 微插入

    两种调用方式：
    1. 传入 insert_plan（推荐）: {{title: [kw1], bp1: [kw2], bp2: [], ...}}
    2. 传入 text + keywords（兼容旧版）: 在 text 中插入 keywords

    Args:
        title: 原标题
        bullet_points: 原五点描述
        insert_plan: 详细的插入计划
        text: 兼容模式 — 要修改的文本
        keywords: 兼容模式 — 要插入的关键词
    """
    bullet_points = bullet_points or []

    # 兼容旧版调用
    if text and not insert_plan:
        prompt = f"""# Role: Amazon Listing 微调编辑器

将以下关键词自然融入文本，做最小幅度改动。

Text: {text}
Keywords to insert: {", ".join(keywords or [])}

Constraints: keep original meaning and tone. Only modify where needed.

Return JSON: {{"text": "modified text", "inserted": ["keyword1", "keyword2"]}}"""
        # 兼容模式的输出与完整 Listing 不同，单独做结构校验。
        return _json_output(prompt, TextInsertionOutput, model="lite", temperature=0.3)

    # 新版：构建插入计划
    plan = insert_plan or {}

    # 构建插入计划文本
    plan_lines = []
    title_kws = plan.get("title", [])
    if title_kws:
        plan_lines.append(f'**Title** — 需插入: {", ".join(title_kws)}')
        plan_lines.append(f"原文: {title}")
    else:
        plan_lines.append(f"**Title** — 无需修改\n原文: {title}")

    for i, bp in enumerate(bullet_points):
        bp_key = f"bp{i+1}"
        bp_kws = plan.get(bp_key, [])
        if bp_kws:
            plan_lines.append(f'**BP{i+1}** — 需插入: {", ".join(bp_kws)}')
            plan_lines.append(f"原文: {bp}")
        else:
            plan_lines.append(f"**BP{i+1}** — 无需修改\n原文: {bp}")

    insert_plan_text = "\n".join(plan_lines)

    prompt = MICRO_INSERT_PROMPT.format(insert_plan=insert_plan_text)
    if feedback:
        prompt += f"\n\n# 用户修改意见（基于上次微调结果继续调整）\n{feedback}"
    return _json_output(prompt, ListingOutput, model="pro", temperature=0.3)


@capability(
    "analysis.listing.allocate",
    description="关键词位置分配（LLM 语义分配，Title + BP1-5）",
    input_model=ListingAllocateInput,
    output_model=AllocationOutput,
    requires=["analysis.keyword.gap"],
)
def listing_allocate(
    listing: dict,
    missing_keywords: list[str],
    use_llm: bool = True,
) -> Result:
    """analysis.listing.allocate — 位置分配

    Args:
        listing: {{title, bullet_points: []}}
        missing_keywords: 需分配的关键词
        use_llm: True=LLM 语义分配, False=确定性规则分配
    """
    title = listing.get("title", "")
    bps = listing.get("bullet_points", [])
    # 输出协议固定为 BP1-BP5；不能把关键词分配到无法返回的 BP6+。
    n_bps = 5

    if not use_llm:
        # 确定性规则：短词放 title，长词均匀分配到各 BP
        assigned_title = []
        assigned_bps = [[] for _ in range(n_bps)]

        for kw in missing_keywords:
            words = len(kw.split())
            if words <= 3 and len(assigned_title) < 5:
                assigned_title.append(kw)
            else:
                bp_idx = min(range(len(assigned_bps)), key=lambda i: len(assigned_bps[i]))
                assigned_bps[bp_idx].append(kw)

        return ok(data={
            "title": assigned_title,
            "bp1": assigned_bps[0],
            "bp2": assigned_bps[1],
            "bp3": assigned_bps[2],
            "bp4": assigned_bps[3],
            "bp5": assigned_bps[4],
            "unassigned": [],
        })

    # LLM 语义分配
    bullets_text = "\n".join(f"BP{i+1}: {bp}" for i, bp in enumerate(bps[:5]))

    prompt = LISTING_ALLOCATE_PROMPT.format(
        title=title,
        bullets_text=bullets_text,
        keywords=", ".join(missing_keywords),
    )

    return _json_output(prompt, AllocationOutput, model="lite", temperature=0.2)


@capability(
    "analysis.listing.part-rewrite",
    description="Listing 局部改写（仅改写 Title 或某一条 BP，最小改动）",
    input_model=ListingPartRewriteInput,
    output_model=PartRewriteOutput,
    requires=["product.get"],
)
def listing_part_rewrite(
    product_title: str,
    part_label: str,
    current_text: str,
    keywords: list[dict],
    existing_keywords: list[str] | None = None,
    other_parts: dict | None = None,
    asin: str = "",
    price: str = "",
) -> Result:
    """analysis.listing.part-rewrite — 局部改写

    仅改写 Title 或某一条 Bullet Point，做最小改动插入指定关键词。

    Args:
        product_title: 产品原标题
        part_label: "Title" 或 "BP1" 等
        current_text: 当前该部分的文本
        keywords: [{{term, grade, score}}, ...] 要插入的关键词
        existing_keywords: 该部分已有的关键词（不要删除）
        other_parts: 其他部分的文本参考 {{title, bp1, bp2, ...}}
    """
    # 格式化关键词
    kw_lines = []
    for kw in keywords:
        term = kw.get("term", kw.get("keyword", ""))
        grade = kw.get("grade", "")
        score = kw.get("score", "")
        volume = kw.get("search_volume", kw.get("searches", ""))
        source = str(kw.get("source") or "a10").upper()
        attributes = [source]
        if grade:
            attributes.append(f"{grade}级")
        if score not in ("", None):
            try:
                attributes.append(f"分数{float(score):.1f}")
            except (TypeError, ValueError):
                attributes.append(f"分数{score}")
        if volume not in ("", None):
            attributes.append(f"月搜索{volume}")
        kw_lines.append(f"- {term} [{', '.join(attributes)}]")

    keywords_text = "\n".join(kw_lines) if kw_lines else "无"

    existing_str = ", ".join(existing_keywords) if existing_keywords else "无"

    # 构建其他部分参考
    other_lines = []
    if other_parts:
        for key, val in other_parts.items():
            if val and key != part_label.lower():
                other_lines.append(f"{key}: {val}")
    other_str = "\n".join(other_lines) if other_lines else "无"

    # 动态参数
    is_title = "title" in part_label.lower()
    base_change = 10 if is_title else 15
    max_change = base_change + (len(keywords) - 1) * 5
    max_chars = 200 if is_title else 250

    prompt = LISTING_PART_REWRITE_PROMPT.format(
        product_title=product_title,
        part_label=part_label,
        current_text=current_text,
        keywords_text=keywords_text,
        existing_keywords=existing_str,
        other_parts=other_str,
        max_change=max_change,
        max_chars=max_chars,
    )
    prompt = prompt.replace(
        "# 产品信息\n- 原始标题:",
        f"# 产品信息\n- ASIN: {asin or 'N/A'}\n- 价格: {price or 'N/A'}\n- 原始标题:",
    )
    prompt = prompt.replace(
        "5. **越重要的关键词放越靠前的位置**\n6. **语法正确、英文流畅**",
        "5. **越重要（分数越高、搜索量越大）的关键词放越靠前的位置**\n"
        "6. **不要把新插入的词放在比它分数更高的已有词前面**\n"
        "7. **语法正确、英文流畅**",
    )

    try:
        # 局部改写返回纯文本，不是 JSON
        from amz.infra.llm import chat

        result = chat(prompt=prompt, model="pro", temperature=0.7)
        return ok(data=PartRewriteOutput(text=result.get("text", "").strip()).model_dump())
    except Exception as e:
        return err(Code.ERROR_LLM, str(e))
