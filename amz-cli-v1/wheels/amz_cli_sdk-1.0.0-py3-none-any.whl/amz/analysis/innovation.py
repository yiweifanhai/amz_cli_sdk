"""
创新分析：可复制性评估。

吸收 amz_agent amz-innovation-copy / evaluate_copyability.py 的四维度框架和微改进方向。
"""

from __future__ import annotations

import re
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from amz.envelope import Result, ok, err, Code
from amz.registry import capability
from amz.infra.llm import chat_json
from amz.analysis.base import parse_structured, require_json
from amz.schemas.analysis_inputs import CompareInnovationInput, MaterialAssessInput


class _InnovationModel(BaseModel):
    model_config = ConfigDict(extra="ignore")


class Barrier(_InnovationModel):
    """单一维度的复制壁垒。"""

    level: Literal["低", "中", "高"]  # 壁垒等级
    reason: str  # 判断理由


class BarrierAnalysis(_InnovationModel):
    """四维度复制壁垒分析。"""

    patent_risk: Barrier  # 专利风险壁垒
    supply_chain: Barrier  # 供应链壁垒（原料/模具/工艺可得性）
    tech_complexity: Barrier  # 技术复杂度壁垒
    brand_bindness: Barrier  # 品牌绑定壁垒（用户对品牌的忠诚度）


class CopyabilityOutput(_InnovationModel):
    """可复制性评估输出。"""

    visual_observations: str = ""  # 对产品图片/外观的视觉观察
    copy_difficulty: Literal["低", "中", "高"]  # 总体复制难度
    barrier_analysis: BarrierAnalysis  # 四维壁垒分析
    differentiation_suggestions: list[dict] = Field(default_factory=list)  # 差异化建议列表
    score: int = Field(ge=0, le=10)  # 可复制性评分 0-10（越低越难复制）
    score_reason: str  # 评分理由
    verdict: str  # 结论


class MaterialAssessmentOutput(_InnovationModel):
    """新品材质可开发性评估输出。"""

    material_reason: str  # 材质判断理由
    material_conclusion: str  # 材质结论
    easy_to_develop_reason: str  # 易开发性判断理由
    easy_to_develop_conclusion: str  # 易开发性结论
    easy_to_develop_mark: bool  # 是否易开发标记


class ComparativeInnovationOutput(_InnovationModel):
    """基准品差分创新分析输出。"""

    status: str  # 分析状态（VALID=有效 / INVALID=输入不足）
    comparison_mode: Literal["REAL_BENCHMARK", "INTERNAL_KNOWLEDGE"]  # 对比模式：真实基准品 / 内部知识
    root_product_keyword: str  # 根产品关键词
    baseline_summary: str  # 基准品总结
    innovation_analysis: str  # 创新分析文本
    primary_dimension: str  # 主创新维度
    secondary_dimensions: list[str]  # 次要创新维度列表
    innovation_score: int = Field(ge=0, le=10)  # 创新分 0-10
    one_sentence_reason: str  # 一句话理由


def _rating_value(value: object, default: float = 5.0) -> float:
    try:
        return float(str(value).split()[0])
    except (TypeError, ValueError, IndexError):
        return default


_TRAILING_PAREN_CONTENT = re.compile(r"\s*[（(][^（）()]*[)）]\s*$")


def _normalize_dimension_tag(value: object) -> str:
    text = str(value or "").strip()
    while text:
        normalized = _TRAILING_PAREN_CONTENT.sub("", text).strip()
        if normalized == text:
            break
        text = normalized
    return text


# ---------------------------------------------------------------------------
# 可复制性评估 Prompt（对齐 evaluate_copyability.py）
# ---------------------------------------------------------------------------

COPYABILITY_PROMPT = """# Role
你是一位有丰富 Amazon 实战经验的"竞品逆向工程专家"。你的核心能力是判断：一个竞品的创新**能不能被低成本复制**，以及**怎么做差异化微改进**。

# Task
我会给你提供：
1. **产品信息**：标题 + 产品描述
2. **创新点描述**：用户认为这个产品的核心亮点
3. **差评信息**（可选）：买家投诉点，微改进方向的来源

你的任务是从以下四个维度判断复制难度，然后给出微改进方向：

## 复制难度四维度

### 1. 专利壁垒
- 外观/功能是否有明显专利风险？
- 独创性结构 vs 通用设计
- 只做粗筛，有明显风险时标记

### 2. 供应链门槛
- 需要特殊工艺（精密注塑、CNC、激光切割）还是通用工艺？
- 需要定制模具还是公模可做？
- 材料是否特殊（普通塑料/硅胶 vs 特种合金/碳纤维）？
- 1688 上有没有类似方案？

### 3. 技术复杂度
- 纯硬件结构创新 vs 软件/算法/芯片方案？
- 硬件结构通常容易复制，软件算法壁垒更高
- 是否涉及认证门槛（FCC/UL/FDA）？

### 4. 品牌绑定
- 创新价值是否依赖品牌认知（特定配色体系、IP 授权）？
- 去掉品牌后创新本身还有没有独立价值？

## 微改进方向
从两个来源挖掘：
- **差评痛点**（优先）：区分结构性缺陷（改了就是新品）和品控问题（改了意义不大）
- **产品本身的机会**：功能叠加（成本+≤20%，感知价值翻倍）、外观微调（颜色/材质/包装）、规格扩展（尺寸/容量变体）

# Critical Rules
- 如果提供了图片，视觉分析必须包含至少 2 处对图片细节的具体引用
- 微改进建议要具体可执行，避免"优化用户体验"这类空话
- 专利风险只做粗筛，不做法律意见；有明显风险时提醒深查
- 如果没有差评信息，基于产品图片和品类常识推测痛点，标注为"推测"

---
**产品信息**
- ASIN: {asin}
- 标题: {title}
- 产品描述: {description}
- 图片 URL: {image_url}

**用户识别的创新点**
{innovation_desc}

**差评/痛点信息**
{reviews_info}

---

请严格按照以下逻辑步骤分析并输出 JSON：

**Step 1: 复制难度四维度判断**
分别从专利壁垒、供应链门槛、技术复杂度、品牌绑定四个角度评估。

**Step 2: 微改进方向**
结合差评痛点和产品机会，给出 3-5 条具体可执行的微改进建议。

**Step 3: 综合评分**
0-10 分。评分逻辑：复制门槛适中 + 差异化空间大 = 高分（理想状态）。

**Output Format (JSON Only):**
请使用中文回答，返回一个 JSON 对象：
{{
  "visual_observations": "从产品图片中观察到的至少两处关键视觉特征",
  "copy_difficulty": "低 / 中 / 高",
  "barrier_analysis": {{
    "patent_risk": {{
      "level": "低 / 中 / 高",
      "reason": "判断依据..."
    }},
    "supply_chain": {{
      "level": "低 / 中 / 高",
      "reason": "判断依据，包括工艺/模具/材料分析..."
    }},
    "tech_complexity": {{
      "level": "低 / 中 / 高",
      "reason": "判断依据..."
    }},
    "brand_bindness": {{
      "level": "低 / 中 / 高",
      "reason": "判断依据..."
    }}
  }},
  "differentiation_suggestions": [
    {{
      "type": "差评痛点 / 功能叠加 / 外观微调 / 规格扩展",
      "suggestion": "具体改进内容",
      "expected_effect": "预期效果",
      "cost_impact": "成本影响估计"
    }}
  ],
  "score": 0-10整数,
  "score_reason": "一句话评分理由",
  "verdict": "值得复制 / 可以尝试 / 需要谨慎 / 不建议复制"
}}"""

# evaluate_copyability.py 的 system/user 双消息原文。上面的常量保留为旧调用方
# 兼容文本；能力实现使用下面这组实验契约。
COPYABILITY_SYSTEM_PROMPT = """# Role
你是一位有丰富 Amazon 实战经验的"竞品逆向工程专家"。你的核心能力是判断：一个竞品的创新**能不能被低成本复制**，以及**怎么做差异化微改进**。

# ⚠️ 视觉分析强制要求
你会收到产品图片。你 **必须** 仔细观察图片并在分析中 **明确引用你从图片中看到的视觉细节**。例如：
- "从图片中可以看到，该产品使用了一体成型的铝合金外壳，需要精密 CNC 模具"
- "图片显示产品有独特的卡扣结构设计，这种结构在 1688 上有大量通用方案"
- "从产品图观察到包装采用了磁吸翻盖礼盒，成本增加但容易复制"

如果无法从图片中提取有意义的视觉信息（图片模糊或无法加载），请在输出中明确说明。
**禁止** 只基于标题文字分析而忽略图片内容。

# Task
我会给你提供：
1. **产品信息**：标题 + 产品图片
2. **创新点描述**：用户认为这个产品的核心亮点
3. **差评信息**（可选）：买家投诉点，微改进方向的来源

你的任务是从以下四个维度判断复制难度，然后给出微改进方向：

## 复制难度四维度

### 1. 专利壁垒
- 外观/功能是否有明显专利风险？
- 基于产品图片中的结构特征判断：独创性结构 vs 通用设计
- 只做粗筛，有明显风险时标记

### 2. 供应链门槛
- 需要特殊工艺（精密注塑、CNC、激光切割）还是通用工艺？
- 需要定制模具还是公模可做？
- 材料是否特殊（普通塑料/硅胶 vs 特种合金/碳纤维）？
- 1688 上有没有类似方案？

### 3. 技术复杂度
- 纯硬件结构创新 vs 软件/算法/芯片方案？
- 硬件结构通常容易复制，软件算法壁垒更高
- 是否涉及认证门槛（FCC/UL/FDA）？

### 4. 品牌绑定
- 创新价值是否依赖品牌认知（特定配色体系、IP 授权）？
- 去掉品牌后创新本身还有没有独立价值？

## 微改进方向
从两个来源挖掘：
- **差评痛点**（优先）：区分结构性缺陷（改了就是新品）和品控问题（改了意义不大）
- **产品本身的机会**：功能叠加（成本+≤20%，感知价值翻倍）、外观微调（颜色/材质/包装）、规格扩展（尺寸/容量变体）

# Critical Rules
- 视觉分析中必须包含至少 2 处对图片视觉细节的具体引用
- 微改进建议要具体可执行，避免"优化用户体验"这类空话
- 专利风险只做粗筛，不做法律意见；有明显风险时提醒深查
- 如果没有差评信息，基于产品图片和品类常识推测痛点，标注为"推测"。"""

COPYABILITY_USER_PROMPT = """请分析以下竞品的创新可复制性。

---
**产品信息**
- ASIN: {asin}
- 标题: {title}
- 以下是产品图片（请仔细观察外观、材质、结构、配件、包装）：

---
**用户识别的创新点**
{innovation}

---
{reviews_section}

---

请严格按照以下逻辑步骤分析并输出 JSON：

**Step 1: 视觉观察记录**
仔细描述你从产品图片中观察到的关键视觉特征：材质、颜色、结构、尺寸比例、配件组成、包装形式。

**Step 2: 复制难度四维度判断**
分别从专利壁垒、供应链门槛、技术复杂度、品牌绑定四个角度评估。

**Step 3: 微改进方向**
结合差评痛点和产品机会，给出 3-5 条具体可执行的微改进建议。

**Step 4: 综合评分**
0-10 分。评分逻辑：复制门槛适中 + 差异化空间大 = 高分（理想状态）。

**Output Format (JSON Only):**
请使用中文回答，返回一个 JSON 对象：
{{
  "visual_observations": "从产品图片中观察到的关键视觉特征...",
  "copy_difficulty": "低 / 中 / 高",
  "barrier_analysis": {{
    "patent_risk": {{"level": "低 / 中 / 高", "reason": "判断依据，必须引用图片细节..."}},
    "supply_chain": {{"level": "低 / 中 / 高", "reason": "判断依据..."}},
    "tech_complexity": {{"level": "低 / 中 / 高", "reason": "判断依据..."}},
    "brand_bindness": {{"level": "低 / 中 / 高", "reason": "判断依据..."}}
  }},
  "differentiation_suggestions": [
    {{
      "type": "差评痛点 / 功能叠加 / 外观微调 / 规格扩展",
      "suggestion": "具体改进内容",
      "expected_effect": "预期效果",
      "cost_impact": "成本影响估计"
    }}
  ],
  "score": 8,
  "score_reason": "一句话评分理由",
  "verdict": "值得复制 / 可以尝试 / 需要谨慎 / 不建议复制"
}}"""


# ---------------------------------------------------------------------------
# 能力注册
# ---------------------------------------------------------------------------

@capability(
    "analysis.innovation.copyability",
    description="多模态创新可复制性评估（专利/供应链/技术/品牌）",
    output_model=CopyabilityOutput,
    requires=["product.get"],
)
def assess_copyability(
    asin: str = "",
    image_url: str = "",
    innovation_desc: str = "",
    description: str = "",
    reviews: list[dict] | None = None,
    title: str = "",
) -> Result:
    """analysis.innovation.copyability — 可复制性

    Args:
        asin: ASIN
        image_url: 产品图 URL（作为多模态图片内容传入）
        innovation_desc: 用户认为的创新点
        description: 产品描述
        reviews: 差评/评论列表 [{rating, title, text}, ...]
    """
    # 格式化差评信息
    reviews_info = ""
    if reviews:
        neg_reviews = [r for r in reviews if _rating_value(r.get("rating")) <= 3]
        if neg_reviews:
            lines = []
            for r in neg_reviews[:10]:
                review_title = r.get("title", "")
                text = (r.get("text", "") or "")[:300]
                lines.append(f"[{r.get('rating', '?')}★] {review_title}\n{text}")
            reviews_info = "**差评/痛点信息**\n" + "\n\n".join(lines)
        else:
            reviews_info = (
                f"**差评/痛点信息**\n共 {len(reviews)} 条评论，无明显差评。"
                "请基于产品图片和品类常识推测可能的痛点，标注为\"推测\"。"
            )
    elif not reviews:
        reviews_info = '**差评/痛点信息**\n（未提供，请基于产品图片和品类常识推测可能的痛点，标注为"推测"）'

    prompt = COPYABILITY_USER_PROMPT.format(
        asin=asin or "unknown",
        title=title or description or innovation_desc or "unknown product",
        innovation=innovation_desc or "no specific innovation described",
        reviews_section=reviews_info,
    )
    parts = prompt.split("\n---\n")
    user_content: list[dict] = [
        {"type": "text", "text": parts[0].strip()},
        {"type": "text", "text": parts[1].strip() if len(parts) > 1 else ""},
    ]
    if image_url:
        user_content.append({"type": "image_url", "image_url": {"url": image_url}})
    if len(parts) > 2:
        user_content.append({"type": "text", "text": "\n---\n".join(parts[2:]).strip()})
    try:
        result = chat_json(
            messages=[
                {"role": "system", "content": COPYABILITY_SYSTEM_PROMPT},
                {"role": "user", "content": user_content},
            ],
            json_schema=CopyabilityOutput.model_json_schema(),
            model="pro", temperature=0.2,
        )
        output = parse_structured(result, CopyabilityOutput)
        if image_url and not output.visual_observations.strip():
            return err(Code.ERROR_LLM, "multimodal output omitted visual_observations")
        return ok(data=output.model_dump())
    except Exception as e:
        return err(Code.ERROR_LLM, str(e))


MATERIAL_PROMPT = """你是一位专业的产品材质分析师，现在需要你根据一个产品的图片，对应的关键词数据，以及产品的标题，判断材质以及改造生产难度

# 输入数据
    1. 主关键词，以及标题中提到的其他搜索关键词
    2. 产品的标题
    3. 关键词对应的市场的一级分类
    4. 二级分类
    5. 三级分类
    6. 产品的图片

# 主要工作
1. 判断该市场的产品的材质。材质需要为金属、陶瓷、玻璃、塑料、橡胶、布料纤维、纸张、骨头、木材、皮革、硅胶、石头珠宝、液体、碳/石墨材料中的一种，如果不属于其中的材质，请输出你认为的材质
如果是电子电器产品、电线、线缆、接头等，不需要判断材质，结果判断为电子产品。
如果产品是某个其他产品的附件（从图片中直接判别，或者分类是 Accessories等），例如手机壳、收纳袋、保护套等，就只看这个附件的材质，不关注主体产品的材质。
金属类产品，如果金属只是装饰或极少量使用（例如固定用的钢丝等），则不是产品的主要材质
2. 判断产品是否容易进行差异化改造的，从生产的角度判断是否容易进行低成本的差异化改造和生产。如3C电子电器产品需要开模会比较贵，但是陶瓷、玻璃、木材、纸张等材质的产品容易进行低成本的差异化改造。
金属类和不锈钢类产品，如果产品主体涉及金属加工，且工艺涉及铸造、弯折、冲压、电镀、表面处理、钻孔、切割、打磨、雕刻、机加工、CNC、激光刻字、激光雕刻等复杂工艺，这些工艺通常都比较复杂，会比较贵，因此不容易改造。
金属类制品如果要认为容易改造，一定是混合材质产品、且不大幅度改变产品金属部分，只改动塑料、布、皮等容易改造材质的情况，比如可以给塑料换个颜色之类的；金属部分，可以是类似改变尺寸等简单加工或者改造。
生物制品（或者含有生物制品、成分的）、化妆品、肉类、可食用产品、保健品（也包括宠物保健品）、化工用品、饲料、种子、药品、猫砂等，涉及复杂的安全性检查和检疫流程，都比较贵，不能简单改造。
电子产品（包括充电类的儿童玩具），先判断是不是充电的（需要插座供电的就属于没有电池+不需要充电），如果带有电池，或是需要充电类型的，涉及电池生产加工很贵，都认为不容易改造；
电子产品一定是在不改变软硬件本体的情况下，才算容易改造。
如果是工具套装等组合类产品，可以分开考虑各个部分，只要有一些部分容易改造，或者可以扩充其他工具，就算容易改造。
3. 给出最终的判断结果。

# 输出
material_reason # 材质判断的理由
material_conclusion # 最终的材质判断结果
easy_to_develop_reason # 是否容易开发该产品，不需要复杂的生产流程就可以低成本快速改造的理由
easy_to_develop_conclusion # 是否容易开发该产品的结论
easy_to_develop_mark # 是否容易开发该产品，使用bool类型描述，True为容易改造，False为难改造。

所有输出必须为中文。"""


@capability(
    "analysis.material.assess",
    description="新品材质与低成本可开发性多模态分析",
    input_model=MaterialAssessInput,
    output_model=MaterialAssessmentOutput,
)
def assess_material(product_info: dict, image_url: str = "") -> Result:
    resolved_image = image_url or product_info.get("image_url", product_info.get("main_image_url", "")) or ""
    categories = product_info.get("categories", []) or []
    if not isinstance(categories, list):
        categories = [categories]
    c1 = product_info.get("category_display_name_1", categories[0] if categories else product_info.get("category", ""))
    c2 = product_info.get("category_display_name_2", categories[1] if len(categories) > 1 else "")
    c3 = product_info.get("category_display_name_3", categories[2] if len(categories) > 2 else "")
    user_text = (
        f'主关键词：{product_info.get("main_keyword", "")}\n'
        f'其他搜索关键词：{product_info.get("keywords", "")}\n'
        f'产品标题：{product_info.get("product_name", product_info.get("title", ""))}\n'
        f'关键词对应的市场的一级分类：{c1}\n二级分类：{c2}\n三级分类：{c3}。以下为产品图片：'
    )
    content: list[dict] = [{"type": "text", "text": user_text}]
    if resolved_image:
        content.append({"type": "image_url", "image_url": {"url": resolved_image}})
    content.append({
        "type": "text",
        "text": "请根据以上图片和文字，判断该市场的产品的材质与是否容易低成本差异化改造。先给出理由，再给出最终结论。",
    })
    try:
        result = chat_json(
            messages=[
                {"role": "system", "content": MATERIAL_PROMPT},
                {"role": "user", "content": content},
            ],
            json_schema=MaterialAssessmentOutput.model_json_schema(),
            model="pro", temperature=0.2,
        )
        return ok(data=parse_structured(result, MaterialAssessmentOutput).model_dump())
    except Exception as exc:
        return err(Code.ERROR_LLM, str(exc))


INNOVATION_COMPARE_SYSTEM_PROMPT = """# Role
你是一位拥有敏锐洞察力的“亚马逊蓝海选品专家”。你的核心能力是通过对比“市场现有畅销品（Benchmark）”和“新发布产品（New Release）”，精准识别出具有颠覆性创新的市场机会。

# Task
我会给你提供两组数据：
1. **[New Product]**: 一个新上架产品的标题、图片特征描述（或直接提供图片）、卖点。
2. **[Benchmark Group]**: 该关键词下销量最高的 3-5 个老爆款产品的标题、图片特征描述（或图片）。

你的任务是进行“差分分析”，判断 [New Product] 是否属于“伪创新”，还是真正的“蓝海机会”。

# Innovation Dimensions (创新评判维度)
请严格基于以下 10 个维度来寻找差异。如果产品仅仅是换了包装或稍微改了尺寸，不属于创新。

1. **形态颠覆 (Form Factor Innovation)**: 把产品原本固有的形状彻底改变（例：把平铺的菜板做成书本状；把传统的风扇做成无叶的）。
2. **跨界混搭 (Hybridization)**: 两个毫不相关的成熟品类强行融合（例：保温杯+蓝牙音箱；行李箱+滑板车）。
3. **场景细分 (Micro-Scenario)**: 针对极特定的场景设计（例：不是普通的“地毯”，而是“房车专用防潮地毯”；不是“台灯”，是“乐谱架专用灯”）。
4. **场景迁移 (Scenario Migration)**: 把A场景的产品拿到B场景用（例：原本是手术室用的精密剪刀，现在作为厨房剪刀卖）。
5. **人群迁移 (Demographic Shift)**: 使用对象发生根本转变（例：原本给婴儿用的硅胶餐具，现在做成宠物专用；原本是女性用的美妆蛋，现在做成男性专用）。
6. **人群标签化 (Identity/Subculture)**: 强绑定某种亚文化或身份标签（例：Goth（哥特风）家居；LGBTQ 彩虹主题办公用品）。
7. **情绪价值放大 (Emotional Value)**: 功能不重要，卖的是解压、治愈、搞怪或炫耀（例：木鱼解压玩具；巨型回车键；“禁止焦虑”摆件）。
8. **功能叠加 (All-in-One)**: 极度的多功能集成（例：一个野营灯同时是：充电宝+驱蚊器+SOS信号灯+收音机）。
9. **极致单点突破 (Extreme Feature)**: 放弃其他功能，把某一个参数做到变态（例：不做多功能，但待机时间长达 1 年的录音笔）。
10. **视觉/材质升级 (Aesthetic/Material Upgrade)**: 功能不变，但材质或设计风格降维打击（例：把塑料收纳盒做成亚克力+黄铜轻奢风；把普通数据线做成流光夜光线）。

# Critical Rule (去噪原则)
如果 [New Product] 和 [Benchmark Group] 根本不是同一类东西（例如：新品是手机壳，竞品是浇水软管），这是数据错误，请直接标记为 "INVALID_PAIR"。"""

INNOVATION_COMPARE_STEPS = """请严格按照以下逻辑步骤进行分析并输出 JSON：

**Step 1: 确定基准 (Establish Baseline)**
- **情况 A (如果 [PART A] 有数据):** 基于 [PART A] 的内容，总结该品类的“平庸标准”。
- **情况 B (如果 [PART A] 为 "NONE" 或数据无效):** 1. 首先提取 [PART B] 的**核心产品词 (Root Keyword)**（例如把 "Cute Dinosaur Taco Holder" 还原为 "Taco Holder"）。
  2. 调取你的**内部常识库**，构建该产品在亚马逊市场上的“大众化画像”（通常是什么材质？什么形状？有什么标配功能？）。这将作为你的“虚拟基准”。

**Step 2: 差异识别 (Identify Deviation)**
将 [PART B] 与 Step 1 确定的基准（无论是真实的还是虚拟的）进行对比。
- 新品是否在形态、场景、功能或材质上，显著背离了你认知的“标准品”？
- 如果新品属于知名/经典IP（Hello Kitty、米老鼠、初音未来等）、热门电影/游戏作品、球队/球星等的周边产品，由于涉及潜在的知识产权问题，请给予0-2分的“弱创新”/“无创新”评价。
- 如果原品是通用款（例如适用于所有车型的配件），而新品是某个具体型号的定制款（适用于某个具体车型的配件），由于这两类产品并不能直接对比，请给予小于等于5分的“弱创新”评价。
- *警告：* 如果你使用的是“内部常识”，请采取保守策略。不要把现代标配（如 Type-C 接口、普通防水）误判为颠覆性创新。在使用“内部常识模式”时，请务必自我质疑： "这个所谓的创新点（例如无线、便携），在最近 2 年的亚马逊市场上是否已经泛滥？" 只有当你确信这是一个极少见的设计时，才给予 7 分以上的高分。如果不确定，请给予 4-6 分的“中度优化”评价。

**Step 3: 维度匹配 (Categorize)**
匹配 10 大创新维度，从强到弱排序。

**Step 4: 评分 (Scoring)**
按 0-10 分打分。

**Output Format (JSON Only):**
请使用中文回答语言，并返回一个 JSON 对象，返回的格式如下：
{
  "status": "VALID",
  "comparison_mode": "REAL_BENCHMARK" 或 "INTERNAL_KNOWLEDGE",
  "root_product_keyword": "例如：Cutting Board (仅在内部常识模式下必填)",
  "baseline_summary": "描述你用来对比的标准（是基于竞品数据总结的，还是基于常识构建的）...",
  "innovation_analysis": "分析新品哪里不一样...",
  "primary_dimension": "核心维度",
  "secondary_dimensions": ["其他维度"],
  "innovation_score": 打分0-10分,
  "one_sentence_reason": "简短的几句话理由..."
}"""


@capability(
    "analysis.innovation.compare",
    description="新品与 3-5 个畅销基准品的多模态差分创新评估",
    input_model=CompareInnovationInput,
    output_model=ComparativeInnovationOutput,
)
def compare_innovation(new_product: dict, benchmarks: list[dict] | None = None) -> Result:
    benchmark_items = (benchmarks or [])[:5]
    benchmark_text = "NONE" if not benchmark_items else "\n".join(
        f'- [{index}] {item.get("product_name", item.get("title", ""))} (ASIN: {item.get("asin", "")})'
        for index, item in enumerate(benchmark_items, start=1)
    )
    new_text = (
        f'- {new_product.get("product_name", new_product.get("title", ""))} '
        f'(ASIN: {new_product.get("asin", "")})'
    )
    content: list[dict] = [
        {"type": "text", "text": "请分析以下产品数据。\n注意：[PART A] 可能为空。如果为空，请触发“内部常识判断模式”。"},
        {"type": "text", "text": f"**[PART A: Benchmark Group (老爆款/参照系)]**\n这是产品标题 {benchmark_text} 以下是产品图片"},
    ]
    for item in benchmark_items:
        image_url = str(item.get("image_url") or item.get("main_image_url") or "").strip()
        if image_url:
            content.append({"type": "image_url", "image_url": {"url": image_url}})
    content.append({
        "type": "text",
        "text": f"**[PART B: New Product (待验证新品)]**\n这是产品标题 {new_text} 以下是产品图片",
    })
    new_image = str(new_product.get("image_url") or new_product.get("main_image_url") or "").strip()
    if new_image:
        content.append({"type": "image_url", "image_url": {"url": new_image}})
    content.append({"type": "text", "text": INNOVATION_COMPARE_STEPS})
    try:
        result = chat_json(
            messages=[
                {"role": "system", "content": INNOVATION_COMPARE_SYSTEM_PROMPT},
                {"role": "user", "content": content},
            ],
            json_schema=ComparativeInnovationOutput.model_json_schema(),
            model="pro", temperature=0.2,
        )
        raw = require_json(result)
        if not isinstance(raw, dict):
            raise ValueError("comparative innovation output must be a JSON object")
        if raw.get("comparison_mode") not in {"REAL_BENCHMARK", "INTERNAL_KNOWLEDGE"}:
            raw["comparison_mode"] = "REAL_BENCHMARK"
        raw["primary_dimension"] = _normalize_dimension_tag(raw.get("primary_dimension"))
        secondary = raw.get("secondary_dimensions", [])
        if not isinstance(secondary, (list, tuple)):
            secondary = [secondary]
        raw["secondary_dimensions"] = list(dict.fromkeys(
            tag for item in secondary if (tag := _normalize_dimension_tag(item))
        ))
        output = ComparativeInnovationOutput.model_validate(raw)
        if not benchmark_items:
            output.comparison_mode = "INTERNAL_KNOWLEDGE"
        return ok(data=output.model_dump())
    except Exception as exc:
        return err(Code.ERROR_LLM, str(exc))
