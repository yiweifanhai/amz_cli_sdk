"""需求评估与市场进入时机。

需求分本身是确定性计算；本模块保留兼容入口并要求调用方显式提供真实趋势
数据。市场时机是固定框架的常识推理，输入包含产品事实和明确日期。
"""

from __future__ import annotations

import calendar
from datetime import date
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from amz.calc.demand import score_demand
from amz.envelope import Code, Result, err, ok
from amz.infra.llm import chat_json
from amz.analysis.base import parse_structured
from amz.registry import capability
from amz.schemas.analysis_inputs import DemandAssessInput, MarketTimingInput


class _DemandModel(BaseModel):
    model_config = ConfigDict(extra="ignore")


class DemandScoreBreakdown(_DemandModel):
    """需求分拆解。"""

    bluered_sub_score: int  # 蓝海/红海子分（市场供需结构）
    trend_sub_score: int  # 趋势子分（真实搜索趋势）
    reason: str  # 评分说明


class DemandOutput(_DemandModel):
    """需求评估输出（确定性计算）。"""

    block: Literal["demand"] = "demand"  # 固定块标识
    score: int = Field(ge=0, le=10)  # 需求分 0-10
    stop: bool  # 是否触发 STOP 规则（硬性否决）
    stop_reason: str | None = None  # STOP 原因
    score_breakdown: DemandScoreBreakdown  # 分项得分
    data: dict  # 输入明细数据（回传）


class TimingDetails(_DemandModel):
    """市场进入时机明细。"""

    product_function: str  # 产品功能
    use_case_inference: str  # 使用场景推断链（功能→场景→具体高峰月份）
    seasonality_type: Literal["A", "B", "C", "D"]  # 季节性类型：A 强季节 / B 节日绑定 / C 弱季节 / D 无季节
    seasonality_label: str  # 季节性标签（如 summer、holiday）
    peak_demand_window: str  # 需求高峰窗口（具体月份）
    launch_window: str  # 建议上架窗口（具体月/年）
    mismatch_reason: str  # 上架窗口与需求窗口匹配/错配原因


class TimingOutput(_DemandModel):
    """市场进入时机评估输出。"""

    block: Literal["market_timing"] = "market_timing"  # 固定块标识
    score: int = Field(ge=0, le=100)  # 时机分 0-100
    verdict: Literal["GO", "CAUTION", "STOP"]  # 结论：适合进入 / 谨慎 / 放弃
    verdict_reason: str  # 结论理由
    details: TimingDetails  # 时机明细


def _add_months(value: date, months: int) -> date:
    month_index = value.month - 1 + months
    year = value.year + month_index // 12
    month = month_index % 12 + 1
    day = min(value.day, calendar.monthrange(year, month)[1])
    return date(year, month, day)


@capability(
    "analysis.demand.assess",
    description="基于真实 Google/Amazon 趋势输入的确定性需求评估兼容入口",
    input_model=DemandAssessInput,
    output_model=DemandOutput,
)
def demand_assess(
    keyword: str,
    asin: str = "",
    google_trends: dict | None = None,
    amazon_trend: dict | None = None,
    market_data: dict | None = None,
) -> Result:
    """评估需求；不允许 LLM 凭 keyword 编造趋势数值。"""
    if not google_trends:
        return err(
            Code.ERROR_PARAM,
            "google_trends is required; fetch real trend data in data/entities before scoring",
            data={"required": ["target_avg", "baseline_avg", "cagr_3y", "trend_direction"]},
        )
    result = score_demand(
        keyword=keyword,
        google_trends=google_trends,
        amazon_trend=amazon_trend,
        market_data=market_data,
    )
    if result.code == Code.OK and asin:
        result.data["data"]["asin"] = asin
    try:
        result.data = DemandOutput.model_validate(result.data).model_dump()
    except Exception as exc:
        return err(Code.ERROR_PARAM, f"invalid demand inputs: {exc}")
    return result


TIMING_PROMPT = """You are an Amazon market-entry timing analyst. Use common-sense product
understanding, not title keyword scanning and not invented sales data.

Current date: {current_date}
Expected FBA sellable date (current date + 3 months): {launch_date}
Default market: United States / Northern Hemisphere

Product title: {title}
Category: {category}
Features:\n{features}
Description: {description}
Optional supplied market signals (supporting evidence only):\n{market_data}

Method:
1. Explain product function.
2. Infer who uses it, in what weather/occasion, and what problem it solves.
3. From that use case infer concrete peak-demand months.
4. Compare the launch date with the demand window.
5. Classify seasonality: A strong seasonal, B holiday-bound, C weak seasonal, D non-seasonal.

Scoring:
- 0-40 STOP: peak has passed and next useful window is at least 6 months away.
- 41-55 CAUTION: tight launch or 3-5 months of inventory waiting.
- 56-75 GO: launch overlaps the rising-demand window.
- 76-100 GO: non-seasonal or perfectly timed before peak.

Return JSON only:
{{
  "block": "market_timing",
  "score": 0,
  "verdict": "GO|CAUTION|STOP",
  "verdict_reason": "one sentence",
  "details": {{
    "product_function": "...",
    "use_case_inference": "function -> situation -> concrete peak months",
    "seasonality_type": "A|B|C|D",
    "seasonality_label": "...",
    "peak_demand_window": "specific months",
    "launch_window": "specific month/year",
    "mismatch_reason": "why the windows match or mismatch"
  }}
}}"""


@capability(
    "analysis.market.timing",
    description="按当前日期+3个月开售窗口评估市场进入时机",
    input_model=MarketTimingInput,
    output_model=TimingOutput,
    requires=["keyword.trends"],
)
def market_timing(
    asin: str = "",
    keyword: str = "",
    market_data: dict | None = None,
    product_info: dict | None = None,
    current_date: str = "",
) -> Result:
    product = product_info or {}
    if not product and not (asin or keyword):
        return err(Code.ERROR_PARAM, "product_info or asin/keyword is required")
    try:
        today = date.fromisoformat(current_date) if current_date else date.today()
    except ValueError:
        return err(Code.ERROR_PARAM, "current_date must be YYYY-MM-DD")
    launch = _add_months(today, 3)
    features = product.get("bullet_points", product.get("features", [])) or []
    if isinstance(features, str):
        features = [features]
    prompt = TIMING_PROMPT.format(
        current_date=today.isoformat(), launch_date=launch.isoformat(),
        title=product.get("title", keyword or asin or "unknown"),
        category=product.get("category", product.get("node_label_path", "unknown")),
        features="\n".join(str(item) for item in features[:10]),
        description=product.get("description", product.get("productDescription", "")),
        market_data="\n".join(f"{key}: {value}" for key, value in (market_data or {}).items()) or "none",
    )
    try:
        response = chat_json(
            prompt=prompt, json_schema=TimingOutput.model_json_schema(),
            model="lite", temperature=0.2,
        )
        output = parse_structured(response, TimingOutput)
        # launch_window 是事实字段，不允许模型改写成模糊文本。
        output.details.launch_window = launch.strftime("%Y-%m")
        return ok(data=output.model_dump())
    except Exception as exc:
        return err(Code.ERROR_LLM, str(exc))
