"""
COSMO 语义分析：产品语义提取 + 跨 ASIN 聚合。

吸收 listing_agent lib/cosmo extract.ts / aggregate.ts / merge.ts。
"""

from __future__ import annotations

from collections import Counter
from typing import Literal

from pydantic import AliasChoices, BaseModel, ConfigDict, Field

from amz.calc.cosmo import TERM_FIELDS, merge_cosmo_results
from amz.envelope import Result, ok, err, Code
from amz.registry import capability
from amz.infra.llm import chat_json
from amz.analysis.base import parse_structured, require_json
from amz.schemas.analysis_inputs import CalcCosmoMergeInput, CosmoClassifyInput, CosmoExtractInput


class _CosmoOutputModel(BaseModel):
    """COSMO 抽取结果的严格契约。"""

    model_config = ConfigDict(extra="forbid", populate_by_name=True, strict=True)


class _CosmoDerivedModel(BaseModel):
    """聚合和分类阶段的兼容契约。"""

    model_config = ConfigDict(extra="ignore", populate_by_name=True)


class TermLocation(_CosmoOutputModel):
    """术语在 Listing 各位置的出现标记（True=出现）。"""

    title: bool  # 出现在标题
    bulletPoints: bool  # 出现在五点描述
    review: bool  # 出现在评论
    imageDescription: bool  # 出现在图片描述
    aPlus: bool  # 出现在 A+ 页面


class TermWithLocation(_CosmoOutputModel):
    """带出现位置的术语。"""

    term: str  # 术语文本
    location: TermLocation  # 出现位置标记


class ProductEssence(_CosmoOutputModel):
    """产品本质维度（"是什么"）。"""

    is_a_description: list[TermWithLocation]  # "是什么"描述性术语
    is_a_category: str  # 类目归类（自由文本）
    used_as: list[TermWithLocation]  # 被当作什么用
    made_of: list[TermWithLocation]  # 材质构成


class FunctionalUtility(_CosmoOutputModel):
    """功能效用维度（"能做什么"）。"""

    used_to: list[TermWithLocation]  # 用来做什么
    capable_of: list[TermWithLocation]  # 具备的能力
    used_for_func: list[TermWithLocation]  # 功能用途


class ContextualMapping(_CosmoOutputModel):
    """场景映射维度（"在什么场合/环境用"）。"""

    used_for_eve: list[TermWithLocation]  # 适用场合/事件（如生日、露营）
    used_on: list[TermWithLocation]  # 作用对象/表面（如皮肤、桌面）
    used_in_loc: list[TermWithLocation]  # 使用场所（如厨房、户外）
    used_in_body: list[TermWithLocation]  # 使用的身体部位（如头发、手腕）


class AudiencePsychographics(_CosmoOutputModel):
    """人群心理画像维度（"谁用、为什么用"）。"""

    used_for_aud: list[TermWithLocation]  # 目标人群（如给婴儿、给老人）
    used_by: list[TermWithLocation]  # 使用者
    xis_a: list[TermWithLocation]  # 用户身份（X 是什么人）
    xinterested_in: list[TermWithLocation]  # 用户感兴趣的事
    xwant: list[TermWithLocation]  # 用户想要什么
    lifestyle_symbol_of: list[TermWithLocation] = Field(
        validation_alias=AliasChoices("lifestyle_symbol_of", "lifestyle_symbol")
    )  # 生活方式象征（兼容旧 Prompt 字段名）


class EcosystemEconomics(_CosmoOutputModel):
    """生态经济维度（"搭配什么、定价逻辑"）。"""

    used_with: list[TermWithLocation]  # 搭配使用的产品（如保护壳、替换滤芯）
    pricing_justified: str = Field(
        validation_alias=AliasChoices("pricing_justified", "value_proposition")
    )  # 定价合理性说明（兼容旧 Prompt 字段名）


class CosmoOutput(_CosmoOutputModel):
    """COSMO 5 个一级域、19 个二级语义字段的提取结果。"""

    product_essence: ProductEssence  # 产品本质（是什么）
    functional_utility: FunctionalUtility  # 功能效用（能做什么）
    contextual_mapping: ContextualMapping  # 场景映射（什么场合用）
    audience_psychographics: AudiencePsychographics  # 人群画像（谁用）
    ecosystem_economics: EcosystemEconomics  # 生态经济（搭配与定价）


class MergedTerm(_CosmoDerivedModel):
    """跨 ASIN 合并后的单个术语统计。"""

    term: str  # 术语文本
    cosmo_category: str  # COSMO 大类（五大维度之一）
    cosmo_field: str  # COSMO 子字段（如 used_to / made_of）
    count: int = 0  # 总出现次数（各位置之和）
    title_count: int = 0  # 标题中出现次数
    bullet_points_count: int = 0  # 五点中出现次数
    review_count: int = 0  # 评论中出现次数
    image_description_count: int = 0  # 图片描述中出现次数
    a_plus_count: int = 0  # A+ 页面中出现次数
    asins: list[str] = Field(default_factory=list)  # 出现该术语的 ASIN 列表
    weighted_score: int = 0  # 五位置加权分（标题权重最高）


class CosmoMergeOutput(_CosmoDerivedModel):
    """多 ASIN COSMO 结果合并输出。"""

    terms: list[MergedTerm] = Field(default_factory=list)  # 合并后的术语统计列表
    groups: list[MergedTerm] = Field(default_factory=list)  # 术语分组（当前与 terms 同内容，向后兼容）


class TermGroup(_CosmoDerivedModel):
    """同义术语聚合组（含 LLM 分类结果）。"""

    group_id: str  # 分组 ID
    representative_term: str  # 代表术语（英文）
    representative_term_cn: str = ""  # 代表术语中文
    synonyms: list[str] = Field(default_factory=list)  # 同义词列表
    members: list[MergedTerm] = Field(default_factory=list)  # 组内成员术语
    cosmo_category: str  # COSMO 大类
    cosmo_field: str  # COSMO 子字段
    count: int = 0  # 组内总出现次数
    title_count: int = 0  # 组内标题出现次数
    bullet_points_count: int = 0  # 组内五点出现次数
    review_count: int = 0  # 组内评论出现次数
    image_description_count: int = 0  # 组内图片描述出现次数
    a_plus_count: int = 0  # 组内 A+ 出现次数
    weighted_score: int = 0  # 组加权分
    asins: list[str] = Field(default_factory=list)  # 涉及 ASIN 列表
    needs_review: bool = False  # 是否需要人工复核
    warnings: list[str] = Field(default_factory=list)  # 告警信息
    classification: Literal["S", "A", "B", "C"] | None = None  # LLM 分类等级（S 最高）
    keep_in_listing: bool | None = None  # 是否保留在 Listing 中
    suggested_position: str | None = None  # 建议埋词位置（title/bullet 等）
    scores: dict = Field(default_factory=dict)  # 评分明细
    reason: str = ""  # 分类结论理由


class CosmoAggregateOutput(_CosmoDerivedModel):
    """同义聚合输出。"""

    groups: list[TermGroup] = Field(default_factory=list)  # 聚合组列表


class CosmoClassifyOutput(_CosmoDerivedModel):
    """分组分类输出。"""

    groups: list[TermGroup] = Field(default_factory=list)  # 分类后的组列表

# ---------------------------------------------------------------------------
# COSMO 抽取 Prompt（对齐 listing_agent cosmo-extract.ts）
# ---------------------------------------------------------------------------

COSMO_EXTRACT_PROMPT = """# Role: 亚马逊高级算法策略专家 (COSMO & Semantic SEO 专攻)

# Task:
作为一名精通 Amazon COSMO 算法和 Large-scale Knowledge Graph (KG) 的专家，你的任务是深度解析 Listing 原始数据，将其转化为高度结构化的 JSON 格式，以便为 Rufus AI 和 A9 算法提供最优语义对齐。

# Inputs:
- **Product Title:** {title}
- **Bullet Points:** {features}
- **Product Specs:** {details}
- **Product Description:** {description}
- **Brand:** {brand}

# COSMO Extraction Framework & Logic:

## 1. Taxonomy & Physicality (本体与物理属性)
- **is_a_description:** [Array] 简洁的产品定义描述。材质、颜色、形状、特殊属性等。
- **is_a_category:** [String] 亚马逊标准类目路径
- **used_as:** [Array] 识别产品的角色或替代身份（如：空酒瓶 used as Flower Vase）。
- **made_of:** [Array] 材质成分及耐用性语义

## 2. Functionality & Utility (功能与效用)
- **used_for_func:** [Array] 核心功能点，解决的原始痛点（Pain Point Solver）e.g. dry face。
- **capable_of:** [Array] 物理性能或参数边界（如：100% Waterproof, 50lb weight capacity）。
- **used_to:** [Array] 完成特定任务的动作描述（Verb + Object）。

## 3. Spatio-Temporal Context (时空场景与事件)
- **used_for_eve:** [Array] 活动/事件触发点。识别节日、社交聚会或特定生活时刻（如：Baby Shower, Solo Hiking）。
- **used_on:** [Array] 时间维度。包括季节性、时间段（Late Night）或生命周期。
- **used_in_loc:** [Array] 典型物理场景（Indoor, Office, Kitchen counter）。
- **used_in_body:** [Array] 作用部位或生理特征（如：Oily Skin, Lower Back）。

## 4. Persona & Psychographics (受众画像与心理)
- **used_for_aud:** [Array] 针对性受众。因特定职业或需求而产生"刚需"的群体（如：Nurse on night shift）。
- **used_by:** [Array] 身份标签。关联生活方式或爱好（如：Coffee Enthusiast）。
- **xis_a:** [Array] 用户画像定义（User's persona, e.g., Eco-conscious shopper）。
- **xinterested_in:** [Array] 用户的潜在兴趣图谱
- **xwant:** [Array] 挖掘用户的深层渴望（Inner Desire）意图或需求。
- **lifestyle_symbol_of:** [Array] 情感/风格标签（e.g. Minimalist, Luxury, Heavy Duty, health-conscious）。

## 5. Ecosystem & Value (生态位与价值)
- **used_with:** [Array] 强关联的互补品，一般该产品作为配件和其他产品一起使用的那些产品（Complementary products）。如耳机配合手机使用，手机就是 used_with 的主体。
- **pricing_justified:** [String] 总结该产品如何证明其价格的合理性（溢价逻辑分析）。

# 位置标注要求:
对于每个提取的词，必须标注它出现在 listing 的哪些位置：
- title: 是否出现在标题 (Product Title) 中
- bulletPoints: 是否出现在五点描述 (Bullet Points) 或产品参数表 (Product Specs) 中
- review: 当前数据不可用，一律设为 false
- imageDescription: 当前数据不可用，一律设为 false
- aPlus: 是否出现在产品描述 (Product Description / A+ Content) 中

# JSON Output Requirements:
1. 输出为纯 JSON 格式，不含解释性引言
2. 属性值使用短语，保持高度语义化
3. **严格验证规则**: 每个词条必须能在 listing 原文中找到语义对应的文字依据。不需要完全匹配原文措辞，但语义必须能对应上。如果找不到任何依据，不要输出该词条。
4. 如果 listing 中没有相关信息，字段为空数组或空字符串
5. 每个词条格式为: {{"term": "词条内容", "location": {{"title": true/false, "bulletPoints": true/false, "review": false, "imageDescription": false, "aPlus": true/false}}}}
6. 重要：review 和 imageDescription 当前数据不可用，所有词条这两个字段一律设为 false
7. bulletPoints 包括五点描述和产品参数表 (Product Specs) 中的内容
8. aPlus 包括产品描述 (Product Description) 中的内容，如果词条来自 Product Description 则设为 true
9. 必须完整输出 5 个一级域和全部 19 个二级字段；字段可以为空，但不能省略，也不能增加未定义字段

# Example JSON Structure:
```json
{{
  "product_essence": {{
    "is_a_description": [{{"term": "example", "location": {{"title": true, "bulletPoints": false, "review": false, "imageDescription": false, "aPlus": false}}}}],
    "is_a_category": "",
    "used_as": [],
    "made_of": []
  }},
  "functional_utility": {{
    "used_to": [],
    "capable_of": [],
    "used_for_func": []
  }},
  "contextual_mapping": {{
    "used_for_eve": [],
    "used_on": [],
    "used_in_loc": [],
    "used_in_body": []
  }},
  "audience_psychographics": {{
    "used_for_aud": [],
    "used_by": [],
    "xis_a": [],
    "xinterested_in": [],
    "xwant": [],
    "lifestyle_symbol_of": []
  }},
  "ecosystem_economics": {{
    "used_with": [],
    "pricing_justified": ""
  }}
}}
```

开始输出！所有词条必须100%基于 listing 原文的语义信息提取。任何没有原文依据的推测性词条都不要输出——宁缺勿滥。"""


# ---------------------------------------------------------------------------
# COSMO 聚合 Prompt（对齐 listing_agent aggregate.ts）
# ---------------------------------------------------------------------------

COSMO_AGGREGATE_PROMPT = """You are an Amazon search synonym aggregation expert. Group the following terms from the same COSMO semantic field into synonym groups.

## Three Heuristic Rules (you MUST check all three before grouping):

1. **Intent Substitution Test**: If a user searches Term A and only receives products featuring Term B, would they be highly satisfied? If NO -> do NOT group.
   - Example: "yoga mat" and "exercise mat" -> YES (same product intent) -> group
   - Example: "non-toxic" and "eco-friendly" -> NO (different intent) -> do NOT group

2. **Mutually Exclusive Scenario Test**: Do the two terms target different specific pain points or user groups? If YES -> do NOT group.
   - Example: "indoor yoga" and "outdoor yoga" -> YES (different scenarios) -> do NOT group

3. **Parent-Child Rule**: Is Term A a specific subtype of Term B? If YES -> do NOT group (keep as separate standalone terms).
   - Example: "natural rubber" is a subtype of "rubber" -> do NOT group

## Representative term selection:
{target_product_hint}

## Terms to aggregate (all from the same COSMO field):
{terms_text}

## Output format (pure JSON only, no markdown):
{{
  "groups": [
    {{
      "representativeTerm": "yoga mat",
      "representativeTermCn": "瑜伽垫",
      "members": ["yoga mat", "exercise mat", "fitness mat"]
    }},
    {{
      "representativeTerm": "non-toxic",
      "representativeTermCn": "无毒",
      "members": ["non-toxic"]
    }}
  ]
}}

Rules:
- Every input term MUST appear in exactly one group's members list
- A standalone term is a group with only itself as a member
- Do not invent new terms
- representativeTermCn: concise Chinese translation of the representative term (2-6 characters preferred)"""


_SUGGESTED_POSITIONS = {
    "title+bullet", "title", "bullet", "description", "search_term", "not_recommended",
}
_POSITION_LABELS = {
    "title+bullet": "标题 + 首条五点", "title": "标题", "bullet": "五点描述",
    "description": "描述 / A+", "search_term": "后台 Search Term",
    "not_recommended": "不建议使用",
}


def _parse_suggested_position(raw: object) -> str:
    normalized = str(raw or "").lower().strip().replace(" ", "")
    aliases = {"title+bullets": "title+bullet", "bullets": "bullet", "searchterm": "search_term"}
    normalized = aliases.get(normalized, normalized)
    return normalized if normalized in _SUGGESTED_POSITIONS else "not_recommended"


def _build_classify_prompt(
    groups: list[TermGroup], total_asins: int, product_info: dict | None
) -> str:
    term_summary = "\n".join(
        f'- "{group.representative_term}" (COSMO: {group.cosmo_category}/{group.cosmo_field}, '
        f'覆盖 {len(group.asins)}/{total_asins} ASIN, 加权分: {group.weighted_score}, '
        f'标题: {group.title_count}, 五点: {group.bullet_points_count}, A+: {group.a_plus_count})'
        for group in groups
    )
    if product_info:
        product_context = (
            f'\n# 目标产品信息:\n- 标题: {product_info.get("title", "")}\n'
            + (f'- 描述: {product_info.get("description")}\n' if product_info.get("description") else "")
        )
        irrelevant_instruction = """
## irrelevant (布尔值): 与目标产品是否完全无关
- true: 该词条描述的功能、场景、受众与目标产品毫无关系，搜索该词的用户不可能购买目标产品
- false: 有任何程度的相关性（哪怕是间接相关）都标记为 false
- 判断要基于目标产品的实际品类和用途，不要仅看字面意思
"""
        irrelevant_example = '"irrelevant": false, '
        irrelevant_note = "\n- irrelevant 字段必须明确给出 true 或 false"
    else:
        product_context = "\n# 注意: 未提供目标产品信息，请基于词条本身的 Amazon 搜索价值进行评分\n"
        irrelevant_instruction = irrelevant_example = irrelevant_note = ""

    return f"""你是 Amazon COSMO + Rufus 关键词评估专家。在 AI 时代，Listing 不再是简单的关键词堆砌，而是"Rufus 答案库"——每个词条都要判断是否值得写入 Listing、放在哪个位置、以及优先级。

请对以下词条进行多维度评分。
{product_context}
# 评分维度:

## relevanceScore (1-10): 与产品的相关性
- 10: 核心品类词/功能词，搜索该词的用户 100% 要找这类产品
- 7-9: 直接相关的功能/场景词
- 4-6: 间接相关，有一定关联
- 1-3: 弱相关或泛化词

## valueScore (1-10): 搜索价值和购买意图强度
- 10: 高搜索量+强购买意图（如品类大词 "yoga mat"）
- 7-9: 明确购买意图的精准词（如 "non-slip yoga mat"）
- 4-6: 有搜索量但意图不够明确（如 "exercise equipment"）
- 1-3: 低搜索量或纯信息词（如 "how to use"）

## listingScore (1-10): 是否值得写入 Listing
基于 Rufus RAG 框架判断：这个词能否成为 Rufus 采信的"答案素材"？
- 10: 必须写入，是 COSMO 知识图谱的核心节点连接词，缺少它产品会"隐形"
- 7-9: 强烈建议写入，能帮助 AI 理解产品属性/场景/人群
- 4-6: 可写可不写，有一定补充价值但非关键
- 1-3: 不建议写入，信息熵低或过于泛化（如 "high quality"、"best"）

## bulletScore (1-10): 五点描述适用性
判断这个词是否适合放在五点描述中，作为"痛点+解决方案+场景"的 Q&A 向量库：
- 10: 完美适合五点——直接回答用户高频问题（如安全性、耐用性、适配性）
- 7-9: 很适合五点——描述具体功能/使用场景/解决的痛点
- 4-6: 一般适合——可融入五点但不是核心卖点
- 1-3: 不适合五点——太泛化、太技术性、或适合放后台

## suggestedPosition: 建议埋词位置（同时决定是否保留）
这是最终的保留决策字段——选择具体位置代表"保留"，选 not_recommended 代表"不保留"。
必须与 listingScore 保持一致：listingScore >= 5 时应选择具体位置，< 5 时应选 not_recommended。
- "title+bullet": 核心品类词/场景词，必须在标题+首条五点中出现（S级）
- "title": 重要品类词，需要在标题中出现
- "bullet": 功能/场景/痛点词，适合写在五点描述中构建"答案库"
- "description": 长尾语义/叙事性场景词，适合产品描述或 A+ 页面
- "search_term": 补充性词汇，不适合前台但有搜索价值，放后台 Search Term
- "not_recommended": 与产品无关或价值太低，不建议使用
{irrelevant_instruction}
# 竞品总数: {total_asins}

# 待评分词条:
{term_summary}

# 输出格式 (纯 JSON):
{{
  "scores": [
    {{"term": "词条", "relevanceScore": 8, "valueScore": 7, "listingScore": 9, "bulletScore": 7, "suggestedPosition": "title+bullet", {irrelevant_example}"reason": "核心品类词，Rufus 必采信"}}
  ]
}}

注意:
- 必须为每个输入词条都返回评分，不能遗漏
- reason 简洁（15字以内）
- 所有分数都是 1-10 的整数
- suggestedPosition 必须是 title+bullet/title/bullet/description/search_term/not_recommended 之一{irrelevant_note}"""


# ---------------------------------------------------------------------------
# 能力注册
# ---------------------------------------------------------------------------

@capability(
    "analysis.cosmo.extract",
    description="COSMO 多模态语义提取（5 个一级域、19 个二级语义字段 + 位置标注）",
    input_model=CosmoExtractInput,
    output_model=CosmoOutput,
)
def cosmo_extract(product_info: dict, image_url: str = "") -> Result:
    """analysis.cosmo.extract — 语义提取

    Args:
        product_info: {{title, bullet_points, details, description, brand}}
    """
    bullet_points = product_info.get("bullet_points") or product_info.get("features") or []
    if isinstance(bullet_points, str):
        bullet_points = [bullet_points]
    details = (
        product_info.get("product_information")
        or product_info.get("details")
        or product_info.get("product_details_raw")
        or ""
    )
    if isinstance(details, dict):
        details = "\n".join(f"{key}: {value}" for key, value in details.items())
    elif isinstance(details, list):
        detail_lines = []
        for item in details:
            if not isinstance(item, dict):
                detail_lines.append(str(item))
                continue
            name = item.get("name") or item.get("label") or item.get("key")
            value = item.get("value")
            if name and value not in (None, ""):
                detail_lines.append(f"{name}: {value}")
            else:
                detail_lines.extend(f"{key}: {item_value}" for key, item_value in item.items())
        details = "\n".join(detail_lines)
    description = product_info.get("full_description") or product_info.get("description") or ""

    resolved_image = (
        image_url
        or product_info.get("main_image_url")
        or product_info.get("image_url")
        or ""
    )
    if not resolved_image:
        images = product_info.get("images") or []
        if isinstance(images, str):
            resolved_image = images
        elif isinstance(images, list):
            first_image = next((item for item in images if isinstance(item, str) and item), "")
            resolved_image = first_image

    title = product_info.get("title") or ""
    if not any((title, bullet_points, details, description, resolved_image)):
        return err(
            Code.ERROR_MISSING_FIELDS,
            "product_info has no analyzable listing content",
            missing=["product_info.title|bullet_points|details|description|image_url"],
        )

    prompt = COSMO_EXTRACT_PROMPT.format(
        title=title,
        features="\n".join(str(item) for item in bullet_points[:10]),
        details=details,
        description=description,
        brand=product_info.get("brand") or "",
    )
    content: list[dict] = [{"type": "text", "text": prompt}]
    if resolved_image:
        content.append({"type": "image_url", "image_url": {"url": resolved_image}})
    try:
        result = chat_json(
            messages=[{"role": "user", "content": content}],
            json_schema=CosmoOutput.model_json_schema(),
            model="pro",
            temperature=0.3,
        )
        parsed = parse_structured(result, CosmoOutput)
        return ok(data=parsed.model_dump())
    except Exception as e:
        return err(Code.ERROR_LLM, str(e))


@capability(
    "analysis.cosmo.aggregate",
    description="跨 ASIN COSMO 同义聚合（分批、跨批合并、漏词补全）",
    input_model=CalcCosmoMergeInput,
    output_model=CosmoAggregateOutput,
    requires=["analysis.cosmo.extract"],
)
def cosmo_aggregate(
    cosmo_outputs: list[dict],
    min_count: int = 1,
    target_product: str = "",
) -> Result:
    """analysis.cosmo.aggregate — 跨 ASIN COSMO 同义聚合

    流程：收集所有 term -> 按 COSMO 字段分组 -> LLM 同义聚合 -> 去重。

    Args:
        cosmo_outputs: 多个 ASIN 的 cosmo_extract 输出
        min_count: 最少出现次数阈值
        target_product: 目标产品描述，用于 representative term 选择
    """
    if cosmo_outputs and "cosmo_field" in cosmo_outputs[0]:
        merged_terms = cosmo_outputs
    else:
        merged_result = merge_cosmo_results(cosmo_outputs)
        merged_terms = merged_result.data["terms"]
    merged_terms = [term for term in merged_terms if int(term.get("count", 0)) >= max(1, min_count)]
    fields: dict[str, list[dict]] = {}
    for term in merged_terms:
        fields.setdefault(str(term.get("cosmo_field") or "unknown"), []).append(term)

    all_groups: list[TermGroup] = []
    for field_terms in fields.values():
        batches = [field_terms[index : index + 60] for index in range(0, len(field_terms), 60)]
        batch_groups: list[TermGroup] = []
        for batch in batches:
            batch_groups.extend(_aggregate_batch(batch, target_product))
        if len(batches) > 1 and len(batch_groups) > 1:
            batch_groups = _cross_batch_merge(batch_groups, target_product)
        all_groups.extend(batch_groups)
    all_groups.sort(key=lambda group: (-group.count, -group.weighted_score, group.representative_term.lower()))
    return ok(data=CosmoAggregateOutput(groups=all_groups).model_dump())


@capability(
    "analysis.cosmo.merge",
    description="兼容入口：确定性实现位于 calc.cosmo.merge",
    input_model=CalcCosmoMergeInput,
    output_model=CosmoMergeOutput,
    requires=["analysis.cosmo.extract"],
)
def cosmo_merge(cosmo_outputs: list[dict]) -> Result:
    """analysis.cosmo.merge — 跨 ASIN 合并统计

    纯客户端逻辑：将多个 ASIN 的 COSMO 结果合并，统计每个 term 的出现次数。
    不调 LLM。

    Args:
        cosmo_outputs: 多个 ASIN 的 cosmo_extract 输出
    """
    result = merge_cosmo_results(cosmo_outputs)
    terms = [MergedTerm.model_validate(term) for term in result.data["terms"]]
    return ok(data=CosmoMergeOutput(terms=terms, groups=terms).model_dump())


def _group_stats(members: list[dict]) -> dict:
    asins = sorted({asin for member in members for asin in member.get("asins", [])})
    return {
        "count": sum(int(member.get("count", 0)) for member in members),
        "title_count": sum(int(member.get("title_count", 0)) for member in members),
        "bullet_points_count": sum(int(member.get("bullet_points_count", 0)) for member in members),
        "review_count": sum(int(member.get("review_count", 0)) for member in members),
        "image_description_count": sum(int(member.get("image_description_count", 0)) for member in members),
        "a_plus_count": sum(int(member.get("a_plus_count", 0)) for member in members),
        "weighted_score": sum(int(member.get("weighted_score", 0)) for member in members),
        "asins": asins,
    }


def _make_group(members: list[dict], representative: str, representative_cn: str = "") -> TermGroup:
    rep = next((item for item in members if item["term"].lower() == representative.lower()), members[0])
    synonyms = [item["term"] for item in members if item["term"].lower() != rep["term"].lower()]
    warnings = []
    if len(members) > 5:
        warnings.append("同义组超过 5 个成员，请人工复核")
    lowered = [str(item["term"]).lower().split() for item in members]
    for left_index, left in enumerate(lowered):
        for right_index in range(left_index + 1, len(lowered)):
            right = lowered[right_index]
            if len(left) == len(right):
                continue
            shorter, longer = (left, right) if len(left) < len(right) else (right, left)
            if len(longer) - len(shorter) <= 2 and all(word in longer for word in shorter):
                warnings.append(
                    f'"{members[left_index]["term"]}" 和 "{members[right_index]["term"]}" 可能是父子关系'
                )
    coverages = [len(item.get("asins", [])) for item in members]
    if len(members) > 1 and coverages and min(coverages) > 0 and max(coverages) / min(coverages) > 3:
        warnings.append("组内 ASIN 覆盖差异过大")
    return TermGroup(
        group_id=f"{rep['cosmo_field']}::{rep['term']}",
        representative_term=rep["term"], representative_term_cn=representative_cn,
        synonyms=synonyms, members=[MergedTerm.model_validate(item) for item in members],
        cosmo_category=rep["cosmo_category"], cosmo_field=rep["cosmo_field"],
        needs_review=bool(warnings), warnings=warnings, **_group_stats(members),
    )


def _aggregate_batch(terms: list[dict], target_product: str) -> list[TermGroup]:
    if not terms:
        return []
    if len(terms) == 1:
        return [_make_group(terms, terms[0]["term"])]
    terms_text = "\n".join(f'- "{item["term"]}" (count: {item.get("count", 0)})' for item in terms)
    hint = (
        f'choose the term that best matches the target product: "{target_product}"'
        if target_product else
        "choose the most generic, high-search-volume term (usually the shortest and most universal expression)"
    )
    prompt = COSMO_AGGREGATE_PROMPT.format(target_product_hint=hint, terms_text=terms_text)
    try:
        raw = require_json(chat_json(prompt=prompt, model="lite", temperature=0.2))
        llm_groups = raw.get("groups", []) if isinstance(raw, dict) else []
    except Exception:
        llm_groups = []
    lookup = {item["term"].lower(): item for item in terms}
    assigned: set[str] = set()
    groups: list[TermGroup] = []
    for raw_group in llm_groups:
        members = []
        for member_name in raw_group.get("members", []):
            key = str(member_name).lower()
            if key in lookup and key not in assigned:
                members.append(lookup[key])
                assigned.add(key)
        if members:
            groups.append(_make_group(
                members,
                str(raw_group.get("representativeTerm") or members[0]["term"]),
                str(raw_group.get("representativeTermCn") or ""),
            ))
    for key, term in lookup.items():
        if key not in assigned:
            groups.append(_make_group([term], term["term"]))
    return groups


def _cross_batch_merge(groups: list[TermGroup], target_product: str) -> list[TermGroup]:
    representatives = []
    original = {}
    for group in groups:
        item = {
            "term": group.representative_term,
            "cosmo_category": group.cosmo_category,
            "cosmo_field": group.cosmo_field,
            **_group_stats([member.model_dump() for member in group.members]),
        }
        representatives.append(item)
        original[group.representative_term.lower()] = group
    cross = _aggregate_batch(representatives, target_product)
    output: list[TermGroup] = []
    for cross_group in cross:
        source_groups = [original[member.term.lower()] for member in cross_group.members if member.term.lower() in original]
        if not source_groups:
            continue
        if len(source_groups) == 1:
            output.append(source_groups[0])
            continue
        # aggregate.ts 跨批时不信任 LLM 的代表词，而是选 count 最高的原组。
        primary = max(source_groups, key=lambda group: group.count)
        members = [member.model_dump() for source in source_groups for member in source.members]
        output.append(_make_group(
            members, primary.representative_term, primary.representative_term_cn
        ))
    return output


@capability(
    "analysis.cosmo.classify",
    description="COSMO 词组规则 30% + LLM 70% 分类与埋词位置建议",
    input_model=CosmoClassifyInput,
    output_model=CosmoClassifyOutput,
    requires=["analysis.cosmo.aggregate"],
)
def cosmo_classify(
    groups: list[dict],
    total_asins: int,
    product_info: dict | None = None,
    batch_size: int = 50,
) -> Result:
    parsed_groups = [TermGroup.model_validate(group) for group in groups]
    if not parsed_groups:
        return ok(data=CosmoClassifyOutput().model_dump())
    max_weight = max((group.weighted_score for group in parsed_groups), default=1) or 1
    output: list[TermGroup] = []
    for start in range(0, len(parsed_groups), max(1, batch_size)):
        batch = parsed_groups[start : start + max(1, batch_size)]
        prompt = _build_classify_prompt(batch, total_asins, product_info)
        llm_failed = False
        try:
            raw = require_json(chat_json(prompt=prompt, model="pro", temperature=0.2))
            score_map = {
                str(item.get("term") or "").lower(): item
                for item in (raw.get("scores", []) if isinstance(raw, dict) else [])
            }
        except Exception:
            score_map = {}
            llm_failed = True
        for group in batch:
            rule = (
                (len(group.asins) / total_asins if total_asins else 0) * 30
                + (20 if group.title_count else 0)
                + (10 if group.bullet_points_count else 0)
                + group.weighted_score / max_weight * 40
            )
            if llm_failed:
                grade = "S" if rule >= 70 else "A" if rule >= 50 else "B" if rule >= 30 else "C"
                position = "title+bullet" if rule >= 70 else "bullet" if rule >= 50 else "search_term" if rule >= 30 else "not_recommended"
                output.append(group.model_copy(update={
                    "classification": grade,
                    "keep_in_listing": rule >= 30,
                    "suggested_position": position,
                    "reason": f"LLM 评分失败，仅基于规则分 [{_POSITION_LABELS[position]}]",
                    "scores": {"rule_score": round(rule, 1), "final_score": round(rule, 1)},
                }))
                continue
            item = score_map.get(group.representative_term.lower())
            if item:
                relevance = min(10, max(1, float(item.get("relevanceScore", 5))))
                value = min(10, max(1, float(item.get("valueScore", 5))))
                listing_score = min(10, max(1, float(item.get("listingScore", 5))))
                bullet_score = min(10, max(1, float(item.get("bulletScore", 5))))
                llm_score = (relevance + value + listing_score) / 3 * 10
                position = _parse_suggested_position(item.get("suggestedPosition"))
                irrelevant = bool(item.get("irrelevant", False)) and bool(product_info)
                reason = str(item.get("reason") or "")
            else:
                relevance = value = None
                listing_score = bullet_score = 5
                llm_score, irrelevant, reason = rule, False, "LLM 未返回评分，仅基于规则分"
                position = "not_recommended"
            final = rule * 0.3 + llm_score * 0.7
            if irrelevant:
                grade, position = "C", "not_recommended"
            elif final < 30 or listing_score <= 3:
                grade = "C"
            elif final >= 70 and listing_score >= 8 and bullet_score >= 7:
                grade = "S"
            elif final >= 50 and listing_score >= 6:
                grade = "A"
            else:
                grade = "B"
            display_reason = (
                f"与产品无关: {reason} [{_POSITION_LABELS[position]}]"
                if irrelevant else f"{reason} [{_POSITION_LABELS[position]}]"
            )
            scores = {
                "rule_score": round(rule, 1),
                "llm_listing_score": listing_score,
                "llm_bullet_score": bullet_score,
                "final_score": round(final, 1),
            }
            if relevance is not None:
                scores["llm_relevance_score"] = relevance
            if value is not None:
                scores["llm_value_score"] = value
            output.append(group.model_copy(update={
                "classification": grade,
                "keep_in_listing": position != "not_recommended",
                "suggested_position": position,
                "reason": display_reason,
                "scores": scores,
            }))
    return ok(data=CosmoClassifyOutput(groups=output).model_dump())
