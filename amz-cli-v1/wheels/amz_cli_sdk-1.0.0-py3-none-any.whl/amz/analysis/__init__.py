"""
L2 原子化推理 — LLM 固定框架，每个能力完成单一推理任务。

设计原则
--------
- **固定 prompt 模板**：每个能力有稳定的 prompt 模板和方法论，不做 agent 分支决策
- **返回结构化 JSON**：所有输出为 Pydantic 模型，schema 确定
- **纯函数，无副作用**：接收具体字段值（dict/list/str），不自动触发 fetch，不修改 entity
- **依赖数据由调用方保证**：entities 层负责在调用前补齐所需字段
- **可组合**：被 entities lazy 字段引用，或被 composite Pipeline step 调用

与 composite/agents 的关系
--------------------------
- **analysis → entities**：被 lazy 字段引用，entities 负责补齐依赖数据后调用纯函数
- **analysis → composite**：作为 Pipeline 的一个 step 被调用——步骤编排固定，但步骤内部是 LLM 推理
- **analysis → agents**：被 SKILL.md 描述为可用工具，agent 自行决定是否调用、何时调用

模块清单
--------

============== ==============================================
模块           职责
============== ==============================================
voc            VOC：strengths / weaknesses / use-insights / praise / wishlist
keyword        四维评分 / 语义相关性 / 覆盖检查 / 意图聚类
listing        全量改写 / 微插入 / 位置分配 / 局部改写
innovation     可复制性 / 材质 / 基准品差分创新（多模态）
demand         搜索需求评估 + 进入时机
cosmo          语义提取 / 同义聚合 / 规则+LLM 分类
market_gap     市场缺口（成功要素/痛点聚合/微改造提案）
traffic        主定价维度 / 正交维度发现 / ASIN 打标
============== ==============================================

用法::

    from amz.analysis.voc import voc_strengths
    result = voc_strengths(product_info=info, reviews=reviews)
"""
