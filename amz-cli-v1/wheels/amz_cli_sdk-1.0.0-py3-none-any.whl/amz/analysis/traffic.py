"""Traffic Map 的 ASIN 维度发现与单产品打标原子能力。"""

from __future__ import annotations

import json
import math

from pydantic import BaseModel, ConfigDict, Field

from amz.envelope import Code, Result, err, ok
from amz.infra.llm import chat_json
from amz.analysis.base import parse_structured
from amz.registry import capability
from amz.schemas.analysis_inputs import ClassifyAsinInput, TrafficAnalysisInput


class _TrafficModel(BaseModel):
    model_config = ConfigDict(extra="ignore")


class Dimension(_TrafficModel):
    """流量地图维度（一个可枚举的产品属性）。"""

    name: str  # 维度名（如 Material / Use Case）
    values: list[str] = Field(default_factory=list)  # 维度取值列表（可枚举）
    rationale: str = ""  # 选取该维度的理由
    role: str = "llm"  # 维度角色：llm（LLM 原始输出）/ primary_pricing（主定价维度）/ discriminative（判别性正交维度）


class PrimaryDimensionOutput(_TrafficModel):
    """主定价维度发现输出。"""

    primary_pricing_dimension: Dimension  # 解释市场价格差异的主定价维度


class DimensionsOutput(_TrafficModel):
    """正交维度发现输出。"""

    dimensions: list[Dimension] = Field(default_factory=list)  # 与主定价维度正交的判别性维度列表（最多 4 个）


class AsinClassificationOutput(_TrafficModel):
    """单 ASIN 维度打标输出。"""

    classification: dict[str, str] = Field(default_factory=dict)  # 维度名→该 ASIN 所属取值的映射


def _product_lines(products: list[dict], limit: int = 50) -> str:
    lines = []
    for product in products[:limit]:
        keywords = product.get("top_keywords", product.get("keywords", [])) or []
        if isinstance(keywords, list):
            keywords = ", ".join(str(item) for item in keywords[:3])
        lines.append(
            f'- {product.get("asin", "")} | ${product.get("price", "?")} | '
            f'{str(product.get("title", ""))[:80]} | top_kws: {keywords or "-"} | '
            f'raw: {str(product.get("raw_text", product.get("description", "")))[:150]}'
        )
    return "\n".join(lines)


def _format_price_bands(price_bands: list[dict]) -> str:
    if not price_bands:
        return "none"
    lines = []
    for band in price_bands:
        label = band.get("label", "")
        low = band.get("lo", band.get("min", 0))
        high = band.get("hi", band.get("max"))
        high_text = "inf" if high is None or high == math.inf else high
        lines.append(f'- {label} (range: [${low}, ${high_text}))')
    return "\n".join(lines)


def _format_keyword_clusters(keyword_clusters: list[dict] | dict) -> str:
    clusters = keyword_clusters.get("clusters", []) if isinstance(keyword_clusters, dict) else keyword_clusters
    lines = []
    for cluster in clusters or []:
        samples = cluster.get("keywords", cluster.get("members", [])) or []
        lines.append(
            f'- {cluster.get("name", cluster.get("label", ""))}: '
            f'{str(cluster.get("intent") or "").strip()} | sample_kws: '
            f'{", ".join(str(item) for item in samples[:3])}'
        )
    return "\n".join(lines) if lines else "none"


@capability(
    "analysis.asin.primary-pricing-dimension",
    description="选择解释市场价格分层的单一主规格维度",
    input_model=TrafficAnalysisInput,
    output_model=PrimaryDimensionOutput,
    requires=["analysis.cluster.keywords"],
)
def discover_primary_pricing_dimension(
    main_keyword: str,
    price_bands: list[dict],
    refinement_dimensions: dict,
    keyword_clusters: list[dict] | dict,
    products: list[dict],
) -> Result:
    prompt = f"""You are analyzing the "{main_keyword}" Amazon market.

=== Input 1: Amazon front-end price bands (from "Deals & Discounts" filter) ===
{_format_price_bands(price_bands)}

=== Input 2: Amazon refinement dimensions (left-side filters) ===
{json.dumps(refinement_dimensions, ensure_ascii=False) if refinement_dimensions else "none"}

=== Input 3: Keyword clusters (user search intent groups) ===
{_format_keyword_clusters(keyword_clusters)}

=== Input 4: Sample products (ASIN | price | title | top reverse keywords) ===
{_product_lines(products)}

=== Pricing Theory ===
In most product categories, ONE primary spec drives the price tiers. Consumers anchor
on a single number/attribute when comparing prices. Examples:
  - MP3 player → storage capacity (GB)
  - Mattress → thickness (inch) or size
  - Power bank → battery capacity (mAh)
  - Bedding → thread count or size
  - Watch → movement type (quartz vs automatic)
  - Camera → sensor size or megapixels
This is the dimension whose different values map to clearly different price tiers.

=== Task ===
Identify the ONE primary pricing dimension for this market.
- It must be a SINGLE concrete attribute (NOT a vague concept like "quality" or "intent").
- Its values must be enumerable and clearly distinguishable.
- It should explain price variation across the sample products above.
- If Amazon's refinement has a dimension that obviously plays this role, use it.

Output JSON (no markdown):
{{
  "primary_pricing_dimension": {{
    "name": "Dimension Name",
    "values": ["val_low", "val_mid", "val_high"],
    "rationale": "1-2 sentences on why this is the primary price driver in this market"
  }}
}}"""
    try:
        response = chat_json(
            prompt=prompt, json_schema=PrimaryDimensionOutput.model_json_schema(),
            model="pro", temperature=0.2,
        )
        output = parse_structured(response, PrimaryDimensionOutput)
        output.primary_pricing_dimension.role = "primary_pricing"
        return ok(data=output.model_dump())
    except Exception as exc:
        return err(Code.ERROR_LLM, str(exc))


@capability(
    "analysis.asin.discover-dimensions",
    description="发现与主定价维度正交的 2-4 个购买决策维度",
    input_model=TrafficAnalysisInput,
    output_model=DimensionsOutput,
    requires=["analysis.asin.primary-pricing-dimension"],
)
def discover_asin_dimensions(
    main_keyword: str,
    primary_dimension: dict,
    price_bands: list[dict],
    refinement_dimensions: dict,
    keyword_clusters: list[dict] | dict,
    products: list[dict],
) -> Result:
    prompt = f"""You are analyzing the "{main_keyword}" Amazon market.

=== Input 1: Amazon front-end price bands ===
{_format_price_bands(price_bands)}

=== Input 2: Amazon refinement dimensions ===
{json.dumps(refinement_dimensions, ensure_ascii=False) if refinement_dimensions else "none"}

=== Input 3: Keyword clusters (user search intent groups) ===
{_format_keyword_clusters(keyword_clusters)}

=== Input 4: Sample products ===
{_product_lines(products)}

=== Already-decided primary pricing dimension ===
{json.dumps(primary_dimension, ensure_ascii=False)}

=== Note ===
Three other dimensions (price_band, rating_band, brand_origin) will be added
automatically downstream. You do NOT need to propose them.

=== Task ===
Identify 2-4 ADDITIONAL discriminative dimensions, ORTHOGONAL to the primary pricing
dimension and to the auto-injected ones. They should:
1. Be highly relevant to purchase decisions
2. Have enumerable, finite distinct values
3. Be visible from product listings / refinement / search behavior
4. Capture variation NOT already captured by the primary or price_band / rating_band / brand_origin
5. Reflect real signals — if keyword clusters show a clear split (e.g. "for women" vs
   "for men", or "leather" vs "quilted"), extract that as a dimension. DO NOT just
   copy keyword cluster names as values; extract the underlying attribute.

Output JSON (no markdown):
{{
  "dimensions": [
    {{"name": "Dimension Name", "values": ["v1", "v2", "v3"]}}
  ]
}}"""
    try:
        response = chat_json(
            prompt=prompt, json_schema=DimensionsOutput.model_json_schema(),
            model="pro", temperature=0.2,
        )
        output = parse_structured(response, DimensionsOutput)
        output.dimensions = output.dimensions[:4]
        for dimension in output.dimensions:
            dimension.role = "discriminative"
        return ok(data=output.model_dump())
    except Exception as exc:
        return err(Code.ERROR_LLM, str(exc))


@capability(
    "analysis.asin.classify",
    description="按已发现维度为单个 ASIN 打标",
    input_model=ClassifyAsinInput,
    output_model=AsinClassificationOutput,
    requires=["analysis.asin.discover-dimensions"],
)
def classify_asin(product: dict, dimensions: list[dict]) -> Result:
    normalized_dimensions = []
    for dimension in dimensions:
        values = [str(value) for value in dimension.get("values", [])]
        if "other" not in values:
            values.append("other")
        normalized_dimensions.append({**dimension, "values": values})
    prompt = f"""Classify ONE Amazon product using the dimensions below.

=== Dimensions ===
{json.dumps(normalized_dimensions, ensure_ascii=False)}

=== Product info ===
ASIN: {product.get('asin', '')}
Price: {product.get('price', '')}
Title: {product.get('title', '')}

Top reverse keywords (the actual search queries that lead users to this product;
these are strong hints for target user, use case, and product category):
{json.dumps(product.get('top_keywords', product.get('keywords', [])), ensure_ascii=False)}

Product detail text (from the product page):
{str(product.get('raw_text', product.get('description', '')))[:2000]}

=== Rules ===
- Use ALL the info above (title + keywords + detail text) when assigning values.
- Assign the best matching value for each dimension.
- Use "other" if the product clearly has a value for this dimension but it doesn't fit
  any of the listed values (e.g. dimension Material has [Leather, Fabric] and the
  product is Plastic).
- Use "unknown" ONLY if the info genuinely doesn't reveal that attribute.
- Top reverse keywords are especially useful for target-user / use-case / category dimensions.

Output JSON (no markdown):
{{
  "classification": {{"dim_name_1": "value_1", "dim_name_2": "value_2"}}
}}"""
    try:
        response = chat_json(
            prompt=prompt, json_schema=AsinClassificationOutput.model_json_schema(),
            model="pro", temperature=0.2,
        )
        output = parse_structured(response, AsinClassificationOutput)
        allowed = {item["name"]: set(item["values"]) | {"unknown"} for item in normalized_dimensions}
        cleaned = {}
        for name, values in allowed.items():
            value = output.classification.get(name, "unknown")
            cleaned[name] = value if value in values else "other"
        return ok(data=AsinClassificationOutput(classification=cleaned).model_dump())
    except Exception as exc:
        return err(Code.ERROR_LLM, str(exc))
