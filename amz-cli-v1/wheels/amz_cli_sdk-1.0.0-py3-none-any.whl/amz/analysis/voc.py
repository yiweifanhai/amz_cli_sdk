"""
VOC（Voice of Customer）分析：创新优势 / 差评痛点 / 使用洞察。

吸收 product_dev_v2 m03 三路拆解，完整保留原始 prompt 方法论。
"""

from __future__ import annotations

import json

from pydantic import BaseModel, ConfigDict, Field, ValidationError

from amz.envelope import Result, ok, err, Code
from amz.registry import capability
from amz.infra.llm import chat_json
from amz.analysis.base import parse_structured
from amz.schemas.analysis_inputs import VocInput, VocStrengthsInput, VocWeaknessesInput
from amz.schemas.voc import (
    ProductVocListing,
    ProductVocReview,
    VocSatisfactionMetrics,
    VocStrengthsAnalysisInput,
    VocStrengthsOutput,
    VocUseInsightsAnalysisInput,
    VocUseInsightsOutput,
    VocWeaknessSignalsInput,
    VocWeaknessSignalsOutput,
    VocWeaknessesOutput,
)


class _VocModel(BaseModel):
    model_config = ConfigDict(extra="ignore")


class ValuePerception(_VocModel):
    """价值感知（用户对性价比的整体评价）。"""

    overall_sentiment: str = "信息不足"  # 整体情感（超值/物有所值/偏贵但不后悔/信息不足）
    summary: str = ""  # 一句话概括性价比整体评价
    evidence: list[str] = Field(default_factory=list)  # 原文证据摘录列表
    mentioned_by: int = 0  # 提及用户数


class VocPraiseOutput(_VocModel):
    """好评赞美分析输出。"""

    loved_features: list[dict] = Field(default_factory=list)  # 被称赞的功能列表 {feature, enthusiasm, evidence, mentioned_by}
    delight_factors: list[dict] = Field(default_factory=list)  # 超出预期的惊喜点 {delight, category, evidence, mentioned_by}
    value_perception: ValuePerception = Field(default_factory=ValuePerception)  # 价值感知
    durability_signals: list[dict] = Field(default_factory=list)  # 耐用性信号 {observation, usage_duration, evidence, mentioned_by}
    competitive_mentions: list[dict] = Field(default_factory=list)  # 竞品提及 {competitor_name, comparison_result, win_reason, evidence, mentioned_by}
    feature_satisfaction_ranking: list[dict] = Field(default_factory=list)  # 功能满意度排名 {feature, praise_count, representative_quote}


class VocWishlistOutput(_VocModel):
    """愿望清单输出（用户渴望的新功能/变体/配件）。"""

    feature_requests: list[dict] = Field(default_factory=list)  # 新功能请求 {request, source_type, feasibility, evidence, mentioned_by}
    improvement_suggestions: list[dict] = Field(default_factory=list)  # 现有功能改进建议 {target_feature, suggestion, evidence, mentioned_by}
    variant_requests: list[dict] = Field(default_factory=list)  # 变体需求（新颜色/尺寸/规格等） {variant, evidence, mentioned_by}
    accessory_requests: list[dict] = Field(default_factory=list)  # 配件需求 {accessory, evidence, mentioned_by}


def _llm_output(prompt: str, output_model: type[BaseModel], model: str = "pro") -> Result:
    try:
        result = chat_json(
            prompt=prompt,
            json_schema=output_model.model_json_schema(),
            model=model,
            temperature=0.3,
        )
        parsed = parse_structured(result, output_model)
        return ok(data=parsed.model_dump())
    except Exception as exc:
        return err(Code.ERROR_LLM, str(exc))


def _features(product_info: dict) -> list[str]:
    raw = product_info.get("bullet_points", product_info.get("features", [])) or []
    return [raw] if isinstance(raw, str) else [str(item) for item in raw]


def _product_details(product_info: dict) -> str:
    parts: list[str] = []
    for key in ("details", "product_information", "productDescription", "description"):
        value = product_info.get(key)
        if value:
            parts.append(json.dumps(value, ensure_ascii=False) if isinstance(value, (dict, list)) else str(value))
    for key in ("aboutProduct", "productDetails"):
        value = product_info.get(key)
        if value:
            parts.append(json.dumps(value, ensure_ascii=False))
    return "\n".join(parts)[:12000]

# ---------------------------------------------------------------------------
# Prompt 模板（对齐 product_dev_v2 m03_product_analysis.py）
# ---------------------------------------------------------------------------

_JSON_ONLY_SUFFIX = """
严格要求：只输出 JSON，不要任何 markdown 标题、说明文字或 ``` 围栏。字符串值内部如需引用词语，一律用中文引号「」或『』，绝不能使用英文双引号 "（否则会破坏 JSON 结构导致解析失败）。"""


VOC_STRENGTHS_PROMPT = """你是一位拥有10年经验的亚马逊选品专家和工业设计师，擅长通过 Listing 的细微差异发现产品的核心竞争力。

任务：基于下面的产品标题、五点描述、产品参数，对该产品做深度解构，找出它真实的创新点和竞争优势。

要求：
1. 去伪存真：忽略 "High Quality"、"Best Choice" 这类营销辞令，只看真实的参数、结构变化和独特功能。
2. 差分分析：假设市场上 90% 的同类产品都具备基础功能，重点找出这个产品相比它们做了哪些改进（材质升级、增加配件、结构优化、人性化设计等）。
3. 参数量化：每个创新点必须在 detail 中引用具体的参数、材质、尺寸数值或结构描述作为证据。例如，「304不锈钢」而非「优质不锈钢」，「10叶片电机」而非「高效电机」，「防水等级 IPX5」而非「防水设计」。
4. 差异化程度标注：每个创新点标注是「实质性创新」（参数/材质/结构有可验证的差异）还是「定位创新」（功能相同但通过组合/包装/人群定位形成差异）。

## 输入数据
产品标题：{title}

五点描述：
{features}

产品参数：
{details}

## 输出 JSON 结构（所有 value 用中文）：
{{
  "summary": "一句话概括该产品的核心定位与市场切入点",
  "innovation_and_competitive_advantages": [
    {{"innovation_summary": "物理变化+功能获益的简短标题", "detail": "详细拆解，包括材质/尺寸/结构差异等，引用原文中的具体参数作为证据", "innovation_type": "实质性创新|定位创新"}}
  ]
}}
按重要性从高到低排序。
""" + _JSON_ONLY_SUFFIX


VOC_WEAKNESSES_PROMPT = """你是一位资深的亚马逊市场研究专家与产品战略顾问，擅长用 VOC（Voice of Customer）分析法，从评论中提取高价值洞察。

任务：对下面的产品评论做深度解析，产出一份实操性强的 VOC 洞察报告。

分析框架：
1. 核心痛点与缺陷：归纳导致负评的主要原因，区分"偶发质量问题"(Quality)与"结构性设计缺陷"(Structural)、"说明/使用问题"(Instructional)，按对体验的影响排序。
2. 未满足的隐性需求：捕捉 "I wish..."、"If only..."、"如果能...就好了" 这类陈述，以及用户需额外购买配件才能解决的问题。

## 满意度上下文
总评论数：{total_reviews}
好评率（4-5星）：{positive_pct}%
差评率（1-2星）：{negative_pct}%
产品综合评分：{product_rating}

## 辩证分析要求（重要）
这是一个{rating_label}的产品。请在分析每个痛点时遵循以下原则：
1. 频次加权：每个问题的严重程度不仅要看投诉的绝对数量，还要看它在总评论中的占比。例如，一个拥有 1000+ 条评论、好评率 92% 的产品，被 7 人投诉的某个问题很可能只是个体差异或个人偏好，不应标注为「High」严重度。
2. 好评背景对照：对于任何被识别为痛点的问题，请同时检视好评中是否有大量相反的证据。例如，若 7 条差评投诉「味道不好」，但好评区大量提及「气味宜人」或「香味很棒」，则应在 dialectical_note 中标注这一矛盾——说明该问题可能是个人敏感度差异而非产品质量缺陷。
3. 严重度校准：High 严重度应仅保留给（a）涉及安全隐患的问题，（b）在好评率 <85% 的产品中高频出现的问题，或（c）结构性/设计性缺陷（非偶发品控）。对于高满意度产品中的低频投诉，应标记为 Medium 或 Low。
4. 结论导向：请综合满意度上下文，给出一个 balanced_assessment，说明整体来看这些问题的实际影响程度。

## 输入数据
产品标题：{title}

五点描述：
{features}

星级分布：{star_dist}

用户评论：
{reviews}

## 输出规范（严格要求）
1. 每个 top_issue 和 unmet_need 必须包含 cnt（出现次数）、total_referenced（参与统计的评论总数）和 ratio（比例，例如 "7/250 (2.8%)"）。
2. 每个条目的 evidence 必须引用至少 1 条原文评论的原文摘录，不能是概括或推测。
3. issue_type 必须严格三选一：Structural（设计结构问题）、Quality（品控/材质质量问题）、Instructional（说明书/使用说明不清）。
4. cnt 必须是有明确提及该问题的评论计数，不能估算。

## 输出 JSON 结构（所有 value 用中文）：
{{
  "satisfaction_assessment": "综合考虑评分与评论量，客观评价该产品整体满意度水平的一句话",
  "top_issues": [
    {{"pain_point": "痛点", "severity": "High|Medium|Low", "evidence": "原文证据摘录（必须引用原文）", "cnt": 出现次数整数, "total_referenced": 参与统计的总评论数整数, "ratio": "例如 7/250 (2.8%)", "issue_type": "Structural|Quality|Instructional", "dialectical_note": "若好评中对此有相反证据或该问题因整体高满意度应降低权重，在此说明；若无矛盾则填「无」"}}
  ],
  "unmet_needs": [
    {{"unmet_need": "未满足需求", "impact": "High|Medium|Low", "description": "说明", "evidence": "原文证据（必须引用原文）", "cnt": 出现次数整数, "total_referenced": 参与统计的总评论数整数, "ratio": "例如 7/250 (2.8%)"}}
  ],
  "balanced_assessment": "综合满意度上下文，客观评估上述痛点对该产品整体竞争力的实际影响（2-3句话）"
}}
""" + _JSON_ONLY_SUFFIX


VOC_USE_INSIGHTS_PROMPT = """你是一位资深的消费者行为研究员，擅长从用户评论中提取产品使用场景、用户画像和购买动机。

任务：对下面的产品评论做消费者洞察挖掘，从评论中提取三类信息——用户如何使用（场景）、谁在使用（人群）、为什么购买（动机）。请同时从好评和差评中提取信息，正面评论中的场景/动机信号往往更丰富。

## 提取维度

### 1. 使用场景（Use Scenarios）
- 用户在哪里使用这个产品？（场景：家里、办公室、户外、旅行、车上、教堂、健身房等）
- 什么时候使用？（时间：日常、出差、假期、周末、特定活动）
- 如何使用？（方式：搭配什么使用、使用频率、是否作为替代品）
- 特别关注用户提到的意外使用方式或创造性用法

### 2. 用户画像（User Personas）
- 购买者是谁？（角色：自用者、送礼者、家长、教师、办公室职员等）
- 终端使用者是谁？（若购买者与使用者不同，需区分）
- 有什么特征？（年龄暗示、职业暗示、兴趣爱好、生活方式、技术水平）
- 有什么特殊需求？（如：左撇子、过敏体质、老年用户、初学者等）

### 3. 购买动机（Purchase Motivations）
- 为什么选择这款产品？（触发因素：替换旧品、新需求、被推荐、促销）
- 和什么对比过？（竞品比较：和哪些品牌/类型对比过，为什么最终选了这个）
- 决策关键因素是什么？（价格、功能、材质、外观、品牌信任、评价、配送速度等）
- 哪些是惊喜点？（超出预期的功能或体验）

## 输入数据
产品标题：{title}

用户评论：
{reviews}

## 输出 JSON 结构（所有 value 用中文，frequency 取 高频|中频|低频）：
{{
  "use_scenarios": [
    {{"scenario": "场景描述（具体，包含时间、地点、方式）", "frequency": "高频|中频|低频", "evidence": "原文证据摘录", "mentioned_by": 提及用户数整数}}
  ],
  "user_personas": [
    {{"persona": "用户群体名称（例如 职场新手妈妈、退休园艺爱好者）", "traits": "具体特征和行为描述", "evidence": "原文证据摘录", "mentioned_by": 提及用户数整数}}
  ],
  "purchase_motivations": [
    {{"motivation": "购买动机描述", "decision_factor_type": "功能需求|价格敏感|外观设计|品牌信任|礼品需求|替代升级|推荐种草|其他", "evidence": "原文证据摘录", "mentioned_by": 提及用户数整数}}
  ]
}}

按 mentioned_by 从高到低排序，每个维度至少提取 3-5 条（若有足够信号）。
""" + _JSON_ONLY_SUFFIX


VOC_PRAISE_PROMPT = """你是一位资深的消费者洞察专家，擅长从用户好评中挖掘产品真正的竞争力——不是卖家声称的卖点，而是用户用钱包投票后亲口验证的优势。

任务：对下面的产品好评做深度挖掘，找出用户真正喜爱什么、什么超出了预期、产品在真实使用中表现出哪些卖家没有宣传的亮点。

## 提取维度

### 1. 被用户喜爱的功能/特性（Loved Features）
- 用户在评论中明确称赞的具体功能、设计细节或使用体验
- 区分狂热度：
  - 「狂热」：使用强烈情感词汇（love、amazing、incredible、best ever、game changer 等）
  - 「认可」：明确肯定但语气平实（good、works well、happy with、pleased 等）
  - 「提及」：顺带提及但不带强烈情感
- 排除泛泛的营销式好评（"Great product"、"Highly recommend"），只保留有具体指向的称赞

### 2. 惊喜/超出预期的点（Delight Factors）
- 用户明确表示「没想到」「超出预期」「惊喜」的功能或体验
- 分类：功能惊喜（没想到这么好用）| 质量惊喜（没想到材质/做工这么好）| 体验惊喜（没想到用起来这么方便/舒服）| 配件惊喜（没想到还送了XX/XX设计很贴心）
- 特别关注：卖家在 Listing 中没有重点宣传、但用户反复提到的点

### 3. 价值感知（Value Perception）
- 用户对性价比的评价：「超值」（worth every penny / great value / 比想象中好太多）、「物有所值」（fair price / reasonable）、「偏贵」（a bit pricey but worth it / expensive but good）
- 如果用户明确说「比 XX 品牌便宜但质量一样好」这类对比，要摘录

### 4. 耐用性/长期使用信号（Durability Signals）
- 使用了一段时间后的反馈（"after 3 months..."、"still working great"、"holding up well"）
- 如果有反面信号（"started to..."），也记录下来——这是长期可靠性的关键信号

### 5. 竞品对比（Competitive Mentions）
- 用户提到的竞品品牌/产品名称，以及对比结论
- 胜出原因：用户亲口说的为什么这个更好

### 6. 功能满意度排名（Feature Satisfaction Ranking）
- 按被提及次数对产品的核心功能做排序，标注每个功能的被称赞次数和代表性摘录

## 输入数据
产品标题：{title}

五点描述（供了解产品功能列表）：
{features}

好评（4-5星）：
{reviews}

## 输出 JSON 结构（所有 value 用中文）：
{{
  "loved_features": [
    {{"feature": "被称赞的具体功能/特性", "enthusiasm": "狂热|认可|提及", "evidence": "原文证据摘录（必须引用原文）", "mentioned_by": 提及用户数整数}}
  ],
  "delight_factors": [
    {{"delight": "超出预期的惊喜点描述", "category": "功能惊喜|质量惊喜|体验惊喜|配件惊喜", "evidence": "原文证据摘录", "mentioned_by": 提及用户数整数}}
  ],
  "value_perception": {{
    "overall_sentiment": "超值|物有所值|偏贵但不后悔|信息不足",
    "summary": "一句话概括用户对性价比的整体评价",
    "evidence": ["原文摘录1", "原文摘录2"],
    "mentioned_by": 提及用户数整数
  }},
  "durability_signals": [
    {{"observation": "耐用性相关发现（正面或负面）", "usage_duration": "用户自称的使用时长", "evidence": "原文证据摘录", "mentioned_by": 提及用户数整数}}
  ],
  "competitive_mentions": [
    {{"competitor_name": "被提及的竞品品牌/产品名", "comparison_result": "胜出|平手|落败", "win_reason": "用户认为胜出或落败的原因", "evidence": "原文证据摘录", "mentioned_by": 提及用户数整数}}
  ],
  "feature_satisfaction_ranking": [
    {{"feature": "功能名", "praise_count": 被称赞次数整数, "representative_quote": "最能代表用户态度的原文摘录"}}
  ]
}}

按 mentioned_by 从高到低排序。如果某个维度没有足够信号（如没有竞品对比或耐用性反馈），返回空数组或「信息不足」。
""" + _JSON_ONLY_SUFFIX


VOC_WISHLIST_PROMPT = """你是一位资深的产品经理，擅长从用户评论中提取产品迭代信号——不只是修 bug，更是发现用户渴望的新功能和新变体。

任务：对下面的全部产品评论做愿望清单挖掘。注意：以下提取的不是用户投诉（那些是痛点），而是用户表达「想要」「希望」「如果能有」的积极愿望。即使是好评用户，也常会说「I love it, but I wish it had...」。

## 提取维度

### 1. 功能请求（Feature Requests）
- 用户明确提出想要的新功能、新特性（"I wish it had..."、"would be nice if..."、"如果能X就好了"）
- 标记来源：好评中提及 | 差评中提及 | 中性
- 评估可行性：高（小改动即可实现）| 中（需要一定开发）| 低（需要重大改动或违背产品定位）

### 2. 改进建议（Improvement Suggestions）
- 用户对现有功能的改进意见（"would be better if..."、"建议把X改成Y"）
- 必须指定针对哪个现有功能做改进
- 区分改进建议 vs 痛点投诉：改进建议是建设性的、具体的、指向解决方案的；痛点投诉是「X 坏了/不好用」但没有提出怎么改

### 3. 变体请求（Variant Requests）
- 用户想要但当前没有的尺寸、颜色、材质、款式等变体
- 例如：「希望有更大的尺寸」「如果有白色就好了」「能不能出个便携版」

### 4. 配件/附带需求（Accessory Requests）
- 用户希望附带或单独购买的配件
- 例如：「希望附带收纳盒」「如果能配一个挂墙支架就好了」「需要额外的替换头」

## 重要边界
- 不要提取已经在产品中实现的功能（参考五点描述确认）
- 不要提取纯粹的投诉（那是弱点分析的事），只提取有「建设性提议」的内容
- 即使是 1-2 条用户提到的小众需求也要记录——小众需求也可能是蓝海信号

## 输入数据
产品标题：{title}

五点描述（供了解产品现有功能列表）：
{features}

全部用户评论（包含好评和差评）：
{reviews}

## 输出 JSON 结构（所有 value 用中文）：
{{
  "feature_requests": [
    {{"request": "用户想要的功能描述", "source_type": "好评中提及|差评中提及|中性", "evidence": "原文证据摘录（必须引用原文）", "mentioned_by": 提及用户数整数, "feasibility": "高|中|低"}}
  ],
  "improvement_suggestions": [
    {{"suggestion": "具体改进建议", "target_feature": "针对的现有功能名称", "evidence": "原文证据摘录", "mentioned_by": 提及用户数整数}}
  ],
  "variant_requests": [
    {{"variant": "用户想要的变体描述", "evidence": "原文证据摘录", "mentioned_by": 提及用户数整数}}
  ],
  "accessory_requests": [
    {{"accessory": "用户希望附带或配套的配件", "evidence": "原文证据摘录", "mentioned_by": 提及用户数整数}}
  ]
}}

按 mentioned_by 从高到低排序。如果某个维度没有足够信号，返回空数组。
""" + _JSON_ONLY_SUFFIX


# ---------------------------------------------------------------------------
# 辅助函数
# ---------------------------------------------------------------------------

def _format_reviews(reviews: list[dict]) -> str:
    """格式化 Product 已抽样的评论；Analysis 不再二次截断。"""
    lines = []
    for r in reviews:
        review_id = r.get("review_id") or r.get("reviewId") or "unknown"
        rating = r.get("rating", "?")
        title = r.get("title", "")
        text = r.get("text", "") or ""
        lines.append(f"[{review_id}|{rating}★] {title}\n{text}\n")
    return "\n".join(lines)


def _format_positive_reviews(reviews: list[dict]) -> str:
    """从 Product 已抽样评论中格式化全部 4-5 星评论。"""
    positive = [r for r in reviews if _rating_value(r.get("rating")) >= 4]
    positive.sort(key=lambda r: _rating_value(r.get("rating")), reverse=True)  # 5星优先
    lines = []
    for r in positive:
        rating = r.get("rating", "?")
        title = r.get("title", "")
        text = r.get("text", "") or ""
        lines.append(f"[{rating}★] {title}\n{text}\n")
    return "\n".join(lines)


def _rating_value(value: object) -> float:
    try:
        return float(str(value).split()[0])
    except (TypeError, ValueError, IndexError):
        return 0.0


def _input_error(exc: ValidationError) -> Result:
    missing = sorted({
        ".".join(str(part) for part in item.get("loc", ()))
        for item in exc.errors()
        if item.get("type") == "missing"
    })
    if missing:
        return err(
            Code.ERROR_MISSING_FIELDS,
            "missing required fields: " + ", ".join(missing),
            missing=missing,
        )
    return err(Code.ERROR_PARAM, str(exc))


def _listing_snapshot(product_info: dict) -> ProductVocListing:
    """把旧 ProductInfo 宽松字典收敛为严格 VOC Listing。"""
    return ProductVocListing.model_validate({
        "asin": product_info.get("asin"),
        "title": product_info.get("title"),
        "bullet_points": _features(product_info),
        "details": _product_details(product_info),
        "description": product_info.get("description")
        or product_info.get("productDescription")
        or "",
        "brand": product_info.get("brand"),
        "product_rating": product_info.get("product_rating")
        or product_info.get("productRating")
        or product_info.get("rating"),
        "count_ratings": product_info.get("count_ratings")
        or product_info.get("countRatings")
        or product_info.get("count_review")
        or product_info.get("countReview"),
    })


def _review_snapshots(
    reviews: list[dict] | None,
    *,
    legacy_ids: bool = False,
) -> list[ProductVocReview]:
    snapshots: list[ProductVocReview] = []
    for index, review in enumerate(reviews or []):
        raw = dict(review)
        if legacy_ids:
            legacy_title = raw.get("title")
            if not legacy_title and isinstance(raw.get("reviewSummary"), str):
                legacy_title = raw["reviewSummary"]
            raw = {
                "review_id": raw.get("review_id")
                or raw.get("reviewId")
                or f"legacy-{index + 1}",
                "text": raw.get("text") or raw.get("body") or "",
                "rating": raw.get("rating"),
                "title": legacy_title or "",
                "date": raw.get("date"),
                "country": raw.get("country") or "",
                "verified": raw.get("verified", False),
                "user_name": raw.get("user_name") or raw.get("userName") or "",
                "images": raw.get("images") or raw.get("imageUrlList") or [],
            }
        snapshots.append(ProductVocReview.model_validate(raw))
    return snapshots


def _analyze_strengths(
    listing: ProductVocListing,
    reviews_evidence: str | None = None,
) -> Result:
    """执行一次优势语义推理；公开能力只负责输入适配。"""
    prompt = VOC_STRENGTHS_PROMPT.format(
        title=listing.title,
        features="\n".join(listing.bullet_points[:10]),
        details=_product_details(listing.model_dump()) or "无额外参数数据",
    )
    if reviews_evidence and reviews_evidence.strip():
        prompt += f"""

## 用户好评交叉验证（兼容旧入口）
以下是该产品的真实用户好评摘要。请对每个创新点做交叉验证：
- 有明确支持证据：user_validated = true，并摘录 user_evidence
- 有明确反证：user_validated = false
- 信号不足：user_validated = null

好评摘要：
{reviews_evidence[:3000]}
"""
    return _llm_output(prompt, VocStrengthsOutput)


def _analyze_weakness_signals(
    listing: ProductVocListing,
    review_models: list[ProductVocReview],
    metrics: VocSatisfactionMetrics,
    star_dist_override: str | None = None,
) -> Result:
    """执行一次弱点语义推理；不计算或合并确定性指标。"""
    if not review_models:
        return ok(data=VocWeaknessSignalsOutput(
            satisfaction_assessment="无评论数据",
            top_issues=[],
            unmet_needs=[],
            balanced_assessment="",
        ).model_dump())

    prompt = VOC_WEAKNESSES_PROMPT.format(
        title=listing.title,
        features="\n".join(listing.bullet_points[:10]),
        total_reviews=metrics.total_reviews,
        positive_pct=metrics.positive_pct,
        negative_pct=metrics.negative_pct,
        product_rating=metrics.product_rating or "未知",
        rating_label=metrics.rating_label,
        star_dist=star_dist_override or (
            f"4-5★: {metrics.positive_pct}%, "
            f"1-2★: {metrics.negative_pct}%"
        ),
        reviews=_format_reviews([
            review.model_dump(mode="python") for review in review_models
        ]),
    )
    return _llm_output(prompt, VocWeaknessSignalsOutput)


def _analyze_use_signals(
    listing: ProductVocListing,
    review_models: list[ProductVocReview],
) -> Result:
    """执行一次使用洞察语义推理；不负责评论抽样。"""
    if not review_models:
        return ok(data=VocUseInsightsOutput.empty().model_dump())

    prompt = VOC_USE_INSIGHTS_PROMPT.format(
        title=listing.title,
        reviews=_format_reviews([
            review.model_dump(mode="python") for review in review_models
        ]),
    )
    return _llm_output(prompt, VocUseInsightsOutput, model="lite")


# ---------------------------------------------------------------------------
# 能力注册
# ---------------------------------------------------------------------------

@capability(
    "analysis.voc.strength-signals",
    description="从严格 Listing 快照提取产品创新优势",
    input_model=VocStrengthsAnalysisInput,
    output_model=VocStrengthsOutput,
    requires=["product.get"],
)
def voc_strength_signals(product_info: dict) -> Result:
    """严格原子入口：仅根据 Listing 事实提取创新优势。"""
    try:
        listing = _listing_snapshot(product_info)
    except ValidationError as exc:
        return _input_error(exc)
    return _analyze_strengths(listing)


@capability(
    "analysis.voc.strengths",
    description="产品创新优势兼容入口；新链路使用 strength-signals",
    input_model=VocStrengthsInput,
    output_model=VocStrengthsOutput,
)
def voc_strengths(
    product_info: dict,
    reviews: list[dict] | None = None,
    reviews_evidence: str | None = None,
) -> Result:
    """保留旧参数形状，并收敛到同一个优势语义实现。"""
    del reviews
    try:
        listing = _listing_snapshot(product_info)
    except ValidationError as exc:
        return _input_error(exc)
    return _analyze_strengths(listing, reviews_evidence)


@capability(
    "analysis.voc.weakness-signals",
    description="从已抽样评论中提取痛点和未满足需求",
    input_model=VocWeaknessSignalsInput,
    output_model=VocWeaknessSignalsOutput,
    requires=["product.get", "product.reviews", "calc.voc.satisfaction"],
)
def voc_weakness_signals(
    product_info: dict,
    reviews: list[dict],
    satisfaction: dict,
) -> Result:
    """只做 VOC 语义判断；满意度指标由 Calc 显式传入。"""
    try:
        listing = _listing_snapshot(product_info)
        review_models = _review_snapshots(reviews)
        metrics = VocSatisfactionMetrics.model_validate(satisfaction)
    except ValidationError as exc:
        return _input_error(exc)
    return _analyze_weakness_signals(listing, review_models, metrics)


@capability(
    "analysis.voc.weaknesses",
    description="差评 VOC 兼容入口；新链路使用 Calc + weakness-signals",
    input_model=VocWeaknessesInput,
    output_model=VocWeaknessesOutput,
)
def voc_weaknesses(
    product_info: dict,
    reviews: list[dict] | None = None,
    star_ratios: dict | str | None = None,
) -> Result:
    """保留旧参数形状，内部委托同一个 Calc 和语义原子。"""
    from amz.calc.voc import calculate_satisfaction, merge_weakness_signals

    try:
        listing = _listing_snapshot(product_info)
        review_models = _review_snapshots(reviews, legacy_ids=True)
        metrics = calculate_satisfaction(
            reviews=review_models,
            star_ratios=star_ratios if isinstance(star_ratios, dict) else None,
            total_reviews=listing.count_ratings,
            product_rating=listing.product_rating,
        )
    except ValidationError as exc:
        return _input_error(exc)

    if not review_models:
        return ok(data=VocWeaknessesOutput.empty(metrics).model_dump())
    signals = _analyze_weakness_signals(
        listing,
        review_models,
        metrics,
        star_ratios if isinstance(star_ratios, str) else None,
    )
    if signals.code != Code.OK:
        return signals
    try:
        merged = merge_weakness_signals(signals.data, metrics)
    except ValidationError as exc:
        return err(Code.ERROR_LLM, str(exc))
    return ok(data=merged.model_dump(mode="python"))


@capability(
    "analysis.voc.use-signals",
    description="从严格评论快照提取使用场景、用户画像和购买动机",
    input_model=VocUseInsightsAnalysisInput,
    output_model=VocUseInsightsOutput,
    requires=["product.get", "product.reviews"],
)
def voc_use_signals(product_info: dict, reviews: list[dict]) -> Result:
    """严格原子入口：从已抽样评论提取场景、人群和购买动机。"""
    try:
        listing = _listing_snapshot(product_info)
        review_models = _review_snapshots(reviews)
    except ValidationError as exc:
        return _input_error(exc)
    return _analyze_use_signals(listing, review_models)


@capability(
    "analysis.voc.use-insights",
    description="产品使用洞察兼容入口；新链路使用 use-signals",
    input_model=VocInput,
    output_model=VocUseInsightsOutput,
)
def voc_use_insights(
    product_info: dict,
    reviews: list[dict] | None = None,
) -> Result:
    """保留旧参数形状，并收敛到同一个使用洞察语义实现。"""
    try:
        listing = _listing_snapshot(product_info)
        review_models = _review_snapshots(reviews, legacy_ids=True)
    except ValidationError as exc:
        return _input_error(exc)
    return _analyze_use_signals(listing, review_models)


@capability(
    "analysis.voc.praise",
    description="从好评中挖掘用户喜爱点、惊喜点、竞品对比、价值感知",
    input_model=VocInput,
    output_model=VocPraiseOutput,
)
def voc_praise(
    product_info: dict,
    reviews: list[dict] | None = None,
) -> Result:
    """analysis.voc.praise — 好评深度挖掘

    从 4-5 星好评中系统性提取：
    - 用户真正喜爱的功能/特性（与卖家声称的优势互补）
    - 超出预期的惊喜点
    - 价值感知（性价比评价）
    - 耐用性/长期使用信号
    - 竞品对比（用户亲口说的为什么选这个）
    - 功能满意度排名

    Args:
        product_info: {title, bullet_points}
        reviews: 评论列表
    """
    reviews = reviews or []
    reviews_text = _format_positive_reviews(reviews)
    if not reviews_text.strip():
        return ok(data={
            **VocPraiseOutput().model_dump(),
            "value_perception": ValuePerception(summary="无好评数据").model_dump(),
        })

    prompt = VOC_PRAISE_PROMPT.format(
        title=product_info.get("title", ""),
        features="\n".join(_features(product_info)[:10]),
        reviews=reviews_text,
    )
    return _llm_output(prompt, VocPraiseOutput)


@capability(
    "analysis.voc.wishlist",
    description="从评论中提取用户愿望清单：功能请求、改进建议、变体需求、配件需求",
    input_model=VocInput,
    output_model=VocWishlistOutput,
)
def voc_wishlist(
    product_info: dict,
    reviews: list[dict] | None = None,
) -> Result:
    """analysis.voc.wishlist — 用户愿望清单

    从全部评论（好评+差评）中提取建设性的产品迭代信号：
    - 功能请求（用户想要的新功能）
    - 改进建议（对现有功能的具体改进意见）
    - 变体请求（用户想要的尺寸/颜色/款式）
    - 配件需求（用户希望附带或配套的配件）

    注意：这不是痛点提取（那是 weaknesses 的职责），
    而是捕捉用户「想要」「希望」「如果能」的建设性愿望。
    好评用户也常说「I love it, but I wish it had...」。

    Args:
        product_info: {title, bullet_points}
        reviews: 评论列表
    """
    reviews = reviews or []
    reviews_text = _format_reviews(reviews)
    if not reviews_text.strip():
        return ok(data={
            **VocWishlistOutput().model_dump(),
        })

    prompt = VOC_WISHLIST_PROMPT.format(
        title=product_info.get("title", ""),
        features="\n".join(_features(product_info)[:10]),
        reviews=reviews_text,
    )
    return _llm_output(prompt, VocWishlistOutput)
