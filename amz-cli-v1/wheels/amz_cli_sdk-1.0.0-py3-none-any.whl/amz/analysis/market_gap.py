"""
市场缺口分析：成功因子提炼 / 市场缺口（痛点+机会）/ 微改造提案。

吸收 product_dev_v2 m04 三件套。
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from amz.envelope import Result, ok, err, Code
from amz.registry import capability
from amz.infra.llm import chat_json
from amz.analysis.base import parse_structured
from amz.schemas.analysis_inputs import MarketGapInput, MarketProposalsInput, MarketSuccessFactorsInput


class _MarketModel(BaseModel):
    model_config = ConfigDict(extra="ignore")


class SuccessFactor(_MarketModel):
    """单个市场成功要素。"""

    factor_name: str  # 成功要素名称
    description: str = ""  # 要素描述
    example_asins: list[str] = Field(default_factory=list)  # 示例 ASIN 列表
    why_it_works: str = ""  # 为什么有效


class SuccessFactorsOutput(_MarketModel):
    """市场成功因子提炼输出。"""

    market_leaders_success_factors: list[SuccessFactor] = Field(default_factory=list)  # 市场头部卖家成功要素列表


class MarketPoint(_MarketModel):
    """单个痛点或机会点。"""

    point: str  # 要点描述
    description: str = ""  # 详细说明
    severity: Literal["High", "Medium", "Low"] | None = None  # 严重程度（仅痛点使用）
    opportunity_score: int = Field(default=0, ge=0, le=10)  # 机会分 0-10（仅机会点使用）
    asin_cnt: int = 0  # 涉及 ASIN 数
    asin_list: list[str] = Field(default_factory=list)  # 涉及 ASIN 列表


class MarketGapOutput(_MarketModel):
    """市场缺口分析输出。"""

    market_summary: str = ""  # 市场总结
    problem_points: list[MarketPoint] = Field(default_factory=list)  # 痛点列表
    opportunity_points: list[MarketPoint] = Field(default_factory=list)  # 机会点列表
    market_use_insights: dict = Field(default_factory=dict)  # 市场使用洞察（场景/人群/动机）


class RenovationProposal(_MarketModel):
    """单个微改造提案。"""

    title: str  # 提案标题
    target_pain_point: str = ""  # 针对的目标痛点
    change_description: str = ""  # 改动描述
    expected_benefit: str = ""  # 预期收益
    difficulty: Literal["低", "中", "高"]  # 实施难度
    related_asins: list[str] = Field(default_factory=list)  # 相关 ASIN 列表


class ProposalsOutput(_MarketModel):
    """微改造提案输出。"""

    micro_renovation_proposals: list[RenovationProposal] = Field(default_factory=list)  # 微改造提案列表


def _llm_output(prompt: str, output_model: type[_MarketModel], temperature: float = 0.3) -> Result:
    try:
        result = chat_json(
            prompt=prompt, json_schema=output_model.model_json_schema(),
            model="pro", temperature=temperature,
        )
        return ok(data=parse_structured(result, output_model).model_dump())
    except Exception as exc:
        return err(Code.ERROR_LLM, str(exc))


# ---------------------------------------------------------------------------
# Prompt 模板（对齐 product_dev_v2 m04_market_analysis.py）
# ---------------------------------------------------------------------------

_JSON_ONLY = """
严格要求：只输出 JSON，不要任何 markdown 标题、说明文字或 ``` 围栏。"""


SUCCESS_FACTORS_PROMPT = """你是一位资深的亚马逊产品专家，擅长解构头部产品的成功密码。

下面是某细分市场里销量/口碑领先的几个产品（Market Leaders）的创新点与竞争优势。请提炼出这个市场里值得参考的成功因子——可能是特定的产品特性、设计理念、材质选择、功能组合或定位策略，并归类汇总。

# 领先产品数据
{leaders}

# 输出 JSON（所有 value 用中文）：
{{
  "market_leaders_success_factors": [
    {{"factor_name": "成功因子名称", "description": "该因子如何帮助产品成功", "example_asins": ["ASIN"], "why_it_works": "为什么在市场上有效"}}
  ]
}}
""" + _JSON_ONLY


GAP_PROMPT = """你是一位资深的亚马逊产品战略官，擅长做市场缺口分析（Market Gap Analysis），能从多个竞品的微观数据中提取整个类目共性的痛点、未被解决的结构性缺陷以及潜在商业机会。

下面是某细分市场里多个竞品的核心痛点(top_issues)和未满足需求(unmet_needs)。请横向对比并聚合：把相似的问题归一化，识别出这个价格区间内哪些是普遍存在的红海痛点(problem_points)，哪些是尚未被巨头解决的蓝海机会(opportunity_points)。关注被多个 ASIN 共同提及的条目（asin_cnt 高）。

# 竞品痛点数据
{weaknesses}

# 消费者使用洞察（跨产品聚合）
下面是各竞品的使用场景、用户画像和购买动机。请从中提取：(1) 这个市场最主要的 3-5 个使用场景，(2) 哪些人群需求未被充分满足，(3) 哪些购买动机是该品类主要的决策驱动力。这些洞察应与上面的痛点交叉验证——某个场景下的痛点可能比日常场景下的痛点更需要解决。

{use_insights}

# 输出 JSON（所有 value 用中文，opportunity_score 为 1-10 整数表示机会大小）：
{{
  "market_summary": "1-2段总结这个细分市场的主要遗留问题和消费者未被满足的需求",
  "problem_points": [
    {{"point": "问题核心名称", "description": "在市场上的具体表现", "severity": "High|Medium|Low", "opportunity_score": 1-10, "asin_cnt": 整数, "asin_list": ["ASIN"]}}
  ],
  "opportunity_points": [
    {{"point": "未被满足的需求机会名称", "description": "具体表现", "opportunity_score": 1-10, "asin_cnt": 整数, "asin_list": ["ASIN"]}}
  ],
  "market_use_insights": {{
    "dominant_scenarios": [{{"scenario": "场景描述", "cross_product_frequency": "高|中|低", "insight": "该场景对产品设计/营销的启发"}}],
    "key_personas": [{{"persona": "用户群体名称", "need_gaps": "该人群哪些需求未被充分满足", "insight": "对该人群的差异化切入建议"}}],
    "primary_motivations": [{{"motivation": "购买动机描述", "decision_weight": "高|中|低", "insight": "如何强化该决策因子上的竞争力"}}]
  }}
}}
""" + _JSON_ONLY


PROPOSALS_PROMPT = """你是一位经验丰富的产品经理，擅长在现有产品基础上做低成本、可落地的"微改造"（不是从零开发新品），用最小的改动撬动最大的差异化。

下面是某细分市场的成功因子、遗留问题、改进机会和消费者使用洞察。请提出一组具体的产品微改造提案：每条要绑定到一个明确的痛点或机会，给出具体可执行的改造动作（材质/结构/配件/包装/说明书等层面的具体改动，而不是空泛方向），预估收益和实现难度。

# 市场成功因子
{success_factors}

# 遗留问题
{problems}

# 改进机会
{opportunities}

# 消费者使用洞察
{use_insights_summary}

在生成微改造提案时，优先考虑以下方向：
1. 解决高频使用场景中的已知痛点（场景驱动创新）
2. 为未被充分服务的关键用户群做适配（人群驱动创新）
3. 强化主要购买决策因子上的竞争力（动机驱动创新）

# 输出 JSON（所有 value 用中文，difficulty 取 低|中|高）：
{{
  "micro_renovation_proposals": [
    {{"title": "简短动作短语", "target_pain_point": "针对的痛点/机会名称（对应上面的 point）", "change_description": "具体可执行的改造动作", "expected_benefit": "预期效果", "difficulty": "低|中|高", "related_asins": ["ASIN"]}}
  ]
}}
按 (机会大 + 难度低) 优先排序，给出 5-10 条。
""" + _JSON_ONLY


# ---------------------------------------------------------------------------
# 能力注册
# ---------------------------------------------------------------------------

@capability(
    "analysis.market.success-factors",
    description="提炼市场领先产品的成功因子",
    input_model=MarketSuccessFactorsInput,
    output_model=SuccessFactorsOutput,
    requires=["analysis.voc.strengths"],
)
def market_success_factors(leaders: list[dict]) -> Result:
    """analysis.market.success-factors — 成功因子提炼

    将多个 Market Leader 的 VOC 分析结果（strengths）聚合，提炼共性成功因子。

    Args:
        leaders: [{{asin, strengths: {{summary, innovation_and_competitive_advantages: [...]}}}}, ...]
    """
    # 格式化领先产品数据
    lines = []
    for item in leaders:
        asin = item.get("asin", "unknown")
        strengths = item.get("strengths", {})
        summary = strengths.get("summary", "")
        advantages = strengths.get("innovation_and_competitive_advantages", [])
        adv_lines = "\n".join(
            f"  - {a.get('innovation_summary', '')}: {a.get('detail', '')[:200]}"
            for a in advantages[:10]
        )
        lines.append(f"## {asin}\n核心定位: {summary}\n创新优势:\n{adv_lines}\n")

    prompt = SUCCESS_FACTORS_PROMPT.format(leaders="\n".join(lines))

    return _llm_output(prompt, SuccessFactorsOutput)


@capability(
    "analysis.market.gap-analysis",
    description="市场缺口分析（规范 ID）",
    input_model=MarketGapInput,
    output_model=MarketGapOutput,
    requires=["analysis.voc.weaknesses", "analysis.voc.use-insights"],
)
@capability(
    "analysis.market.gap",
    description="市场缺口分析（兼容旧 ID）",
    input_model=MarketGapInput,
    output_model=MarketGapOutput,
    requires=["analysis.voc.weaknesses", "analysis.voc.use-insights"],
)
def market_gap(
    weaknesses: list[dict],
    use_insights: list[dict] | None = None,
) -> Result:
    """analysis.market.gap — 市场缺口分析

    横向对比多个竞品的 VOC 痛点，结合使用洞察进行交叉验证，
    识别红海痛点（普遍存在）和蓝海机会（尚未被解决）。

    Args:
        weaknesses: [{{asin, weaknesses: {{top_issues, unmet_needs, ...}}}}, ...]
        use_insights: [{{asin, use_insights: {{use_scenarios, user_personas, purchase_motivations}}}}, ...]
    """
    # 格式化痛点
    wk_lines = []
    for item in weaknesses:
        asin = item.get("asin", "unknown")
        wk = item.get("weaknesses", {})
        issues = wk.get("top_issues", [])
        unmet = wk.get("unmet_needs", [])
        issue_lines = "\n".join(
            f"  - [{i.get('severity', '?')}] {i.get('pain_point', '')} "
            f"(cnt: {i.get('cnt', '?')}, ratio: {i.get('ratio', '?')}) — {i.get('evidence', '')[:100]}"
            for i in issues[:10]
        )
        unmet_lines = "\n".join(
            f"  - [{u.get('impact', '?')}] {u.get('unmet_need', '')} "
            f"(cnt: {u.get('cnt', '?')}) — {u.get('evidence', '')[:100]}"
            for u in unmet[:10]
        )
        wk_lines.append(f"## {asin}\n### 痛点\n{issue_lines}\n### 未满足需求\n{unmet_lines}\n")

    # 格式化使用洞察
    ui_lines = []
    for item in (use_insights or []):
        asin = item.get("asin", "unknown")
        ui = item.get("use_insights", {})
        scenarios = ui.get("use_scenarios", [])
        personas = ui.get("user_personas", [])
        motivations = ui.get("purchase_motivations", [])
        sc_lines = "\n".join(
            f"  - [{s.get('frequency', '?')}] {s.get('scenario', '')} (mentioned_by: {s.get('mentioned_by', '?')})"
            for s in scenarios[:5]
        )
        ps_lines = "\n".join(
            f"  - {p.get('persona', '')} — traits: {p.get('traits', '')} (mentioned_by: {p.get('mentioned_by', '?')})"
            for p in personas[:5]
        )
        mt_lines = "\n".join(
            f"  - {m.get('motivation', '')} [{m.get('decision_factor_type', '')}] (mentioned_by: {m.get('mentioned_by', '?')})"
            for m in motivations[:5]
        )
        ui_lines.append(f"## {asin}\n### 使用场景\n{sc_lines}\n### 用户画像\n{ps_lines}\n### 购买动机\n{mt_lines}\n")

    prompt = GAP_PROMPT.format(
        weaknesses="\n".join(wk_lines) if wk_lines else "无竞品痛点数据",
        use_insights="\n".join(ui_lines) if ui_lines else "无使用洞察数据",
    )

    return _llm_output(prompt, MarketGapOutput)


@capability(
    "analysis.market.renovation-proposal",
    description="微改造提案（规范 ID）",
    input_model=MarketProposalsInput,
    output_model=ProposalsOutput,
    requires=["analysis.market.success-factors", "analysis.market.gap-analysis"],
)
@capability(
    "analysis.market.proposals",
    description="微改造提案（兼容旧 ID）",
    input_model=MarketProposalsInput,
    output_model=ProposalsOutput,
    requires=["analysis.market.success-factors", "analysis.market.gap-analysis"],
)
def market_proposals(
    success_factors: list[dict] | None = None,
    problem_points: list[dict] | None = None,
    opportunity_points: list[dict] | None = None,
    use_insights: dict | None = None,
) -> Result:
    """analysis.market.proposals — 微改造提案

    综合市场成功因子、遗留问题和改进机会，生成 5-10 条具体的微改造方案。

    Args:
        success_factors: [{{factor_name, description, example_asins, why_it_works}}, ...]
        problem_points: [{{point, description, severity, opportunity_score, asin_cnt, asin_list}}, ...]
        opportunity_points: [{{point, description, opportunity_score, asin_cnt, asin_list}}, ...]
        use_insights: {{dominant_scenarios, key_personas, primary_motivations}}
    """
    # 格式化成功因子
    sf_text = "无"
    if success_factors:
        sf_lines = []
        for f in success_factors[:10]:
            sf_lines.append(
                f"- {f.get('factor_name', '')}: {f.get('description', '')} "
                f"(example: {', '.join(f.get('example_asins', []))})"
            )
        sf_text = "\n".join(sf_lines)

    # 格式化遗留问题
    prob_text = "无"
    if problem_points:
        prob_lines = []
        for p in problem_points[:10]:
            prob_lines.append(
                f"- [{p.get('severity', '?')}] {p.get('point', '')}: {p.get('description', '')} "
                f"(机会分: {p.get('opportunity_score', '?')}, 涉及 {p.get('asin_cnt', '?')} 个 ASIN)"
            )
        prob_text = "\n".join(prob_lines)

    # 格式化改进机会
    opp_text = "无"
    if opportunity_points:
        opp_lines = []
        for o in opportunity_points[:10]:
            opp_lines.append(
                f"- {o.get('point', '')}: {o.get('description', '')} "
                f"(机会分: {o.get('opportunity_score', '?')}, 涉及 {o.get('asin_cnt', '?')} 个 ASIN)"
            )
        opp_text = "\n".join(opp_lines)

    # 格式化使用洞察摘要
    ui_text = "无"
    if use_insights:
        parts = []
        for s in use_insights.get("dominant_scenarios", [])[:3]:
            parts.append(f"场景: {s.get('scenario', '')} ({s.get('cross_product_frequency', '?')}) → {s.get('insight', '')}")
        for p in use_insights.get("key_personas", [])[:3]:
            parts.append(f"人群: {p.get('persona', '')} (缺口: {p.get('need_gaps', '')}) → {p.get('insight', '')}")
        for m in use_insights.get("primary_motivations", [])[:3]:
            parts.append(f"动机: {m.get('motivation', '')} (权重: {m.get('decision_weight', '?')}) → {m.get('insight', '')}")
        ui_text = "\n".join(parts)

    prompt = PROPOSALS_PROMPT.format(
        success_factors=sf_text,
        problems=prob_text,
        opportunities=opp_text,
        use_insights_summary=ui_text,
    )

    return _llm_output(prompt, ProposalsOutput, temperature=0.4)
