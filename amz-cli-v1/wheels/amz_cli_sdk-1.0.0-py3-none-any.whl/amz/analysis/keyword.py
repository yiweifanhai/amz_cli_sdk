"""
关键词评估：四维评分 / LLM 语义相关性 / 覆盖检查 / 关键词聚类。

吸收 listing_agent scoring-engine.ts / llm-relevance.ts 和 traffic_map m06 两阶段聚类。
"""

from __future__ import annotations

from bisect import bisect_right
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from amz.calc.keyword import analyze_gap
from amz.envelope import Result, ok, err, Code
from amz.registry import capability
from amz.infra.llm import chat_json
from amz.analysis.base import require_json
from amz.schemas.analysis_inputs import (
    KeywordClusterInput,
    KeywordGapInput,
    KeywordRelevanceInput,
    KeywordScoreInput,
)


class _AnalysisModel(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)


class RelevanceItem(_AnalysisModel):
    """单个关键词与产品的语义相关性判断。"""

    keyword: str  # 关键词
    match: Literal["perfect", "high", "partial", "low", "unknown"] = "unknown"
    reason: str = ""  # 判断理由


class RelevanceOutput(_AnalysisModel):
    """相关性判断输出。"""

    results: list[RelevanceItem] = Field(default_factory=list)  # 各关键词判断结果


class DimensionScores(_AnalysisModel):
    """四维评分（均 1-10）。"""

    relevance: float  # 相关性分
    traffic: float  # 流量分（搜索量/曝光加权）
    conversion: float  # 转化分（购买率/CVR/购买量加权）
    competition: float  # 竞争友好度分（分数越高=竞争越低=越好）


class ScoredKeyword(_AnalysisModel):
    """单个关键词的综合评分。"""

    keyword: str  # 关键词
    score: float = Field(ge=0, le=10)  # 综合分 0-10（四维加权 + 趋势调整）
    grade: Literal["S", "A", "B", "C"]  # 等级（S≥8 / A≥6 / B≥4 / C<4）
    dimension_scores: DimensionScores  # 四维分项
    trend_adjustment: float = 0  # 趋势调整值（正加负减）
    match_level: Literal["perfect", "high", "partial", "low", "unknown"] = "unknown"
    reason: str = ""  # 评分理由


class KeywordScoreOutput(_AnalysisModel):
    """关键词评分批量输出。"""

    scored_keywords: list[ScoredKeyword] = Field(default_factory=list)  # 评分结果列表
    total_count: int = 0  # 关键词总数
    grade_distribution: dict[str, int] = Field(default_factory=dict)  # 等级分布（如 {"S": 3, "A": 5}）
    average_score: float = 0  # 平均综合分


class GapKeyword(_AnalysisModel):
    """覆盖检查中的单个关键词（仅 S/A 级）。"""

    keyword: str  # 关键词
    grade: Literal["S", "A"]  # 等级（仅统计 S/A 级核心词）
    source: str = "a10"  # 来源（a10 = A10 评分词；cosmo = COSMO 语义词）
    found_in: list[str] = Field(default_factory=list)  # 在 Listing 哪些位置找到（title/bullet 等）


class KeywordGapOutput(_AnalysisModel):
    """关键词覆盖检查输出。"""

    covered: list[GapKeyword] = Field(default_factory=list)  # 已覆盖的关键词
    missing: list[GapKeyword] = Field(default_factory=list)  # 缺失的关键词（未出现在 Listing 中）


class KeywordCluster(_AnalysisModel):
    """单个关键词簇（意图聚类）。"""

    name: str  # 簇名
    intent: str = ""  # 搜索意图（如"信息查询"/"购买"）
    relevant_to_main: bool = True  # 是否与主词相关
    keywords: list[str] = Field(default_factory=list)  # 簇内关键词
    search_total: float = 0  # 簇内总搜索量
    members_count: int = 0  # 簇内关键词数


class KeywordClusterOutput(_AnalysisModel):
    """关键词聚类输出。"""

    clusters: list[KeywordCluster] = Field(default_factory=list)  # 簇列表
    keyword_to_cluster: dict[str, str] = Field(default_factory=dict)  # 关键词→簇名映射
    total_assigned: int = 0  # 已分配关键词总数


def _validated(model: type[_AnalysisModel], data: object) -> Result:
    try:
        return ok(data=model.model_validate(data).model_dump())
    except Exception as exc:
        return err(Code.ERROR_LLM, f"invalid structured output: {exc}")

# ---------------------------------------------------------------------------
# 语义相关性评分（对齐 listing_agent llm-relevance.ts）
# ---------------------------------------------------------------------------

KEYWORD_RELEVANCE_SYSTEM = """你是一位资深的亚马逊运营专家。你的唯一任务是判断关键词与产品的匹配程度。

# 核心原则

判断的关键不仅是词面是否相关，更要判断：**搜索这个关键词的用户，我们的产品能否满足他的需求？**

# 匹配程度（四档）

- **perfect**: 完美匹配。核心品类词，搜这个词的用户就是要买这个产品，产品完全满足需求
- **high**: 非常匹配。直接相关的功能词/场景词，搜这个词的用户需求能被产品满足
- **partial**: 有一些不匹配。间接相关，产品只能部分满足需求，或者词义有偏差
- **low**: 很不匹配。产品不能满足该关键词对应的用户搜索需求（即使词面看起来有关联）

# 判断逻辑

对每个关键词，请思考：
1. 搜索这个词的用户，他真正想要什么？
2. 我们的产品（标题+五点描述）能否满足这个需求？
3. 如果产品不能很好满足该需求，即使词面相关，也应判为 partial 或 low

# 注意事项

- 重点评估产品与关键词的需求匹配度，不要考虑搜索量、竞争度等市场数据
- reason 限 15 字以内
- 必须为每个关键词都返回结果"""


# ---------------------------------------------------------------------------
# 四维综合评分（融合 listing_agent scoring-engine + classify.ts）
# ---------------------------------------------------------------------------

KEYWORD_SCORE_PROMPT = """你是 Amazon COSMO + Rufus 关键词评估专家。在 AI 时代，Listing 不再是简单的关键词堆砌，而是"Rufus 答案库"——每个关键词都要判断是否值得写入 Listing、放在哪个位置、以及优先级。

请对以下关键词进行多维度评分。

# 目标产品信息:
- 标题: {title}
- 描述: {features}

# 评分维度:

## relevanceScore (1-10): 与产品的相关性
- 10: 核心品类词/功能词，搜索该词的用户 100% 要找这类产品
- 7-9: 直接相关的功能/场景词
- 4-6: 间接相关，有一定关联
- 1-3: 弱相关或泛化词

## trafficScore (1-10): 搜索流量价值
- 基于提供的搜索量数据判断
- 10: 月搜索量极大，是品类核心流量入口
- 7-9: 月搜索量高，重要的流量来源
- 4-6: 中等搜索量
- 1-3: 低搜索量或长尾词

## conversionScore (1-10): 转化潜力
- 搜索该词的用户购买意图有多强？
- 10: 强购买意图（如精准功能词、规格词）
- 7-9: 明确购买意图
- 4-6: 有购买意图但不够明确
- 1-3: 信息查询意图为主

## competitionScore (1-10): 竞争友好度
- 注意：分数越高 = 竞争越低 = 越好
- 10: 几乎没有竞争，容易排名
- 7-9: 竞争较低
- 4-6: 中等竞争
- 1-3: 竞争激烈，头部垄断严重

## suggestedPosition: 建议埋词位置
- "title+bullet": 核心词，必须在标题+五点中出现（S级）
- "title": 重要品类词，需要在标题中出现
- "bullet": 功能/场景/痛点词，适合写在五点描述中
- "description": 长尾语义/叙事性场景词，适合产品描述或 A+
- "search_term": 补充性词汇，不适合前台但有搜索价值，放后台 Search Term
- "not_recommended": 与产品无关或价值太低，不建议使用

# 待评分关键词:
{keywords_text}

# 输出格式 (纯 JSON):
{{
  "scores": [
    {{"keyword": "词条", "relevanceScore": 8, "trafficScore": 7, "conversionScore": 6, "competitionScore": 7, "match": "perfect|high|partial|low", "grade": "S|A|B|C", "suggestedPosition": "bullet", "reason": "简短理由（15字以内）"}}
  ]
}}

注意:
- 必须为每个输入关键词都返回评分，不能遗漏
- reason 简洁（15字以内）
- 所有分数都是 1-10 的整数
- suggestedPosition 必须是 title+bullet/title/bullet/description/search_term/not_recommended 之一"""


# ---------------------------------------------------------------------------
# 关键词聚类 — 两阶段（对齐 traffic_map m06）
# ---------------------------------------------------------------------------

CLUSTER_SEED_PROMPT = """You are clustering the top Amazon search keywords for the market "{main_keyword}".

These are the top-volume Amazon search terms shoppers actually type (keyword | monthly_searches):
{kw_list}

Task: Merge keywords that represent the SAME shopper intent into one seed cluster.
- Two keywords with the same intent but different wording (synonyms, word order, plural/singular, "X for Y" vs "Y X") MUST be merged.
- Two keywords with genuinely different intent stay in different clusters.
- Use search volume as a signal: large-volume keywords are real shopper demand, not noise. Do not split a cluster just because two phrasings differ.
- The cluster "name" MUST be copied verbatim from the highest-volume keyword inside that cluster (it acts as the canonical label).
- Mark "relevant_to_main": true if the cluster's intent is a sub-intent of "{main_keyword}" (the shopper would accept a product matching the main keyword). Mark false if the cluster drifts to a different product category.

Output format (STRICT JSON):
{{
  "clusters": [
    {{"name": "<verbatim highest-volume keyword>",
      "intent": "one-sentence intent description (<= 120 chars, no quotes/newlines)",
      "relevant_to_main": true,
      "keywords": ["kw1", "kw2"]}}
  ]
}}

Hard constraints:
- "name": MUST be one of the input keywords above, copied verbatim.
- "keywords": only strings copied EXACTLY from the input list.
- Each input keyword must appear in EXACTLY ONE cluster.
- The main keyword "{main_keyword}" MUST appear in exactly one cluster."""


CLUSTER_ATTACH_PROMPT = """You are assigning Amazon search keywords to existing seed clusters for the market "{main_keyword}".

Seed clusters (already finalized -- do NOT create new ones, do NOT rename):
{seed_block}

Long-tail keywords to assign (keyword | monthly_searches):
{kw_list}

Task: For each long-tail keyword, pick the ONE seed cluster whose intent best matches it.
- Match by shopper intent, not lexical similarity alone.
- A keyword belongs to the cluster a shopper typing it would most likely accept products from.
- If a keyword genuinely matches none of the seed clusters' intent, assign it to "_off_topic".

Output format (STRICT JSON):
{{
  "assignments": [
    {{"keyword": "<verbatim keyword from input>", "cluster": "<seed cluster name OR _off_topic>"}}
  ]
}}

Hard constraints:
- Every input long-tail keyword MUST appear exactly once.
- "keyword" copied verbatim from the input list.
- "cluster" MUST be one of the seed cluster names listed above, or "_off_topic"."""


# ---------------------------------------------------------------------------
# 能力注册
# ---------------------------------------------------------------------------

@capability(
    "analysis.keyword.relevance",
    description="LLM 语义相关性判断（基于搜索意图匹配）",
    input_model=KeywordRelevanceInput,
    output_model=RelevanceOutput,
)
def keyword_relevance(
    keywords: list[str],
    product_info: dict,
    batch_size: int = 20,
    max_retries: int = 2,
) -> Result:
    """analysis.keyword.relevance — 语义相关性

    判断每个关键词与产品的需求匹配度：搜索该词的用户，产品能否满足其需求？

    Args:
        keywords: 关键词列表
        product_info: {{title, bullet_points}}
    """
    normalized = [str(keyword).strip() for keyword in keywords if str(keyword).strip()]
    if not normalized:
        return ok(data=RelevanceOutput().model_dump())
    if not product_info:
        return ok(data=RelevanceOutput(results=[
            RelevanceItem(keyword=keyword, match="unknown", reason="未提供产品信息，未执行语义判断")
            for keyword in normalized
        ]).model_dump(), hint="semantic relevance not evaluated: product_info is empty")

    all_results: list[RelevanceItem] = []
    degraded = False
    for start in range(0, len(normalized), max(1, batch_size)):
        batch = normalized[start : start + max(1, batch_size)]
        kw_list = "\n".join(f"- {kw}" for kw in batch)
        user_prompt = f"""# 产品信息

## 产品标题
{product_info.get('title', '')}

## 产品五点描述（核心卖点）
{chr(10).join(f"{i+1}. {bp}" for i, bp in enumerate(product_info.get('bullet_points', product_info.get('bulletPoints', []))[:5]))}

# 待评分关键词（{len(batch)} 个）

{kw_list}

请逐一评估每个关键词：搜索该词的用户需求，我们的产品能否满足？返回 JSON 数组。"""

        parsed_items: list[dict] | None = None
        for _attempt in range(max_retries + 1):
            try:
                result = chat_json(
                    messages=[
                        {"role": "system", "content": KEYWORD_RELEVANCE_SYSTEM},
                        {"role": "user", "content": user_prompt},
                    ],
                    json_schema={"type": "array", "items": RelevanceItem.model_json_schema()},
                    model="lite",
                    temperature=0.2,
                )
                raw = require_json(result)
                if isinstance(raw, dict):
                    raw = raw.get("results", raw.get("scores", []))
                if isinstance(raw, list):
                    parsed_items = [item for item in raw if isinstance(item, dict)]
                    break
            except Exception:
                continue

        returned: dict[str, RelevanceItem] = {}
        for item in parsed_items or []:
            keyword = str(item.get("keyword") or "").strip()
            key = keyword.lower()
            if key not in {candidate.lower() for candidate in batch}:
                continue
            match = str(item.get("match") or "unknown")
            if match not in {"perfect", "high", "partial", "low"}:
                match = "unknown"
            returned[key] = RelevanceItem(
                keyword=next(candidate for candidate in batch if candidate.lower() == key),
                match=match,
                reason=str(item.get("reason") or ""),
            )
        for keyword in batch:
            item = returned.get(keyword.lower())
            if item is None:
                degraded = True
                item = RelevanceItem(
                    keyword=keyword,
                    match="unknown",
                    reason="LLM 未返回该关键词，语义相关性未知",
                )
            all_results.append(item)

    return ok(
        data=RelevanceOutput(results=all_results).model_dump(),
        hint="partial LLM result: missing keywords marked unknown" if degraded else "",
    )


@capability(
    "analysis.keyword.score",
    description="A10 四维混合评分（确定性百分位 + LLM 语义乘数）",
    input_model=KeywordScoreInput,
    output_model=KeywordScoreOutput,
)
def keyword_score(keywords: list[dict], product_info: dict | None = None) -> Result:
    """analysis.keyword.score — 四维评分

    Args:
        keywords: [{{term, search_volume, ppc, ...}}]
        product_info: {{title, bullet_points}}
    """
    if not keywords:
        return ok(data=KeywordScoreOutput(
            grade_distribution={"S": 0, "A": 0, "B": 0, "C": 0}
        ).model_dump())

    rows = [_normalize_keyword_row(item) for item in keywords]
    relevance_result = keyword_relevance(
        [row["keyword"] for row in rows], product_info or {}
    )
    if relevance_result.code == Code.OK:
        relevance_map = {
            item["keyword"].lower(): item
            for item in relevance_result.data.get("results", [])
        }
    else:
        relevance_map = {}

    lookups = {
        "searches": _percentile_lookup([row["searches"] for row in rows]),
        "exposure": _percentile_lookup([row["weekly_exposure"] for row in rows]),
        "purchase_rate": _percentile_lookup([row["purchase_rate"] for row in rows]),
        "cvr": _percentile_lookup([row["cvr"] for row in rows]),
        "purchases": _percentile_lookup([row["purchases"] for row in rows]),
        "supply_demand": _percentile_lookup([row["supply_demand"] for row in rows]),
        "spr": _percentile_lookup([row["spr"] for row in rows], reverse=True),
        "top3": _percentile_lookup([row["top3"] for row in rows], reverse=True),
        "asin_count": _percentile_lookup([row["asin_count"] for row in rows]),
        "exposure_coverage": _percentile_lookup([row["exposure_coverage"] for row in rows]),
    }
    multipliers = {
        "perfect": 1.3, "high": 1.0, "partial": 0.7,
        "low": 0.4, "unknown": 1.0,
    }
    scored: list[ScoredKeyword] = []
    distribution = {"S": 0, "A": 0, "B": 0, "C": 0}
    for row in rows:
        llm = relevance_map.get(row["keyword"].lower(), {})
        match = llm.get("match", "unknown")
        relevance_base = _weighted_average([
            (lookups["asin_count"](row["asin_count"]), 0.5),
            (lookups["exposure_coverage"](row["exposure_coverage"]), 0.5),
        ])
        relevance = min(10, max(0, relevance_base * multipliers.get(match, 1.0)))
        if row["feature_missing"]:
            # scoring-engine.ts Task 3.9：feature 整体为 null 时三维固定中性 5 分。
            traffic = conversion = competition = 5.0
        else:
            traffic = _weighted_average([
                (lookups["searches"](row["searches"]), 0.6),
                (lookups["exposure"](row["weekly_exposure"]), 0.4),
            ])
            conversion = _weighted_average([
                (lookups["purchase_rate"](row["purchase_rate"]), 0.4),
                (lookups["cvr"](row["cvr"]), 0.4),
                (lookups["purchases"](row["purchases"]), 0.2),
            ])
            competition = _weighted_average([
                (lookups["supply_demand"](row["supply_demand"]), 0.4),
                (lookups["spr"](row["spr"]), 0.3),
                (lookups["top3"](row["top3"]), 0.3),
            ])
        trend = _trend_adjustment(row["trend"])
        score = round(min(10, max(0,
            relevance * 0.30 + traffic * 0.25 + conversion * 0.25 + competition * 0.20 + trend
        )), 1)
        grade: Literal["S", "A", "B", "C"] = (
            "S" if score >= 8 else "A" if score >= 6 else "B" if score >= 4 else "C"
        )
        distribution[grade] += 1
        scored.append(ScoredKeyword(
            keyword=row["keyword"], score=score, grade=grade,
            dimension_scores=DimensionScores(
                relevance=round(relevance, 1), traffic=round(traffic, 1),
                conversion=round(conversion, 1), competition=round(competition, 1),
            ),
            trend_adjustment=trend, match_level=match,
            reason=str(llm.get("reason") or ""),
        ))
    average = round(sum(item.score for item in scored) / len(scored), 1) if scored else 0
    return ok(data=KeywordScoreOutput(
        scored_keywords=scored, total_count=len(scored),
        grade_distribution=distribution, average_score=average,
    ).model_dump())


@capability(
    "analysis.keyword.gap",
    description="兼容入口：确定性实现位于 calc.keyword.gap",
    input_model=KeywordGapInput,
    output_model=KeywordGapOutput,
)
def keyword_gap(
    keywords: list[dict],
    listing_text: dict,
) -> Result:
    """analysis.keyword.gap — 覆盖检查

    检查哪些关键词已在 listing 文本中出现，哪些缺失。

    Args:
        keywords: [{{term, grade}}, ...]
        listing_text: {{title, bullet_points: []}}
    """
    return analyze_gap(keywords=keywords, listing_text=listing_text)


@capability(
    "analysis.cluster.keywords",
    description="关键词意图聚类（两阶段，完整性校验与漏词兜底）",
    input_model=KeywordClusterInput,
    output_model=KeywordClusterOutput,
    requires=["keyword.miner"],
)
def cluster_keywords(
    keywords: list[dict],
    main_keyword: str = "",
    seed_count: int = 30,
    batch_size: int = 50,
) -> Result:
    """analysis.cluster.keywords — 两阶段关键词聚类

    Stage 1: 从高搜索量词中做种子聚类
    Stage 2: 将剩余长尾词分配到已有种子 cluster

    Args:
        keywords: [{{term, search_volume}}, ...]
        main_keyword: 主关键词，用于判断 relevant_to_main
        seed_count: 种子数量
        batch_size: 长尾词每批数量
    """
    normalized_keywords = [
        {
            **item,
            "term": str(item.get("term") or item.get("keyword") or "").strip(),
            "search_volume": item.get("search_volume", item.get("searches", 0)) or 0,
        }
        for item in keywords
        if str(item.get("term") or item.get("keyword") or "").strip()
    ]
    sorted_kws = sorted(
        normalized_keywords,
        key=lambda x: x.get("search_volume", 0) or 0,
        reverse=True,
    )
    seed_count = max(1, seed_count)
    main_match = next(
        (item for item in sorted_kws if item["term"].lower() == main_keyword.lower()), None
    ) if main_keyword else None
    seeds = ([main_match] if main_match else []) + [
        item for item in sorted_kws if item is not main_match
    ][: seed_count - (1 if main_match else 0)]
    seed_terms = {item["term"] for item in seeds}
    long_tail = [item for item in sorted_kws if item["term"] not in seed_terms]

    main_kw = main_keyword or (seeds[0].get("term", "") if seeds else "unknown")

    # Stage 1: 种子聚类
    kw_list = "\n".join(
        f"- {kw.get('term', '')} | {kw.get('search_volume', '?')}"
        for kw in seeds
    )
    seed_prompt = CLUSTER_SEED_PROMPT.format(main_keyword=main_kw, kw_list=kw_list)

    try:
        seed_result = chat_json(prompt=seed_prompt, model="pro", temperature=0.2, ttl_seconds=86400)
        raw_seed = require_json(seed_result)
        clusters = raw_seed.get("clusters", []) if isinstance(raw_seed, dict) else []
    except Exception as e:
        return err(Code.ERROR_LLM, f"Stage 1 seed clustering failed: {e}")

    seed_volume = {item["term"]: float(item.get("search_volume") or 0) for item in seeds}
    seed_set = set(seed_volume)
    normalized_clusters: list[dict] = []
    by_name: dict[str, dict] = {}
    assigned_seeds: set[str] = set()
    for raw_cluster in clusters:
        members = [term for term in raw_cluster.get("keywords", []) if term in seed_set and term not in assigned_seeds]
        if not members:
            continue
        name = str(raw_cluster.get("name") or "")
        if name not in members:
            name = max(members, key=lambda term: seed_volume[term])
        cluster = by_name.get(name)
        if cluster is None:
            cluster = {
                "name": name,
                "intent": str(raw_cluster.get("intent") or ""),
                "relevant_to_main": bool(raw_cluster.get("relevant_to_main", True)),
                "keywords": [],
            }
            by_name[name] = cluster
            normalized_clusters.append(cluster)
        cluster["keywords"].extend(members)
        assigned_seeds.update(members)
    for seed in seeds:
        term = seed["term"]
        if term not in assigned_seeds:
            normalized_clusters.append({
                "name": term, "intent": "LLM omitted seed; deterministic singleton fallback",
                "relevant_to_main": term.lower() == main_kw.lower(), "keywords": [term],
            })
    clusters = normalized_clusters
    if not clusters:
        return ok(data=KeywordClusterOutput().model_dump())

    # Stage 2: 分配长尾词
    seed_block = "\n".join(
        f'- {c["name"]}: {c.get("intent", "")} (keywords: {", ".join(c.get("keywords", [])[:5])}{"..." if len(c.get("keywords", [])) > 5 else ""})'
        for c in clusters
    )

    all_assignments = []
    batch_size = max(1, batch_size)
    for batch_start in range(0, len(long_tail), batch_size):
        batch = long_tail[batch_start : batch_start + batch_size]
        if not batch:
            break

        lt_list = "\n".join(
            f"- {kw.get('term', '')} | {kw.get('search_volume', '?')}"
            for kw in batch
        )
        attach_prompt = CLUSTER_ATTACH_PROMPT.format(
            main_keyword=main_kw,
            seed_block=seed_block,
            kw_list=lt_list,
        )
        try:
            attach_result = chat_json(prompt=attach_prompt, model="lite", temperature=0.1, ttl_seconds=86400)
            raw_assignments = require_json(attach_result)
            batch_assignments = (
                raw_assignments.get("assignments", [])
                if isinstance(raw_assignments, dict) else []
            )
        except Exception:
            batch_assignments = []
        valid_terms = {item["term"] for item in batch}
        seen: set[str] = set()
        valid_cluster_names = {cluster["name"] for cluster in clusters}
        for assignment in batch_assignments:
            term = str(assignment.get("keyword") or "")
            if term not in valid_terms or term in seen:
                continue
            cluster_name = str(assignment.get("cluster") or "_off_topic")
            if cluster_name not in valid_cluster_names:
                cluster_name = "_off_topic"
            all_assignments.append({"keyword": term, "cluster": cluster_name})
            seen.add(term)
        for item in batch:
            term = item["term"]
            if term not in seen:
                all_assignments.append({"keyword": term, "cluster": "_off_topic"})

    # 将分配结果合并到 clusters
    cluster_map = {c["name"]: c for c in clusters}
    off_topic = {"name": "_off_topic", "intent": "Off-topic keywords", "keywords": [], "relevant_to_main": False}

    for a in all_assignments:
        c_name = a.get("cluster", "_off_topic")
        target = cluster_map.get(c_name, off_topic)
        keyword = a.get("keyword", "")
        if keyword and keyword not in target.setdefault("keywords", []):
            target["keywords"].append(keyword)

    if off_topic["keywords"]:
        cluster_map["_off_topic"] = off_topic
    volume_map = {item["term"]: float(item.get("search_volume") or 0) for item in normalized_keywords}
    keyword_to_cluster: dict[str, str] = {}
    output_clusters: list[KeywordCluster] = []
    for cluster in cluster_map.values():
        members = cluster.get("keywords", [])
        for term in members:
            keyword_to_cluster[term] = cluster["name"]
        output_clusters.append(KeywordCluster(
            **cluster,
            search_total=sum(volume_map.get(term, 0) for term in members),
            members_count=len(members),
        ))
    return ok(data=KeywordClusterOutput(
        clusters=output_clusters,
        keyword_to_cluster=keyword_to_cluster,
        total_assigned=len(keyword_to_cluster),
    ).model_dump())


def _value(data: dict, *names: str, default=None):
    for name in names:
        if data.get(name) is not None:
            return data[name]
    return default


def _number(value):
    try:
        return float(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def _normalize_keyword_row(item: dict) -> dict:
    nested_feature = item.get("feature")
    feature_missing = "feature" in item and not isinstance(nested_feature, dict)
    feature = nested_feature if isinstance(nested_feature, dict) else item
    searches = _number(_value(feature, "searches", "search_volume"))
    weekly_exposure = _number(_value(item, "weeklyExposureSum", "weekly_exposure_sum", "exposure"))
    asin_count = _number(_value(item, "asinCount", "asin_count"))
    return {
        "keyword": str(_value(item, "keyword", "term", default="")),
        "feature_missing": feature_missing,
        "searches": searches,
        "weekly_exposure": weekly_exposure,
        "purchase_rate": _number(_value(feature, "purchaseRate", "purchase_rate")),
        "cvr": _number(_value(feature, "cvr")),
        "purchases": _number(_value(feature, "purchases")),
        "supply_demand": _number(_value(feature, "supplyDemandRatio", "supply_demand_ratio")),
        "spr": _number(_value(feature, "cprExact", "spr", "cpr_exact")),
        "top3": _number(_value(feature, "top3ClickingRate", "top3_clicking_rate")),
        "asin_count": asin_count,
        "exposure_coverage": (
            min((weekly_exposure or 0) / searches, 1) if searches and searches > 0 else None
        ),
        "trend": _value(feature, "searchesTrend", "searches_trend", default=[]),
    }


def _percentile_to_score(percentile: float) -> float:
    percentile = min(100.0, max(0.0, percentile))
    segments = [(95, 10), (80, 8), (60, 6), (35, 4), (10, 2)]
    for index in range(len(segments) - 1):
        high_pct, high_score = segments[index]
        low_pct, low_score = segments[index + 1]
        if percentile >= low_pct:
            ratio = (percentile - low_pct) / (high_pct - low_pct)
            return min(10.0, max(1.0, low_score + ratio * (high_score - low_score)))
    return 1.0


def _percentile_lookup(values: list[float | None], reverse: bool = False):
    sorted_values = sorted(value for value in values if value is not None)

    def lookup(value: float | None) -> float | None:
        if value is None:
            return None
        if not sorted_values:
            return 5.0
        percentile = bisect_right(sorted_values, value) / len(sorted_values) * 100
        return _percentile_to_score(100 - percentile if reverse else percentile)

    return lookup


def _weighted_average(items: list[tuple[float | None, float]]) -> float:
    valid = [(value, weight) for value, weight in items if value is not None]
    if not valid:
        return 5.0
    total_weight = sum(weight for _value_, weight in valid)
    return sum(value * weight for value, weight in valid) / total_weight


def _trend_adjustment(trend: list[dict] | None) -> float:
    if not trend or len(trend) < 4:
        return 0
    values = [float(item.get("searches") or item.get("search") or 0) for item in trend]
    midpoint = len(values) // 2
    earlier = sum(values[:midpoint]) / max(1, midpoint)
    recent = sum(values[midpoint:]) / max(1, len(values) - midpoint)
    if earlier == 0:
        return 0
    change = (recent - earlier) / earlier
    if change > 1:
        return 1.0
    if change > 0.5:
        return 0.5
    if change > 0.2:
        return 0.3
    if change < -0.5:
        return -0.5
    if change < -0.2:
        return -0.3
    return 0
