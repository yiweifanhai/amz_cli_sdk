"""
amz CLI：SDK 命令行入口（harness 可驱动）。

用法:
  amz capabilities [--id <capability_id>]      列出全部能力 / 单个能力 schema
  amz run <capability_id> --param key=value...  调用单个能力
      [--out FILE] [--task run_id]
  amz task new <name> [--param key=value...]    创建任务工作区
  amz task run <capability_id> --param ... [--task run_id]   在任务内调用能力
  amz task status <run_id>                      任务状态 + 调用时间线 + 文件清单
  amz task files <run_id> [--kind kind]         列出任务中间文件
  amz task list                                 最近任务
  amz task cleanup [--older-than-hours N]       清理过期已结束任务
  amz doctor                                    检查配置/缓存/token

参数约定
--------
- ``--param key=value``：值先按 JSON 解析（嵌套 dict/list），失败按字符串；
  再按能力 input_schema 做类型强制（"1"→1, "true"→True）
- ``amz run`` 为单发调用；``amz task run`` 会记录调用与中间文件
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# 参数解析
# ---------------------------------------------------------------------------


def _parse_value(raw: str) -> Any:
    """--param 值解析：先试 JSON，失败按字符串。"""
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, ValueError):
        return raw


def _parse_params(tokens: list[str]) -> dict:
    """解析 ``--param key=value`` 序列（可多次出现；也接受裸 ``key=value``）。"""
    params: dict = {}
    i = 0
    while i < len(tokens):
        token = tokens[i]
        if token in ("--param", "-p"):
            i += 1
            if i >= len(tokens):
                break
            key_value = tokens[i]
            if "=" in key_value:
                key, _, value = key_value.partition("=")
                params[key.strip()] = _parse_value(value)
            else:
                # --param key value 形式
                params[key_value.strip()] = _parse_value(tokens[i + 1]) if i + 1 < len(tokens) else ""
                i += 1
        elif token.startswith("--param="):
            key_value = token[len("--param="):]
            key, _, value = key_value.partition("=")
            params[key.strip()] = _parse_value(value)
        elif "=" in token and not token.startswith("--"):
            # 裸 key=value（兼容旧用法：--param a=1 b=2）
            key, _, value = token.partition("=")
            params[key.strip()] = _parse_value(value)
        i += 1
    return params


def _load_capabilities():
    """导入全部能力并返回 registry。"""
    from amz.registry import registry
    from amz.discovery import load_builtin_capabilities

    load_builtin_capabilities()
    return registry


# ---------------------------------------------------------------------------
# capabilities 命令
# ---------------------------------------------------------------------------


def cmd_capabilities(cap_id: str | None = None):
    registry = _load_capabilities()
    if cap_id:
        cap = registry.get(cap_id)
        if cap is None:
            print(f"unknown capability: {cap_id}", file=sys.stderr)
            sys.exit(1)
        print(json.dumps({
            "id": cap.id,
            "category": cap.category,
            "description": cap.description,
            "requires": cap.requires,
            "requires_fields": cap.requires_fields,
            "input_schema": cap.input_schema,
            "output_schema": cap.output_schema,
        }, indent=2, ensure_ascii=False))
        return

    caps = registry.capabilities_json()
    print(json.dumps(caps, indent=2, ensure_ascii=False))
    print(f"\nTotal: {len(caps)} capabilities")


# ---------------------------------------------------------------------------
# run 命令
# ---------------------------------------------------------------------------


def cmd_run(capability_id: str, params: dict | None = None, out: str | None = None):
    """调用单个能力（单发，不隐式建任务）。"""
    registry = _load_capabilities()
    result = registry.invoke(capability_id, params or {})
    payload = result.model_dump()
    if out:
        path = Path(out)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, indent=2, ensure_ascii=False, default=str))
        print(f"written: {path}")
    print(json.dumps(payload, indent=2, ensure_ascii=False, default=str))


# ---------------------------------------------------------------------------
# task 命令
# ---------------------------------------------------------------------------


def cmd_task_new(name: str, params: dict | None = None):
    from amz.infra.runtime import Runtime

    rt = Runtime.begin(name=name, params=params or {})
    print(json.dumps({
        "run_id": rt.run_id,
        "name": rt.name,
        "status": "running",
        "workspace": str(rt.dir),
    }, indent=2, ensure_ascii=False))


def cmd_task_run(capability_id: str, params: dict | None = None, run_id: str | None = None):
    """在任务工作区内调用能力：自动建任务（或挂到 --task），记录调用与中间文件。"""
    from amz.infra.runtime import Runtime, runtime_context
    from amz.registry import registry

    _load_capabilities()

    if run_id:
        rt = Runtime.open(run_id)
        if rt is None:
            print(f"unknown task: {run_id}", file=sys.stderr)
            sys.exit(1)
    else:
        rt = Runtime.begin(name=f"run:{capability_id}", params=params or {})

    with runtime_context(rt):
        result = registry.invoke(capability_id, params or {})

    rt.finish(success=result.code.value == "OK", error="" if result.code.value == "OK" else result.message)
    code = result.code.value
    files = rt.files(kind="result")
    result_file = files[-1]["path"] if files else ""
    from amz.config import config

    result_path = str(config.cache_dir / result_file) if result_file else ""
    print(json.dumps({
        "run_id": rt.run_id,
        "capability": capability_id,
        "code": code,
        "message": result.message[:200],
        "result_file": result_path,
        "elapsed_ms": round(result.meta.elapsed_ms, 1),
    }, indent=2, ensure_ascii=False))


def cmd_task_status(run_id: str):
    from amz.infra.runtime import Runtime

    manifest = Runtime.status(run_id)
    if manifest is None:
        print(f"unknown task: {run_id}", file=sys.stderr)
        sys.exit(1)
    print(json.dumps({
        "run_id": manifest.get("run_id"),
        "name": manifest.get("name"),
        "status": manifest.get("status"),
        "params": manifest.get("params"),
        "created_at": manifest.get("created_at"),
        "finished_at": manifest.get("finished_at"),
        "error": manifest.get("error"),
        "files": manifest.get("files", []),
        "calls": manifest.get("calls", []),
    }, indent=2, ensure_ascii=False, default=str))


def cmd_task_files(run_id: str, kind: str | None = None):
    from amz.config import config
    from amz.infra.runtime import Runtime

    files = Runtime.files_of(run_id, kind)
    if not files:
        if kind:
            print(f"no files of kind '{kind}' for task {run_id}")
        else:
            print(f"no files for task {run_id}")
        return
    base = config.cache_dir
    for f in files:
        print(f"[{f.get('kind')}] {f.get('name')}  {base / f.get('path', '')}  ({f.get('size', 0)}B)")


def cmd_task_list():
    from amz.infra.runtime import Runtime

    runs = Runtime.list_runs()
    if not runs:
        print("no tasks")
        return
    print(json.dumps(runs, indent=2, ensure_ascii=False))


def cmd_task_cleanup(older_than_hours: int = 168):
    from amz.infra.runtime import Runtime

    removed = Runtime.cleanup(older_than_hours=older_than_hours)
    print(f"removed {len(removed)} task workspace(s)")
    for run_id in removed:
        print(f"  {run_id}")


# ---------------------------------------------------------------------------
# doctor
# ---------------------------------------------------------------------------


def cmd_doctor():
    """检查配置"""
    from amz.config import config

    config.load()

    issues = []
    ok_items = []

    # 检查 token
    token = config.data_api_token
    if token:
        ok_items.append("✅ data_api.token configured")
    else:
        issues.append("❌ data_api.token not set (env: AMZ_API_TOKEN)")

    # 检查 base_url
    url = config.data_api_base_url
    ok_items.append(f"✅ data_api.base_url: {url}")

    # 检查缓存目录
    cache_dir = config.cache_dir
    cache_dir.mkdir(parents=True, exist_ok=True)
    ok_items.append(f"✅ cache_dir: {cache_dir}")

    # 检查 SIF token
    sif_file = config.sif_token_file
    if sif_file.exists():
        ok_items.append(f"✅ sif_token_file: {sif_file}")
    else:
        issues.append(f"⚠️  sif_token_file not found: {sif_file}")

    for item in ok_items:
        print(item)
    for item in issues:
        print(item)

    if not issues:
        print("\n✅ All checks passed")


# ---------------------------------------------------------------------------
# composite 命令
# ---------------------------------------------------------------------------


def cmd_composite_list():
    from amz.composite import list_pipelines

    _load_capabilities()
    pipelines = list_pipelines()
    if not pipelines:
        print("no pipelines discovered (add to ~/.amz/composite/ or AMZ_COMPOSITE_DIR)")
        return
    print(json.dumps(pipelines, indent=2, ensure_ascii=False))


def cmd_composite_new(name: str, category: str = "", description: str = ""):
    _load_capabilities()
    r = registry_invoke("composite.scaffold", {
        "name": name, "category": category, "description": description,
    })
    print(json.dumps(r.model_dump(), indent=2, ensure_ascii=False, default=str))
    if r.code.value != "OK":
        sys.exit(1)


def cmd_composite_run(name: str, params: dict | None = None, force: bool = False):
    from amz.composite import run_pipeline

    _load_capabilities()
    result = run_pipeline(name, params or {}, force=force)
    out = {
        "pipeline": name,
        "run_id": result.run_id,
        "success": result.success,
        "elapsed_ms": round(result.elapsed_ms, 1),
        "errors": result.errors,
        "steps": {s: a.status for s, a in result.artifacts.items()},
    }
    print(json.dumps(out, indent=2, ensure_ascii=False, default=str))
    if not result.success:
        sys.exit(1)


def cmd_composite_show(run_id: str, step: str | None = None):
    from amz.composite.base import Artifact
    from amz.infra.runtime import Runtime

    manifest = Runtime.status(run_id)
    if manifest is None:
        print(f"unknown run: {run_id}", file=sys.stderr)
        sys.exit(1)

    if step:
        artifact = Artifact.load(run_id, step)
        if artifact is None:
            print(f"no artifact for step '{step}' in run {run_id}", file=sys.stderr)
            sys.exit(1)
        print(json.dumps(artifact.to_dict(), indent=2, ensure_ascii=False, default=str))
        return

    print(json.dumps({
        "run_id": manifest.get("run_id"),
        "name": manifest.get("name"),
        "status": manifest.get("status"),
        "params": manifest.get("params"),
        "created_at": manifest.get("created_at"),
        "finished_at": manifest.get("finished_at"),
        "error": manifest.get("error"),
        "steps": manifest.get("steps", {}),
        "calls": len(manifest.get("calls", [])),
        "files": [f.get("path") for f in manifest.get("files", [])],
    }, indent=2, ensure_ascii=False, default=str))


def cmd_composite_spec_schema():
    from amz.composite.spec import PipelineSpec

    print(json.dumps(PipelineSpec.model_json_schema(), indent=2, ensure_ascii=False))


def _load_spec_file(path: str) -> dict:
    p = Path(path)
    if not p.exists():
        print(f"spec file not found: {path}", file=sys.stderr)
        sys.exit(1)
    if p.suffix == ".json":
        return json.loads(p.read_text(encoding="utf-8"))
    import yaml

    return yaml.safe_load(p.read_text(encoding="utf-8")) or {}


def cmd_composite_validate(path: str):
    _load_capabilities()
    r = registry_invoke("composite.validate", {"spec": _load_spec_file(path)})
    print(json.dumps(r.model_dump(), indent=2, ensure_ascii=False, default=str))
    if r.code.value != "OK":
        sys.exit(1)


def cmd_composite_compile(path: str):
    _load_capabilities()
    r = registry_invoke("composite.compile", {"spec": _load_spec_file(path)})
    print(json.dumps(r.model_dump(), indent=2, ensure_ascii=False, default=str))
    if r.code.value != "OK":
        sys.exit(1)


def registry_invoke(capability_id: str, params: dict):
    """调用能力（已加载内置能力）。"""
    from amz.registry import registry

    return registry.invoke(capability_id, params)


def _cmd_composite(args: list[str]):
    if not args:
        print("Usage: amz composite list|new|run|show|spec-schema|validate|compile ...")
        return

    sub = args[0]
    rest = args[1:]

    if sub == "list":
        cmd_composite_list()

    elif sub == "new":
        if not rest or rest[0].startswith("--"):
            print("Usage: amz composite new <name> [--category X] [--description Y]")
            return
        name = rest[0]
        category, description = "", ""
        i = 1
        while i < len(rest):
            if rest[i] == "--category" and i + 1 < len(rest):
                category = rest[i + 1]
                i += 2
            elif rest[i] == "--description" and i + 1 < len(rest):
                description = rest[i + 1]
                i += 2
            else:
                i += 1
        cmd_composite_new(name, category, description)

    elif sub == "run":
        if not rest or rest[0].startswith("--"):
            print("Usage: amz composite run <name> [--param k=v ...] [--force]")
            return
        name = rest[0]
        tokens = rest[1:]
        force = "--force" in tokens
        tokens = [t for t in tokens if t != "--force"]
        cmd_composite_run(name, _parse_params(tokens), force)

    elif sub == "show":
        if not rest:
            print("Usage: amz composite show <run_id> [--step X]")
            return
        run_id = rest[0]
        step = None
        for i, t in enumerate(rest[1:], start=1):
            if t == "--step" and i + 1 < len(rest):
                step = rest[i + 1]
        cmd_composite_show(run_id, step)

    elif sub == "spec-schema":
        cmd_composite_spec_schema()

    elif sub == "validate":
        if not rest:
            print("Usage: amz composite validate <spec.json|spec.yaml>")
            return
        cmd_composite_validate(rest[0])

    elif sub == "compile":
        if not rest:
            print("Usage: amz composite compile <spec.json|spec.yaml>")
            return
        cmd_composite_compile(rest[0])

    else:
        print(f"Unknown composite subcommand: {sub}")


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------


def main():
    args = sys.argv[1:]

    if not args:
        from amz import __version__

        print(f"amz-cli-sdk v{__version__}")
        print("Usage: amz <command> [options]")
        print("  capabilities [--id <cap>]        List all capabilities / one schema")
        print("  run <id> [--param k=v ...]       Run a capability")
        print("       [--out FILE] [--task run_id]")
        print("  task new <name> [--param k=v ...]")
        print("  task run <id> [--param k=v ...] [--task run_id]")
        print("  task status <run_id>")
        print("  task files <run_id> [--kind kind]")
        print("  task list")
        print("  task cleanup [--older-than-hours N]")
        print("  composite list / new <name> / run <name> [--param k=v] [--force]")
        print("  composite show <run_id> [--step X] / spec-schema")
        print("  composite validate|compile <spec.json>")
        print("  serve http|mcp [--port PORT] [--host HOST] [--no-auth]")
        print("  setup [--web] [--status --json] [--token X] [--base-url URL] [--no-prompt]")
        print("  python <script.py> [args...]       Run a script in the SDK environment")
        print("  version [--json]")
        print("  doctor")
        return

    cmd = args[0]

    if cmd in ("version", "--version", "-V"):
        from amz import __version__

        if "--json" in args[1:]:
            print(json.dumps({
                "name": "amz-cli-sdk",
                "version": __version__,
                "python": sys.version.split()[0],
            }, ensure_ascii=False))
        else:
            print(f"amz-cli-sdk {__version__}")

    elif cmd == "capabilities":
        cap_id = None
        if len(args) >= 3 and args[1] == "--id":
            cap_id = args[2]
        elif len(args) == 2 and args[1] != "--id":
            cap_id = args[1]
        cmd_capabilities(cap_id)

    elif cmd == "run":
        if len(args) < 2:
            print("Usage: amz run <capability_id> [--param key=value ...] [--out FILE] [--task run_id]")
            return
        cap_id = args[1]
        tokens = args[2:]
        out = None
        task_id = None
        rest = []
        i = 0
        while i < len(tokens):
            if tokens[i] == "--out" and i + 1 < len(tokens):
                out = tokens[i + 1]
                i += 2
            elif tokens[i] == "--task" and i + 1 < len(tokens):
                task_id = tokens[i + 1]
                i += 2
            else:
                rest.append(tokens[i])
                i += 1
        params = _parse_params(rest)
        if task_id:
            _run_attached(cap_id, params, task_id)
        else:
            cmd_run(cap_id, params, out)

    elif cmd == "task":
        _cmd_task(args[1:])

    elif cmd == "composite":
        _cmd_composite(args[1:])

    elif cmd == "serve":
        _cmd_serve(args[1:])

    elif cmd == "setup":
        _cmd_setup(args[1:])

    elif cmd == "python":
        if len(args) < 2:
            print("Usage: amz python <script.py> [args...]", file=sys.stderr)
            sys.exit(2)
        import runpy

        script = Path(args[1])
        if not script.is_file():
            print(f"script not found: {script}", file=sys.stderr)
            sys.exit(2)
        sys.argv = [str(script), *args[2:]]
        runpy.run_path(str(script), run_name="__main__")

    elif cmd == "doctor":
        cmd_doctor()
    else:
        print(f"Unknown command: {cmd}")


def _run_attached(capability_id: str, params: dict, run_id: str):
    """挂到已有任务执行（记录但复用任务）。"""
    from amz.infra.runtime import Runtime, runtime_context
    from amz.registry import registry

    rt = Runtime.open(run_id)
    if rt is None:
        print(f"unknown task: {run_id}", file=sys.stderr)
        sys.exit(1)
    with runtime_context(rt):
        result = registry.invoke(capability_id, params or {})
    print(json.dumps(result.model_dump(), indent=2, ensure_ascii=False, default=str))


# ---------------------------------------------------------------------------
# serve 命令（远程服务模式）
# ---------------------------------------------------------------------------


def _cmd_serve(args: list[str]):
    """amz serve http|mcp --port 8000 --host 0.0.0.0 [--no-auth]"""
    if not args or args[0] not in ("http", "mcp"):
        print("Usage: amz serve http|mcp [--port PORT] [--host HOST] [--no-auth]")
        return
    kind = args[0]
    port = 8000
    host = "127.0.0.1"
    no_auth = False
    rest = args[1:]
    i = 0
    while i < len(rest):
        if rest[i] == "--port" and i + 1 < len(rest):
            port = int(rest[i + 1])
            i += 2
        elif rest[i] == "--host" and i + 1 < len(rest):
            host = rest[i + 1]
            i += 2
        elif rest[i] == "--no-auth":
            no_auth = True
            i += 1
        else:
            i += 1

    from amz.config import config

    config.load()
    auth_token = "" if no_auth else config.data_api_token

    if kind == "http":
        from amz.serve.http import create_app

        app = create_app(auth_token=auth_token)
        path = "/"
    else:
        from amz.serve.mcp import create_asgi_app

        app = create_asgi_app(auth_token=auth_token)
        path = "/mcp"

    auth_note = "无鉴权" if no_auth else "X-API-Token 鉴权"
    print(f"amz serve {kind} → http://{host}:{port}{path}（{auth_note}）")
    print("按 Ctrl+C 停止")
    import uvicorn

    uvicorn.run(app, host=host, port=port, log_level="info")


# ---------------------------------------------------------------------------
# setup 命令（开箱配置向导）
# ---------------------------------------------------------------------------


def _cmd_setup(args: list[str]):
    """amz setup [--web] [--status --json] [--token X] [--base-url URL] [--no-prompt]

    把配置写入 ~/.amz/config.yaml（服务端部署 / 新机器上手）。
    """
    if "--status" in args:
        from amz.setup_web import saved_status

        status = saved_status()
        if "--json" in args:
            print(json.dumps(status, ensure_ascii=False))
        else:
            print("AMZ 数据 Token：" + ("已配置" if status["data_api_token"] else "未配置"))
            for provider, is_set in status["api_keys"].items():
                print(f"{provider}：" + ("已配置" if is_set else "未配置"))
        return

    if "--web" in args:
        from amz.setup_web import run_web_setup

        result = run_web_setup(open_browser="--no-open" not in args)
        if result:
            sys.exit(result)
        return

    import yaml

    from amz.config import config

    config.load()
    token_arg = None
    base_url_arg = None
    no_prompt = False
    rest = args
    i = 0
    while i < len(rest):
        if rest[i] == "--token" and i + 1 < len(rest):
            token_arg = rest[i + 1]
            i += 2
        elif rest[i] == "--base-url" and i + 1 < len(rest):
            base_url_arg = rest[i + 1]
            i += 2
        elif rest[i] == "--no-prompt":
            no_prompt = True
            i += 1
        else:
            i += 1

    target = Path.home() / ".amz" / "config.yaml"
    target.parent.mkdir(parents=True, exist_ok=True)

    data: dict = {}
    if target.exists():
        try:
            data = yaml.safe_load(target.read_text()) or {}
        except Exception:
            data = {}

    current_token = token_arg or config.data_api_token or ""
    current_url = base_url_arg or config.data_api_base_url or "https://amz.jxpxxzj.cn"

    def _prompt(label: str, current: str, secret: bool = False) -> str:
        if no_prompt or not sys.stdin.isatty():
            return current
        shown = "（已配置，回车保留）" if current else ""
        display = "***" if (secret and current) else current
        try:
            value = input(f"{label} [{display}]{shown}: ").strip()
        except (EOFError, KeyboardInterrupt):
            return current
        return value or current

    token = _prompt("data_api.token", current_token, secret=True)
    base_url = _prompt("data_api.base_url", current_url)

    data.setdefault("data_api", {})
    data["data_api"]["token"] = token
    data["data_api"]["base_url"] = base_url

    sif_default = str(config.sif_token_file)
    sif = _prompt("sif.token_file", sif_default)
    if sif:
        data.setdefault("sif", {})
        data["sif"]["token_file"] = sif

    # 物化 LLM API keys：从当前合并配置（项目 .env 等）写入，保证任意 cwd 可用
    llm_keys = data.setdefault("api_keys", {})
    for provider in ("deepseek", "doubao", "anthropic", "openrouter", "ark"):
        current = config.api_key(provider) or ""
        value = _prompt(f"api_keys.{provider}", current, secret=True)
        if value:
            llm_keys[provider] = value

    from amz.setup_web import write_saved_config

    write_saved_config(data, target)

    print(f"\n✅ 配置已写入 {target}")
    cmd_doctor()


def _cmd_task(args: list[str]):
    if not args:
        print("Usage: amz task new|run|status|files|list|cleanup ...")
        return
    sub = args[0]
    rest = args[1:]

    if sub == "new":
        name = rest[0] if rest and not rest[0].startswith("--") else "task"
        params = _parse_params(rest[1:] if rest and not rest[0].startswith("--") else rest)
        cmd_task_new(name, params)

    elif sub == "run":
        if len(rest) < 1 or rest[0].startswith("--"):
            print("Usage: amz task run <capability_id> [--param key=value ...] [--task run_id]")
            return
        cap_id = rest[0]
        task_id = None
        tokens = []
        i = 1
        while i < len(rest):
            if rest[i] == "--task" and i + 1 < len(rest):
                task_id = rest[i + 1]
                i += 2
            else:
                tokens.append(rest[i])
                i += 1
        params = _parse_params(tokens)
        cmd_task_run(cap_id, params, task_id)

    elif sub == "status":
        if len(rest) < 1:
            print("Usage: amz task status <run_id>")
            return
        cmd_task_status(rest[0])

    elif sub == "files":
        if len(rest) < 1:
            print("Usage: amz task files <run_id> [--kind kind]")
            return
        run_id = rest[0]
        kind = None
        for i, token in enumerate(rest[1:], start=1):
            if token == "--kind" and i + 1 < len(rest):
                kind = rest[i + 1]
        cmd_task_files(run_id, kind)

    elif sub == "list":
        cmd_task_list()

    elif sub == "cleanup":
        hours = 168
        for i, token in enumerate(rest):
            if token == "--older-than-hours" and i + 1 < len(rest):
                try:
                    hours = int(rest[i + 1])
                except ValueError:
                    pass
        cmd_task_cleanup(hours)

    else:
        print(f"Unknown task subcommand: {sub}")


if __name__ == "__main__":
    main()
