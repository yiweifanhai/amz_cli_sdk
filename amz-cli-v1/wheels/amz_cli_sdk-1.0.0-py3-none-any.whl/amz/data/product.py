"""
Product 数据获取：product-info / reviews / rufus / refinements / search / nr-page。

包装 AmzDataApi 适配器，标准化输出。
"""

from __future__ import annotations

import hashlib
from typing import Any

from amz.envelope import Result, ok, err, Code
from amz.registry import capability
from amz.data.sources.amz_api import AmzDataApi
from amz.data.normalizer import normalize_field, normalize_product_info
from amz.schemas.data_outputs import (
    NrPageOutput,
    ProductInfoOutput,
    ProductSearchOutput,
    RefinementsOutput,
    ReviewsOutput,
    RufusOutput,
)


_api: AmzDataApi | None = None


def _get_api() -> AmzDataApi:
    global _api
    if _api is None:
        _api = AmzDataApi()
    return _api


def _review_id(raw: dict[str, Any]) -> str:
    """返回上游 review ID；缺失时用稳定的内容指纹代替。"""
    existing = raw.get("review_id") or raw.get("reviewId") or raw.get("id")
    if existing:
        return str(existing)
    parts = (
        raw.get("user_name") or raw.get("userName") or raw.get("author") or "",
        raw.get("date") or "",
        raw.get("title") or raw.get("reviewSummary") or "",
        raw.get("text") or raw.get("body") or "",
    )
    digest = hashlib.sha256("\x1f".join(map(str, parts)).encode("utf-8")).hexdigest()[:24]
    return f"generated:{digest}"


def _review_rating(raw: Any) -> int | None:
    parsed = normalize_field("rating", raw)
    if parsed is None:
        return None
    rating = int(float(parsed) + 0.5)
    return rating if 1 <= rating <= 5 else None


def _review_verified(raw: Any) -> bool:
    if isinstance(raw, str):
        return raw.strip().lower() in {"1", "true", "yes", "verified"}
    return bool(raw)


def _normalize_review_summary(raw: Any) -> dict[str, Any]:
    """把上游评分汇总收敛为 Calc 接受的稳定字段，丢弃展示型附加键。"""
    if not isinstance(raw, dict):
        return {}
    nested = raw.get("reviewSummary") or raw.get("review_summary")
    source = nested if isinstance(nested, dict) else raw
    normalized: dict[str, Any] = {}
    aliases = {
        "fiveStar": ("fiveStar", "five_star"),
        "fourStar": ("fourStar", "four_star"),
        "threeStar": ("threeStar", "three_star"),
        "twoStar": ("twoStar", "two_star"),
        "oneStar": ("oneStar", "one_star"),
    }
    for target, names in aliases.items():
        value = next((source[name] for name in names if name in source), None)
        if value is not None:
            normalized[target] = value
    for name in ("countRatings", "count_ratings", "totalReviews", "total_reviews"):
        if name in raw:
            normalized["countRatings"] = raw[name]
            break
        if name in source:
            normalized["countRatings"] = source[name]
            break
    return normalized


def _normalize_review_item(raw: dict[str, Any]) -> dict[str, Any]:
    title = raw.get("title")
    if not title and isinstance(raw.get("reviewSummary"), str):
        title = raw["reviewSummary"]
    return {
        "review_id": _review_id(raw),
        "rating": _review_rating(raw.get("rating")),
        "title": str(title or ""),
        "text": str(raw.get("text") or raw.get("body") or ""),
        "date": raw.get("date"),
        "verified": _review_verified(raw.get("verified", False)),
        "user_name": str(raw.get("user_name") or raw.get("userName") or raw.get("author") or ""),
        "images": list(raw.get("images") or raw.get("imageUrlList") or []),
    }


def _normalize_reviews_result(
    result: Result,
    *,
    asin: str,
    mode: str,
    star_filter: str,
) -> Result:
    """将 reviews 上游原始字段转为 product.reviews 公开契约。"""
    if result.code != Code.OK:
        return result
    if not isinstance(result.data, dict):
        return err(
            Code.ERROR_UPSTREAM,
            "[reviews] upstream returned a non-object payload",
            upstream=result.meta.upstream or "reviews",
        )

    raw_items = result.data.get("items", [])
    if not isinstance(raw_items, list):
        return err(
            Code.ERROR_UPSTREAM,
            "[reviews] upstream returned a non-list items field",
            upstream=result.meta.upstream or "reviews",
        )

    items = []
    seen: set[str] = set()
    for raw in raw_items:
        if not isinstance(raw, dict):
            continue
        item = _normalize_review_item(raw)
        if item["review_id"] in seen:
            continue
        seen.add(item["review_id"])
        items.append(item)

    raw_data = result.data
    head = next(
        (
            item for item in raw_items
            if isinstance(item, dict)
            and (
                any(
                    item.get(key) is not None
                    for key in (
                        "count_ratings", "countRatings", "product_rating",
                        "productRating", "review_summary",
                    )
                )
                or isinstance(item.get("reviewSummary"), dict)
            )
        ),
        {},
    )
    normalized = {
        "asin": str(raw_data.get("asin") or asin),
        "items": items,
        "mode": mode,
        "star_filter": star_filter,
        "count": len(items),
        "star_counts": {
            str(star): sum(item.get("rating") == star for item in items)
            for star in range(1, 6)
        },
    }
    count_ratings = raw_data.get(
        "count_ratings",
        raw_data.get("countRatings", head.get("count_ratings", head.get("countRatings"))),
    )
    if count_ratings is not None:
        normalized["count_ratings"] = count_ratings
    overall_rating = normalize_field(
        "rating",
        raw_data.get(
            "rating",
            raw_data.get(
                "productRating",
                head.get("product_rating", head.get("productRating")),
            ),
        ),
    )
    if overall_rating is not None:
        normalized["rating"] = overall_rating
    review_summary = raw_data.get(
        "review_summary",
        raw_data.get("reviewSummary", head.get("review_summary", head.get("reviewSummary"))),
    )
    if isinstance(review_summary, dict):
        normalized["review_summary"] = _normalize_review_summary(review_summary)
    if raw_data.get("source"):
        normalized["source"] = raw_data["source"]

    result.data = normalized
    return result


@capability("product.get", description="通过 ASIN 获取商品详情（慢端点，首次调用需等 10-30s）", output_model=ProductInfoOutput)
def product_get(asin: str) -> Result:
    """product.get — ASIN 详情"""
    api = _get_api()
    result = api.product_info(asin)
    if result.code != Code.OK:
        return result

    # 标准化：上游返回 flat dict 或 {"items": [...]} 两种格式
    data = result.data
    if isinstance(data, dict):
        if "items" in data:
            # Wrapped 格式：{"items": [...], "asin": ...}
            items = data.get("items", [])
            if items:
                normalized = normalize_product_info(items[0])
                normalized["asin"] = data.get("asin", asin)
                result.data = normalized
                return result
        else:
            # Flat 格式：直接标准化整个 dict
            normalized = normalize_product_info(data)
            result.data = normalized
            return result

    return result


@capability("product.reviews", description="获取 ASIN 评论列表。支持 mode (low/mid/high 每星 20/50/100 条) 或手动 star_filter/max_pages", output_model=ReviewsOutput)
def product_reviews(asin: str, mode: str = "mid", star_filter: str = "all", max_pages: int = 1, domain_code: str = "com") -> Result:
    """product.reviews — 评论

    mode: low=每星20条, mid=每星50条, high=每星100条。仅 star_filter="all" 时生效。
    指定 star_filter 时走旧逻辑，mode 被忽略。
    """
    api = _get_api()
    if star_filter == "all":
        reviews_by_mode = getattr(api, "reviews_by_mode", None)
        if reviews_by_mode is not None:
            result = reviews_by_mode(asin, mode, domain_code)
        else:
            # Mock/自定义数据源可以只实现基础 reviews 接口。
            result = api.reviews(asin, star_filter, max_pages, domain_code)
    else:
        result = api.reviews(asin, star_filter, max_pages, domain_code)
    return _normalize_reviews_result(
        result,
        asin=asin,
        mode=mode,
        star_filter=star_filter,
    )


@capability("product.search", description="Amazon 关键词搜索", output_model=ProductSearchOutput)
def product_search(keyword: str) -> Result:
    """product.search — 关键词搜索"""
    return _get_api().amazon_search(keyword)


@capability("product.rufus", description="获取 ASIN 的 Rufus AI 问答", output_model=RufusOutput)
def product_rufus(asin: str) -> Result:
    """product.rufus — Rufus 问答"""
    return _get_api().rufus(asin)


@capability("product.refinements", description="获取关键词搜索的筛选维度", output_model=RefinementsOutput)
def product_refinements(keyword: str) -> Result:
    """product.refinements — 搜索筛选维度"""
    return _get_api().refinements(keyword)


@capability("product.nr-page", description="解析 Amazon New Releases 榜单页", output_model=NrPageOutput)
def product_nr_page(url: str) -> Result:
    """product.nr-page — 榜单页"""
    return _get_api().nr_page(url)
