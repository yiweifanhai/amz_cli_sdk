"""
通用搜索数据获取：火山 web 搜索。
"""

from __future__ import annotations

from amz.envelope import Result
from amz.registry import capability
from amz.data.sources.amz_api import AmzDataApi
from amz.schemas.data_outputs import WebSearchOutput


_api: AmzDataApi | None = None


def _get_api() -> AmzDataApi:
    global _api
    if _api is None:
        _api = AmzDataApi()
    return _api


@capability("search.web", description="火山通用 web 搜索", output_model=WebSearchOutput)
def search_web(query: str, limit: int | None = None) -> Result:
    """search.web — 通用 web 搜索"""
    return _get_api().web_search(query, limit)
