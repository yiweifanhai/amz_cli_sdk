"""
Category 数据获取：类目树 / 类目搜索。
"""

from __future__ import annotations

from amz.envelope import Result
from amz.registry import capability
from amz.data.sources.amz_api import AmzDataApi
from amz.schemas.data_outputs import CategorySearchOutput, CategoryTreeOutput


_api: AmzDataApi | None = None


def _get_api() -> AmzDataApi:
    global _api
    if _api is None:
        _api = AmzDataApi()
    return _api


@capability("category.tree", description="获取 Amazon 类目树", output_model=CategoryTreeOutput)
def category_tree(type_: str) -> Result:
    """category.tree — 类目树"""
    return _get_api().tree_list(type_)


@capability("category.search", description="关键词或类目名搜索 Amazon 类目", output_model=CategorySearchOutput)
def category_search(keyword: str = "", category_name: str = "", category_id: str = "") -> Result:
    """category.search — 类目搜索"""
    return _get_api().tree_search(keyword=keyword, category_name=category_name, category_id=category_id)
