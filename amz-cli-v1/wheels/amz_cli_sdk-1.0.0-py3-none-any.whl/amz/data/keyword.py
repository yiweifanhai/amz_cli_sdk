"""
Keyword 数据获取：keyword-reverse / keyword-miner / trends。
"""

from __future__ import annotations

from amz.envelope import Result, ok, Code
from amz.registry import capability
from amz.data.sources.amz_api import AmzDataApi
from amz.data.normalizer import (
    normalize_keyword_miner_item,
    normalize_keyword_reverse_item,
    normalize_trend_points,
)
from amz.schemas.data_outputs import (
    KeywordMinerOutput,
    KeywordReverseOutput,
    KeywordTrendsOutput,
)


_api: AmzDataApi | None = None


def _get_api() -> AmzDataApi:
    global _api
    if _api is None:
        _api = AmzDataApi()
    return _api


def _normalize_items(result: Result, normalizer) -> Result:
    """对 Result.data.items 逐条标准化（camelCase 上游字段 → SDK 标准字段）。"""
    if result.code != Code.OK or not isinstance(result.data, dict):
        return result
    items = result.data.get("items")
    if isinstance(items, list):
        result.data["items"] = [
            normalizer(it) for it in items if isinstance(it, dict)
        ]
    return result


@capability("keyword.reverse", description="通过 ASIN 反查关键词列表（流量占比/自然占比/PPC）", output_model=KeywordReverseOutput)
def keyword_reverse(asin: str) -> Result:
    """keyword.reverse — ASIN 反查关键词"""
    return _normalize_items(_get_api().keyword_reverse(asin), normalize_keyword_reverse_item)


@capability("keyword.miner", description="关键词特征挖掘（搜索量/PPC/点击率/转化率/Top3 ASIN）", output_model=KeywordMinerOutput)
def keyword_miner(keyword: str, history_date: str | None = None) -> Result:
    """keyword.miner — 关键词特征"""
    result = _get_api().keyword_miner(keyword, history_date)
    result = _normalize_items(result, normalize_keyword_miner_item)
    if result.code == Code.OK and isinstance(result.data, dict):
        result.data.setdefault("keyword", keyword)
    return result


@capability("keyword.trends", description="关键词趋势时间序列", output_model=KeywordTrendsOutput)
def keyword_trends(keyword: str) -> Result:
    """keyword.trends — 趋势

    trends 端点在信封解包后 data 是 point 列表（``[{date, searches, ...}]``），
    标准化为 ``{keyword, points: [{date, value}]}``。
    """
    result = _get_api().trends(keyword)
    if result.code != Code.OK:
        return result
    raw_points = result.data if isinstance(result.data, list) else None
    return ok(data={"keyword": keyword, "points": normalize_trend_points(raw_points)})
