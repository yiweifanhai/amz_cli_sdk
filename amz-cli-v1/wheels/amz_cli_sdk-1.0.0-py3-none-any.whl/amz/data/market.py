"""
Market 数据获取：competing-lookup / market-research（降级返回原始数据，聚合走 entities/calc）。
"""

from __future__ import annotations

from amz.envelope import Result, ok, Code
from amz.registry import capability
from amz.data.sources.amz_api import AmzDataApi
from amz.data.normalizer import normalize_competing_item
from amz.schemas.data_outputs import CompetitorsOutput, SnapshotOutput


_api: AmzDataApi | None = None


def _get_api() -> AmzDataApi:
    global _api
    if _api is None:
        _api = AmzDataApi()
    return _api


def _normalize_items(result: Result) -> Result:
    """对 Result.data.items 逐条标准化（camelCase 上游字段 → SDK 标准字段）。"""
    if result.code != Code.OK or not isinstance(result.data, dict):
        return result
    items = result.data.get("items")
    if isinstance(items, list):
        result.data["items"] = [
            normalize_competing_item(it) for it in items if isinstance(it, dict)
        ]
    return result


@capability("market.competitors", description="竞品查询：按关键词或 ASIN 拉竞品列表（支持多 ASIN + 分页）", output_model=CompetitorsOutput)
def market_competitors(
    keyword: str | None = None,
    asin: str | list[str] | None = None,
    page: int = 1,
    pages: int = 1,
) -> Result:
    """market.competitors — 竞品查询"""
    result = _get_api().competing_lookup(keyword=keyword, asin=asin, page=page, pages=pages)
    return _normalize_items(result)


@capability("market.snapshot", description="市场快照（上游 market-research 禁用，默认返回 competitors 原始数据，聚合计算由 entities/calc 层负责）", output_model=SnapshotOutput)
def market_snapshot(keyword: str) -> Result:
    """market.snapshot — 市场特征

    上游 /api/seller-sprite/market-research 403 禁用中，
    默认返回 TOP2K competitors 原始数据，上游恢复后自动切换。
    聚合计算（calculate_stats）由 entities 层或调用方负责。
    """
    api = _get_api()

    # 先尝试直接调用 market-research
    result = api.market_research(keyword)
    if result.code == Code.OK:
        return result

    # 降级：返回 competitors 原始数据
    competitors_result = api.competing_lookup(keyword=keyword, pages=2)
    if competitors_result.code != Code.OK:
        return competitors_result

    items = (competitors_result.data or {}).get("items", [])
    items = [normalize_competing_item(it) for it in items if isinstance(it, dict)]

    return ok(
        data={
            "keyword": keyword,
            "items": items,
        },
        upstream="aggregate",
        hint="market-research endpoint disabled, returned raw competitors data. Use Market entity or calc.market.calculate_stats for aggregation.",
    )
