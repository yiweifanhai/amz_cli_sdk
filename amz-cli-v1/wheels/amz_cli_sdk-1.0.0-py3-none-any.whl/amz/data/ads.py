"""
广告数据获取：SIF 流量漏斗。
"""

from __future__ import annotations

from amz.envelope import Result
from amz.registry import capability
from amz.data.sources.sif import SifApi
from amz.schemas.data_outputs import AdsFunnelOutput


_api: SifApi | None = None


def _get_api() -> SifApi:
    global _api
    if _api is None:
        _api = SifApi()
    return _api


@capability("ads.keyword-funnel", description="SIF 关键词流量漏斗 + 广告成本（搜索量/点击/订单/CPC/CPA/ACOS）", output_model=AdsFunnelOutput)
def ads_keyword_funnel(keywords: list[str]) -> Result:
    """ads.keyword-funnel — SIF 流量漏斗"""
    return _get_api().keyword_funnel(keywords)
