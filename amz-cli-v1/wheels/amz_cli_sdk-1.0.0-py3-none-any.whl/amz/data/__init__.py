"""
L1 数据获取层 — 封装上游 API 调用，返回标准化数据。

设计原则
--------
- 所有端点返回带缓存的 Result 信封
- 上游异常映射为统一错误码
- 端点按领域分组（product/keyword/market/supply/category/search/ads）

数据源适配器
------------
sources/ 子包封装不同上游的差异：::

    sources/base.py     DataSource 抽象基类：缓存 + 归一化 + HTTP 错误映射
    sources/amz_api.py  AmzDataApi — 15 端点（product-info / reviews / competing-lookup / ...）
    sources/sif.py      SifApi — SIF 流量漏斗（~/.sif_token）
    sources/aba_file.py AbaFile — ABA CSV 读取（中英文表头兼容）
    sources/mock.py     MockDataSource — 测试用静态数据

端点模块
--------

============= ==============================================
模块          职责
============= ==============================================
product       product.get / reviews / search / rufus / refinements / nr-page
keyword       keyword.reverse / miner / trends
market        market.competitors / snapshot（降级 → calc.market.stats）
supply        supply.search-1688
category      category.tree / search
search        search.web
ads           ads.keyword-funnel（SIF）
============= ==============================================

用法::

    from amz.data.product import product_get, reviews_get
    result = product_get("B0XXXX")
"""
