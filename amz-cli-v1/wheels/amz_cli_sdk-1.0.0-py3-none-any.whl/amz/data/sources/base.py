"""
数据源适配器基类：缓存 + 重试 + 归一化。

所有适配器继承此基类。
"""

from __future__ import annotations

import json
import time
from abc import ABC, abstractmethod
from typing import Any

from amz.envelope import Code, Result, Meta, ok, err, UpstreamError, AuthError, RateLimitError
from amz.config import config
from amz.infra.cache import file_read, file_write


class DataSource(ABC):
    """数据源适配器基类"""

    source_name: str = ""

    def __init__(self):
        self._qps_tracker: dict[str, list[float]] = {}

    # -- 子类实现 ------------------------------------------------------------

    @abstractmethod
    def _call_endpoint(self, slug: str, params: dict) -> dict:
        """实际 HTTP 调用，返回上游原始响应"""
        ...

    # -- 缓存 ----------------------------------------------------------------

    def _read_cache(self, slug: str, key: str, ttl_hours: int) -> dict | None:
        """读缓存"""
        return file_read(slug, key, ttl_hours)

    def _write_cache(self, slug: str, key: str, ttl_hours: int, data: Any):
        """写缓存"""
        file_write(slug, key, ttl_hours, data)

    # -- QPS 限速 ------------------------------------------------------------

    def _qps_wait(self, endpoint: str, qps: float = 1.0):
        """按端点限速"""
        if qps <= 0:
            return
        now = time.time()
        timestamps = self._qps_tracker.setdefault(endpoint, [])
        timestamps[:] = [t for t in timestamps if now - t < 1.0]
        if len(timestamps) >= qps:
            sleep_time = 1.0 - (now - timestamps[0])
            if sleep_time > 0:
                time.sleep(sleep_time)
        timestamps.append(time.time())

    # -- 归一化 --------------------------------------------------------------

    def normalize_response(
        self,
        upstream_data: dict | None,
        slug: str,
        from_cache: bool = False,
    ) -> Result:
        """将上游原始响应归一化为统一信封。

        Args:
            upstream_data: 上游响应 dict
            slug: 端点标识
            from_cache: 是否来自缓存

        Returns:
            Result 信封
        """
        if upstream_data is None:
            return err(
                Code.ERROR_UPSTREAM,
                message=f"[{slug}] upstream returned empty",
                upstream=slug,
                hint="check upstream service",
            )

        # 检查上游错误
        if "error" in upstream_data:
            return err(
                Code.ERROR_UPSTREAM,
                message=f"[{slug}] {upstream_data['error']}",
                data=upstream_data,
                upstream=slug,
            )

        # 解包嵌套信封 {code, message, data, success}。
        # seller-sprite 系列端点（competing-lookup / keyword-reverse / keyword-miner
        # / trends 等）返回统一信封，真实数据埋在 data 字段；data 可能是 dict
        # （competing-lookup / keyword-*）也可能是 list（trends 时间序列），
        # 只要存在 success 键就按信封解包。平铺端点（product-info / reviews 等）
        # 没有 success 键，不受影响。SIF 适配器在调用前已自行解包，同样无 success 键。
        if isinstance(upstream_data, dict) and "success" in upstream_data:
            if not upstream_data.get("success"):
                return err(
                    Code.ERROR_UPSTREAM,
                    message=f"[{slug}] {upstream_data.get('message') or 'upstream error'}",
                    data=upstream_data,
                    upstream=slug,
                )
            upstream_data = upstream_data.get("data")

        return ok(
            data=upstream_data,
            from_cache=from_cache,
            upstream=slug,
        )

    def normalize_http_error(
        self,
        status: int,
        body: str,
        slug: str,
    ) -> Result:
        """HTTP 错误 → 统一信封。

        映射规则（01-数据源对接.md §3）：
          - HTTP 401 → ERROR_AUTH
          - HTTP 422/400 → ERROR_PARAM
          - HTTP 404 → ERROR_NOT_FOUND
          - HTTP 429 → ERROR_RATE_LIMIT
          - HTTP 502/503/504 → ERROR_UPSTREAM
        """
        msg = body[:200] if body else ""

        match status:
            case 401:
                return err(Code.ERROR_AUTH, f"[{slug}] authentication failed", upstream=slug)
            case 403:
                return err(
                    Code.ERROR_UPSTREAM,
                    f"[{slug}] upstream disabled (403)",
                    upstream=slug,
                    hint="endpoint deprecated by upstream, see docs for fallback",
                )
            case 404:
                return err(Code.ERROR_NOT_FOUND, f"[{slug}] resource not found", upstream=slug)
            case 422 | 400:
                return err(Code.ERROR_PARAM, f"[{slug}] invalid params: {msg}", upstream=slug)
            case 429:
                return err(Code.ERROR_RATE_LIMIT, f"[{slug}] rate limited", upstream=slug)
            case _ if status >= 500:
                return err(Code.ERROR_UPSTREAM, f"[{slug}] upstream error HTTP {status}", upstream=slug)
            case _:
                return err(Code.ERROR_UPSTREAM, f"[{slug}] HTTP {status}: {msg}", upstream=slug)
