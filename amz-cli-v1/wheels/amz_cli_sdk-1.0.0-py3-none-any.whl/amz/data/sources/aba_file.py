"""
ABA 本地 CSV 读取器：读取 Amazon Brand Analytics 周报数据。

兼容中英文表头、skiprows、自动列名映射。
"""

from __future__ import annotations

import csv
import re
from pathlib import Path
from typing import Any

from amz.envelope import Result, ok, err, Code


# 中英文表头映射
HEADER_MAP: dict[str, str] = {
    # 英文
    "search term": "term",
    "search frequency rank": "rank",
    "click share": "click_share",
    "conversion share": "conversion_share",
    "top 3 clicked asins": "top3_asins",
    "top 3 clicked products": "top3_asins",
    "#1 clicked asin": "top1_asin",
    "#2 clicked asin": "top2_asin",
    "#3 clicked asin": "top3_asin",
    # 中文
    "搜索词": "term",
    "搜索频率排名": "rank",
    "点击分享": "click_share",
    "转化分享": "conversion_share",
    "点击最多的前三个商品": "top3_asins",
    "点击最多的第 1 个商品": "top1_asin",
    "点击最多的第 2 个商品": "top2_asin",
    "点击最多的第 3 个商品": "top3_asin",
}


def read_aba(csv_path: str, week: str | None = None) -> Result:
    """读取 ABA 周报 CSV

    Args:
        csv_path: CSV 文件路径
        week: 周标识（用于错误信息）

    Returns:
        Result.data = {rows: [{term, rank, click_share, conversion_share, top3_asins[]}], week}
    """
    path = Path(csv_path)
    if not path.exists():
        return err(Code.ERROR_NOT_FOUND, f"ABA CSV not found: {csv_path}")

    try:
        text = path.read_text(encoding="utf-8-sig")
    except UnicodeDecodeError:
        text = path.read_text(encoding="gbk")

    lines = text.split("\n")

    # 跳过空行和前导非 CSV 行，找表头
    header_idx = 0
    for i, line in enumerate(lines):
        line = line.strip()
        if not line:
            continue
        # 表头行含典型的 ABA 列名
        if any(kw in line.lower() for kw in ["search term", "搜索词", "click share", "点击分享"]):
            header_idx = i
            break
    else:
        return err(Code.ERROR_PARAM, f"No ABA header found in {csv_path}")

    # 解析表头
    reader = csv.reader(lines[header_idx:])
    raw_headers = next(reader)
    headers = [_map_header(h.strip()) for h in raw_headers]

    # 解析数据行
    rows = []
    for raw_row in reader:
        if not raw_row or all(not cell.strip() for cell in raw_row):
            continue
        if len(raw_row) < 2:
            continue
        row = {}
        for i, h in enumerate(headers):
            if i < len(raw_row):
                val = raw_row[i].strip()

                # 类型转换
                if h == "rank":
                    try:
                        row[h] = int(val.replace(",", ""))
                    except ValueError:
                        row[h] = None
                elif h in ("click_share", "conversion_share"):
                    try:
                        row[h] = float(val.replace("%", "").strip())
                    except ValueError:
                        row[h] = None
                elif h == "top3_asins":
                    # 可能是 "ASIN1,ASIN2,ASIN3" 或分三列
                    if val:
                        row[h] = [a.strip() for a in val.split(",")]
                    else:
                        # 尝试合并三列
                        asins = []
                        for j in range(3):
                            col = f"top{j+1}_asin"
                            if col in headers:
                                idx = headers.index(col)
                                if idx < len(raw_row) and raw_row[idx].strip():
                                    asins.append(raw_row[idx].strip())
                        row[h] = asins if asins else []
                else:
                    row[h] = val

        if row.get("term"):
            rows.append(row)

    return ok(data={
        "rows": rows,
        "week": week or path.stem,
        "path": str(path),
        "row_count": len(rows),
    })


def _map_header(raw: str) -> str:
    """表头标准化映射"""
    key = raw.lower().strip().rstrip(":")
    return HEADER_MAP.get(key, key.lower().replace(" ", "_").replace("#", ""))
