"""
SIF API 适配器：关键词流量漏斗 + 广告成本数据。

认证：~/.sif_token（JWT，Header + Cookie）。
API：https://www.sif.com/api/search/keywordFunnel/list
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from amz.config import config
from amz.envelope import Result, ok, err, Code
from amz.data.sources.base import DataSource


class SifApi(DataSource):
    """SIF 关键词流量漏斗 API"""

    source_name = "sif"

    SLUG = "sif-keyword-funnel"
    TTL_HOURS = 24 * 14  # 14 天
    API_URL = "https://www.sif.com/api/search/keywordFunnel/list"

    def _get_token(self) -> str:
        """读取 ~/.sif_token"""
        token_file = config.sif_token_file
        if not token_file.exists():
            raise FileNotFoundError(f"SIF token file not found: {token_file}")
        return token_file.read_text().strip()

    def _call_endpoint(self, endpoint_id: str, params: dict) -> dict:
        """不适用于 SIF（有独立调用流程）"""
        raise NotImplementedError

    def keyword_funnel(self, keywords: list[str]) -> Result:
        """查询关键词流量漏斗

        Returns:
            Result.data = {keywords: [{term, searchVolume, clickCount, orderCount, ppc, cpa, acos}]}
        """
        if not keywords:
            return err(Code.ERROR_PARAM, "keywords is required")

        cache_key = "+".join(_safe_cache(k) for k in keywords)

        # 读缓存
        cached = self._read_cache(self.SLUG, cache_key, self.TTL_HOURS)
        if cached is not None:
            return self.normalize_response(cached, self.SLUG, from_cache=True)

        # 获取 token
        try:
            token = self._get_token()
        except FileNotFoundError as e:
            return err(Code.ERROR_AUTH, str(e))

        ts = str(int(time.time() * 1000))
        url = f"{self.API_URL}?country=US&_t={ts}&_m=Sif_12cd-563b-405e-b473-f4d2"

        headers = {
            "Authorization": token,
            "Cookie": f"sif_token={token}",
            "Content-Type": "application/json",
        }

        body = {
            "pageSize": 100,
            "pageNum": 1,
            "sortBy": "",
            "customPrice": "",
            "customProfitRate": "",
            "desc": True,
            "strategy": "legacyForSales_exact",
            "matchTypes": [],
            "keywords": keywords,
        }

        # HTTP POST
        import urllib.request
        import urllib.error

        try:
            req = urllib.request.Request(
                url,
                data=json.dumps(body).encode("utf-8"),
                headers=headers,
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=15) as resp:
                result = json.loads(resp.read().decode())
        except Exception as e:
            return err(Code.ERROR_UPSTREAM, f"SIF API error: {e}")

        if result.get("code") != 1:
            return err(
                Code.ERROR_UPSTREAM,
                f"SIF API returned code={result.get('code')}: {result.get('msg', '')}",
            )

        data = result.get("data", result)

        # 精简：只保留第一个 keyword 的数据
        if "keywords" in data and isinstance(data["keywords"], list) and len(data["keywords"]) > 1:
            data["keywords"] = data["keywords"][:1]

        self._write_cache(self.SLUG, cache_key, self.TTL_HOURS, data)
        return self.normalize_response(data, self.SLUG)


def _safe_cache(keyword: str) -> str:
    key = keyword.lower().replace(" ", "_")
    for ch in ("/", "\\", ":"):
        key = key.replace(ch, "_")
    return key
