"""
测试用 Mock 数据源：支持从 tests/fixtures/ 目录加载 JSON fixture，或使用内联静态数据。

优先级：fixture 文件 > 内联静态数据

用于单元测试与离线开发。
"""

from __future__ import annotations

import json
from pathlib import Path

from amz.envelope import Result, ok


# 默认 fixtures 目录
def _default_fixtures_dir() -> Path:
    import os
    env = os.environ.get("AMZ_TEST_FIXTURES")
    if env:
        return Path(env)
    current = Path(__file__).resolve().parent.parent.parent.parent
    candidate = current / "tests" / "fixtures"
    if candidate.exists():
        return candidate
    cwd = Path.cwd() / "tests" / "fixtures"
    if cwd.exists():
        return cwd
    return candidate


# ============================================================================
# 内联静态数据（fallback，当 fixtures 目录无对应文件时使用）
# ============================================================================

MOCK_PRODUCT_INFO = {
    "asin": "B0XXXXX",
    "title": "Sample Product Title - Premium Quality",
    "brand": "SampleBrand",
    "price": "$23.99",
    "rating": 4.5,
    "countReview": 1234,
    "bulletPoints": [
        "Premium quality material for long-lasting durability",
        "Ergonomic design for comfortable daily use",
        "Easy to clean and maintain",
        "Multi-purpose functionality for versatile applications",
        "Satisfaction guaranteed with 30-day return policy",
    ],
    "images": [
        "https://example.com/images/main.jpg",
        "https://example.com/images/back.jpg",
    ],
    "description": "This is a sample product description for testing purposes.",
    "variations": [
        {"asin": "B0XXXXY", "price": "$19.99", "title": "Small Size"},
        {"asin": "B0XXXXZ", "price": "$29.99", "title": "Large Size"},
    ],
    "categories": ["Home & Kitchen", "Kitchen & Dining", "Kitchen Gadgets"],
    "listingDate": "2024-03-15",
    "dimensions": "10.5 x 7.3 x 2.1 inches",
    "weight": "1.2 kg",
}

MOCK_COMPETING_ITEMS = [
    {"asin": "B0COMP1", "title": "Competitor Product A", "price": "$19.99",
     "totalUnits": 456, "rating": 4.2, "reviews": 890, "availableDate": "2023-06-15",
     "brand": "BrandA", "sellerNation": "CN", "fbaFee": "$4.50"},
    {"asin": "B0COMP2", "title": "Competitor Product B", "price": "$25.99",
     "totalUnits": 1200, "rating": 4.6, "reviews": 2340, "availableDate": "2022-01-10",
     "brand": "BrandB", "sellerNation": "US", "fbaFee": "$5.00"},
    {"asin": "B0COMP3", "title": "Competitor Product C", "price": "$15.50",
     "totalUnits": 320, "rating": 3.9, "reviews": 450, "availableDate": "2024-01-20",
     "brand": "BrandA", "sellerNation": "CN", "fbaFee": "$3.80"},
    {"asin": "B0COMP4", "title": "Competitor Product D", "price": "$35.00",
     "totalUnits": 890, "rating": 4.4, "reviews": 1560, "availableDate": "2023-09-01",
     "brand": "BrandC", "sellerNation": "US", "fbaFee": "$6.00"},
    {"asin": "B0COMP5", "title": "Competitor Product E", "price": "$22.00",
     "totalUnits": 670, "rating": 4.1, "reviews": 780, "availableDate": "2023-11-15",
     "brand": "BrandD", "sellerNation": "CN", "fbaFee": "$4.80"},
]

MOCK_REVIEWS = [
    {"reviewId": "R1", "rating": 5, "title": "Excellent product!",
     "text": "Love this product, great quality.", "date": "2024-06-15",
     "verified": True, "userName": "User1"},
    {"reviewId": "R2", "rating": 4, "title": "Good value",
     "text": "Works well, good for the price.", "date": "2024-05-20",
     "verified": True, "userName": "User2"},
    {"reviewId": "R3", "rating": 2, "title": "Disappointed",
     "text": "Broke after a week. Poor quality.", "date": "2024-04-10",
     "verified": True, "userName": "User3"},
    {"reviewId": "R4", "rating": 5, "title": "Best purchase ever",
     "text": "Exactly what I needed. Highly recommend.", "date": "2024-06-01",
     "verified": True, "userName": "User4"},
    {"reviewId": "R5", "rating": 1, "title": "Terrible",
     "text": "Completely different from description. Returning.", "date": "2024-03-25",
     "verified": False, "userName": "User5"},
]

MOCK_KEYWORD_ITEMS = [
    {"term": "sample keyword 1", "searchVolume": 15000, "ppc": 1.2,
     "clickRate": "52%", "conversionRate": "8.5%",
     "topAsins": ["B0XXXX1", "B0XXXX2", "B0XXXX3"]},
    {"term": "sample keyword 2", "searchVolume": 8500, "ppc": 0.8,
     "clickRate": "45%", "conversionRate": "6.2%",
     "topAsins": ["B0XXXX4", "B0XXXX5", "B0XXXX6"]},
    {"term": "sample keyword 3", "searchVolume": 32000, "ppc": 2.1,
     "clickRate": "60%", "conversionRate": "12.1%",
     "topAsins": ["B0XXXX7", "B0XXXX8", "B0XXXX9"]},
]

MOCK_1688_RESULTS = [
    {"title": "Supplier A - Premium Quality", "price": "15.50", "sales": 5000,
     "similarity": 85.5, "imageUrl": "https://example.com/1688/img1.jpg",
     "url": "https://detail.1688.com/offer/xxx.html"},
    {"title": "Supplier B - Factory Direct", "price": "12.80", "sales": 12000,
     "similarity": 78.2, "imageUrl": "https://example.com/1688/img2.jpg",
     "url": "https://detail.1688.com/offer/yyy.html"},
    {"title": "Supplier C - OEM Available", "price": "18.00", "sales": 3000,
     "similarity": 72.0, "imageUrl": "https://example.com/1688/img3.jpg",
     "url": "https://detail.1688.com/offer/zzz.html"},
]


# ============================================================================
# MockDataSource
# ============================================================================

class MockDataSource:
    """Mock 数据源（测试/离线开发用）

    数据加载优先级:
    1. tests/fixtures/{endpoint}/{key}.json (真实抓取数据)
    2. 内联 MOCK_* 静态数据
    """

    source_name = "mock"

    def __init__(self, fixtures_dir: str | Path | None = None):
        if fixtures_dir:
            self._fixtures_dir = Path(fixtures_dir)
        else:
            self._fixtures_dir = _default_fixtures_dir()

    # ------------------------------------------------------------------
    # fixture 文件加载
    # ------------------------------------------------------------------

    def _load_fixture(self, endpoint: str, key: str) -> dict | None:
        path = self._fixtures_dir / endpoint / f"{key}.json"
        if path.exists():
            return json.loads(path.read_text())
        return None

    # ------------------------------------------------------------------
    # 端点方法
    # ------------------------------------------------------------------

    def product_info(self, asin: str) -> Result:
        data = self._load_fixture("product", asin)
        if data:
            return ok(data=data, upstream="mock")
        data = dict(MOCK_PRODUCT_INFO)
        data["asin"] = asin
        return ok(data=data, upstream="mock")

    def reviews(self, asin: str, star_filter: str = "all", max_pages: int = 1, domain_code: str = "com") -> Result:
        data = self._load_fixture("reviews", asin)
        if data:
            return ok(data=data, upstream="mock")
        return ok(data={"asin": asin, "items": MOCK_REVIEWS, "count_ratings": len(MOCK_REVIEWS)}, upstream="mock")

    def competing_lookup(self, **kwargs) -> Result:
        asin = kwargs.get("asin", "")
        if isinstance(asin, list):
            asin = asin[0] if asin else ""
        data = self._load_fixture("competing", asin)
        if data:
            return ok(data=data, upstream="mock")
        return ok(data={"items": MOCK_COMPETING_ITEMS}, upstream="mock")

    def keyword_reverse(self, asin: str) -> Result:
        data = self._load_fixture("keyword_reverse", asin)
        if data:
            return ok(data=data, upstream="mock")
        return ok(data={"asin": asin, "items": MOCK_KEYWORD_ITEMS}, upstream="mock")

    def keyword_miner(self, keyword: str, history_date: str | None = None) -> Result:
        data = self._load_fixture("keyword_miner", keyword)
        if data:
            if isinstance(data, dict) and keyword in data:
                return ok(data=data[keyword], upstream="mock")
            return ok(data=data, upstream="mock")
        return ok(data={"keyword": keyword, "items": MOCK_KEYWORD_ITEMS}, upstream="mock")

    def market_research(self, keyword: str) -> Result:
        data = self._load_fixture("market_research", keyword)
        if data:
            if isinstance(data, dict) and keyword in data:
                return ok(data=data[keyword], upstream="mock")
            return ok(data=data, upstream="mock")
        return self.competing_lookup(keyword=keyword)

    def product_search_1688(self, asin: str, image_url: str) -> Result:
        data = self._load_fixture("supply_1688", asin)
        if data:
            return ok(data=data, upstream="mock")
        return ok(data={"asin": asin, "results": MOCK_1688_RESULTS}, upstream="mock")

    def amazon_search(self, keyword: str) -> Result:
        data = self._load_fixture("search", keyword)
        if data:
            return ok(data=data, upstream="mock")
        return ok(data={"keyword": keyword, "items": []}, upstream="mock")

    def rufus(self, asin: str) -> Result:
        data = self._load_fixture("rufus", asin)
        if data:
            return ok(data=data, upstream="mock")
        return ok(data={"asin": asin, "questions": []}, upstream="mock")

    def trends(self, keyword: str) -> Result:
        data = self._load_fixture("trends", keyword)
        if data:
            if isinstance(data, dict) and keyword in data:
                return ok(data=data[keyword], upstream="mock")
            return ok(data=data, upstream="mock")
        return ok(data={"keyword": keyword, "trends": []}, upstream="mock")
