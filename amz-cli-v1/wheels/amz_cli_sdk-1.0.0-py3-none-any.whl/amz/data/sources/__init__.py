"""
数据源适配器 — 封装不同上游 API 的实现差异。

每个适配器继承 DataSource 基类，统一提供：
- 缓存（文件 + TTL）
- 响应归一化（上游 camelCase → SDK 标准字段）
- HTTP 错误映射（状态码 → Code 枚举）

适配器清单
----------

============= ==============================================
适配器        说明
============= ==============================================
base          DataSource 抽象基类：缓存 + 归一化 + HTTP 错误映射
amz_api       AmzDataApi — 15 端点，SDK 主数据源
sif           SifApi — SIF 流量漏斗（~/.sif_token 认证）
aba_file      AbaFile — ABA CSV 本地文件读取（中英文表头兼容）
mock          MockDataSource — 测试用静态数据
============= ==============================================

用法::

    from amz.data.sources.amz_api import AmzDataApi
    api = AmzDataApi()
    result = api.get_product_info("B0XXXX")
"""
