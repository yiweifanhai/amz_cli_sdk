"""
Supply 数据获取：1688 图搜。
"""

from __future__ import annotations

from amz.envelope import Result
from amz.registry import capability
from amz.data.sources.amz_api import AmzDataApi
from amz.schemas.data_outputs import SupplySearchOutput


_api: AmzDataApi | None = None


def _get_api() -> AmzDataApi:
    global _api
    if _api is None:
        _api = AmzDataApi()
    return _api


@capability("supply.search-1688", description="通过图片 URL 搜索 1688 供应商（Top50 相似度排序）", output_model=SupplySearchOutput)
def supply_search_1688(asin: str, image_url: str) -> Result:
    """supply.search-1688 — 1688 图搜

    Args:
        asin: ASIN（用于缓存 key）
        image_url: Amazon 主图链接
    """
    return _get_api().product_search_1688(asin, image_url)
