"""
Finance 结果模型与整合函数。

``FinanceData`` 是挂在 Product 上的财务计算结果模型，定义在 entities 层
（结果模型属于实体状态，不放在 calc 纯函数层）。

``build_finance`` 是整合辅助：接收字段值，编排 ``calc.fba.margin`` 与
``calc.finance.return-on-capital`` 两个纯函数，合并为 ``FinanceData``。
它本身无副作用（不 fetch / 不回填 / 不写缓存）——fetch → enrich → 回填
仍由 ``Product.get_finance()`` 收敛（副作用边界只有 entities 的 get_xxx）。

分层利润体系
--------------
M1 = (price - FBA - 头程 - 佣金) / price
      平台费用后利润率，不含采购成本和广告。
      用于快速判断类目费用结构是否健康。

M2 = (price - FBA - 头程 - 佣金 - CPA) / price
      平台+广告后利润率，不含采购成本。
      CPA = CPC / CVR，CPC 来自关键词 exactPpc 均值，CVR 来自 purchases/clicks。
      用于判断广告投放后的盈利空间。

采购毛利率 = (price - FBA - 头程 - 佣金 - 采购价) / price  ← gross_margin_pct

使用示例
--------
from amz.entities.product import Product

p = Product.fetch("B0XXXX")
p.get_finance(shipping_method="fast", cpc=1.5, cvr=0.1)
"""

from __future__ import annotations

from datetime import date, datetime
from typing import Any

from pydantic import BaseModel, Field

from amz.calc.margin import CNY_PER_USD


class FinanceData(BaseModel):
    """利润和资金效率计算结果。"""

    selling_price: float | None = None
    referral_fee: float | None = None
    fba_fee: float | None = None
    shipping_cost: float | None = None
    purchase_price: float | None = None
    total_cost: float | None = None
    gross_profit: float | None = None
    gross_margin_pct: float | None = None
    break_even_price: float | None = None
    m1_margin_pct: float | None = None
    m2_margin_pct: float | None = None
    cpc: float | None = None
    cvr: float | None = None
    cpa: float | None = None
    roi_pct: float | None = None
    daily_return_pct: float | None = None
    capital_per_unit: float | None = None
    profit_per_unit: float | None = None
    assumptions: dict = Field(default_factory=dict)


def build_finance(
    selling_price: float | None,
    weight_g: float | None,
    dimensions_cm: dict[str, Any] | None,
    shipping_method: str = "fast",
    purchase_price: float | None = None,
    cpc: float | None = None,
    cvr: float | None = None,
    product_type: str | None = None,
    fulfillment_date: date | datetime | str | None = None,
    include_fuel_surcharge: bool = True,
    exchange_rate: float = CNY_PER_USD,
) -> FinanceData:
    """整合 ``calc.fba.margin`` + ``calc.finance.return-on-capital`` → FinanceData。

    纯整合：接收字段值（不依赖 Product 对象），编排两个 calc 纯函数并合并为
    类型化结果。不 fetch、不回填、不写缓存——这些由 ``Product.get_finance()`` 负责。

    Args:
        selling_price: 售价（$）
        weight_g: 包装重量（g）
        dimensions_cm: 包装尺寸 dict {length, width, height}（cm）
        shipping_method: 头程方式 slow/fast/air/express
        purchase_price: 采购价（$）
        cpc / cvr: 广告指标，用于 M2
        product_type: non_apparel/apparel/dangerous_goods
        fulfillment_date: FBA 出库日期
        include_fuel_surcharge: 是否计入燃油附加费
        exchange_rate: 人民币兑美元汇率

    Returns:
        FinanceData 实例 — 类型化的全量财务指标
    """
    from amz.calc.finance import calculate_return_on_capital
    from amz.calc.margin import calculate_margin

    price = selling_price or 0
    dims = dimensions_cm or {}
    margin_result = calculate_margin(
        selling_price=price,
        pkg_weight_g=weight_g or 0,
        pkg_dims_cm=(
            dims.get("length", 0),
            dims.get("width", 0),
            dims.get("height", 0),
        ) if dims else None,
        shipping_method=shipping_method,
        purchase_price=purchase_price,
        cpc=cpc,
        cvr=cvr,
        product_type=product_type,
        fulfillment_date=fulfillment_date,
        include_fuel_surcharge=include_fuel_surcharge,
        exchange_rate=exchange_rate,
    )

    roi_result = calculate_return_on_capital(
        selling_price=price,
        unit_cost=margin_result["purchase_price"],
        shipping_method=shipping_method,
        weight_g=weight_g,
        platform_cost=margin_result["referral_fee"] + margin_result["fba_fee"],
        exchange_rate=exchange_rate,
    )

    # margin_result 和 roi_result 共享 shipping_cost，合并时去重
    merged = {**margin_result, **roi_result}
    return FinanceData(
        selling_price=price,
        **merged,
        assumptions={
            "shipping_method": shipping_method,
            "product_type": product_type or "non_apparel",
            "fulfillment_date": (
                fulfillment_date.isoformat()
                if isinstance(fulfillment_date, (date, datetime))
                else fulfillment_date
            ),
            "include_fuel_surcharge": include_fuel_surcharge,
            "exchange_rate": exchange_rate,
        },
    )
