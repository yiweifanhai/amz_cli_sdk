"""Supplier 数据模型"""

from pydantic import BaseModel


class Supplier(BaseModel):
    """1688 供应商"""
    title: str = ""
    price: str = ""
    sales: int | str = 0
    similarity: float = 0.0
    image_url: str = ""
    url: str = ""
