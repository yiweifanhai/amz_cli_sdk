"""LLM 分析结果数据模型"""

from pydantic import BaseModel, Field


class Assessment(BaseModel):
    """单点 LLM 判断结果"""
    kind: str = ""              # 评估类型（risk/innovation/timing/demand）
    score: float = 0.0          # 0-10 或 0-100
    stop: bool = False          # 是否为硬阻
    verdict: str = ""           # GO/CAUTION/STOP
    dimensions: dict = Field(default_factory=dict)
    data: dict = Field(default_factory=dict)
