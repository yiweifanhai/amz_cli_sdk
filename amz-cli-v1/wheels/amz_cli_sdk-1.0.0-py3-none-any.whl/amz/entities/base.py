"""
Entity 基类：Pydantic v2 模型 + lazy 字段声明、enrich 调度、逐字段 TTL 缓存。

所有 lazy getter 都通过 ``@lazy_field`` 进入同一条解析链路，保证直接调用
``get_xxx()`` 与 ``entity.enrich("xxx")`` 具有相同的 TTL、依赖和 single-flight
语义。
"""

from __future__ import annotations

import hashlib
import inspect
import json
import os
import tempfile
import threading
import weakref
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path
from typing import Any, Callable, ClassVar

from pydantic import BaseModel, ConfigDict, PrivateAttr
from pydantic_core import PydanticUndefined

from amz.config import config
from amz.envelope import AmzError, Code, Result, err, ok


ENTITY_CACHE_SCHEMA = "amz.entity.v2"


class EnrichSpec:
    """Lazy 字段声明。"""

    def __init__(
        self,
        field: str,
        method: str,
        depends: list[str],
        source: str,
        ttl_hours: int = 24,
        version: str = "1",
        optional_depends: list[str] | None = None,
        invalidates_on: list[str] | None = None,
        dependency_params: dict[str, list[str]] | None = None,
    ):
        self.field = field
        self.method = method
        self.depends = depends
        self.optional_depends = optional_depends or []
        self.invalidates_on = invalidates_on or []
        self.dependency_params = dependency_params or {}
        self.source = source
        self.ttl_hours = ttl_hours
        self.version = version

    @property
    def invalidation_dependencies(self) -> tuple[str, ...]:
        """All fields whose refresh makes this derived value stale."""
        return tuple(dict.fromkeys([
            *self.depends,
            *self.optional_depends,
            *self.invalidates_on,
        ]))


def lazy_field(field: str):
    """把实体 getter 接入统一 lazy resolver。"""

    def decorator(loader: Callable[..., Result]):
        @wraps(loader)
        def wrapper(self: "Entity", *args, **kwargs) -> Result:
            return self._resolve_lazy(field, loader, args, kwargs)

        wrapper.__entity_lazy_field__ = field
        wrapper.__entity_loader__ = loader
        return wrapper

    return decorator


class Entity(BaseModel):
    """Pydantic 模型与领域聚合根的统一基类。"""

    model_config = ConfigDict(
        validate_assignment=True,
        extra="ignore",
        arbitrary_types_allowed=True,
    )

    entity_type: ClassVar[str] = "entity"
    identity_fields: ClassVar[tuple[str, ...]] = ()
    lazy_fields: ClassVar[dict[str, EnrichSpec]] = {}

    _cache_id: str = PrivateAttr(default="")
    _fetched_at: dict[str, str] = PrivateAttr(default_factory=dict)
    _fetch_keys: dict[str, str] = PrivateAttr(default_factory=dict)
    _result_data: dict[str, Any] = PrivateAttr(default_factory=dict)
    _active_fetch_keys: dict[str, str] = PrivateAttr(default_factory=dict)

    _inflight: ClassVar[dict[str, threading.Event]] = {}
    _inflight_lock: ClassVar[threading.Lock] = threading.Lock()
    _save_locks: ClassVar[dict[str, threading.Lock]] = {}
    _save_locks_guard: ClassVar[threading.Lock] = threading.Lock()
    _identity_map: ClassVar[weakref.WeakValueDictionary] = weakref.WeakValueDictionary()
    _identity_lock: ClassVar[threading.RLock] = threading.RLock()
    _resolve_local: ClassVar[threading.local] = threading.local()

    @classmethod
    def __pydantic_init_subclass__(cls, **kwargs: Any) -> None:
        """Validate the lazy dependency graph once the Pydantic model is ready."""
        super().__pydantic_init_subclass__(**kwargs)
        cls._validate_lazy_specs()

    @classmethod
    def _validate_lazy_specs(cls) -> None:
        """Fail fast for broken lazy declarations instead of at first production call."""
        known_fields = set(cls.model_fields) | set(cls.lazy_fields)
        for identity in cls.identity_fields:
            if identity not in cls.model_fields:
                raise TypeError(
                    f"{cls.__name__}.identity_fields references unknown field '{identity}'"
                )

        graph: dict[str, list[str]] = {}
        for field, spec in cls.lazy_fields.items():
            if spec.field != field:
                raise TypeError(
                    f"{cls.__name__}.lazy_fields['{field}'] declares field "
                    f"'{spec.field}'"
                )

            method = getattr(cls, spec.method, None)
            if method is None:
                raise TypeError(
                    f"{cls.__name__}.{spec.method} is required by lazy field '{field}'"
                )
            if getattr(method, "__entity_lazy_field__", None) != field:
                raise TypeError(
                    f"{cls.__name__}.{spec.method} must use @lazy_field('{field}')"
                )

            dependencies = [*spec.depends, *spec.optional_depends, *spec.invalidates_on]
            unknown = sorted(set(dependencies) - known_fields)
            if unknown:
                raise TypeError(
                    f"{cls.__name__}.{field} references unknown dependencies: {unknown}"
                )

            enrich_dependencies = [*spec.depends, *spec.optional_depends]
            unknown_parameter_targets = sorted(
                set(spec.dependency_params) - set(enrich_dependencies)
            )
            if unknown_parameter_targets:
                raise TypeError(
                    f"{cls.__name__}.{field} forwards parameters to non-enriched "
                    f"dependencies: {unknown_parameter_targets}"
                )
            graph[field] = [dep for dep in enrich_dependencies if dep in cls.lazy_fields]
            for dependency in graph[field]:
                dependency_spec = cls.lazy_fields[dependency]
                dependency_method = getattr(cls, dependency_spec.method)
                loader = (
                    getattr(dependency_method, "__entity_loader__", None)
                    or dependency_method
                )
                forwarded = set(spec.dependency_params.get(dependency, []))
                required = [
                    name
                    for name, parameter in inspect.signature(loader).parameters.items()
                    if name != "self"
                    and parameter.kind
                    not in {
                        inspect.Parameter.VAR_POSITIONAL,
                        inspect.Parameter.VAR_KEYWORD,
                    }
                    and parameter.default is inspect.Parameter.empty
                    and name not in forwarded
                ]
                if required:
                    raise TypeError(
                        f"{cls.__name__}.{field} cannot auto-enrich '{dependency}'; "
                        f"{dependency_spec.method} requires arguments {required}"
                    )
                target_loader = getattr(method, "__entity_loader__", None) or method
                target_parameters = set(inspect.signature(target_loader).parameters) - {"self"}
                dependency_parameters = set(inspect.signature(loader).parameters) - {"self"}
                missing_from_target = sorted(forwarded - target_parameters)
                missing_from_dependency = sorted(forwarded - dependency_parameters)
                if missing_from_target or missing_from_dependency:
                    raise TypeError(
                        f"{cls.__name__}.{field} has invalid parameter forwarding for "
                        f"'{dependency}': target_missing={missing_from_target}, "
                        f"dependency_missing={missing_from_dependency}"
                    )

        visiting: set[str] = set()
        visited: set[str] = set()

        def visit(field: str, path: list[str]) -> None:
            if field in visiting:
                start = path.index(field)
                cycle = " -> ".join([*path[start:], field])
                raise TypeError(f"{cls.__name__} has cyclic lazy dependencies: {cycle}")
            if field in visited:
                return
            visiting.add(field)
            path.append(field)
            for dependency in graph.get(field, []):
                visit(dependency, path)
            path.pop()
            visiting.remove(field)
            visited.add(field)

        for field in graph:
            visit(field, [])

    def model_post_init(self, __context: Any) -> None:
        if not self._cache_id and self.identity_fields:
            values = [getattr(self, name, None) for name in self.identity_fields]
            if any(value not in (None, "") for value in values):
                self._cache_id = self.compose_cache_id(*values)

        # 显式传入的 lazy 值视为已填充，便于用已有数据构造只读实体。
        for field in self.lazy_fields:
            if field in self.model_fields_set and getattr(self, field, None) is not None:
                self._fetched_at[field] = _utc_now()
                default_key = self._default_field_cache_key(field)
                if default_key:
                    self._fetch_keys[field] = default_key

        self._remember()

    # ------------------------------------------------------------------
    # 实体身份与缓存持久化
    # ------------------------------------------------------------------

    @staticmethod
    def compose_cache_id(*parts: Any) -> str:
        normalized = ["" if part is None else str(part) for part in parts]
        if len(normalized) == 1:
            return normalized[0]
        return json.dumps(normalized, ensure_ascii=False, separators=(",", ":"))

    @classmethod
    def cache_id_for(cls, **values: Any) -> str:
        return cls.compose_cache_id(*(values.get(name) for name in cls.identity_fields))

    def project_to(self, input_cls: type[Any]) -> dict | None:
        """按 input_model 的投影元数据从本实体构造输入 dict（只读）。

        供 composite autowire 使用：把聚合根投影成某个能力的 InputModel，
        **绝不触发 enrich** —— 必填字段取不到就返回 None（调用方决定报错
        还是先补齐依赖）；可选字段取不到则跳过，留给 params / 默认值。

        Args:
            input_cls: 能力的 input_model（Pydantic 模型类）。

        Returns:
            投影输入 dict；不可投影时返回 None。
        """
        from amz.schemas.projection import project

        return project(self, input_cls)

    def _remember(self) -> None:
        if not self._cache_id:
            return
        key = (str(config.cache_dir), type(self), self._cache_id)
        with self._identity_lock:
            self._identity_map[key] = self

    @classmethod
    def _live(cls, cache_id: str) -> "Entity | None":
        with cls._identity_lock:
            return cls._identity_map.get((str(config.cache_dir), cls, cache_id))

    @classmethod
    def _cache_file(cls, cache_id: str) -> Path:
        entity_dir = config.cache_dir / "entities" / cls.entity_type
        entity_dir.mkdir(parents=True, exist_ok=True)
        digest = hashlib.sha256(cache_id.encode("utf-8")).hexdigest()
        return entity_dir / f"{digest}.json"

    @classmethod
    def _legacy_cache_file(cls, cache_id: str) -> Path | None:
        # 只兼容读取不会逃逸目录的旧文件名。
        if not cache_id or cache_id in {".", ".."}:
            return None
        if Path(cache_id).name != cache_id or "/" in cache_id or "\\" in cache_id:
            return None
        return config.cache_dir / "entities" / cls.entity_type / f"{cache_id}.json"

    def _entity_cache_path(self) -> Path:
        if not self._cache_id:
            raise ValueError(f"{self.entity_type} entity has no cache identity")
        return type(self)._cache_file(self._cache_id)

    def save(self) -> None:
        """原子持久化实体及嵌套实体的缓存元数据。"""
        path = self._entity_cache_path()
        payload = {
            "schema": ENTITY_CACHE_SCHEMA,
            "entity_type": self.entity_type,
            "cache_id": self._cache_id,
            "saved_at": _utc_now(),
            "fetched_at": dict(self._fetched_at),
            "fetch_keys": dict(self._fetch_keys),
            "result_data": _serialize_value(self._result_data),
            "fields": {
                name: _serialize_value(getattr(self, name))
                for name in type(self).model_fields
            },
        }

        lock = self._save_lock(path)
        temp_path: Path | None = None
        with lock:
            try:
                with tempfile.NamedTemporaryFile(
                    mode="w",
                    encoding="utf-8",
                    dir=path.parent,
                    prefix=f".{path.name}.",
                    suffix=".tmp",
                    delete=False,
                ) as handle:
                    json.dump(payload, handle, ensure_ascii=False, default=str)
                    handle.flush()
                    os.fsync(handle.fileno())
                    temp_path = Path(handle.name)
                os.replace(temp_path, path)
                temp_path = None
            finally:
                if temp_path is not None:
                    temp_path.unlink(missing_ok=True)
        self._remember()
        self._record_in_runtime()

    def _record_in_runtime(self) -> None:
        """若当前上下文有 Runtime，把实体缓存文件登记到任务 manifest（失败不影响保存）。"""
        from amz.infra.runtime import get_current

        rt = get_current()
        if rt is None:
            return
        try:
            path = self._entity_cache_path()
            try:
                rel = path.relative_to(config.cache_dir)
            except ValueError:
                rel = path
            rt.record(
                kind="entity",
                name=f"{self.entity_type}:{self._cache_id}",
                rel_path=str(rel),
                schema=ENTITY_CACHE_SCHEMA,
            )
        except Exception:
            pass

    @classmethod
    def _save_lock(cls, path: Path) -> threading.Lock:
        key = str(path)
        with cls._save_locks_guard:
            return cls._save_locks.setdefault(key, threading.Lock())

    @classmethod
    def load(cls, cache_id: str, *, use_identity: bool = True) -> "Entity | None":
        if use_identity:
            live = cls._live(cache_id)
            if live is not None:
                return live

        candidates = [cls._cache_file(cache_id)]
        legacy = cls._legacy_cache_file(cache_id)
        if legacy is not None and legacy != candidates[0]:
            candidates.append(legacy)

        path = next((candidate for candidate in candidates if candidate.exists()), None)
        if path is None:
            return None

        try:
            data = json.loads(path.read_text())
            fields = _deserialize_value(data.get("fields", {}))
            instance = cls.model_validate(fields)
            instance._cache_id = data.get("cache_id") or cache_id
            instance._fetched_at = dict(data.get("fetched_at", {}))
            instance._fetch_keys = dict(data.get("fetch_keys", {}))
            instance._result_data = _deserialize_value(data.get("result_data", {}))
            instance._backfill_fetch_keys()
            instance._remember()
            return instance
        except (OSError, json.JSONDecodeError, KeyError, TypeError, ValueError):
            return None

    def _copy_state_from(self, other: "Entity") -> None:
        for name in type(self).model_fields:
            setattr(self, name, getattr(other, name))
        self._cache_id = other._cache_id
        self._fetched_at = dict(other._fetched_at)
        self._fetch_keys = dict(other._fetch_keys)
        self._result_data = dict(other._result_data)
        self._remember()

    # ------------------------------------------------------------------
    # TTL、依赖和失效传播
    # ------------------------------------------------------------------

    def _check_field(self, field: str, fetch_key: str | None = None) -> bool:
        spec = self.lazy_fields.get(field)
        field_declared = field in type(self).model_fields
        value = getattr(self, field, None) if field_declared else None

        if field_declared and value is None:
            return False
        if spec is None:
            return field_declared and value is not None

        # 虚拟 lazy 字段没有模型属性，以时间戳作为已填充标记。
        if field not in self._fetched_at:
            return False
        if fetch_key is not None and self._fetch_keys.get(field) != fetch_key:
            return False

        try:
            fetched_at = datetime.fromisoformat(
                self._fetched_at[field].replace("Z", "+00:00")
            )
            if (datetime.now(timezone.utc) - fetched_at).total_seconds() > spec.ttl_hours * 3600:
                return False
        except (ValueError, KeyError, TypeError):
            return False

        # 嵌套实体若已有字段过期，父字段也视为过期。
        if isinstance(value, Entity):
            for child_field in value._fetched_at:
                if child_field in value.lazy_fields:
                    child_key = value._fetch_keys.get(child_field)
                    if not value._check_field(child_field, child_key):
                        return False
        return True

    def _check_depends(self, depends: list[str]) -> list[str]:
        return [field for field in depends if not self._check_field(field)]

    def _mark_fetched(self, field: str, fetch_key: str | None = None) -> None:
        self._invalidate_dependents(field)
        self._fetched_at[field] = _utc_now()
        key = fetch_key or self._active_fetch_keys.get(field)
        if key is None and field in self.lazy_fields:
            key = self._default_field_cache_key(field)
        if key is not None:
            self._fetch_keys[field] = key

    def _writeback(self, field: str, value: Any) -> None:
        if field not in type(self).model_fields:
            raise ValueError(f"unknown entity field: {field}")
        setattr(self, field, value)
        self._mark_fetched(field)
        self.save()

    def invalidate(self, field: str | None = None) -> None:
        targets = [field] if field else list(self.lazy_fields)
        for target in targets:
            self._invalidate_field(target)
        self.save()

    def _invalidate_dependents(self, field: str, visited: set[str] | None = None) -> None:
        visited = visited or set()
        if field in visited:
            return
        visited.add(field)
        for child, spec in self.lazy_fields.items():
            if field in spec.invalidation_dependencies:
                self._invalidate_field(child)
                self._invalidate_dependents(child, visited)

    def _invalidate_field(self, field: str) -> None:
        self._fetched_at.pop(field, None)
        self._fetch_keys.pop(field, None)
        self._result_data.pop(field, None)
        field_info = type(self).model_fields.get(field)
        if field_info is None:
            return
        default = field_info.get_default(call_default_factory=True)
        if default is PydanticUndefined:
            default = None
        setattr(self, field, default)

    # ------------------------------------------------------------------
    # 统一 lazy 调度
    # ------------------------------------------------------------------

    def enrich(self, field: str, **kwargs) -> Result:
        spec = self.lazy_fields.get(field)
        if spec is None:
            return err(Code.ERROR_PARAM, f"unknown lazy field: {field}")
        method = getattr(self, spec.method, None)
        if method is None:
            return err(
                Code.ERROR_SERVER_INTERNAL,
                f"method '{spec.method}' not found on {self.entity_type}",
            )
        if getattr(method, "__entity_lazy_field__", None) != field:
            return err(
                Code.ERROR_SERVER_INTERNAL,
                f"method '{spec.method}' must use @lazy_field('{field}')",
            )
        return method(**kwargs)

    def refresh(self, field: str, **kwargs) -> Result:
        """强制刷新一个 lazy 字段并返回该字段的规范值。

        这是 SDK 的显式刷新入口；与直接操作 ``_fetched_at`` 相比，它会同时
        清理参数指纹、缓存结果和下游依赖，然后复用正常的 enrich 调度链。
        """
        if field not in self.lazy_fields:
            return err(Code.ERROR_PARAM, f"unknown lazy field: {field}")
        self.invalidate(field)
        return self.enrich(field, **kwargs)

    def _require_field_value(self, field: str, result: Result) -> Any:
        """Return a populated entity field or raise a Python-facing error.

        Entity getters keep returning :class:`Result` for registry/CLI callers.  Typed
        convenience methods use this helper to expose normal object-oriented return
        values without duplicating error handling in every entity.
        """
        if result.code != Code.OK:
            detail = result.message or result.meta.hint or "lazy enrichment failed"
            raise AmzError(f"{self.entity_type}.{field} [{result.code.value}]: {detail}")

        value = getattr(self, field, None)
        if value is None:
            raise AmzError(
                f"{self.entity_type}.{field} [{Code.ERROR_SERVER_INTERNAL.value}]: "
                "getter succeeded without a populated field"
            )
        return value

    def _resolve_lazy(
        self,
        field: str,
        loader: Callable[..., Result],
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> Result:
        spec = self.lazy_fields.get(field)
        if spec is None:
            return err(Code.ERROR_PARAM, f"unknown lazy field: {field}")

        try:
            fetch_key = self._make_call_key(
                loader, args, kwargs, version=spec.version,
            )
            bound = inspect.signature(loader).bind(self, *args, **kwargs)
            bound.apply_defaults()
            target_params = {
                name: value
                for name, value in bound.arguments.items()
                if name != "self"
            }
        except TypeError as exc:
            return err(Code.ERROR_PARAM, str(exc))

        token = (id(self), field, fetch_key)
        stack = getattr(self._resolve_local, "stack", [])
        if token in stack:
            return err(Code.ERROR_SERVER_INTERNAL, f"cyclic enrich dependency at {field}")
        stack.append(token)
        self._resolve_local.stack = stack

        try:
            # 先检查依赖，再检查目标，保证依赖刷新后能正确失效下游。
            for dependency in spec.depends:
                dependency_kwargs = {
                    name: target_params[name]
                    for name in spec.dependency_params.get(dependency, [])
                    if name in target_params
                }
                dependency_key = self._field_cache_key(
                    dependency, dependency_kwargs,
                ) if dependency in self.lazy_fields else None
                if self._check_field(dependency, dependency_key):
                    continue
                if dependency not in self.lazy_fields:
                    return err(
                        Code.ERROR_UPSTREAM,
                        f"missing fields for {field}: [{dependency}]",
                        missing=[dependency],
                    )
                dependency_result = self.enrich(dependency, **dependency_kwargs)
                if dependency_result.code != Code.OK:
                    return dependency_result

            # 可选依赖只在首次计算时尽力补齐；失败不阻断目标能力。若它曾经
            # 填充但现已过期，则目标结果也必须失效，随后用刷新结果（或无该
            # 可选输入）重新计算。这样既避免缓存不一致，也不会让可选数据源
            # 的失败拖垮主分析。
            target_cached = self._check_field(field, fetch_key)
            for dependency in spec.optional_depends:
                dependency_kwargs = {
                    name: target_params[name]
                    for name in spec.dependency_params.get(dependency, [])
                    if name in target_params
                }
                dependency_key = self._field_cache_key(
                    dependency, dependency_kwargs,
                ) if dependency in self.lazy_fields else None
                if self._check_field(dependency, dependency_key):
                    continue
                was_fetched = (
                    dependency in self._fetched_at
                    or getattr(self, dependency, None) is not None
                )
                if target_cached and not was_fetched:
                    continue
                if was_fetched:
                    self._invalidate_field(field)
                    target_cached = False
                if dependency in self.lazy_fields:
                    self.enrich(dependency, **dependency_kwargs)

            # 只观察、不主动 fetch 的输入（例如已有评论作为 strengths 的补充
            # 证据）过期时同样使目标失效。
            for dependency in spec.invalidates_on:
                if dependency not in self._fetched_at:
                    continue
                dependency_key = (
                    self._default_field_cache_key(dependency)
                    if dependency in self.lazy_fields else None
                )
                if not self._check_field(dependency, dependency_key):
                    self._invalidate_field(field)

            if self._check_field(field, fetch_key):
                return self._cached_result(field, spec)

            flight_key = self._flight_key(field)
            while True:
                flight_state = self._single_flight(flight_key)
                if flight_state == "leader":
                    break
                if flight_state == "timeout":
                    return err(Code.ERROR_UPSTREAM, f"timed out waiting for {field}")
                refreshed = type(self).load(self._cache_id, use_identity=False)
                if refreshed is not None:
                    self._copy_state_from(refreshed)
                if self._check_field(field, fetch_key):
                    return self._cached_result(field, spec, waited=True)
                # 另一组参数刚执行完；重新竞争同一字段的执行权。

            self._active_fetch_keys[field] = fetch_key
            try:
                result = loader(self, *args, **kwargs)
                if not isinstance(result, Result):
                    return err(
                        Code.ERROR_SERVER_INTERNAL,
                        f"{spec.method} returned {type(result).__name__}, expected Result",
                    )
                if result.code != Code.OK:
                    return result
                if not self._check_field(field, fetch_key):
                    return err(
                        Code.ERROR_SERVER_INTERNAL,
                        f"{spec.method} succeeded without writing back '{field}'",
                    )

                # Entity 原子能力的公开契约就是字段声明本身。loader 可以用任意
                # 临时响应完成回填，但调用方永远拿到与 Entity schema 一致的值。
                # 虚拟 lazy 字段（一次回填多个字段）没有模型属性，保留 loader
                # 声明的响应数据。
                if field in type(self).model_fields:
                    canonical_data = _json_value(getattr(self, field))
                else:
                    canonical_data = _json_value(result.data)
                self._result_data[field] = canonical_data
                self.save()
                meta = result.meta.model_copy(deep=True)
                meta.from_cache = False
                meta.upstream = meta.upstream or spec.source
                if field not in meta.enriched:
                    meta.enriched.append(field)
                return result.model_copy(update={"data": canonical_data, "meta": meta})
            except Exception as exc:
                return err(
                    Code.ERROR_SERVER_INTERNAL,
                    f"{self.entity_type}.{spec.method} failed: {exc}",
                )
            finally:
                self._active_fetch_keys.pop(field, None)
                self._single_flight_done(flight_key)
        finally:
            stack.pop()

    def _cached_result(self, field: str, spec: EnrichSpec, waited: bool = False) -> Result:
        # 声明字段始终以当前 Entity 值为准；这也会自动纠正旧缓存中保存的
        # wrapper 响应（例如 {"market": ...}）与字段 schema 不一致的问题。
        if field in type(self).model_fields:
            data = _json_value(getattr(self, field))
        elif field in self._result_data:
            data = _json_value(self._result_data[field])
        else:
            data = {"field": field, "enriched": True}
        result = ok(data=data, from_cache=True, upstream=spec.source)
        if waited:
            result.meta.usage["single_flight_waited"] = True
        return result

    def _make_call_key(
        self,
        loader: Callable[..., Result],
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
        *,
        version: str = "1",
    ) -> str:
        bound = inspect.signature(loader).bind(self, *args, **kwargs)
        bound.apply_defaults()
        params = {
            name: _json_value(value)
            for name, value in bound.arguments.items()
            if name != "self"
        }
        payload = {"version": version, "params": params}
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def _default_field_cache_key(self, field: str) -> str | None:
        return self._field_cache_key(field, {})

    def _field_cache_key(
        self,
        field: str,
        kwargs: dict[str, Any],
    ) -> str | None:
        spec = self.lazy_fields.get(field)
        method = getattr(self, spec.method, None) if spec else None
        loader = getattr(method, "__entity_loader__", None)
        if loader is None:
            return None
        try:
            return self._make_call_key(loader, (), kwargs, version=spec.version)
        except TypeError:
            return None

    def _backfill_fetch_keys(self) -> None:
        for field in self._fetched_at:
            if field not in self._fetch_keys:
                key = self._default_field_cache_key(field)
                if key:
                    self._fetch_keys[field] = key

    def _flight_key(self, field: str) -> str:
        identity = self._cache_id or f"memory:{id(self)}"
        digest = hashlib.sha256(identity.encode("utf-8")).hexdigest()[:20]
        return f"{self.entity_type}:{digest}:{field}"

    @classmethod
    def _single_flight(cls, key: str) -> str:
        with cls._inflight_lock:
            if key in cls._inflight:
                event = cls._inflight[key]
                leader = False
            else:
                cls._inflight[key] = threading.Event()
                leader = True
        if leader:
            return "leader"
        return "waited" if event.wait(timeout=120) else "timeout"

    @classmethod
    def _single_flight_done(cls, key: str) -> None:
        with cls._inflight_lock:
            event = cls._inflight.pop(key, None)
        if event:
            event.set()

    # ------------------------------------------------------------------
    # 批量与构造工具
    # ------------------------------------------------------------------

    @classmethod
    def batch_fetch(cls, cache_ids: list[str], concurrency: int = 5) -> dict[str, "Entity"]:
        results: dict[str, Entity] = {}
        with ThreadPoolExecutor(max_workers=max(1, concurrency)) as executor:
            futures = {executor.submit(cls.fetch, cache_id): cache_id for cache_id in cache_ids}
            for future in as_completed(futures):
                cache_id = futures[future]
                try:
                    entity = future.result()
                    if entity is not None:
                        results[cache_id] = entity
                except Exception:
                    pass
        return results

    @classmethod
    def _from_dict(cls, data: dict[str, Any]) -> "Entity | None":
        try:
            valid_fields = {
                key: value for key, value in data.items()
                if key in cls.model_fields
            }
            return cls(**valid_fields)
        except Exception:
            return None


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _json_value(value: Any) -> Any:
    if isinstance(value, BaseModel):
        return value.model_dump(mode="json")
    if isinstance(value, dict):
        return {str(key): _json_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_json_value(item) for item in value]
    if isinstance(value, Path):
        return str(value)
    return value


def _serialize_value(value: Any) -> Any:
    if isinstance(value, Entity):
        return {
            "__amz_entity__": True,
            "entity_type": value.entity_type,
            "cache_id": value._cache_id,
            "fetched_at": dict(value._fetched_at),
            "fetch_keys": dict(value._fetch_keys),
            "result_data": _serialize_value(value._result_data),
            "fields": {
                name: _serialize_value(getattr(value, name))
                for name in type(value).model_fields
            },
        }
    if isinstance(value, BaseModel):
        return value.model_dump(mode="json")
    if isinstance(value, dict):
        return {str(key): _serialize_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_serialize_value(item) for item in value]
    return value


def _deserialize_value(value: Any) -> Any:
    if isinstance(value, list):
        return [_deserialize_value(item) for item in value]
    if not isinstance(value, dict):
        return value
    if value.get("__amz_entity__") is True:
        entity_cls = _find_entity_class(value.get("entity_type", ""))
        fields = _deserialize_value(value.get("fields", {}))
        if entity_cls is None:
            return fields
        cache_id = value.get("cache_id", "")
        live = entity_cls._live(cache_id) if cache_id else None
        if live is not None:
            return live
        instance = entity_cls.model_validate(fields)
        instance._cache_id = cache_id
        instance._fetched_at = dict(value.get("fetched_at", {}))
        instance._fetch_keys = dict(value.get("fetch_keys", {}))
        instance._result_data = _deserialize_value(value.get("result_data", {}))
        instance._backfill_fetch_keys()
        instance._remember()
        return instance
    return {key: _deserialize_value(item) for key, item in value.items()}


def _find_entity_class(entity_type: str) -> type[Entity] | None:
    pending = list(Entity.__subclasses__())
    while pending:
        candidate = pending.pop()
        if candidate.entity_type == entity_type:
            return candidate
        pending.extend(candidate.__subclasses__())
    return None
