"""
实体注册表初始化。
"""

from amz.entities.store import entity_registry
from amz.entities.product import Product
from amz.entities.keyword import Keyword
from amz.entities.market import Market
from amz.entities.review import ReviewData

# 注册实体类型
entity_registry.register(Product)
entity_registry.register(Keyword)
entity_registry.register(Market)
entity_registry.register(ReviewData)
