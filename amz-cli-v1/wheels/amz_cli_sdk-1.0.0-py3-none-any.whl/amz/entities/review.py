"""
Review 数据模型：ReviewData 继承 Entity，获得 TTL 缓存 + single-flight + 持久化。
"""

from __future__ import annotations

from typing import Any, ClassVar

from pydantic import BaseModel, Field

from amz.entities.base import Entity, EnrichSpec, lazy_field
from amz.envelope import Result, Code


class ReviewItem(BaseModel):
    """单条评论"""
    review_id: str = ""
    rating: int | None = None
    title: str = ""
    text: str = ""
    date: str | None = None
    verified: bool = False
    user_name: str = ""
    images: list[str] = Field(default_factory=list)


class ReviewData(Entity):
    """评论集 — Entity 子类，获得 TTL 缓存 + single-flight + 持久化。

    可通过 fetch() 创建或从缓存加载，也可由 Product.get_reviews() 自动填充。
    """

    entity_type: ClassVar[str] = "review"
    identity_fields: ClassVar[tuple[str, ...]] = (
        "asin", "mode", "star_filter", "max_pages",
    )

    lazy_fields: ClassVar[dict[str, EnrichSpec]] = {
        # ReviewData 的字段由单次 API 调用填充，无需 lazy 加载。
        # 但保留 EnrichSpec 声明以支持 TTL 缓存和 enrich() 统一调度。
        "items": EnrichSpec(
            field="items", method="fetch_items",
            depends=[], source="/amazon/reviews", ttl_hours=48, version="3",
        ),
    }

    # -- 核心字段 ----------------------------------------------------------------

    asin: str = Field(min_length=1)
    count_ratings: int | None = None
    rating: float | None = None
    review_summary: dict[str, Any] = Field(default_factory=dict)
    star_counts: dict[str, int] = Field(default_factory=dict)
    items: list[ReviewItem] = Field(default_factory=list)
    sample_items: list[ReviewItem] = Field(default_factory=list)
    source: str = "amazon"
    star_filter: str | None = None
    mode: str = "mid"
    max_pages: int = 1

    # ------------------------------------------------------------------
    # 工厂方法
    # ------------------------------------------------------------------

    @classmethod
    def fetch(
        cls, asin: str, mode: str = "mid",
        star_filter: str = "all", max_pages: int = 1,
    ) -> ReviewData | None:
        """从 API 获取评论数据（或从缓存加载）。

        cache_id 包含 asin+mode+star_filter 以区分不同参数组合。
        """
        cache_id = cls.compose_cache_id(asin, mode, star_filter, max_pages)

        # 尝试从缓存加载
        cached = cls.load(cache_id)
        if cached is None:
            legacy_id = f"{asin}:{mode}:{star_filter}:{max_pages}"
            legacy = cls.load(legacy_id)
            if legacy is not None:
                legacy._cache_id = cache_id
                legacy.save()
                cached = legacy
        if cached:
            refresh = cached.fetch_items()
            return cached if refresh.code == Code.OK else None

        from amz.data.product import product_reviews
        result = product_reviews(asin, mode=mode, star_filter=star_filter, max_pages=max_pages)
        if result.code != Code.OK or not result.data:
            return None

        data = result.data
        # 转换 items 为 ReviewItem 列表
        raw_items = data.get("items", []) if isinstance(data, dict) else []
        items = [_dict_to_review_item(it) for it in raw_items]

        instance = cls(
            asin=asin,
            count_ratings=data.get("count_ratings") if isinstance(data, dict) else None,
            rating=data.get("rating") if isinstance(data, dict) else None,
            review_summary=data.get("review_summary", {}) if isinstance(data, dict) else {},
            star_counts=data.get("star_counts", {}) if isinstance(data, dict) else {},
            items=items,
            sample_items=_sample_items(items),
            source=data.get("source", "amazon") if isinstance(data, dict) else "amazon",
            star_filter=star_filter,
            mode=mode,
            max_pages=max_pages,
        )
        instance._cache_id = cache_id
        instance._mark_fetched("items")
        instance.save()
        return instance

    # ------------------------------------------------------------------
    # 实体方法
    # ------------------------------------------------------------------

    @lazy_field("items")
    def fetch_items(self) -> Result:
        """获取评论列表（按 mode/star_filter/max_pages 筛选，含 TTL 缓存）"""
        from amz.data.product import product_reviews
        result = product_reviews(
            self.asin, mode=self.mode,
            star_filter=self.star_filter or "all",
            max_pages=self.max_pages,
        )
        if result.code == Code.OK and result.data:
            data = result.data
            raw_items = data.get("items", []) if isinstance(data, dict) else []
            self.count_ratings = data.get("count_ratings") if isinstance(data, dict) else None
            self.rating = data.get("rating") if isinstance(data, dict) else None
            self.review_summary = data.get("review_summary", {}) if isinstance(data, dict) else {}
            self.star_counts = data.get("star_counts", {}) if isinstance(data, dict) else {}
            self.source = data.get("source", "amazon") if isinstance(data, dict) else "amazon"
            items = [_dict_to_review_item(it) for it in raw_items]
            self.sample_items = _sample_items(items)
            self._writeback("items", items)
        return result

    def get_items(self) -> Result:
        """获取评论列表（带缓存检查）。"""
        return self.fetch_items()

    @property
    def count(self) -> int:
        """评论总数"""
        return len(self.items)

    def by_star(self, star: int) -> list[ReviewItem]:
        """按星级筛选"""
        return [it for it in self.items if it.rating == star]

    def analysis_items(self) -> list[ReviewItem]:
        """返回 Product VOC 使用的分星抽样。

        抽样在评论字段模型中产生并持久化；Analysis 只消费结果。
        旧缓存没有 ``sample_items`` 时会按同一规则补算。
        """
        return list(self.sample_items or _sample_items(self.items))


# ============================================================================
# 内部工具
# ============================================================================

def _parse_rating(raw_rating) -> int | None:
    """解析评分：'1.0 out of 5 stars' → 1, '4.5 out of 5 stars' → 5, 4 → 4"""
    if raw_rating is None:
        return None
    if isinstance(raw_rating, (int, float)):
        return int(raw_rating)
    if isinstance(raw_rating, str):
        part = raw_rating.split(" out of")[0].strip()
        try:
            return int(float(part) + 0.5)
        except (ValueError, TypeError):
            return None
    return None


def _dict_to_review_item(data: dict[str, Any]) -> ReviewItem:
    """将 API 返回的 dict 转为 ReviewItem。"""
    review_id = str(data.get("review_id") or data.get("reviewId") or data.get("id")
                    or f"{data.get('userName','')}:{data.get('date','')}")
    images = data.get("images") or data.get("imageUrlList") or []
    title = data.get("title")
    if not title and isinstance(data.get("reviewSummary"), str):
        title = data["reviewSummary"]
    return ReviewItem(
        review_id=review_id,
        rating=_parse_rating(data.get("rating")),
        title=str(title or ""),
        text=str(data.get("text") or data.get("body") or ""),
        date=data.get("date"),
        verified=bool(data.get("verified", False)),
        user_name=str(data.get("user_name") or data.get("userName") or data.get("author") or ""),
        images=images,
    )


def _sample_items(items: list[ReviewItem], max_items: int = 60) -> list[ReviewItem]:
    """从 1-5 星样本中轮询取样，避免输入顺序让单一星级占满上下文。"""
    star_order = (5, 4, 3, 2, 1)
    buckets = {
        star: [item for item in items if item.rating == star]
        for star in star_order
    }
    unknown = [item for item in items if item.rating not in buckets]
    sampled: list[ReviewItem] = []
    index = 0
    while len(sampled) < max_items:
        added = False
        for star in star_order:
            bucket = buckets[star]
            if index < len(bucket):
                sampled.append(bucket[index])
                added = True
                if len(sampled) == max_items:
                    break
        if not added:
            break
        index += 1
    if len(sampled) < max_items:
        sampled.extend(unknown[: max_items - len(sampled)])
    return sampled
