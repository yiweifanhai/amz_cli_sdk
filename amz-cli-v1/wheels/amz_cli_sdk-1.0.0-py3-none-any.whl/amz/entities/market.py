"""
Market 实体：绑定到关键词的市场分析。

Market 以 keyword term 为标识，聚合竞品列表 → 市场画像统计 → 市场画像 → 机会分析。
与 Keyword 实体的区别：Keyword 关注词本身的特征（搜索量、趋势、评分），Market 关注
该词对应的市场竞争格局（价格带、垄断度、卖家结构、机会缺口）。
"""

from __future__ import annotations

from typing import Any, ClassVar, cast

from pydantic import BaseModel, Field

from amz.entities.base import Entity, EnrichSpec, lazy_field
from amz.envelope import Result, ok, err, Code
from amz.schemas.data_outputs import CompetingItemOutput


# -- 市场分析辅助模型 -----------------------------------------------------------

class PriceBand(BaseModel):
    """价格带"""
    label: str = ""
    min: float = 0.0
    max: float = 0.0
    count: int = 0
    share_pct: float = 0.0


class PriceStats(BaseModel):
    """价格统计"""
    p25: float | None = None
    p50: float | None = None
    p75: float | None = None
    band_count: int = 0
    bands: list[PriceBand] = Field(default_factory=list)


class RatingStats(BaseModel):
    """评分统计"""
    avg: float | None = None
    dist: dict[str, int] = Field(default_factory=dict)


class MonopolyStats(BaseModel):
    """垄断度统计"""
    cr10: float | None = None       # Top10 品牌份额
    cr20: float | None = None       # Top20 品牌份额
    top_brand_share: float | None = None


class SellerStats(BaseModel):
    """卖家结构"""
    total: int = 0
    cn_pct: float | None = None
    amazon_pct: float | None = None


class MarketStats(BaseModel):
    """市场画像统计（calc.market.stats 输出）"""
    price: PriceStats = Field(default_factory=PriceStats)
    rating: RatingStats = Field(default_factory=RatingStats)
    listing_date: dict[str, Any] = Field(default_factory=dict)    # {median, new_release_pct}
    reviews: dict[str, Any] = Field(default_factory=dict)         # {median, count_dist}
    monopoly: MonopolyStats = Field(default_factory=MonopolyStats)
    sellers: SellerStats = Field(default_factory=SellerStats)
    aplus_video_pct: float | None = None
    return_rate: dict[str, Any] | None = None                     # {pct, risk}


class MarketProfile(BaseModel):
    """8 维市场画像"""
    keyword: str = ""
    dimensions: dict[str, Any] = Field(default_factory=dict)
    overall_score: float = 0.0


class Opportunity(BaseModel):
    """市场机会"""
    keyword: str = ""
    gaps: list[dict[str, Any]] = Field(default_factory=list)
    proposals: list[dict[str, Any]] = Field(default_factory=list)
    opportunity_score: float = 0.0


# -- Market 实体 ---------------------------------------------------------------

class Market(Entity):
    """Market 实体 — 以 keyword term 为标识的市场竞争格局"""

    entity_type: ClassVar[str] = "market"
    identity_fields: ClassVar[tuple[str, ...]] = ("marketplace", "category", "term")

    lazy_fields: ClassVar[dict[str, EnrichSpec]] = {
        "products": EnrichSpec(
            field="products", method="get_products",
            depends=[], source="/competing-lookup", ttl_hours=24,
        ),
        "stats": EnrichSpec(
            field="stats", method="get_stats",
            depends=["products"], source="calc.market.stats", ttl_hours=24,
        ),
        "profile": EnrichSpec(
            field="profile", method="get_profile",
            depends=["stats"], source="calc.market.profile", ttl_hours=24,
        ),
        "opportunity": EnrichSpec(
            field="opportunity", method="get_opportunity",
            depends=["stats"], source="calc.market.opportunity", ttl_hours=24,
        ),
    }

    # -- 核心字段 ----------------------------------------------------------------

    term: str = Field(min_length=1, json_schema_extra={"alias": "term"})
    marketplace: str = Field(default="US", json_schema_extra={"alias": "marketplace"})
    category: str = Field(default="", json_schema_extra={"alias": "category"})

    # -- lazy 字段 ---------------------------------------------------------------

    products: list[CompetingItemOutput] | None = None
    stats: MarketStats | None = None              # 类型化的市场画像统计
    profile: MarketProfile | None = None           # 类型化的 8 维市场画像
    opportunity: Opportunity | None = None          # 类型化的市场机会分析

    # ------------------------------------------------------------------
    # 工厂方法
    # ------------------------------------------------------------------

    @classmethod
    def fetch(cls, term: str, marketplace: str = "US", category: str = "") -> Market | None:
        """创建 Market 实体（不立即拉取数据）"""
        cache_id = cls.compose_cache_id(marketplace, category, term)
        cached = cls.load(cache_id)
        if cached is None and marketplace == "US" and not category:
            legacy = cls.load(term)
            if legacy is not None:
                legacy._cache_id = cache_id
                legacy.marketplace = marketplace
                legacy.category = category
                legacy.save()
                cached = legacy
        if cached:
            return cached
        instance = cls(term=term, marketplace=marketplace, category=category)
        instance._cache_id = cache_id
        instance.save()
        return instance

    # ------------------------------------------------------------------
    # 实体方法
    # ------------------------------------------------------------------

    @lazy_field("products")
    def get_products(self, pages: int = 2) -> Result:
        """获取该关键词的竞品列表（standardized dict，写入 self.products）"""
        from amz.data.market import market_competitors
        result = market_competitors(keyword=self.term, pages=pages)
        if result.code == Code.OK:
            self._writeback("products", (result.data or {}).get("items", []))
        return result

    @lazy_field("stats")
    def get_stats(self) -> Result:
        """计算市场画像统计（价格带/评分/上架时间/垄断度/卖家结构）"""
        from amz.calc.market import calculate_stats
        stats = calculate_stats([
            item.model_dump(mode="python") for item in (self.products or [])
        ])
        self._writeback("stats", stats)
        return ok(data=self.stats)

    @lazy_field("profile")
    def get_profile(self) -> Result:
        """8 维市场画像（综合评分，委托 calc.market.calculate_profile）"""
        from amz.calc.market import calculate_profile
        profile = calculate_profile(
            self.stats.model_dump(mode="python"), keyword=self.term,
        )
        self._writeback("profile", profile)
        return ok(data=self.profile)

    @lazy_field("opportunity")
    def get_opportunity(self) -> Result:
        """市场机会/缺口分析（gap + 微改造提案 + 机会分，委托 calc.market.opportunity）"""
        from amz.calc.market import calculate_opportunity_score
        opportunity = calculate_opportunity_score(
            self.stats.model_dump(mode="python"), keyword=self.term,
        )
        self._writeback("opportunity", opportunity)
        return ok(data=self.opportunity)

    # ------------------------------------------------------------------
    # Python object API
    # ------------------------------------------------------------------

    def require_products(self, pages: int = 2) -> list[CompetingItemOutput]:
        """Return lightweight competitors, fetching them when needed.

        These are deliberately summaries rather than full ``Product`` entities so a
        ``Product -> Market -> products`` traversal cannot recursively embed another
        complete Product/Market object graph.
        """
        return cast(
            list[CompetingItemOutput],
            self._require_field_value("products", self.get_products(pages=pages)),
        )

    def require_stats(self) -> MarketStats:
        """Return typed market statistics, loading products first when needed."""
        return cast(
            MarketStats,
            self._require_field_value("stats", self.get_stats()),
        )

    def require_profile(self) -> MarketProfile:
        """Return the typed eight-dimension market profile."""
        return cast(
            MarketProfile,
            self._require_field_value("profile", self.get_profile()),
        )

    def require_opportunity(self) -> Opportunity:
        """Return the typed market opportunity assessment."""
        return cast(
            Opportunity,
            self._require_field_value("opportunity", self.get_opportunity()),
        )
