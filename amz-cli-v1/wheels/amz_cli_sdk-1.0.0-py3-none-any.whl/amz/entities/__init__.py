"""
L2 实体属性获取与标准化 — Pydantic v2 模型 + 按需填充 + 逐字段 TTL + single-flight。

设计原则
--------
- **实体 = Pydantic 模型 + 行为**：字段声明即类型，不再需要 datatypes 层单独定义模型
- **惰性加载**：调用 entity.get_xxx() → 底层调 calc/analysis → 结果写回 entity.xxx
- **逐字段 TTL**：每个 lazy 字段独立缓存时间，过期自动重拉
- **链式依赖**：lazy 字段可以依赖其他 lazy 字段，触发时自动级联 enrich

数据流::

    data/product.py ──HTTP──▶ 上游 API
       │
       ├── normalize (data/normalizer.py) ──▶ 标准 dict
       │
       └── entities/Product.fetch() ──▶ Product 实例 (Pydantic 模型)
                                          │
                                          ├── .get_finance() ──▶ entities/finance.py → calc.{margin,finance}
                                          ├── .get_voc()      ──▶ analysis/voc.py
                                          └── .save()         ──▶ ~/.cache/amz-cli/entities/

calc/analysis 只负责纯计算/推理，不关心缓存和状态管理——由 Entity 基类统一处理。

模块清单
--------

============= ==============================================
模块          职责
============= ==============================================
base          Entity( BaseModel ) 基类 + EnrichSpec + single-flight
store         EntityRegistry 工厂（磁盘加载 / API 创建）
registry      实体类型注册
product       Product — 完整 ASIN 数据聚合（Pydantic 模型）
keyword       Keyword + KeywordScore + KeywordCluster + TrendPoint + Abapoint
market        Market + MarketStats + MarketProfile + Opportunity + PriceBand 等
finance       FinanceData 结果模型 + build_finance 整合函数
============= ==============================================

用法::

    from amz.entities.product import Product
    p = Product.fetch("B0XXXX")              # 从 API 创建或磁盘加载
    margin = p.get_finance(shipping="fast")   # 自动触发 calc，结果缓存
    p.save()                                  # 持久化到磁盘

    # Product 也是 Pydantic 模型
    print(p.model_dump())                     # → 完整字段 dict
    print(p.model_json_schema())              # → JSON Schema
"""

from amz.entities.base import Entity, EnrichSpec, lazy_field
from amz.entities.store import entity_registry
from amz.entities.product import Product, ProductDetails
from amz.entities.keyword import (
    Keyword, KeywordScore, KeywordCluster, TrendPoint, Abapoint,
)
from amz.entities.market import (
    Market, MarketStats, MarketProfile, Opportunity,
    PriceBand, PriceStats, RatingStats, MonopolyStats, SellerStats,
)
from amz.entities.supply import Supplier
from amz.entities.review import ReviewData, ReviewItem
from amz.entities.finance import FinanceData
from amz.entities.assessment import Assessment

# -- 解决跨模块前向引用 -----------------------------------------------------------
# Product 引用了 ReviewData / FinanceData / Market，Keyword 引用了 Market，
# 这些类型定义在独立模块中。model_rebuild() 在全部导入完成后解析前向引用。
Product.model_rebuild()
Keyword.model_rebuild()
Market.model_rebuild()
ReviewData.model_rebuild()

for _entity_cls in (Product, Keyword, Market, ReviewData):
    entity_registry.register(_entity_cls)

__all__ = [
    "Entity", "EnrichSpec", "lazy_field", "entity_registry",
    "Product", "ProductDetails",
    "Keyword", "KeywordScore", "KeywordCluster", "TrendPoint", "Abapoint",
    "Market", "MarketStats", "MarketProfile", "Opportunity",
    "PriceBand", "PriceStats", "RatingStats", "MonopolyStats", "SellerStats",
    "Supplier",
    "ReviewData", "ReviewItem",
    "FinanceData",
    "Assessment",
]
