"""
实体注册表 + 工厂：获取/创建实体实例，管理单例。
"""

from __future__ import annotations

import threading
from typing import Type

from amz.entities.base import Entity


class EntityRegistry:
    """实体工厂"""

    def __init__(self):
        self._types: dict[str, Type[Entity]] = {}
        self._lock = threading.RLock()

    def register(self, entity_cls: Type[Entity]):
        """注册实体类型"""
        with self._lock:
            existing = self._types.get(entity_cls.entity_type)
            if existing is not None and existing is not entity_cls:
                raise ValueError(f"duplicate entity type: {entity_cls.entity_type}")
            self._types[entity_cls.entity_type] = entity_cls

    def get(self, entity_type: str, cache_id: str) -> Entity | None:
        """获取实体：磁盘加载 或 创建新实例后持久化"""
        with self._lock:
            cls = self._types.get(entity_type)
        if cls is None:
            return None

        # 尝试加载缓存
        instance = cls.load(cache_id)
        if instance is not None:
            return instance

        # 创建新实例（子类需要提供 factory 方法）
        if hasattr(cls, "fetch"):
            return cls.fetch(cache_id)

        return None

    def list_types(self) -> list[str]:
        with self._lock:
            return sorted(self._types)

    def classes(self) -> list[Type[Entity]]:
        """列出全部已注册实体类（供能力桥等遍历）。"""
        with self._lock:
            return list(self._types.values())


# 全局单例
entity_registry = EntityRegistry()
