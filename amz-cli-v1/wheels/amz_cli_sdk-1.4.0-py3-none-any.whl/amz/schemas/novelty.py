"""Product novelty against earlier solutions in its Market samples and solution-term search.

An earlier ("legacy") product was first available at least ``min_lead_months``
before the target product; when the target has no listing date, at least
``min_age_months`` before the evaluation date. ``existing`` and
``innovation_score`` are separate outputs: the score is calculated from
model-graded dimensions; when an existing solution matches, the score is capped
(default 60). A same-solution judgement whose mechanism, form or function differs
by level 2 or more is an ``upgrade`` and does not count as existing.
"""
from __future__ import annotations

from datetime import date
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

Text = Annotated[str, Field(min_length=1)]
NoveltyDimension = Literal["mechanism", "form", "function", "scenario", "performance", "appearance"]
NOVELTY_DIMENSIONS: tuple[str, ...] = ("mechanism", "form", "function", "scenario", "performance", "appearance")
DIMENSION_LABELS: dict[str, str] = {
    "mechanism": "核心原理/机制",
    "form": "形态与结构",
    "function": "功能组合",
    "scenario": "场景与人群",
    "performance": "关键参数/性能",
    "appearance": "材质与外观",
}
# Weights sum to 1; mechanism-level change matters most for "new solution".
DIMENSION_WEIGHTS: dict[str, float] = {
    "mechanism": 0.30, "form": 0.20, "function": 0.20,
    "scenario": 0.15, "performance": 0.10, "appearance": 0.05,
}
MAX_LEVEL = 3
DEFAULT_EXISTING_CAP = 60
# A "same solution" may only differ by tweaks on these dimensions (level <= 1).
STRUCTURAL_DIMENSIONS: tuple[str, ...] = ("mechanism", "form", "function")
UPGRADE_LEVEL = 2
MAX_COMPARISON_GROUPS = 13  # max_groups (<=12) plus the solution-search group
MAX_PRESCREEN_CANDIDATES = 200


class _Frozen(BaseModel):
    model_config = ConfigDict(frozen=True, str_strip_whitespace=True)


class _Output(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


def _upper(value):
    return value.strip().upper() if isinstance(value, str) else value


# ---------------------------------------------------------------------------
# calc.product.legacy_split
# ---------------------------------------------------------------------------


class DatedProduct(_Frozen):
    asin: Text
    listing_date: str | None = None
    monthly_sales: int | None = None

    _asin = field_validator("asin", mode="before")(_upper)


class LegacySplitInput(_Frozen):
    products: tuple[DatedProduct, ...]
    as_of: date
    min_age_months: int = Field(default=12, ge=1, le=120)
    exclude_asins: tuple[str, ...] = ()
    anchor_date: str | None = Field(default=None, description="本品上架日期；有效时按它往前 min_lead_months 取老品")
    min_lead_months: int = Field(default=6, ge=0, le=120)


class LegacySplitOutput(_Output):
    cutoff_date: date
    cutoff_basis: Literal["target_listing", "as_of"]
    anchor_date: date | None = None
    legacy_asins: list[str]
    recent_asins: list[str]
    missing_date_asins: list[str]
    listing_dates: dict[str, str] = Field(description="ASIN → 规范化后的上架日期 (ISO)")


# ---------------------------------------------------------------------------
# analysis.product.novelty
# ---------------------------------------------------------------------------


class NoveltyProductFacts(_Frozen):
    asin: Text
    title: str = ""
    bullet_points: tuple[str, ...] = ()
    image_url: str = ""
    listing_date: str | None = None
    monthly_sales: int | None = None

    _asin = field_validator("asin", mode="before")(_upper)


class NoveltyGroupInput(_Frozen):
    group_name: Text
    solution: Text
    legacy_count: int = Field(ge=1)
    members: tuple[NoveltyProductFacts, ...] = Field(min_length=1, max_length=5)


class NoveltyAnalysisInput(_Frozen):
    target: NoveltyProductFacts
    groups: tuple[NoveltyGroupInput, ...] = Field(min_length=1, max_length=MAX_COMPARISON_GROUPS)
    model: str = Field(default="pro", min_length=1)

    @model_validator(mode="after")
    def target_not_in_groups(self):
        names = [group.group_name for group in self.groups]
        if len(set(names)) != len(names):
            raise ValueError("group_name must be unique")
        seen = set()
        for group in self.groups:
            if len(group.members) > group.legacy_count:
                raise ValueError("representatives cannot outnumber the legacy products in the group")
            for member in group.members:
                if member.asin == self.target.asin:
                    raise ValueError("target product must not be its own legacy benchmark")
                if member.asin in seen:
                    raise ValueError(f"duplicate legacy benchmark: {member.asin}")
                seen.add(member.asin)
        return self


class DimensionGrade(_Output):
    dimension: NoveltyDimension
    level: int = Field(strict=True, ge=0, le=MAX_LEVEL, description="0 无差异，1 微调，2 明显差异，3 根本不同")
    evidence: Text


class GroupJudgement(_Output):
    """Model output for one legacy solution group."""

    same_solution: bool = Field(strict=True, description="本品是否与该组老品属于同一解决方案（核心原理与形态一致，仅参数/外观/包装微调）")
    matched_asins: list[Text] = Field(description="与本品方案相同的老品 ASIN")
    shared_points: list[Text]
    novel_points: list[Text]
    dimensions: list[DimensionGrade]
    reason: Text

    @model_validator(mode="after")
    def complete_dimensions(self):
        seen = [grade.dimension for grade in self.dimensions]
        if sorted(seen) != sorted(NOVELTY_DIMENSIONS):
            raise ValueError(f"dimensions must grade each of {list(NOVELTY_DIMENSIONS)} exactly once")
        self.matched_asins = [_upper(asin) for asin in self.matched_asins]
        if len(set(self.matched_asins)) != len(self.matched_asins):
            raise ValueError("matched_asins must be unique")
        if self.same_solution and not self.matched_asins:
            raise ValueError("same_solution requires matched_asins")
        if not self.same_solution and self.matched_asins:
            raise ValueError("matched_asins must be empty when same_solution is false")
        return self


class NoveltyGroupJudgement(GroupJudgement):
    group_name: Text
    compared_asins: list[Text] = Field(min_length=1)
    images_used: list[str] = Field(default_factory=list, description="成功送入模型的主图所属 ASIN")

    @model_validator(mode="after")
    def matches_were_compared(self):
        unknown = set(self.matched_asins) - set(self.compared_asins)
        if unknown:
            raise ValueError(f"matched_asins not in the comparison: {sorted(unknown)}")
        return self


class SkippedGroup(_Output):
    group_name: Text
    reason: Text


class FailedRef(_Output):
    asin: Text
    reason: Text


class NoveltyAnalysisOutput(_Output):
    groups: list[NoveltyGroupJudgement]
    skipped_groups: list[SkippedGroup] = Field(default_factory=list)
    failed_refs: list[FailedRef] = Field(default_factory=list)
    limitations: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# analysis.product.solution_terms
# ---------------------------------------------------------------------------


class SolutionTermsInput(_Frozen):
    asin: Text
    title: Text
    brand: str | None = Field(default=None, description="品牌名，其中的词不得出现在方案词里")
    bullet_points: tuple[str, ...] = ()
    avoid_terms: tuple[str, ...] = Field(default=(), description="已用于市场取样的搜索词，方案词不得与之相同")
    model: str = Field(default="lite", min_length=1)


class SolutionTermsDraft(_Output):
    """Model output."""

    terms: list[Text] = Field(min_length=1, max_length=2)
    reason: Text


class SolutionTermsOutput(_Output):
    terms: list[str] = Field(min_length=1, max_length=2)
    reason: str


# ---------------------------------------------------------------------------
# analysis.product.solution_prescreen
# ---------------------------------------------------------------------------


class PrescreenCandidate(_Frozen):
    asin: Text
    title: Text

    _asin = field_validator("asin", mode="before")(_upper)


class PrescreenTarget(_Frozen):
    asin: Text
    title: Text
    bullet_points: tuple[str, ...] = ()


class SolutionPrescreenInput(_Frozen):
    target: PrescreenTarget
    candidates: tuple[PrescreenCandidate, ...] = Field(min_length=1, max_length=MAX_PRESCREEN_CANDIDATES)
    limit: int = Field(default=8, ge=1, le=20)
    model: str = Field(default="lite", min_length=1)

    @model_validator(mode="after")
    def unique_candidates(self):
        asins = [item.asin for item in self.candidates]
        if len(set(asins)) != len(asins):
            raise ValueError("candidates must have unique ASINs")
        if self.target.asin.strip().upper() in asins:
            raise ValueError("target must not be a prescreen candidate")
        return self


class PrescreenPick(_Output):
    id: Text
    reason: Text


class PrescreenDraft(_Output):
    """Model output; ids are the short local ids shown to the model."""

    matches: list[PrescreenPick]


class PrescreenSelection(_Output):
    asin: Text
    title: Text
    reason: Text


class SolutionPrescreenOutput(_Output):
    selected: list[PrescreenSelection] = Field(description="按可能性从高到低排序的疑似同方案候选")
    screened_count: int


# ---------------------------------------------------------------------------
# calc.product.novelty_score
# ---------------------------------------------------------------------------


class NoveltyScoreInput(_Frozen):
    groups: tuple[NoveltyGroupJudgement, ...] = Field(min_length=1)
    existing_cap: int = Field(default=DEFAULT_EXISTING_CAP, ge=0, le=100)


class GroupScore(_Output):
    group_name: Text
    same_solution: bool = Field(description="模型原始判定")
    match_type: Literal["same", "upgrade", "different"] = Field(
        description="same 计入 existing；upgrade 为模型判同方案但原理/形态/功能有 ≥2 级差异的改良款")
    raised_dimensions: list[NoveltyDimension] = Field(default_factory=list, description="使 same_solution 降为 upgrade 的维度")
    score: int = Field(ge=0, le=100)


class NoveltyScoreOutput(_Output):
    existing: bool
    innovation_score: int = Field(ge=0, le=100)
    raw_score: int = Field(ge=0, le=100, description="封顶前分数：existing=true 时取匹配到的老品方案组得分，否则取最接近的老品方案组得分")
    score_capped: bool
    existing_cap: int
    closest_group: Text
    group_scores: list[GroupScore]


# ---------------------------------------------------------------------------
# entity.product.novelty
# ---------------------------------------------------------------------------


MatchSource = Literal["market_sample", "solution_search"]


class ExistingMatch(_Output):
    asin: Text
    group_name: Text
    listing_date: str | None = None
    monthly_sales: int | None = None
    source: MatchSource
    query: Text = Field(description="召回该商品的搜索词")
    match_type: Literal["existing_hot", "prior_attempt"] = Field(
        description="月销量 ≥ hot_sales_threshold 为 existing_hot，否则（含销量未知）为 prior_attempt")


class UpgradeMatch(_Output):
    asin: Text
    group_name: Text
    listing_date: str | None = None
    monthly_sales: int | None = None
    source: MatchSource
    query: Text
    raised_dimensions: list[NoveltyDimension]


class SearchCoverage(_Output):
    query: Text
    source: MatchSource
    pages: int
    total: int | None = Field(default=None, description="接口报告的结果总数，未知为空")
    fetched: int = Field(description="实际拉到的商品数")


class NoveltySample(_Output):
    market_term: Text
    market_terms: list[str] = Field(default_factory=list, description="用于市场取样的全部搜索词")
    term_source: Literal["input", "reverse_keyword"] = "reverse_keyword"
    cutoff_basis: Literal["target_listing", "as_of"] = "as_of"
    target_listing_date: date | None = None
    solution_terms: list[str] = Field(default_factory=list)
    solution_candidate_count: int = Field(default=0, description="方案词召回中早于截止日、送入标题预筛的商品数")
    solution_prescreened: list[str] = Field(default_factory=list, description="标题预筛判定可能同方案的 ASIN")
    coverage: list[SearchCoverage] = Field(default_factory=list)
    pages: int
    product_count: int
    legacy_count: int
    recent_count: int
    missing_date_asins: list[str]
    eligible_group_count: int | None = Field(default=None, ge=0, description="含符合年限老品的候选组总数，包括跳过的组，本品不计入老品")
    target_group: Text | None = Field(default=None, description="本品按标题归入的候选组名称，未归入候选组时为空")
    compared_group_count: int
    skipped_groups: list[SkippedGroup]
    failed_refs: list[FailedRef]


class ProductNoveltyOutput(_Output):
    asin: Text
    as_of: date
    cutoff_date: date
    cutoff_basis: Literal["target_listing", "as_of"]
    min_age_months: int
    min_lead_months: int
    hot_sales_threshold: int
    existing: bool
    existing_matches: list[ExistingMatch]
    upgrades: list[UpgradeMatch]
    innovation_score: int = Field(ge=0, le=100)
    raw_score: int = Field(ge=0, le=100)
    score_capped: bool
    existing_cap: int
    closest_group: Text
    novel_points: list[str]
    groups: list[NoveltyGroupJudgement]
    group_scores: list[GroupScore]
    sample: NoveltySample
    limitations: list[str]
