"""Contracts for the evidence-first solution directions task.

Market turns one search sample into product lines (one per parent ASIN), tags every
line along 2-4 solution axes with one model request, then a deterministic
calculation picks the directions that verified new product lines are moving into.
The model never sees sales and never grades a direction; an optional second
request only explains program-graded cards and must cite their evidence ASINs.
"""
from __future__ import annotations

from datetime import date
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field

from amz.schemas.solution_outlook import Asin, Month, NonNegative, Text, TrendPoint

Kind = Literal["结构形态", "人群对象", "使用场景", "功能配置"]
Nature = Literal["新方案", "简化降配", "加量套装", "节日季节"]
Relation = Literal["T", "A", "X"]          # 本体 / 配件 / 离题
Grade = Literal["A", "B", "C"]
Role = Literal["默认形态", "当前主流", "候选", "无验证新品", "节日季节"]
MarketType = Literal["纯新市场", "新品破局", "单点新品", "老品主导"]
KIND_TYPE = {"结构形态": "新结构", "人群对象": "细分人群", "使用场景": "细分场景", "功能配置": "配置升级"}
UNKNOWN = "未知"
OTHER = "其他"


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class _Open(BaseModel):
    model_config = ConfigDict(extra="forbid")


# ---------------------------------------------------------------------------
# Inputs
# ---------------------------------------------------------------------------


class DirectionsThresholds(_Strict):
    """Gates for a verified new line and for a direction card. Defaults are the
    amz-cli solution_validation calibration (4,568 qualifying new products, 2026-11-24)."""

    new_months: int = Field(default=6, ge=1, le=24, description="新品：上架不超过的月数")
    fresh_months: int = Field(default=3, ge=1, le=12, description="最新进入者：上架不超过的月数")
    min_monthly_units: int = Field(default=200, ge=0)
    min_monthly_revenue: NonNegative = 5000
    official_min_units: int = Field(default=200, ge=0, description="亚马逊前台'过去一个月 X+ 件'标记的下限")
    max_review_rate_pct: NonNegative = 10
    min_reviews_for_rate: int = Field(default=50, ge=0)
    max_launch_rate_ratio: NonNegative = 3
    pure_new_share: float = Field(default=0.5, ge=0, le=1, description="≤新品月数的商品线月销占比达到即为纯新市场")
    default_share: float = Field(default=0.6, ge=0, le=1, description="占样本月销达到且新品里没明显更高 → 默认形态")
    min_shift: float = Field(default=0.10, ge=0, le=1, description="新品中份额比老品高出的最小幅度")
    min_base_lines: int = Field(default=5, ge=1, description="老品对照组最少商品线数，不足则不算份额变化，最高 B")
    noisy_share: float = Field(default=0.5, ge=0, le=1, description="离题商品超过该比例时提示样本偏小")
    max_cards: int = Field(default=3, ge=1, le=10)


class SampleRow(_Strict):
    """One search-sample row. Variants of one parent may appear several times; each
    carries the parent's sales estimate, so rows are merged per parent."""

    asin: Asin
    parent_asin: Asin | None = None
    title: str | None = None
    image_url: str | None = None
    brand: str | None = None
    price_usd: NonNegative | None = None
    monthly_units: int | None = Field(default=None, ge=0)
    monthly_revenue: NonNegative | None = None
    rating: float | None = Field(default=None, ge=0, le=5)
    count_review: int | None = Field(default=None, ge=0)
    available_date: date | None = None
    sales_trend: list[TrendPoint] = Field(default_factory=list)
    official_units: int | None = Field(default=None, ge=0, description="亚马逊前台'过去一个月 X+ 件'")
    m1: float | None = Field(default=None, description="调用方算好的毛利率（%），可选")
    amazon_choice: bool = False
    best_seller: bool = False


class AbaTop3Row(_Strict):
    """One weekly ABA top-3 click slot for the market's main search term (Amazon data)."""

    week: date
    asin: Asin
    click_share: float | None = None
    conversion_share: float | None = None


class SolutionLinesInput(_Strict):
    current_date: date
    rows: list[SampleRow] = Field(min_length=1)
    aba_top3: list[AbaTop3Row] = Field(default_factory=list)
    thresholds: DirectionsThresholds = Field(default_factory=DirectionsThresholds)


# ---------------------------------------------------------------------------
# Lines and market structure (calc.market.solution_lines)
# ---------------------------------------------------------------------------


class AbaPresence(_Strict):
    weeks_13: int
    weeks_52: int
    first_week: date
    click_share: float | None
    conversion_share: float | None


class ProductLine(_Open):
    asin: Asin
    asins: list[Asin]
    parent_asin: Asin
    title: str | None
    image_url: str | None
    brand: str | None
    price_usd: float | None
    monthly_units: int | None
    monthly_revenue: float | None
    rating: float | None
    count_review: int | None
    m1: float | None
    launch: date | None
    age_months: float | None
    cohort: str
    official_units: int | None
    amazon_choice: bool
    best_seller: bool
    fresh: bool
    new: bool
    over_gate: bool
    suspect: list[str]
    verified: bool
    official_ok: bool
    sales: list[TrendPoint] = Field(description="上架以来的月销（含当月不完整数据）")
    aba: AbaPresence | None


class CohortRow(_Strict):
    cohort: str
    lines: int
    sold: int
    units_share: float | None
    revenue_share: float | None
    revenue_median: float | None
    over_gate: int
    official_200: int


class FollowRow(_Strict):
    window: str
    lines: int
    over_gate: int
    official_200: int
    suspected: int


class AbaSummary(_Strict):
    last_week: date
    weeks: int
    slots: int
    asins: int
    new_slots: int
    unknown_slots: int


class MarketStructure(_Strict):
    type: MarketType
    lines: int
    sold: int
    fresh_lines: int
    fresh_share: float | None
    new_lines: int
    new_share: float | None
    verified_lines: int
    official_lines: int
    suspected_lines: int
    growth_3m: float | None = Field(description="同一批商品线最近 3 个完整月 vs 前 3 个月")
    growth_3m_lines: int
    cohorts: list[CohortRow]
    follow: list[FollowRow]
    entries: list[tuple[Month, int]] = Field(description="近 12 个月每月上架的商品线数")
    aba: AbaSummary | None


class SolutionLinesResult(_Strict):
    current_date: date
    thresholds: DirectionsThresholds
    lines: list[ProductLine]
    structure: MarketStructure
    limitations: list[Text]


# ---------------------------------------------------------------------------
# Tags (analysis.market.solution_tags)
# ---------------------------------------------------------------------------


class TagTitle(_Strict):
    item_id: Annotated[str, Field(min_length=1)]
    title: str | None = None
    price: float | None = None
    platform: Literal["amazon", "taobao"] = "amazon"


class SolutionTagsInput(_Strict):
    term: Text
    product_hint: str | None = Field(default=None, description="一句话说明这是什么产品，可选")
    category: str | None = None
    items: list[TagTitle] = Field(min_length=1, max_length=120)
    model: str = "pro"


class TagValue(_Strict):
    v: Annotated[str, Field(min_length=1, max_length=20)]
    desc: str = ""
    nature: Nature = "新方案"


class TagAxis(_Strict):
    name: Text
    kind: Kind
    values: list[TagValue] = Field(min_length=2, max_length=6)


class TaggedItem(_Strict):
    item_id: str
    rel: Relation
    values: list[str]


class SolutionTags(_Strict):
    axes: list[TagAxis] = Field(min_length=1, max_length=4)
    items: list[TaggedItem]
    coerced: int = Field(default=0, description="越界取值被改成'其他'的个数")
    limitations: list[Text]


# ---------------------------------------------------------------------------
# Directions (calc.market.solution_directions)
# ---------------------------------------------------------------------------


class SolutionDirectionsInput(_Strict):
    current_date: date
    lines: list[ProductLine]
    tags: SolutionTags
    taobao_prices_cny: dict[str, float] = Field(default_factory=dict, description="淘宝商品 ID → 人民币标价，可选")
    thresholds: DirectionsThresholds = Field(default_factory=DirectionsThresholds)


class ComboValue(_Strict):
    axis: str
    value: str
    k: int
    n: int


class DirectionValue(_Open):
    axis: str
    kind: Kind
    value: str
    desc: str
    nature: Nature
    role: Role
    grade: Grade | None = None
    lines: int
    share: float | None
    recent_share: float | None
    base_share: float | None
    shift: float | None
    verified: list[Asin]
    official_verified: int
    aba_verified: int
    suspected: int
    follow: list[FollowRow]
    price_median: float | None
    price_verified: float | None
    price_older: float | None
    m1_verified: float | None
    revenue_verified: float | None
    rating_verified: float | None
    reviews_verified: float | None
    launch_verified: tuple[date, date] | None
    growth_3m: float | None
    growth_3m_lines: int
    taobao_count: int = 0
    taobao_price_median_cny: float | None = None
    series: list[tuple[Month, float | None]]
    top: list[Asin]


class DirectionCard(DirectionValue):
    type: str = Field(description="新结构/细分人群/细分场景/配置升级，或简化降配/加量套装")
    combo: list[ComboValue]
    entries_6m: int
    ramped_6m: int
    ramp_rate_6m: float | None
    notes: list[str] = Field(description="规则生成的反证与提醒")
    market_price_median: float | None
    market_growth_3m: float | None


class DirectionAxis(_Strict):
    name: str
    kind: Kind
    values: list[DirectionValue]


class SolutionDirections(_Strict):
    axes: list[DirectionAxis]
    cards: list[DirectionCard] = Field(description="新方案方向，按证据等级排序")
    minor_cards: list[DirectionCard] = Field(description="简化降配 / 加量套装：有销量证据但不算创新")
    on_topic: int
    accessory: int
    off_topic: int
    untagged: int
    has_base: bool
    noisy: bool
    tags: dict[str, tuple[Relation, list[str]]]
    limitations: list[Text]


# ---------------------------------------------------------------------------
# Explanations (analysis.market.solution_explain)
# ---------------------------------------------------------------------------


class ExplainCard(_Strict):
    ref: str
    value: str
    axis: str
    type: str
    grade: Grade
    desc: str
    numbers: dict = Field(description="程序算出的证据数字，原样给模型参考")
    evidence: list[dict] = Field(description="证据商品：asin、标题、价格、月销、上架日")
    others: list[str] = Field(description="同一维度的其他取值，replaces 只能从这里选")


class SolutionExplainInput(_Strict):
    term: Text
    product_hint: str | None = None
    cards: list[ExplainCard] = Field(min_length=1, max_length=10)
    model: str = "pro"


class CardExplanation(_Strict):
    ref: str
    value: str = Field(default="", description="对应方向卡的取值")
    axis: str = Field(default="", description="对应方向卡的维度；同名取值跨维度时用于区分")
    nature: Literal["新方案", "简化降配", "加量套装"] = Field(
        default="新方案", description="模型对照同维度其他做法复核的变化类型；非新方案的卡由程序移到 minor_cards")
    why: list[Text] = Field(min_length=1, max_length=4)
    replaces: str = Field(description="替代的同维度取值，没有则为空字符串")
    barriers: list[str] = Field(max_length=4)
    counter_evidence: list[Text] = Field(min_length=1, max_length=4)
    unknowns: list[str] = Field(max_length=4)
    evidence_ids: list[Asin] = Field(min_length=1)


class SolutionExplanations(_Strict):
    explanations: list[CardExplanation]
    limitations: list[Text]


# ---------------------------------------------------------------------------
# Entity task result (entity.market.solution_directions)
# ---------------------------------------------------------------------------


class SolutionDirectionsResult(_Strict):
    term: Text
    current_date: date
    structure: MarketStructure
    directions: SolutionDirections | None = Field(description="没有已验证新品线时为空，不出方向卡")
    explanations: list[CardExplanation] = Field(default_factory=list)
    lines: list[ProductLine]
    tags: SolutionTags | None
    taobao_sample: dict | None = None
    usage: dict = Field(default_factory=dict)
    limitations: list[Text]
