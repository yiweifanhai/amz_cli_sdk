"""Judge whether a Product repeats a legacy solution and grade its novelty.

Input is prepared by ``Product.novelty``: the target's title, bullets and main
image, plus legacy solution groups (each with up to five representative legacy
products). One model request per group compares the target against that group;
outputs are validated (complete six dimensions, matched ASINs drawn from the
group) with one bounded repair. Scoring is done by ``calc.product.novelty_score``.
Product and Market data are supplied by the Entity.
"""

from __future__ import annotations

import json

from pydantic import ValidationError

from amz.analysis.base import AnalysisContractError, parse_structured
from amz.envelope import Code, Result, err, ok
from amz.infra.images import prepare_image
from amz.infra.llm import chat_json
from amz.registry import capability
from amz.schemas.novelty import (
    DIMENSION_LABELS, FailedRef, GroupJudgement, NoveltyAnalysisInput, NoveltyAnalysisOutput,
    NoveltyGroupInput, NoveltyGroupJudgement, NoveltyProductFacts, SkippedGroup,
)

BULLET_LIMIT = 600

NOVELTY_PROMPT = """# 角色
你是亚马逊选品的产品方案评审。判断【待评估商品】相对【老品方案组】是否属于已有解决方案，并逐维度评估差异。

# 定义
- 解决方案：商品解决用户问题所依赖的核心原理/机制 + 基本形态结构 + 主要功能组合。
- same_solution=true：本组有老品与本品属于同一方案系——解决问题的核心方式相同，差异可能只是尺寸、数量、颜色、材质、包装、配件或参数微调，也可能是在该方案上的改良。
- same_solution=false：本组老品与本品只是同品类或同用途，核心方式不同，用户会把它们视为另一种解决办法。
- 是否算"已有方案"由程序依据维度等级判定：mechanism、form、function 都 ≤1 级为已有方案；任一 ≥2 级记为改良款。

# 维度与等级（level 0–3）
{dimensions}
等级：0 无差异；1 微调（参数、颜色、数量、轻微改款）；2 明显差异（用户可明显感知的新结构/新功能/新场景）；3 根本不同（另一种原理或形态）。

# 规则
1. 只依据提供的标题、五点和主图，不得用常识补造商品没有声明的属性；证据不足的维度按 0 级并在 evidence 说明“未见差异证据”。
2. 结合每件商品的主图和五点判断形态与功能。图文冲突时说明冲突；不可从主图推断不可见的内部机制。
3. 只要本组任一代表老品与本品属于同一方案系，就设 same_solution=true 并列出这些 ASIN。否则设为 false，matched_asins 为空数组。
   同品类、同用途不等于同一方案系。维度等级必须如实评定，不要为迁就 same_solution 压低或抬高等级。
4. 按与本品方案最接近的代表老品评定六个维度，每个维度恰好一次。evidence 用中文写出对比的 ASIN、可见特征或五点依据。
5. shared_points 写与老品相同的方案要素；novel_points 只写本品相对本组老品确有证据的新点，没有则为空数组。
6. 组名和方案概述只帮助定位；只凭实际提供的代表商品认定匹配和新点。只输出 JSON。
"""


def _dimension_text() -> str:
    return "\n".join(f"- {key}：{label}" for key, label in DIMENSION_LABELS.items())


def _facts_text(item: NoveltyProductFacts) -> str:
    bullets = [bullet.strip()[:BULLET_LIMIT] for bullet in item.bullet_points if bullet.strip()]
    payload = {"asin": item.asin, "title": item.title, "bullet_points": bullets}
    return json.dumps(payload, ensure_ascii=False)


def _group_messages(target: NoveltyProductFacts, target_image: str, group: NoveltyGroupInput,
                    members: list[tuple[NoveltyProductFacts, str]]):
    content: list[dict] = [{"type": "text", "text": (
        f"【老品方案组】{group.group_name}\n方案概述：{group.solution}\n"
        f"本组样本中上架满期的老品共 {group.legacy_count} 件，以下为代表商品："
    )}]
    for member, image in members:
        content.append({"type": "text", "text": f"老品 {_facts_text(member)}\n老品 {member.asin} 主图："})
        content.append({"type": "image_url", "image_url": {"url": image}})
    content.append({"type": "text", "text": f"【待评估商品】{_facts_text(target)}\n待评估商品主图："})
    content.append({"type": "image_url", "image_url": {"url": target_image}})
    content.append({"type": "text", "text": "请按规则输出 JSON。"})
    messages = [
        {"role": "system", "content": NOVELTY_PROMPT.format(dimensions=_dimension_text())},
        {"role": "user", "content": content},
    ]
    return messages


def _judge_group(target, target_image, group, members, model, llm_call, usage):
    messages = _group_messages(target, target_image, group, members)
    compared_asins = [member.asin for member, _ in members]
    for attempt in range(2):
        usage["llm_requests"] += 1
        try:
            response = llm_call(
                messages=messages, json_schema=GroupJudgement.model_json_schema(),
                model=model, temperature=0.2,
            )
        except Exception as exc:
            return None, f"novelty request failed for group {group.group_name}: {exc}"
        tokens = response.get("usage") if isinstance(response, dict) else None
        if isinstance(tokens, dict):
            for field in ("prompt_tokens", "completion_tokens", "input_tokens", "output_tokens", "total_tokens"):
                if isinstance(tokens.get(field), int):
                    usage[field] = usage.get(field, 0) + tokens[field]
        try:
            parsed = parse_structured(response, GroupJudgement)
            return NoveltyGroupJudgement(
                **parsed.model_dump(), group_name=group.group_name,
                compared_asins=compared_asins, images_used=[*compared_asins, target.asin],
            ), None
        except (ValidationError, AnalysisContractError) as exc:
            if attempt:
                return None, f"invalid novelty judgement for group {group.group_name}: {exc}"
            previous = response.get("json", {}) if isinstance(response, dict) else {}
            messages = [*messages,
                {"role": "assistant", "content": json.dumps(previous, ensure_ascii=False)},
                {"role": "user", "content": (
                    f"校验失败：{exc}\n请修正并返回完整 JSON：六个维度各一次，"
                    f"matched_asins 只能取自 {compared_asins}，same_solution=false 时为空。"
                )},
            ]


@capability(
    "analysis.product.novelty",
    description="对比本品与上架满期老品方案组，判断是否已有方案并逐维度评估差异",
    input_model=NoveltyAnalysisInput,
    output_model=NoveltyAnalysisOutput,
)
def product_novelty(target: dict, groups: list[dict], model: str = "pro") -> Result:
    return _product_novelty(target=target, groups=groups, model=model, llm_call=chat_json, prepare=prepare_image)


def _product_novelty(*, target, groups, model="pro", llm_call, prepare) -> Result:
    try:
        data = NoveltyAnalysisInput(target=target, groups=groups, model=model)
    except ValidationError as exc:
        return err(Code.ERROR_PARAM, str(exc))
    usage = {"llm_requests": 0}
    missing = []
    if not data.target.title.strip():
        missing.append("target.title")
    if not any(bullet.strip() for bullet in data.target.bullet_points):
        missing.append("target.bullet_points")
    if not data.target.image_url:
        missing.append("target.image_url")
    for index, group in enumerate(data.groups):
        for member in group.members:
            if not member.title.strip() or not any(b.strip() for b in member.bullet_points):
                missing.append(f"groups[{index}].{member.asin}.listing")
    if missing:
        return err(Code.ERROR_MISSING_FIELDS, "ERROR_MISSING_FIELDS: " + ", ".join(missing), missing=missing, usage=usage)

    images: dict[str, str | None] = {}

    def image_for(url: str) -> str | None:
        if not url:
            return None
        if url not in images:
            try:
                images[url] = prepare(url).data_url
            except Exception:
                images[url] = None
        return images[url]

    target_image = image_for(data.target.image_url)
    if not target_image:
        return err(Code.ERROR_UPSTREAM, "target main image could not be prepared", missing=["target.image_url"], usage=usage)

    judgements, skipped_groups, failed_refs = [], [], []
    for group in data.groups:
        members = []
        for member in group.members:
            image = image_for(member.image_url)
            if image:
                members.append((member, image))
            else:
                reason = "主图无法读取" if member.image_url else "缺少主图"
                failed_refs.append(FailedRef(asin=member.asin, reason=reason))
        if not members:
            skipped_groups.append(SkippedGroup(group_name=group.group_name, reason="没有主图可用于比较的老品"))
            continue
        judgement, error = _judge_group(data.target, target_image, group, members, data.model, llm_call, usage)
        if judgement is None:
            return err(Code.ERROR_LLM, error, usage=usage)
        judgements.append(judgement)

    output = NoveltyAnalysisOutput(
        groups=judgements, skipped_groups=skipped_groups, failed_refs=failed_refs,
        limitations=[f"{len(failed_refs)} 件代表老品缺少可读取的主图，已从比较中排除。"] if failed_refs else [],
    )
    if not judgements:
        code = Code.ERROR_UPSTREAM if any(m.image_url for g in data.groups for m in g.members) else Code.ERROR_MISSING_FIELDS
        return err(code, "no readable main images for legacy products", data=output.model_dump(mode="json"),
                   missing=[f"{ref.asin}.image_url" for ref in failed_refs], usage=usage)
    return ok(data=output.model_dump(mode="json"), usage=usage)
