"""Title prescreen: which recalled candidates may share the target's solution.

``Product.novelty`` searches solution terms without a sales floor, so most
results are noise (searching "cat carrier cat house" returns many cat mats).
This semantic task keeps only candidates whose titles plausibly describe the
same core solution, ranked by likelihood, so that a small set can go to the
image + bullet comparison. Short local ids are shown to the model and mapped
back to ASINs; output is validated with one bounded repair. No fetching.
"""

from __future__ import annotations

import json

from pydantic import ValidationError

from amz.analysis.base import AnalysisContractError, parse_structured
from amz.envelope import Code, Result, err, ok
from amz.infra.llm import chat_json
from amz.registry import capability
from amz.schemas.novelty import (
    PrescreenDraft, PrescreenSelection, SolutionPrescreenInput, SolutionPrescreenOutput,
)

BULLET_LIMIT = 300

PRESCREEN_PROMPT = """# 任务
你是亚马逊选品评审。根据候选商品标题，挑出"可能与本品属于同一解决方案"的商品，供后续用主图和五点细比。

# 判断标准
- 同一解决方案：核心原理/机制、基本形态结构和主要功能组合相同或高度相近；差异只在尺寸、数量、颜色、配件或参数。
- 只是同品类、同用途但形态或功能组合明显不同的，不选。例如本品是"两个可堆叠成猫屋的猫包，附隧道和抓板"，普通猫垫、普通猫窝、单个猫包都不选；"猫隧道 + 猫包 + 猫屋 + 抓板 可拆可组合"要选。
- 标题信息不足但有较大可能同方案的，可以选，并在 reason 说明不确定点；明显无关的不选。

# 输出
只输出 JSON：{{"matches": [{{"id": "候选编号", "reason": "中文理由"}}]}}。按可能性从高到低排序，最多 {limit} 个；id 只能取自输入；没有符合的返回空数组。
"""


@capability(
    "analysis.product.solution_prescreen",
    description="按标题预筛方案词召回的候选，保留可能与本品同方案的商品",
    input_model=SolutionPrescreenInput,
    output_model=SolutionPrescreenOutput,
)
def solution_prescreen(target: dict, candidates: list[dict], limit: int = 8, model: str = "lite") -> Result:
    return _solution_prescreen(target=target, candidates=candidates, limit=limit, model=model, llm_call=chat_json)


def _solution_prescreen(*, target, candidates, limit=8, model="lite", llm_call) -> Result:
    try:
        data = SolutionPrescreenInput(target=target, candidates=candidates, limit=limit, model=model)
    except ValidationError as exc:
        return err(Code.ERROR_PARAM, str(exc))
    local = {str(index): item for index, item in enumerate(data.candidates, 1)}
    payload = {
        "target": {
            "title": data.target.title,
            "bullet_points": [b.strip()[:BULLET_LIMIT] for b in data.target.bullet_points if b.strip()],
        },
        "candidates": [{"id": key, "title": item.title} for key, item in local.items()],
    }
    messages = [
        {"role": "system", "content": PRESCREEN_PROMPT.format(limit=data.limit)},
        {"role": "user", "content": json.dumps(payload, ensure_ascii=False)},
    ]
    usage = {"llm_requests": 0}
    for attempt in range(2):
        usage["llm_requests"] += 1
        try:
            response = llm_call(messages=messages, json_schema=PrescreenDraft.model_json_schema(),
                                model=data.model, temperature=0.2)
        except Exception as exc:
            return err(Code.ERROR_LLM, f"prescreen request failed: {exc}", usage=usage)
        try:
            draft = parse_structured(response, PrescreenDraft)
            ids = [pick.id.strip() for pick in draft.matches]
            unknown = sorted(set(ids) - set(local))
            if unknown:
                raise AnalysisContractError(f"unknown candidate ids: {unknown}")
            if len(set(ids)) != len(ids):
                raise AnalysisContractError("candidate ids must be unique")
            if len(ids) > data.limit:
                raise AnalysisContractError(f"at most {data.limit} matches are allowed")
            selected = [
                PrescreenSelection(asin=local[pick.id.strip()].asin, title=local[pick.id.strip()].title, reason=pick.reason)
                for pick in draft.matches
            ]
            return ok(data=SolutionPrescreenOutput(
                selected=selected, screened_count=len(local),
            ).model_dump(mode="json"), usage=usage)
        except (ValidationError, AnalysisContractError) as exc:
            if attempt:
                return err(Code.ERROR_LLM, f"invalid prescreen result: {exc}", usage=usage)
            previous = response.get("json", {}) if isinstance(response, dict) else {}
            messages = [*messages,
                {"role": "assistant", "content": json.dumps(previous, ensure_ascii=False)},
                {"role": "user", "content": f"校验失败：{exc}\n请修正并返回完整 JSON：id 只能取自输入候选编号、不重复、最多 {data.limit} 个。"},
            ]
    return err(Code.ERROR_LLM, "unreachable", usage=usage)
