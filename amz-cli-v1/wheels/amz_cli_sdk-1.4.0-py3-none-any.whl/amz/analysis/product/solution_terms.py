"""Extract English search terms for a Product's core solution from its own title.

Used by ``Product.novelty`` to recall earlier products with the same solution
that the category-level market sample misses (long-tail, low-sales listings).
The model only picks words: every word of a term must already appear in the
title (case, simple plurals and ®/™ ignored), so terms stay close to how sellers
actually describe the product. Bullets are context for choosing words, not a
word source. Output is validated (1–2 distinct 2–4 word terms, no brand words,
not equal to the market sampling terms) with one bounded repair. No fetching.
"""

from __future__ import annotations

import json
import re

from pydantic import ValidationError

from amz.analysis.base import AnalysisContractError, parse_structured
from amz.envelope import Code, Result, err, ok
from amz.infra.llm import chat_json
from amz.registry import capability
from amz.schemas.novelty import SolutionTermsDraft, SolutionTermsInput, SolutionTermsOutput

BULLET_LIMIT = 300
MIN_WORDS, MAX_WORDS = 2, 4
_WORD = re.compile(r"[a-z0-9]+(?:['-][a-z0-9]+)*")

SOLUTION_TERMS_PROMPT = """# 任务
从亚马逊商品标题里挑词，组成 1–2 个英文搜索词，用于搜索"采用同一解决方案/形态"的其他商品（包括销量很低的长尾商品）。

# 规则
1. 搜索词里的每个单词都必须出现在标题里，不得自己编造或换同义词；可以跳过中间的词，把标题中描述核心方案的名词组合起来。
   例如标题 "2 Stackable Cat Carriers Form a Cat House, with Tunnel" 可以抽出 "cat carrier cat house"。
2. 搜索词描述核心方案或形态（关键结构、组合方式），不要只是品类词；五点只用来帮助判断哪些词是核心方案。
3. 每个词 {min_words}–{max_words} 个单词，全部小写；不要品牌、型号、颜色、尺寸、数量、年份或促销词。
4. 两个词时，从不同角度描述同一方案；不得与"已用于市场取样的搜索词"相同。
5. 只输出 JSON：{{"terms": ["..."], "reason": "中文说明"}}。
"""


def _stem(word: str) -> str:
    """Treat simple plurals as the same title word (carriers → carrier, boxes → box)."""
    if len(word) > 4 and word.endswith("ies"):
        return word[:-3] + "y"
    if len(word) > 3 and word.endswith("es") and word[-3] in "sxz":
        return word[:-2]
    if len(word) > 3 and word.endswith("s") and not word.endswith("ss"):
        return word[:-1]
    return word


def _words(text: str) -> list[str]:
    return _WORD.findall(text.lower().replace("®", " ").replace("™", " "))


def _normalize(term: str) -> str:
    return " ".join(_words(term))


def _validate(draft: SolutionTermsDraft, *, title: str, brand: str | None, avoid: set[str]) -> list[str]:
    title_words = {_stem(word) for word in _words(title)}
    brand_words = {_stem(word) for word in _words(brand or "")}
    terms: list[str] = []
    for raw in draft.terms:
        term = _normalize(raw)
        words = term.split()
        if not MIN_WORDS <= len(words) <= MAX_WORDS:
            raise AnalysisContractError(f"term must have {MIN_WORDS}-{MAX_WORDS} English words: {raw!r}")
        foreign = [word for word in words if _stem(word) not in title_words]
        if foreign:
            raise AnalysisContractError(f"words not found in the title: {foreign} in {raw!r}")
        branded = [word for word in words if _stem(word) in brand_words]
        if branded:
            raise AnalysisContractError(f"brand words are not allowed: {branded} in {raw!r}")
        if term in avoid:
            raise AnalysisContractError(f"term repeats a market sampling term: {raw!r}")
        if term in terms:
            raise AnalysisContractError(f"duplicate term: {raw!r}")
        terms.append(term)
    return terms


@capability(
    "analysis.product.solution_terms",
    description="从本品标题中抽取描述核心方案/形态的英文方案词",
    input_model=SolutionTermsInput,
    output_model=SolutionTermsOutput,
)
def solution_terms(asin: str, title: str, brand: str | None = None, bullet_points=(), avoid_terms=(),
                   model: str = "lite") -> Result:
    return _solution_terms(asin=asin, title=title, brand=brand, bullet_points=bullet_points,
                           avoid_terms=avoid_terms, model=model, llm_call=chat_json)


def _solution_terms(*, asin, title, brand=None, bullet_points=(), avoid_terms=(), model="lite", llm_call) -> Result:
    try:
        data = SolutionTermsInput(asin=asin, title=title, brand=brand, bullet_points=bullet_points,
                                  avoid_terms=avoid_terms, model=model)
    except ValidationError as exc:
        return err(Code.ERROR_PARAM, str(exc))
    if not data.title.strip():
        return err(Code.ERROR_MISSING_FIELDS, "ERROR_MISSING_FIELDS: title", missing=["title"])
    avoid = {_normalize(term) for term in data.avoid_terms if term.strip()}
    payload = {
        "title": data.title,
        "brand": data.brand or "",
        "bullet_points": [bullet.strip()[:BULLET_LIMIT] for bullet in data.bullet_points if bullet.strip()],
        "market_sampling_terms": sorted(avoid),
    }
    messages = [
        {"role": "system", "content": SOLUTION_TERMS_PROMPT.format(min_words=MIN_WORDS, max_words=MAX_WORDS)},
        {"role": "user", "content": json.dumps(payload, ensure_ascii=False)},
    ]
    usage = {"llm_requests": 0}
    for attempt in range(2):
        usage["llm_requests"] += 1
        try:
            response = llm_call(messages=messages, json_schema=SolutionTermsDraft.model_json_schema(),
                                model=data.model, temperature=0.2)
        except Exception as exc:
            return err(Code.ERROR_LLM, f"solution term request failed: {exc}", usage=usage)
        try:
            draft = parse_structured(response, SolutionTermsDraft)
            terms = _validate(draft, title=data.title, brand=data.brand, avoid=avoid)
            return ok(data=SolutionTermsOutput(terms=terms, reason=draft.reason).model_dump(mode="json"), usage=usage)
        except (ValidationError, AnalysisContractError) as exc:
            if attempt:
                return err(Code.ERROR_LLM, f"invalid solution terms: {exc}", usage=usage)
            previous = response.get("json", {}) if isinstance(response, dict) else {}
            messages = [*messages,
                {"role": "assistant", "content": json.dumps(previous, ensure_ascii=False)},
                {"role": "user", "content": (
                    f"校验失败：{exc}\n请修正并返回完整 JSON：只能使用标题中出现的单词，不含品牌词，"
                    f"每个词 {MIN_WORDS}–{MAX_WORDS} 个单词，互不相同，且不得与市场取样词相同。"
                )},
            ]
    return err(Code.ERROR_LLM, "unreachable", usage=usage)
