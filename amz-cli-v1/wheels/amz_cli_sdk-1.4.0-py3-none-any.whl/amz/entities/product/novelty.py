"""Compare a Product's listing and main image with earlier solutions.

Two recall channels feed the image + bullet comparison:

1. Market sample: the caller's ``terms`` (one Market per term) or the reverse
   primary keyword. Titles are grouped by ``Market.summary``; the target's own
   group goes first, other groups by legacy sales; ``max_groups`` applies.
2. Solution-term search: a lite model writes 1–2 English terms for the core
   solution/form, ``market.competitors`` fetches them without a sales floor, a
   title prescreen keeps likely same-solution candidates, and those form one
   extra group outside ``max_groups``. This finds earlier attempts that never
   sold well enough to rank in the category sample.

Earlier ("legacy") means listed at least ``min_lead_months`` before the target
(fallback: ``min_age_months`` before ``as_of``). Results are a one-off task and
are not written to Product or Market fields.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from datetime import date
from types import SimpleNamespace
from typing import TYPE_CHECKING, Any

from amz.entities._core import operations
from amz.entities._core.store import entity_store
from amz.entities.product.facts import _missing
from amz.envelope import Code, Result, err, ok
from amz.schemas.entity_ref import product_ref
from amz.schemas.novelty import (
    MAX_PRESCREEN_CANDIDATES, ExistingMatch, FailedRef, NoveltySample, ProductNoveltyOutput,
    SearchCoverage, SkippedGroup, UpgradeMatch,
)

# product-info is slow (10–30 s); bounded to stay polite to the data server.
FETCH_CONCURRENCY = 4
PRESCREEN_LIMIT = 10  # ranked candidates kept so failed detail loads can be replaced

if TYPE_CHECKING:
    from amz.entities.market import Market
    from amz.entities.product.entity import Product


def _listing_facts(product: Product) -> dict | Result:
    failure = product._ensure_analysis_facts()
    if failure is not None:
        return failure

    bullets = [text.strip() for text in product.bullet_points if text.strip()]
    image_url = product._project_image_url().strip()
    missing = []
    if not bullets:
        missing.append("bullet_points")
    if not image_url:
        missing.append("images")
    if missing:
        return _missing(*missing)

    return {"asin": product.asin, "title": product.title, "bullet_points": bullets,
            "image_url": image_url, "listing_date": product.listing_date}


def _load_listing_facts(product: Product, asins: list[str]) -> dict[str, dict | Result]:
    """Fetch legacy Product details concurrently; each Product enriches its own fields."""
    entities = {asin: entity_store.get_or_create(product_ref(product.marketplace, asin)) for asin in asins}
    if len(entities) <= 1:
        return {asin: _listing_facts(entity) for asin, entity in entities.items()}
    results: dict[str, dict | Result] = {}
    with ThreadPoolExecutor(max_workers=min(FETCH_CONCURRENCY, len(entities))) as executor:
        futures = {asin: executor.submit(_listing_facts, entity) for asin, entity in entities.items()}
        for asin, future in futures.items():
            try:
                results[asin] = future.result()
            except Exception as exc:  # one failed Product must not abort the task
                results[asin] = err(Code.ERROR_UPSTREAM, f"{type(exc).__name__}: {exc}")
    return results


def _search(term: str, pages: int) -> Result:
    """Keyword product search through the Data layer (no keyword-miner dependency)."""
    from amz.data.market import market_competitors
    return market_competitors(keyword=term, pages=pages)


def _reported_total(result: Result) -> int | None:
    total = (result.data or {}).get("total") if result.code == Code.OK and isinstance(result.data, dict) else None
    return total if isinstance(total, int) and not isinstance(total, bool) and total >= 0 else None


def _fail(info: NoveltySample, asin: str, result: Result) -> None:
    info.failed_refs.append(FailedRef(asin=asin, reason=result.message or result.code.value))


class _Usage:
    def __init__(self):
        self.requests = 0
        self.stages: dict[str, Any] = {}

    def add(self, stage: str, usage: dict | None) -> None:
        usage = dict(usage or {})
        self.requests += int(usage.get("llm_requests", 0) or 0)
        if stage in self.stages:
            previous = self.stages[stage]
            self.stages[stage] = previous + [usage] if isinstance(previous, list) else [previous, usage]
        else:
            self.stages[stage] = usage

    def meta(self) -> dict:
        return {"llm_requests": self.requests, **self.stages}


def _markets(product: Product, terms: list[str] | None) -> list[Market] | Result:
    if terms is not None:
        from amz.entities.market import Market

        cleaned: list[str] = []
        for term in terms:
            text = " ".join(str(term).split())
            if text and text.lower() not in {item.lower() for item in cleaned}:
                cleaned.append(text)
        if not cleaned:
            return err(Code.ERROR_PARAM, "terms must contain at least one non-empty keyword")
        markets = []
        for term in cleaned:
            market = Market.fetch(term, marketplace=product.marketplace)
            if market is None:
                return err(Code.ERROR_UPSTREAM, f"failed to create Market for {term}")
            markets.append(market)
        return markets
    result = product.enrich("market")
    if result.code != Code.OK:
        return result
    market = product.market
    if market is None:
        return _missing("market")
    if market.marketplace != product.marketplace:
        return err(Code.ERROR_PARAM, "primary market must be in the Product marketplace")
    return [market]


def _unique_name(name: str, used: set[str]) -> str:
    candidate, number = name, 2
    while candidate in used:
        candidate, number = f"{name}（{number}）", number + 1
    used.add(candidate)
    return candidate


def _group_representatives(
    product: Product, pooled: list[SimpleNamespace], origins: dict[str, dict],
    listing_dates: dict[str, str], info: NoveltySample, max_groups: int, per_group: int, claimed: set[str],
) -> list[dict]:
    ranked = []
    for group in pooled:
        members = [asin for asin in group.product_ids if asin in listing_dates]
        if not members:
            info.skipped_groups.append(SkippedGroup(group_name=group.name, reason="组内没有早于截止日的老品"))
            continue
        members.sort(key=lambda asin: origins[asin]["monthly_sales"] or 0, reverse=True)
        volume = sum(origins[asin]["monthly_sales"] or 0 for asin in members)
        # The target's title group is the likeliest place to find an existing solution.
        target_in_group = product.asin in group.product_ids
        if target_in_group and info.target_group is None:
            info.target_group = group.name
        ranked.append(((target_in_group, volume), group, members))

    info.eligible_group_count = len(ranked)
    ranked.sort(key=lambda row: row[0], reverse=True)
    # Selection equals a sequential walk (try groups in priority order until
    # max_groups have a usable representative; inside a group replace failed
    # representatives with the next legacy product). With k slots left, the next
    # k groups would all be tried anyway, so they are resolved together, and each
    # round fetches every group's shortfall concurrently. An ASIN appearing in
    # groups of several Markets is used once.
    loaded: dict[int, list[dict]] = {}
    position = 0
    while position < len(ranked) and sum(1 for rows in loaded.values() if rows) < max_groups:
        window = list(range(position, min(len(ranked), position + max_groups - sum(1 for rows in loaded.values() if rows))))
        position += len(window)
        cursors = dict.fromkeys(window, 0)
        for index in window:
            loaded[index] = []
        while True:
            wanted = []
            for index in window:
                members = ranked[index][2]
                need = per_group - len(loaded[index])
                take = []
                while need > len(take) and cursors[index] < len(members):
                    asin = members[cursors[index]]
                    cursors[index] += 1
                    if asin not in claimed:
                        claimed.add(asin)
                        take.append(asin)
                wanted.append((index, take))
            if not any(take for _, take in wanted):
                break
            facts = _load_listing_facts(product, [asin for _, take in wanted for asin in take])
            for index, take in wanted:
                for asin in take:
                    if isinstance(facts[asin], Result):
                        _fail(info, asin, facts[asin])
                    else:
                        loaded[index].append({**facts[asin], "listing_date": listing_dates[asin],
                                              "monthly_sales": origins[asin]["monthly_sales"]})

    groups = []
    for index, (_, group, members) in enumerate(ranked):
        if index not in loaded:
            info.skipped_groups.append(SkippedGroup(group_name=group.name, reason=f"超出 max_groups={max_groups}（本品所在组优先，其余按老品月销量排序）"))
        elif loaded[index]:
            groups.append({"group_name": group.name, "solution": group.solution,
                           "legacy_count": len(members), "members": loaded[index]})
        else:
            info.skipped_groups.append(SkippedGroup(group_name=group.name, reason="代表老品资料均无法补齐"))
    return groups


def _split(rows: dict[str, dict], *, as_of, min_age_months, min_lead_months, anchor, exclude) -> Result:
    return operations.run_calc("calc.product.legacy_split", {
        "products": [{"asin": asin, "listing_date": row["listing_date"]} for asin, row in rows.items()],
        "as_of": as_of, "min_age_months": min_age_months, "min_lead_months": min_lead_months,
        "anchor_date": anchor, "exclude_asins": sorted(exclude),
    })


def _solution_group(
    product: Product, target: dict, *, avoid_terms: list[str], as_of: date, anchor: str | None,
    min_age_months: int, min_lead_months: int, solution_pages: int, solution_max: int, screen_model: str,
    claimed: set[str], origins: dict[str, dict], listing_dates: dict[str, str], info: NoveltySample,
    usage: _Usage, notes: list[str],
) -> dict | None:
    generated = operations.run_analysis("analysis.product.solution_terms", {
        "asin": product.asin, "title": target["title"], "brand": product.brand,
        "bullet_points": target["bullet_points"], "avoid_terms": avoid_terms, "model": screen_model,
    })
    usage.add("solution_terms", generated.meta.usage)
    if generated.code != Code.OK:
        notes.append(f"方案词生成失败，本次未做方案词召回：{generated.message}")
        return None
    terms = generated.data["terms"]
    info.solution_terms = terms

    rows: dict[str, dict] = {}
    searched: set[str] = {term.lower() for term in avoid_terms}
    for extracted in terms:
        # Search is strict on long phrases; on zero results drop the leading
        # word (usually a modifier) and retry, down to two words.
        words = extracted.split()
        items: list[dict] = []
        while len(words) >= 2:
            term = " ".join(words)
            words = words[1:]
            if term in searched:
                continue
            searched.add(term)
            found = _search(term, solution_pages)
            if found.code != Code.OK:
                info.coverage.append(SearchCoverage(query=term, source="solution_search", pages=solution_pages, fetched=0))
                notes.append(f"方案词「{term}」检索失败：{found.message}")
                break
            items = [item for item in (found.data or {}).get("items", []) if isinstance(item, dict) and item.get("asin")]
            info.coverage.append(SearchCoverage(
                query=term, source="solution_search", pages=solution_pages,
                total=_reported_total(found), fetched=len(items),
            ))
            if items:
                break
        for item in items:
            rows.setdefault(str(item["asin"]).strip().upper(), {
                "title": str(item.get("title") or ""),
                "listing_date": item.get("listing_date") or item.get("available_date"),
                "monthly_sales": item.get("monthly_sales"),
                "source": "solution_search", "query": term,
            })
    if not rows:
        return None

    split = _split(rows, as_of=as_of, min_age_months=min_age_months, min_lead_months=min_lead_months,
                   anchor=anchor, exclude={product.asin, *claimed})
    if split.code != Code.OK:
        notes.append(f"方案词召回的上架日期筛选失败：{split.message}")
        return None
    candidates = [asin for asin in split.data["legacy_asins"] if rows[asin]["title"].strip()]
    if len(candidates) > MAX_PRESCREEN_CANDIDATES:
        notes.append(f"方案词召回有 {len(candidates)} 件早期商品，仅按检索顺序预筛前 {MAX_PRESCREEN_CANDIDATES} 件。")
        candidates = candidates[:MAX_PRESCREEN_CANDIDATES]
    info.solution_candidate_count = len(candidates)
    if not candidates:
        return None

    screened = operations.run_analysis("analysis.product.solution_prescreen", {
        "target": {"asin": product.asin, "title": target["title"], "bullet_points": target["bullet_points"]},
        "candidates": [{"asin": asin, "title": rows[asin]["title"]} for asin in candidates],
        "limit": max(PRESCREEN_LIMIT, solution_max), "model": screen_model,
    })
    usage.add("prescreen", screened.meta.usage)
    if screened.code != Code.OK:
        notes.append(f"方案词召回的标题预筛失败，本次未比较召回商品：{screened.message}")
        return None
    selected = [item["asin"] for item in screened.data["selected"]]
    info.solution_prescreened = selected
    if not selected:
        return None

    # Highest-ranked first; a failed detail load is replaced by the next pick.
    loaded: list[dict] = []
    cursor = 0
    while len(loaded) < solution_max and cursor < len(selected):
        batch = selected[cursor:cursor + solution_max - len(loaded)]
        cursor += len(batch)
        facts = _load_listing_facts(product, batch)
        for asin in batch:
            if isinstance(facts[asin], Result):
                _fail(info, asin, facts[asin])
                continue
            claimed.add(asin)
            listing_dates[asin] = split.data["listing_dates"][asin]
            origins[asin] = rows[asin]
            loaded.append({**facts[asin], "listing_date": listing_dates[asin], "monthly_sales": rows[asin]["monthly_sales"]})
    name = f"方案词召回：{' / '.join(terms)}"
    if not loaded:
        info.skipped_groups.append(SkippedGroup(group_name=name, reason="预筛候选的资料均无法补齐"))
        return None
    return {
        "group_name": name,
        "solution": f"以方案词「{'」「'.join(terms)}」检索（不设销量门槛）、经标题预筛判断可能与本品同方案的早期商品。",
        "legacy_count": len(selected), "members": loaded,
    }


def novelty(
    product: Product,
    terms: list[str] | None = None,
    pages: int = 2,
    min_age_months: int = 12,
    min_lead_months: int = 6,
    max_groups: int = 6,
    per_group: int = 3,
    existing_cap: int = 60,
    hot_sales: int = 100,
    solution_search: bool = True,
    solution_pages: int = 2,
    solution_max: int = 5,
    as_of: date | None = None,
    model: str = "pro",
    screen_model: str = "lite",
) -> Result:
    as_of = as_of or date.today()
    target = _listing_facts(product)
    if isinstance(target, Result):
        return target

    markets = _markets(product, terms)
    if isinstance(markets, Result):
        return markets
    usage = _Usage()

    # 1. Market samples (one per term), with search coverage.
    origins: dict[str, dict] = {}
    samples: list[tuple[Market, list[str]]] = []
    coverage: list[SearchCoverage] = []
    for market in markets:
        result = market.enrich("products", pages=pages)
        if result.code != Code.OK:
            return result
        asins = []
        for item in market.products or []:
            if not item.asin:
                continue
            asin = item.asin.strip().upper()
            asins.append(asin)
            origins.setdefault(asin, {
                "title": item.title or "",
                "listing_date": getattr(item, "listing_date", None) or item.available_date,
                "monthly_sales": item.monthly_sales, "source": "market_sample", "query": market.term,
            })
        coverage.append(SearchCoverage(
            query=market.term, source="market_sample", pages=pages,
            total=getattr(market, "search_total", None), fetched=len(asins),
        ))
        samples.append((market, asins))
    if not origins:
        return _missing("market.products")

    # 2. Earlier-than-target split; the target's own listing date anchors it.
    anchor = product.listing_date or (origins.get(product.asin) or {}).get("listing_date")
    split = _split(origins, as_of=as_of, min_age_months=min_age_months, min_lead_months=min_lead_months,
                   anchor=anchor, exclude={product.asin})
    if split.code != Code.OK:
        return split
    split_data = split.data
    listing_dates = {asin: split_data["listing_dates"][asin] for asin in split_data["legacy_asins"]}
    sample_size = len(origins)
    info = NoveltySample(
        market_term=markets[0].term, market_terms=[market.term for market in markets],
        term_source="input" if terms is not None else "reverse_keyword",
        cutoff_basis=split_data["cutoff_basis"], target_listing_date=split_data["anchor_date"],
        coverage=coverage, pages=pages, product_count=sample_size, legacy_count=len(listing_dates),
        recent_count=len(split_data["recent_asins"]), missing_date_asins=split_data["missing_date_asins"],
        eligible_group_count=0, compared_group_count=0, skipped_groups=[], failed_refs=[],
    )
    notes: list[str] = []

    # 3. Market groups by title classification.
    pooled: list[SimpleNamespace] = []
    used_names: set[str] = set()
    for market, asins in samples:
        legacy_here = [asin for asin in asins if asin in listing_dates]
        if not legacy_here:
            notes.append(f"市场「{market.term}」样本中没有早于截止日的老品，未做标题分组。")
            continue
        if not any(origins[asin]["title"].strip() for asin in legacy_here):
            notes.append(f"市场「{market.term}」的老品均缺少标题，未做标题分组。")
            continue
        classified = market.enrich("summary", pages=pages, model=model)
        usage.add("classification", classified.meta.usage)
        if classified.code != Code.OK:
            classified.meta.usage = usage.meta()
            return classified
        summary = market.summary
        if summary is None:
            return _missing("market.summary")
        info.failed_refs.extend(
            FailedRef(asin=item.item_id, reason=item.reason)
            for item in summary.unclassified if item.item_id in legacy_here
        )
        prefix = f"{market.term}｜" if len(markets) > 1 else ""
        for group in summary.groups:
            pooled.append(SimpleNamespace(
                name=_unique_name(prefix + group.name, used_names), solution=group.solution,
                product_ids=[asin.strip().upper() for asin in group.product_ids],
            ))
    claimed: set[str] = set()
    groups = _group_representatives(product, pooled, origins, listing_dates, info, max_groups, per_group, claimed)

    # 4. Solution-term recall: low-sales earlier attempts, own group outside max_groups.
    if solution_search:
        extra = _solution_group(
            product, target, avoid_terms=[market.term for market in markets], as_of=as_of, anchor=anchor,
            min_age_months=min_age_months, min_lead_months=min_lead_months, solution_pages=solution_pages,
            solution_max=solution_max, screen_model=screen_model, claimed=claimed, origins=origins,
            listing_dates=listing_dates, info=info, usage=usage, notes=notes,
        )
        if extra is not None:
            extra["group_name"] = _unique_name(extra["group_name"], used_names)
            groups.append(extra)
    if not groups:
        return err(Code.ERROR_MISSING_FIELDS, "没有可供图文比较的早期商品，详见 sample",
                   missing=["legacy_products"], data={"sample": info.model_dump(mode="json"), "limitations": notes},
                   usage=usage.meta())

    # 5. Image + bullet comparison, then deterministic scoring.
    analysis = operations.run_analysis("analysis.product.novelty", {
        "target": target, "groups": groups, "model": model,
    })
    usage.add("comparison", analysis.meta.usage)
    details = analysis.data if isinstance(analysis.data, dict) else {}
    info.skipped_groups.extend(SkippedGroup.model_validate(group) for group in details.get("skipped_groups", []))
    info.failed_refs.extend(FailedRef.model_validate(ref) for ref in details.get("failed_refs", []))
    if analysis.code != Code.OK:
        analysis.data = {**details, "sample": info.model_dump(mode="json")}
        analysis.meta.usage = usage.meta()
        return analysis
    judgements = analysis.data["groups"]
    info.compared_group_count = len(judgements)
    score = operations.run_calc("calc.product.novelty_score", {"groups": judgements, "existing_cap": existing_cap})
    if score.code != Code.OK:
        score.meta.usage = usage.meta()
        return score
    score_data = score.data
    kinds = {row["group_name"]: row for row in score_data["group_scores"]}

    matches, upgrades = [], []
    for group in judgements:
        kind = kinds[group["group_name"]]
        for asin in group["matched_asins"]:
            origin = origins[asin]
            common = {
                "asin": asin, "group_name": group["group_name"], "listing_date": listing_dates.get(asin),
                "monthly_sales": origin["monthly_sales"], "source": origin["source"], "query": origin["query"],
            }
            if kind["match_type"] == "same":
                hot = (origin["monthly_sales"] or 0) >= hot_sales
                matches.append(ExistingMatch(**common, match_type="existing_hot" if hot else "prior_attempt"))
            elif kind["match_type"] == "upgrade":
                upgrades.append(UpgradeMatch(**common, raised_dimensions=kind["raised_dimensions"]))
    closest = next(group for group in judgements if group["group_name"] == score_data["closest_group"])

    compared_count = sum(len(group["compared_asins"]) for group in judgements)
    if info.cutoff_basis == "target_listing":
        cutoff_text = f"老品口径：比本品上架日 {info.target_listing_date} 早至少 {min_lead_months} 个月（截止 {split_data['cutoff_date']}）。"
    else:
        cutoff_text = f"本品缺上架日期，老品口径退回评估日 {as_of} 往前 {min_age_months} 个月（截止 {split_data['cutoff_date']}）。"
    terms_text = "、".join(f"「{term}」" for term in info.market_terms)
    limitations = [
        cutoff_text,
        f"市场取样词 {terms_text}（{'调用方传入' if info.term_source == 'input' else '反查主词'}）前 {pages} 页共 {sample_size} 件，"
        f"其中老品 {info.legacy_count} 件；方案词召回早期商品 {info.solution_candidate_count} 件，标题预筛保留 {len(info.solution_prescreened)} 件。"
        f"实际比较 {info.compared_group_count} 组、{compared_count} 件早期商品；existing=false 仅表示在这些商品中未发现同类方案。",
        "市场组按标题分组，本品所在组优先，其余按组内老品月销量排序，每组取高销量代表；方案词召回组不设销量门槛、不占 max_groups。",
        "同方案判定要求原理、形态、功能三个维度都 ≤1 级；任一 ≥2 级记为改良款（upgrades），不计入 existing。"
        "existing=true 时创新分取匹配组得分并按 existing_cap 封顶；否则取最接近组的得分。",
        f"existing_matches 中月销量 ≥ {hot_sales} 为 existing_hot（卖起来的老品），否则为 prior_attempt（做过但没卖起来）。",
        *notes,
        *analysis.data.get("limitations", []),
    ]
    if info.missing_date_asins:
        limitations.append(f"市场样本中 {len(info.missing_date_asins)} 件商品没有有效上架日期，已排除。")
    if info.target_group is None and info.eligible_group_count > max_groups:
        guidance = "可调大 max_groups（上限 12）复查。" if max_groups < 12 else "max_groups 已达到上限 12。"
        limitations.append(
            f"本品未归入含老品的 {info.eligible_group_count} 个候选组，本次按组内老品月销量排序，最多比较 {max_groups} 组。"
            f"低销量组中的相似方案可能遗漏。跳过原因见 sample.skipped_groups。{guidance}"
        )

    output = ProductNoveltyOutput(
        asin=product.asin, as_of=as_of, cutoff_date=split_data["cutoff_date"], cutoff_basis=split_data["cutoff_basis"],
        min_age_months=min_age_months, min_lead_months=min_lead_months, hot_sales_threshold=hot_sales,
        existing_matches=matches, upgrades=upgrades, novel_points=closest["novel_points"], groups=judgements,
        sample=info, limitations=limitations, **score_data,
    )
    return ok(data=output.model_dump(mode="json"), usage=usage.meta())
