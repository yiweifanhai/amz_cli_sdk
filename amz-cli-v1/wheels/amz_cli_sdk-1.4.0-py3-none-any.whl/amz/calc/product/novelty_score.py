"""Deterministic innovation score from model-graded novelty dimensions.

Each legacy group scores ``100 × Σ weight × level / 3``. A model "same solution"
whose mechanism, form or function is graded level 2+ contradicts the definition
(only tweaks) and is recorded as ``upgrade``, not existing. When any group is the
same solution, ``existing`` is true: the raw score comes from the lowest-scoring
matched group (how far the product moved from the solution it repeats) and the
final score is capped (default 60). Otherwise the raw score is the lowest group
score, because the closest legacy solution bounds how new the product is.
"""

from __future__ import annotations

from amz.envelope import Result, ok
from amz.registry import capability
from amz.schemas.novelty import (
    DIMENSION_WEIGHTS, MAX_LEVEL, STRUCTURAL_DIMENSIONS, UPGRADE_LEVEL,
    GroupScore, NoveltyScoreInput, NoveltyScoreOutput,
)


def match_type(group) -> tuple[str, list[str]]:
    """same_solution is only kept when mechanism/form/function differ by tweaks (<= level 1)."""
    if not group.same_solution:
        return "different", []
    raised = [grade.dimension for grade in group.dimensions
              if grade.dimension in STRUCTURAL_DIMENSIONS and grade.level >= UPGRADE_LEVEL]
    return ("upgrade", sorted(raised, key=STRUCTURAL_DIMENSIONS.index)) if raised else ("same", [])


def group_score(dimensions) -> int:
    total = sum(DIMENSION_WEIGHTS[grade.dimension] * grade.level for grade in dimensions)
    return round(100 * total / MAX_LEVEL)


@capability(
    "calc.product.novelty_score",
    description="按六个维度等级计算创新分；与老品方案相同时封顶",
    input_model=NoveltyScoreInput,
    output_model=NoveltyScoreOutput,
)
def novelty_score(groups, existing_cap: int = 60) -> Result:
    data = NoveltyScoreInput(groups=groups, existing_cap=existing_cap)
    scores = []
    for group in data.groups:
        kind, raised = match_type(group)
        scores.append(GroupScore(
            group_name=group.group_name, same_solution=group.same_solution, match_type=kind,
            raised_dimensions=raised, score=group_score(group.dimensions),
        ))
    matched = [item for item in scores if item.match_type == "same"]
    existing = bool(matched)
    # A repeated solution defines the baseline; unmatched groups cannot lower it.
    closest = min(matched or scores, key=lambda item: item.score)
    raw = closest.score
    final = min(raw, data.existing_cap) if existing else raw
    return ok(data=NoveltyScoreOutput(
        existing=existing, innovation_score=final, raw_score=raw,
        score_capped=existing and raw > data.existing_cap, existing_cap=data.existing_cap,
        closest_group=closest.group_name, group_scores=scores,
    ).model_dump(mode="json"))
