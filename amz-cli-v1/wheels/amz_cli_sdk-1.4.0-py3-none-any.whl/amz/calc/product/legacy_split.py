"""Split a Market sample into legacy, recent and undated products.

A product is legacy when its first-available date is on or before the target
product's listing date minus ``min_lead_months`` (fallback: ``as_of`` minus
``min_age_months``) calendar months. Dates are compared as
calendar dates, so timezone-aware and naive inputs cannot raise.
"""

from __future__ import annotations

import calendar
from datetime import date, datetime

from amz.envelope import Code, Result, err, ok
from amz.registry import capability
from amz.schemas.novelty import LegacySplitInput, LegacySplitOutput


def months_before(day: date, months: int) -> date:
    """Calendar subtraction; month-end days clamp (2025-03-31 − 1 → 2025-02-28)."""
    total = day.year * 12 + (day.month - 1) - months
    year, month = divmod(total, 12)
    month += 1
    return date(year, month, min(day.day, calendar.monthrange(year, month)[1]))


def parse_listing_date(value: str | None) -> date | None:
    if not value:
        return None
    try:
        # Validate the entire ISO date or timestamp; compare its local calendar day.
        return datetime.fromisoformat(value.strip()).date()
    except ValueError:
        return None


@capability(
    "calc.product.legacy_split",
    description="按上架日期把样本分为早于本品的老品、较新商品和缺日期商品",
    input_model=LegacySplitInput,
    output_model=LegacySplitOutput,
)
def legacy_split(
    products, as_of, min_age_months: int = 12, exclude_asins=(),
    anchor_date: str | None = None, min_lead_months: int = 6,
) -> Result:
    """Legacy = listed on or before the cutoff.

    With a valid target listing date (``anchor_date``) the cutoff is that date
    minus ``min_lead_months``; otherwise ``as_of`` minus ``min_age_months``.
    The cutoff never exceeds ``as_of``, so historical back-tests stay causal.
    """
    data = LegacySplitInput(
        products=products, as_of=as_of, min_age_months=min_age_months, exclude_asins=exclude_asins,
        anchor_date=anchor_date, min_lead_months=min_lead_months,
    )
    anchor = parse_listing_date(data.anchor_date)
    try:
        if anchor is not None:
            cutoff, basis = min(months_before(anchor, data.min_lead_months), data.as_of), "target_listing"
        else:
            cutoff, basis = months_before(data.as_of, data.min_age_months), "as_of"
    except ValueError:
        return err(Code.ERROR_PARAM, "reference date is too early to subtract the lead months")
    excluded = {asin.strip().upper() for asin in data.exclude_asins}
    legacy, recent, missing, dates, seen = [], [], [], {}, set()
    for product in data.products:
        if product.asin in excluded or product.asin in seen:
            continue
        seen.add(product.asin)
        listed = parse_listing_date(product.listing_date)
        if listed is None or listed > data.as_of:
            missing.append(product.asin)
            continue
        dates[product.asin] = listed.isoformat()
        (legacy if listed <= cutoff else recent).append(product.asin)
    return ok(data=LegacySplitOutput(
        cutoff_date=cutoff, cutoff_basis=basis, anchor_date=anchor, legacy_asins=legacy, recent_asins=recent,
        missing_date_asins=missing, listing_dates=dates,
    ).model_dump(mode="json"))
