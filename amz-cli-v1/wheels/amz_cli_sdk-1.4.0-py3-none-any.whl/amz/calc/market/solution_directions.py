"""Turn tagged product lines into evidence-graded solution directions.

Deterministic. The model only tagged lines (relation, axis values, change nature);
this calculation decides roles, grades and cards from sales facts:

- comparison: lines launched within ``new_months`` with sales vs older lines with sales
- 默认形态: ≥ ``default_share`` of the sample and new lines are not clearly higher
- 当前主流: highest share among older lines (needs a base of ``min_base_lines``)
- 节日季节: never a card
- 候选: has verified new lines. A = ≥2 verified + ≥1 official 200+ + share shift ≥ ``min_shift``;
  B = ≥2 verified; C = 1. Without a large enough base the shift is unknown, so at most B.
- 新方案 candidates become cards; 简化降配 / 加量套装 are listed apart (minor_cards).
"""
from __future__ import annotations

from collections import Counter
from datetime import date
from statistics import median

from amz.calc.market.solution_lines import follow_table, history_of, matched_growth, month_of, shift_month
from amz.envelope import Result, ok
from amz.registry import capability
from amz.schemas.solution_directions import (
    KIND_TYPE, OTHER, UNKNOWN, DirectionsThresholds, SolutionDirections, SolutionDirectionsInput,
)

LIMITATIONS = [
    "方案标签由模型只看标题和价格打出，结构差异只在图片里的商品可能分错；同一样本两次打标可能不同。",
    "证据等级由程序按规则给出，阈值未经回测；A 级只说明证据硬，不代表创新程度高。",
    "份额与起量都只基于搜索第一页的商品，有幸存者偏差。",
]


def _med(values):
    values = [v for v in values if v is not None]
    return round(median(values), 4) if values else None


def _round(row: dict) -> dict:
    return {k: round(v, 4) if isinstance(v, float) else v for k, v in row.items()}


def _notes(row: dict, market_growth: float | None) -> list[str]:
    notes = []
    if row["grade"] == "C":
        notes.append("只有 1 条新品线过线，可能是个别卖家运营强，不能证明这个方向成立")
    if not row["official_verified"]:
        notes.append("过线新品都没有官方 200+ 标记，销量只有第三方估算")
    if row["suspected"]:
        notes.append(f"另有 {row['suspected']} 条疑似老链接换新 ASIN，已排除在证据外")
    if row["shift"] is None:
        notes.append("老品对照组太小，没法比较新老份额，等级最高 B")
    newest = row["follow"][0]
    if newest["lines"] >= 5 and not newest["over_gate"]:
        notes.append(f"最近上架的 {newest['lines']} 条线还没有一条过线：可能窗口在收窄，也可能只是时间太短")
    if row["price_verified"] and row["price_older"] and row["price_verified"] < row["price_older"] * 0.85:
        notes.append(f"过线新品中位价 ${row['price_verified']:.2f}，比同方向老品 ${row['price_older']:.2f} 低 15% 以上，进入者在降价")
    if row["rating_verified"] is not None and row["rating_verified"] < 4.0:
        notes.append(f"过线新品评分中位 {row['rating_verified']:.1f}，口碑偏低：是改良空间，也是退货风险")
    growth = row["growth_3m"]
    if growth is not None and row["growth_3m_lines"] >= 3 and growth < 0 and (market_growth is None or market_growth >= 0):
        notes.append(f"这个方向里有完整记录的 {row['growth_3m_lines']} 条老商品线近 3 个月销量 {growth:+.0%}，老需求在走弱")
    return notes


def directions(lines: list[dict], tags: dict, as_of: date, t: DirectionsThresholds,
               taobao_prices: dict[str, float] | None = None) -> dict:
    taobao_prices = taobao_prices or {}
    items = {i["item_id"]: (i["rel"], i["values"]) for i in tags["items"]}
    axes_in = tags["axes"]
    on = [l for l in lines if (items.get(l["asin"]) or (None,))[0] == "T"]
    sold = [l for l in on if (l["monthly_units"] or 0) > 0]
    recent = [l for l in sold if l["new"]]
    base = [l for l in sold if l["age_months"] is not None and not l["new"]]
    base_ids = {l["asin"] for l in base}
    has_base = len(base) >= t.min_base_lines and bool(recent)
    months = [shift_month(month_of(as_of), -i) for i in range(12, 0, -1)]
    histories = {l["asin"]: history_of(l) for l in on}
    market_growth, _ = matched_growth(sold, as_of)
    market_price = _med([l["price_usd"] for l in sold])
    taobao = [(item_id, values) for item_id, (rel, values) in items.items()
              if rel == "T" and item_id.startswith("taobao:")]

    def share(group, members):
        whole = sum(l["monthly_units"] for l in group)
        return sum(l["monthly_units"] for l in group if l["asin"] in members) / whole if whole else None

    axes, candidates = [], []
    for index, axis in enumerate(axes_in):
        rows = []
        for value in axis["values"]:
            group = [l for l in on if items[l["asin"]][1][index] == value["v"]]
            tb = [taobao_prices.get(i.removeprefix("taobao:")) for i, vals in taobao if vals[index] == value["v"]]
            if not group and not tb:
                continue
            members = {l["asin"] for l in group}
            verified = sorted((l for l in group if l["verified"]), key=lambda l: -(l["monthly_units"] or 0))
            recent_share, base_share = share(recent, members), share(base, members)
            shift = recent_share - base_share if has_base and recent_share is not None and base_share is not None else None
            series = []
            for month in months:
                whole = sum(h[month] for h in histories.values() if month in h)
                part = sum(histories[a][month] for a in members if month in histories[a])
                series.append((month, round(part / whole, 4) if whole else None))
            older = [l for l in group if l["asin"] in base_ids]
            growth, growth_lines = matched_growth([l for l in group if (l["monthly_units"] or 0) > 0], as_of)
            launches = sorted(l["launch"] for l in verified if l["launch"])
            rows.append(_round({
                "axis": axis["name"], "kind": axis["kind"], "value": value["v"], "desc": value.get("desc") or "",
                "nature": value.get("nature") or "新方案", "lines": len(group),
                "share": share(sold, members), "recent_share": recent_share, "base_share": base_share, "shift": shift,
                "verified": [l["asin"] for l in verified], "official_verified": sum(l["official_ok"] for l in verified),
                "aba_verified": sum(bool((l.get("aba") or {}).get("weeks_13")) for l in verified),
                "suspected": sum(bool(l["suspect"]) for l in group), "follow": follow_table(group, t),
                "price_median": _med([l["price_usd"] for l in group if (l["monthly_units"] or 0) > 0]),
                "price_verified": _med([l["price_usd"] for l in verified]),
                "price_older": _med([l["price_usd"] for l in older]),
                "m1_verified": _med([l["m1"] for l in verified]),
                "revenue_verified": _med([l["monthly_revenue"] for l in verified]),
                "rating_verified": _med([l["rating"] for l in verified]),
                "reviews_verified": _med([l["count_review"] for l in verified]),
                "launch_verified": (launches[0], launches[-1]) if launches else None,
                "growth_3m": growth, "growth_3m_lines": growth_lines,
                "taobao_count": len(tb), "taobao_price_median_cny": _med(tb),
                "series": series, "top": [l["asin"] for l in sorted(group, key=lambda l: -(l["monthly_units"] or 0))[:8]],
            }))
        leader = max(rows, key=lambda r: r["base_share"] or 0) if has_base and rows else None
        for row in rows:
            flat = row["shift"] is None or row["shift"] < t.min_shift
            if row["nature"] == "节日季节":
                row["role"] = "节日季节"
            elif (row["share"] or 0) >= t.default_share and flat:
                row["role"] = "默认形态"
            elif row is leader and (row["base_share"] or 0) > 0:
                row["role"] = "当前主流"
            elif row["verified"]:
                row["role"] = "候选"
                n = len(row["verified"])
                if n >= 2 and row["official_verified"] and row["shift"] is not None and row["shift"] >= t.min_shift:
                    row["grade"] = "A"
                else:
                    row["grade"] = "B" if n >= 2 else "C"
                candidates.append((index, row))
            else:
                row["role"] = "无验证新品"
        axes.append({"name": axis["name"], "kind": axis["kind"], "values": rows})

    by_asin = {l["asin"]: l for l in on}
    candidates.sort(key=lambda c: (c[1]["grade"], -len(c[1]["verified"]), -(c[1]["shift"] or 0),
                                   -sum(by_asin[a]["monthly_units"] or 0 for a in c[1]["verified"])))
    amazon_rel = Counter((items.get(l["asin"]) or (None,))[0] for l in lines)
    tagged = sum(v for k, v in amazon_rel.items() if k)
    noisy = bool(tagged) and amazon_rel.get("X", 0) / tagged > t.noisy_share
    cards, minor = [], []
    for index, row in candidates:
        bucket = cards if row["nature"] == "新方案" else minor
        if len(bucket) == t.max_cards:
            continue
        mine = set(row["verified"])
        if any(len(mine & set(c["verified"])) / len(mine | set(c["verified"])) >= 0.75 for c in bucket):
            continue
        verified = [by_asin[a] for a in row["verified"]]
        combo = []
        for other, axis in enumerate(axes_in):
            if other == index or len(verified) < 2:
                continue
            counts = Counter(v for l in verified if (v := items[l["asin"]][1][other]) not in (UNKNOWN, OTHER))
            if counts:
                value, k = counts.most_common(1)[0]
                if k / len(verified) >= 0.6:
                    combo.append({"axis": axis["name"], "value": value, "k": k, "n": len(verified)})
        notes = _notes(row, market_growth)
        if noisy:
            notes.append(f"搜索第一页 {tagged} 条里有 {amazon_rel.get('X', 0)} 条离题，样本偏小，谨慎看")
        entries = sum(f["lines"] for f in row["follow"])
        ramped = sum(f["over_gate"] for f in row["follow"])
        bucket.append({**row, "type": KIND_TYPE[row["kind"]] if row["nature"] == "新方案" else row["nature"],
                       "combo": combo, "entries_6m": entries, "ramped_6m": ramped,
                       "ramp_rate_6m": round(ramped / entries, 4) if entries else None,
                       "notes": notes, "market_price_median": market_price, "market_growth_3m": market_growth})
    return {"axes": axes, "cards": cards, "minor_cards": minor, "on_topic": amazon_rel.get("T", 0),
            "accessory": amazon_rel.get("A", 0), "off_topic": amazon_rel.get("X", 0),
            "untagged": amazon_rel.get(None, 0), "has_base": has_base, "noisy": noisy,
            "tags": {l["asin"]: items[l["asin"]] for l in lines if l["asin"] in items},
            "limitations": LIMITATIONS}


@capability(
    "calc.market.solution_directions",
    description="按方案标签计算每个方向的新品证据（已验证新品线、官方标记、新老份额变化、跟进起量），定 A/B/C 并出方向卡",
    input_model=SolutionDirectionsInput, output_model=SolutionDirections,
)
def solution_directions(current_date: date, lines: list[dict], tags: dict,
                        taobao_prices_cny: dict | None = None, thresholds: dict | None = None) -> Result:
    data = SolutionDirectionsInput(current_date=current_date, lines=lines, tags=tags,
                                   taobao_prices_cny=taobao_prices_cny or {}, thresholds=thresholds or {})
    result = directions([l.model_dump() for l in data.lines], data.tags.model_dump(), data.current_date,
                        data.thresholds, data.taobao_prices_cny)
    return ok(data=SolutionDirections.model_validate(result).model_dump(mode="json"))
