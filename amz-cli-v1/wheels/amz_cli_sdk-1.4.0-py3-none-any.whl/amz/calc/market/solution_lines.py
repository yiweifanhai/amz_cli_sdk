"""Merge a search sample into product lines and describe the market's new-product structure.

Deterministic. One line = one parent ASIN (competing-lookup lists several variants,
each carrying the parent's sales). A line's launch is the earliest sibling date in the
sample, moved earlier when its sales history starts before that date, so a new child
under an old parent is not a new product. Relist rules are the same as
``calc.market.solution_validation``; growth compares the same lines like
``calc.market.solution_signals``.
"""
from __future__ import annotations

from calendar import monthrange
from collections import Counter
from datetime import date
from statistics import median

from amz.envelope import Result, ok
from amz.registry import capability
from amz.schemas.solution_directions import (
    DirectionsThresholds, SampleRow, SolutionLinesInput, SolutionLinesResult,
)

DAYS_PER_MONTH = 30.44
UNKNOWN_COHORT = "未知"

LIMITATIONS = [
    "月销量、月销额和逐月销量来自第三方估算；'官方 200+' 是亚马逊前台'过去一个月 X+ 件'标记，是下限。",
    "样本只有搜索结果第一页，没起量的进入者大多不在里面：起量率和新品份额偏乐观（幸存者偏差）。",
    "同父体变体共用父体销量，已合并为一条商品线；样本外的老变体无法识别。",
    "疑似老链接规则是启发式（评论占比、上架当月销量异常），可能误判。",
]


def _med(values):
    values = [v for v in values if v is not None]
    return median(values) if values else None


def month_of(d: date) -> str:
    return f"{d.year:04d}-{d.month:02d}"


def shift_month(month: str, delta: int) -> str:
    index = int(month[:4]) * 12 + int(month[5:]) - 1 + delta
    return f"{index // 12:04d}-{index % 12 + 1:02d}"


def _month_days(month: str) -> int:
    return monthrange(int(month[:4]), int(month[5:]))[1]


def _cohorts(t: DirectionsThresholds) -> list[tuple[str, int | None]]:
    return [(f"≤{t.fresh_months}月", t.fresh_months), (f"{t.fresh_months}–{t.new_months}月", t.new_months),
            ("6–12月" if t.new_months == 6 else f"{t.new_months}–12月", 12), ("12–24月", 24), (">24月", None)]


def _launch(rows: list[SampleRow]) -> date | None:
    dates = sorted(r.available_date for r in rows if r.available_date)
    launch = dates[0] if dates else None
    sold = sorted(p.month for p in rows[0].sales_trend if p.units > 0)
    if launch and sold and sold[0] < month_of(launch):
        launch = date(int(sold[0][:4]), int(sold[0][5:]), 1)
    return launch


def relist_reasons(launch: date, units, reviews, history: dict[str, int], as_of: date,
                   t: DirectionsThresholds) -> list[str]:
    """Signals that the line's reviews or sales were inherited from an older listing."""
    age = max((as_of - launch).days, 1)
    reasons = []
    if units and reviews is not None and reviews >= t.min_reviews_for_rate:
        rate = reviews / (units * age / 30) * 100
        if rate > t.max_review_rate_pct:
            reasons.append(f"上架 {age} 天已有 {reviews} 条评论，约占上架以来估算销量的 {rate:.0f}%，评论可能继承自老链接")
    launch_month, current = month_of(launch), month_of(as_of)
    later = [u / _month_days(m) for m, u in history.items() if launch_month < m < current]
    if launch_month < current and launch_month in history and later and max(later) > 0:
        active = _month_days(launch_month) - launch.day + 1
        ratio = history[launch_month] / active / max(later)
        if ratio > t.max_launch_rate_ratio:
            reasons.append(f"上架当月只有 {active} 天却记了 {history[launch_month]} 件，"
                           f"日均是之后最好月份的 {ratio:.1f} 倍，销量记录可能来自老链接")
    return reasons


def build_lines(rows: list[SampleRow], as_of: date, t: DirectionsThresholds) -> list[dict]:
    groups: dict[str, list[SampleRow]] = {}
    for row in rows:
        groups.setdefault(row.parent_asin or row.asin, []).append(row)
    lines = []
    for parent, group in groups.items():
        head = group[0]
        launch = _launch(group)
        if launch and launch > as_of:
            launch = None
        age = (as_of - launch).days / DAYS_PER_MONTH if launch else None
        units, price = head.monthly_units, head.price_usd
        revenue = head.monthly_revenue if head.monthly_revenue is not None else (
            units * price if units is not None and price is not None else None)
        official = [r.official_units for r in group if r.official_units is not None]
        history = {p.month: p.units for p in head.sales_trend}
        if launch:
            history = {m: u for m, u in history.items() if m >= month_of(launch)}
        cohort = UNKNOWN_COHORT if age is None else next(
            label for label, limit in _cohorts(t) if limit is None or age <= limit)
        line = {
            "asin": head.asin, "asins": [r.asin for r in group], "parent_asin": parent,
            "title": head.title, "image_url": head.image_url, "brand": head.brand,
            "price_usd": price, "monthly_units": units, "monthly_revenue": revenue,
            "rating": head.rating, "count_review": head.count_review, "m1": head.m1,
            "launch": launch, "age_months": round(age, 2) if age is not None else None, "cohort": cohort,
            "official_units": max(official) if official else None,
            "amazon_choice": any(r.amazon_choice for r in group), "best_seller": any(r.best_seller for r in group),
            "fresh": age is not None and age <= t.fresh_months,
            "new": age is not None and age <= t.new_months,
            "sales": [{"month": m, "units": u} for m, u in sorted(history.items())],
            "aba": None,
        }
        line["over_gate"] = (units or 0) > t.min_monthly_units and (revenue or 0) > t.min_monthly_revenue
        line["suspect"] = (relist_reasons(launch, units, head.count_review, history, as_of, t)
                           if line["new"] and line["over_gate"] else [])
        line["verified"] = line["new"] and line["over_gate"] and not line["suspect"]
        line["official_ok"] = line["official_units"] is not None and line["official_units"] >= t.official_min_units
        lines.append(line)
    return lines


def history_of(line: dict) -> dict[str, int]:
    return {p["month"]: p["units"] for p in line["sales"]}


def matched_growth(lines: list[dict], as_of: date) -> tuple[float | None, int]:
    """Same lines, last 3 complete months vs the 3 before; lines launched inside the window are excluded."""
    end = shift_month(month_of(as_of), -1)
    recent = [shift_month(end, -i) for i in (2, 1, 0)]
    previous = [shift_month(m, -3) for m in recent]
    need = set(recent) | set(previous)
    recent_sum = base_sum = count = 0
    for line in lines:
        history = history_of(line)
        if not need <= history.keys():
            continue
        count += 1
        recent_sum += sum(history[m] for m in recent)
        base_sum += sum(history[m] for m in previous)
    return (round(recent_sum / base_sum - 1, 4) if count and base_sum > 0 else None), count


def follow_table(lines: list[dict], t: DirectionsThresholds) -> list[dict]:
    """Recent entrants by launch window: how many lines, how many cleared the gate."""
    rows = []
    windows = ((f"≤{t.fresh_months}月", lambda l: l["fresh"]),
               (f"{t.fresh_months}–{t.new_months}月", lambda l: l["new"] and not l["fresh"]))
    for label, pick in windows:
        group = [l for l in lines if pick(l)]
        rows.append({"window": label, "lines": len(group),
                     "over_gate": sum(l["over_gate"] and not l["suspect"] for l in group),
                     "official_200": sum(l["official_ok"] and not l["suspect"] for l in group),
                     "suspected": sum(bool(l["suspect"]) for l in group)})
    return rows


def attach_aba(lines: list[dict], rows, as_of: date) -> dict | None:
    """Mark lines that held an ABA top-3 click slot for the main term; summarise the last 13 weeks."""
    rows = [r for r in rows if r.week <= as_of]
    if not rows:
        return None
    owner = {a: i for i, line in enumerate(lines) for a in {*line["asins"], line["parent_asin"]}}
    last = max(r.week for r in rows)
    cut = date.fromordinal(last.toordinal() - 7 * 13)
    by_line: dict[int, list] = {}
    for row in rows:
        if row.asin in owner:
            by_line.setdefault(owner[row.asin], []).append(row)
    for index, hits in by_line.items():
        recent = [h for h in hits if h.week > cut]
        clicks = [h.click_share for h in recent if h.click_share is not None]
        convs = [h.conversion_share for h in recent if h.conversion_share is not None]
        lines[index]["aba"] = {
            "weeks_13": len({h.week for h in recent}), "weeks_52": len({h.week for h in hits}),
            "first_week": min(h.week for h in hits),
            "click_share": round(sum(clicks) / len(clicks), 2) if clicks else None,
            "conversion_share": round(sum(convs) / len(convs), 2) if convs else None,
        }
    recent = [r for r in rows if r.week > cut]
    return {"last_week": last, "weeks": len({r.week for r in recent}), "slots": len(recent),
            "asins": len({r.asin for r in recent}),
            "new_slots": sum(1 for r in recent if r.asin in owner and lines[owner[r.asin]]["new"]),
            "unknown_slots": sum(1 for r in recent if r.asin not in owner)}


def structure(lines: list[dict], as_of: date, t: DirectionsThresholds, aba: dict | None) -> dict:
    sold = [l for l in lines if (l["monthly_units"] or 0) > 0]
    units = sum(l["monthly_units"] for l in sold)
    revenue = sum(l["monthly_revenue"] or 0 for l in sold)

    def share(pick):
        return sum(l["monthly_units"] for l in sold if pick(l)) / units if units else None

    cohorts = []
    for label in [c[0] for c in _cohorts(t)] + [UNKNOWN_COHORT]:
        group = [l for l in lines if l["cohort"] == label]
        if label == UNKNOWN_COHORT and not group:
            continue
        active = [l for l in group if (l["monthly_units"] or 0) > 0]
        cohorts.append({
            "cohort": label, "lines": len(group), "sold": len(active),
            "units_share": sum(l["monthly_units"] for l in active) / units if units else None,
            "revenue_share": sum(l["monthly_revenue"] or 0 for l in active) / revenue if revenue else None,
            "revenue_median": _med([l["monthly_revenue"] for l in active]),
            "over_gate": sum(l["over_gate"] for l in group), "official_200": sum(l["official_ok"] for l in group),
        })
    verified = [l for l in lines if l["verified"]]
    new_share = share(lambda l: l["new"])
    if new_share is not None and new_share >= t.pure_new_share:
        kind = "纯新市场"
    elif len(verified) >= 2:
        kind = "新品破局"
    else:
        kind = "单点新品" if verified else "老品主导"
    launched = Counter(month_of(l["launch"]) for l in lines if l["launch"])
    current = month_of(as_of)
    growth, growth_lines = matched_growth(sold, as_of)
    return {
        "type": kind, "lines": len(lines), "sold": len(sold),
        "fresh_lines": sum(l["fresh"] for l in lines), "fresh_share": share(lambda l: l["fresh"]),
        "new_lines": sum(l["new"] for l in lines), "new_share": new_share,
        "verified_lines": len(verified), "official_lines": sum(l["official_ok"] for l in verified),
        "suspected_lines": sum(bool(l["suspect"]) for l in lines),
        "growth_3m": growth, "growth_3m_lines": growth_lines, "cohorts": cohorts, "follow": follow_table(lines, t),
        "entries": [(m, launched.get(m, 0)) for m in (shift_month(current, -i) for i in range(11, -1, -1))],
        "aba": aba,
    }


@capability(
    "calc.market.solution_lines",
    description="把搜索样本按父体合并成商品线，判定已验证新品、疑似老链接、官方销量标记和 ABA 前三，并给出市场新品结构",
    input_model=SolutionLinesInput, output_model=SolutionLinesResult,
)
def solution_lines(current_date: date, rows: list[dict], aba_top3: list[dict] | None = None,
                   thresholds: dict | None = None) -> Result:
    data = SolutionLinesInput(current_date=current_date, rows=rows, aba_top3=aba_top3 or [],
                              thresholds=thresholds or {})
    t, as_of = data.thresholds, data.current_date
    lines = build_lines(data.rows, as_of, t)
    aba = attach_aba(lines, data.aba_top3, as_of)
    result = SolutionLinesResult(current_date=as_of, thresholds=t, lines=lines,
                                 structure=structure(lines, as_of, t, aba), limitations=LIMITATIONS)
    return ok(data=result.model_dump(mode="json"))
