"""内置能力发现。

集中维护需要通过导入触发 ``@capability`` 的模块，SDK、CLI 与测试共用，
避免只有 CLI 能看到完整注册表。
"""

from __future__ import annotations

from importlib import import_module


_BUILTIN_MODULES = (
    "amz.data.product",
    "amz.data.taobao",
    "amz.data.keyword",
    "amz.data.market",
    "amz.data.supply",
    "amz.data.category",
    "amz.data.search",
    "amz.data.ads",
    "amz.data.fx",
    "amz.calc.fba",
    "amz.calc.margin",
    "amz.calc.finance",
    "amz.calc.cosmo",
    "amz.calc.demand",
    "amz.calc.keyword",
    "amz.calc.market",
    "amz.calc.traffic",
    "amz.calc.listing",
    "amz.calc.material",
    "amz.calc.voc",
    "amz.analysis.product.cosmo",
    "amz.analysis.product.strengths",
    "amz.analysis.product.weaknesses",
    "amz.analysis.product.use_insights",
    "amz.analysis.product.praise",
    "amz.analysis.product.wishlist",
    "amz.analysis.product.material",
    "amz.analysis.product.copyability",
    "amz.analysis.product.compare",
    "amz.analysis.product.listing_rewrite",
    "amz.analysis.product.listing_insert",
    "amz.analysis.product.listing_allocate",
    "amz.analysis.product.listing_part_rewrite",
    "amz.analysis.product.cosmo_classify",
    "amz.analysis.product.classify",
    "amz.analysis.market.classify",
    "amz.analysis.market.cosmo",
    "amz.analysis.market.cosmo_aggregate",
    "amz.analysis.market.cosmo_merge",
    "amz.analysis.market.demand",
    "amz.analysis.market.timing",
    "amz.analysis.market.success_factors",
    "amz.analysis.market.gap",
    "amz.analysis.market.proposals",
    "amz.analysis.market.price_dimension",
    "amz.analysis.market.dimensions",
    "amz.analysis.keyword.relevance",
    "amz.analysis.keyword.score",
    "amz.analysis.keyword.gap",
    "amz.analysis.keyword.cluster",
    "amz.analysis.taobao_market.classify",
)


def load_builtin_capabilities() -> None:
    """幂等导入所有内置能力模块。"""
    for module_name in _BUILTIN_MODULES:
        import_module(module_name)
    # 实体 lazy getter 注册为能力（幂等；需在 data/calc/analysis 导入后执行）
    from amz.entities.bridge import register_entity_capabilities

    register_entity_capabilities()
    # composite 能力（validate/compile/scaffold）+ 已发现 pipeline 注册为 composite.<name>
    import_module("amz.composite.capabilities")
    from amz.composite import register_pipelines

    register_pipelines()

    # 依赖完整性校验：全部注册完成后统一检查 requires 引用。
    from amz.registry import registry

    issues = registry.validate_requires()
    if issues:
        raise RuntimeError(
            "capability requires validation failed:\n  " + "\n  ".join(issues)
        )
