"""
Keyword 实体：词维度的一切 — Pydantic v2 模型，字段定义直接包含辅助模型。

Keyword 关注搜索词本身的特征：搜索量、趋势、ABA 排名、四维评分、聚类。
市场分析（竞品统计、价格带、垄断度等）已拆分到 Market 实体。
"""

from __future__ import annotations

from typing import Any, ClassVar, TYPE_CHECKING, cast
from copy import deepcopy
from functools import wraps
import inspect

from pydantic import BaseModel, Field

from amz.entities.base import Entity, EnrichSpec, lazy_field
from amz.schemas.entity_ref import EntityRef, keyword_ref, normalize_term
from amz.envelope import Result, ok, err, Code
from amz.schemas.data_outputs import CompetingItemOutput

if TYPE_CHECKING:
    from amz.entities.market import Market, MarketProfile, MarketStats, Opportunity


def _with_candidate_keywords(method):
    """Resolve supplied candidate data before the lazy cache key is built."""
    @wraps(method)
    def wrapper(self, *args, **kwargs):
        try:
            bound = inspect.signature(method).bind(self, *args, **kwargs)
            bound.apply_defaults()
        except TypeError as exc:
            return err(Code.ERROR_PARAM, str(exc))
        candidates = bound.arguments.get("keywords")
        if candidates is None:
            candidates = self.related_keywords
        if not candidates:
            return err(Code.ERROR_MISSING_FIELDS,
                       "keywords or existing related_keywords required; no candidate set was supplied",
                       missing=["keywords"])
        if not isinstance(candidates, list) or any(not isinstance(item, dict) for item in candidates):
            return err(Code.ERROR_PARAM, "keywords must be a list of keyword objects")
        try:
            terms = [normalize_term(str(item.get("term") or item.get("keyword") or "")) for item in candidates]
        except ValueError as exc:
            return err(Code.ERROR_PARAM, str(exc))
        if any(not term for term in terms) or len(set(terms)) != len(terms):
            return err(Code.ERROR_PARAM, "candidate terms must be non-empty and unique")
        if self.term.casefold() not in terms:
            return err(Code.ERROR_PARAM, "current Keyword.term must belong to the candidate set")
        bound.arguments["keywords"] = deepcopy(candidates)
        return method(*bound.args, **bound.kwargs)
    return wrapper


# -- 辅助模型（原 datatypes/keyword.py）------------------------------------------

class TrendPoint(BaseModel):
    """趋势数据点"""
    date: str = ""          # ISO 日期
    value: float | None = None


class Abapoint(BaseModel):
    """ABA 周数据点"""
    week: str = ""          # 周标识
    rank: int | None = None


class KeywordScore(BaseModel):
    """关键词四维评分结果"""
    keyword: str = ""
    score: float = 0.0          # 0-10
    grade: str = "C"            # S/A/B/C
    dimension_scores: dict[str, float] = Field(default_factory=dict)
    match_level: str = ""       # perfect/high/partial/low
    reason: str = ""


class KeywordCluster(BaseModel):
    """关键词聚类结果"""
    label: str = ""
    members: list[str] = Field(default_factory=list)
    weighted_traffic: float = 0.0
    trend: str = ""
    competition: str = ""
    members_count: int = 0


# -- Keyword 实体 ---------------------------------------------------------------

class Keyword(Entity):
    """Keyword 实体 — 搜索词的完整数据聚合"""

    entity_type: ClassVar[str] = "keyword"
    identity_fields: ClassVar[tuple[str, ...]] = ("marketplace", "category", "term")

    lazy_fields: ClassVar[dict[str, EnrichSpec]] = {
        "metrics": EnrichSpec(
            field="metrics", method="get_metrics",
            depends=[], source="/keyword-miner", ttl_hours=48,
        ),
        "trends": EnrichSpec(
            field="trends", method="get_trends",
            depends=[], source="/seller-sprite/trends", ttl_hours=48,
        ),
        "aba_series": EnrichSpec(
            field="aba_series", method="get_aba_series",
            depends=[], source="aba_file", ttl_hours=168,
        ),
        "cluster": EnrichSpec(
            field="cluster", method="get_cluster",
            depends=[], invalidates_on=["related_keywords"],
            source="analysis.cluster.keywords", ttl_hours=24, version="2",
        ),
        "score": EnrichSpec(
            field="score", method="get_score",
            depends=[], invalidates_on=["related_keywords"],
            source="analysis.keyword.score", ttl_hours=24, version="2",
        ),
        "market": EnrichSpec(
            field="market", method="get_market",
            depends=[], source="entity.market", ttl_hours=24,
        ),
        "market_stats": EnrichSpec(
            field="market_stats", method="get_market_stats",
            depends=["market"], source="entity.market.stats", ttl_hours=24,
        ),
        "market_profile": EnrichSpec(
            field="market_profile", method="get_market_profile",
            depends=["market_stats"], source="entity.market.profile", ttl_hours=24,
        ),
        "market_opportunity": EnrichSpec(
            field="market_opportunity", method="get_market_opportunity",
            depends=["market_stats"], source="entity.market.opportunity", ttl_hours=24,
        ),
        "products": EnrichSpec(
            field="products", method="get_products",
            depends=[], source="/competing-lookup", ttl_hours=24,
        ),
    }

    # -- 核心字段 ----------------------------------------------------------------

    term: str = Field(min_length=1, json_schema_extra={"alias": "term"})
    marketplace: str = Field(default="US", json_schema_extra={"alias": "marketplace"})
    category: str = Field(default="", json_schema_extra={"alias": "category"})

    search_volume: int | None = Field(default=None, json_schema_extra={"alias": "searchVolume"})
    competition: float | None = Field(default=None, json_schema_extra={"alias": "competition"})
    ppc: float | None = Field(default=None, json_schema_extra={"alias": "ppc"})
    click_rate: float | None = Field(default=None, json_schema_extra={"alias": "clickRate"})
    conversion_rate: float | None = Field(default=None, json_schema_extra={"alias": "conversionRate"})
    top3_asins: list[str] = Field(default_factory=list, json_schema_extra={"alias": "topAsins"})

    # ABA 排名
    aba_rank: int | None = Field(default=None, json_schema_extra={"alias": "abaRank"})
    aba_history: list[Abapoint] = Field(default_factory=list, json_schema_extra={"alias": "abaHistory"})

    # 趋势
    sv_trend: list[TrendPoint] = Field(default_factory=list, json_schema_extra={"alias": "svTrend"})

    # 来自反向查找
    traffic_pct: float | None = Field(default=None, json_schema_extra={"alias": "trafficPercentage"})
    natural_ratio: float | None = Field(default=None, json_schema_extra={"alias": "naturalRatio"})
    ad_ratio: float | None = Field(default=None, json_schema_extra={"alias": "adRatio"})
    rank: int | None = Field(default=None, json_schema_extra={"alias": "rankPosition"})

    # -- lazy 字段 ---------------------------------------------------------------

    related_keywords: list[dict[str, Any]] | None = None
    trends: list[dict[str, Any]] | None = None
    aba_series: list[dict[str, Any]] | None = None
    cluster: dict[str, Any] | None = None
    score: dict[str, Any] | None = None
    market_ref: EntityRef | None = None
    market: Market | None = Field(default=None, exclude=True)                          # 该词的市场分析实体
    market_stats: MarketStats | None = Field(default=None, exclude=True)
    market_profile: MarketProfile | None = Field(default=None, exclude=True)
    market_opportunity: Opportunity | None = Field(default=None, exclude=True)
    product_refs: list[EntityRef] | None = None
    products: list[CompetingItemOutput] | None = Field(default=None, exclude=True)

    # ------------------------------------------------------------------
    # 工厂方法
    # ------------------------------------------------------------------

    @classmethod
    def fetch(
        cls,
        term: str,
        marketplace: str = "US",
        category: str = "",
        force_refresh: bool = False,
    ) -> Keyword | None:
        """从 API 获取 Keyword（core 字段）"""
        ref = keyword_ref(marketplace, category, term)
        marketplace, category, term = ref.key
        cache_id = ref.cache_id
        cached = cls.load(cache_id)
        if cached is not None and not force_refresh:
            return cached

        if marketplace != "US" or category:
            return None
        from amz.data.keyword import keyword_miner
        result = keyword_miner(term)
        if result.code != Code.OK or not result.data:
            return None
        items = (result.data or {}).get("items", [])
        if not items:
            return None
        data = items[0]
        values = dict(
            term=term,
            marketplace=marketplace,
            category=category,
            search_volume=data.get("search_volume"),
            competition=data.get("competition"),
            ppc=data.get("ppc"),
            click_rate=data.get("click_rate"),
            conversion_rate=data.get("conversion_rate"),
            top3_asins=data.get("top3_asins", []),
            related_keywords=items,
        )
        if cached is None:
            instance = cls(**values)
        else:
            instance = cached
            for field, value in values.items():
                if getattr(instance, field) != value:
                    setattr(instance, field, value)
                    instance._invalidate_dependents(field)
        instance._cache_id = cache_id
        instance._mark_fetched("related_keywords")
        instance._mark_fetched("metrics")
        instance.save()
        return instance

    @classmethod
    def from_reverse(
        cls,
        data: dict[str, Any],
        *,
        marketplace: str = "US",
        category: str = "",
    ) -> Keyword | None:
        """从 reverse_keywords 的 dict item 构造轻量 Keyword 实例。

        不触发 API 调用，仅使用已有的反向查找数据。
        """
        try:
            term = data.get("term") or data.get("keywords") or data.get("keyword") or ""
            if not term:
                return None
            instance = cls(
                term=term,
                marketplace=marketplace,
                category=category,
                search_volume=data.get("searches") or data.get("search_volume"),
                competition=data.get("competition"),
                ppc=data.get("exactPpc") or data.get("ppc"),
                traffic_pct=(
                    data.get("trafficPercentage")
                    or data.get("traffic_pct")
                ),
                natural_ratio=data.get("naturalRatio") or data.get("natural_ratio"),
                ad_ratio=data.get("adRatio") or data.get("ad_ratio"),
                rank=data.get("rankExactSearches") or data.get("rank"),
                top3_asins=data.get("topAsins") or data.get("top3_asins", []),
            )
            instance._cache_id = instance.ref.cache_id
            instance._remember()
            return instance
        except Exception:
            return None

    @classmethod
    def _from_reverse(cls, data: dict[str, Any]) -> Keyword | None:
        """兼容旧内部名称；新代码使用 :meth:`from_reverse`。"""
        return cls.from_reverse(data)

    # ------------------------------------------------------------------
    # 实体方法
    # ------------------------------------------------------------------

    @lazy_field("metrics")
    def get_metrics(self) -> Result:
        """获取关键词特征（core 字段刷新）"""
        if self.marketplace != "US" or self.category:
            return err(Code.ERROR_PARAM, "upstream keyword data currently supports marketplace US and no category filter only")
        from amz.data.keyword import keyword_miner
        result = keyword_miner(self.term)
        if result.code == Code.OK:
            items = (result.data or {}).get("items", [])
            if items:
                for k, v in items[0].items():
                    if k in type(self).model_fields:
                        setattr(self, k, v)
                self.related_keywords = items
                self._mark_fetched("related_keywords")
                self._mark_fetched("metrics")
                self.save()
            else:
                return err(Code.ERROR_NOT_FOUND, f"no metrics found for {self.term}")
        return result

    def expand(self) -> Result:
        """拓展关键词"""
        if self.marketplace != "US" or self.category:
            return err(Code.ERROR_PARAM, "upstream keyword data currently supports marketplace US and no category filter only")
        from amz.data.keyword import keyword_miner
        result = keyword_miner(self.term)
        if result.code == Code.OK:
            self._writeback("related_keywords", (result.data or {}).get("items", []))
        return result

    @lazy_field("trends")
    def get_trends(self) -> Result:
        """获取关键词搜索量趋势时间序列（写入 self.trends）"""
        if self.marketplace != "US" or self.category:
            return err(Code.ERROR_PARAM, "upstream keyword data currently supports marketplace US and no category filter only")
        from amz.data.keyword import keyword_trends
        result = keyword_trends(self.term)
        if result.code == Code.OK:
            self._writeback("trends", (result.data or {}).get("points", []))
        return result

    @lazy_field("aba_series")
    def get_aba_series(self, csv_path: str = "") -> Result:
        """获取关键词 ABA 周排名序列（需 csv_path 指向 ABA CSV 文件）"""
        from amz.data.sources.aba_file import read_aba
        if not csv_path:
            return err(Code.ERROR_PARAM, "csv_path required for ABA data")
        result = read_aba(csv_path)
        if result.code == Code.OK:
            self._writeback("aba_series", (result.data or {}).get("rows", []))
        return result

    @lazy_field("market")
    def get_market(self) -> Result:
        """获取该关键词的市场分析实体。

        只创建并写回 Market 对象；Stats、Profile 与 Opportunity 由各自的
        lazy 方法按需级联，避免仅访问对象时提前拉取竞品数据。
        """
        from amz.entities.market import Market
        market = Market.fetch(
            self.term,
            marketplace=self.marketplace,
            category=self.category,
        )
        if market is None:
            return err(Code.ERROR_UPSTREAM, f"failed to create Market for {self.term}")

        self.market_ref = market.ref
        self._writeback("market", market)
        return ok(data={"market": market})

    @lazy_field("market_stats")
    def get_market_stats(self) -> Result:
        """从 Keyword 直接获取 Market Stats；缺少 Market 时自动级联创建。"""
        if self.market is None:
            return err(Code.ERROR_SERVER_INTERNAL, "market dependency was not populated")
        result = self.market.get_stats()
        if result.code == Code.OK and self.market.stats is not None:
            self._writeback("market_stats", self.market.stats)
        return result

    @lazy_field("market_profile")
    def get_market_profile(self) -> Result:
        """从 Keyword 直接获取 Market Profile；自动级联 Market 与 Stats。"""
        if self.market is None:
            return err(Code.ERROR_SERVER_INTERNAL, "market dependency was not populated")
        result = self.market.get_profile()
        if result.code == Code.OK and self.market.profile is not None:
            self._writeback("market_profile", self.market.profile)
        return result

    @lazy_field("market_opportunity")
    def get_market_opportunity(self) -> Result:
        """从 Keyword 直接获取 Market Opportunity；自动级联 Market 与 Stats。"""
        if self.market is None:
            return err(Code.ERROR_SERVER_INTERNAL, "market dependency was not populated")
        result = self.market.get_opportunity()
        if result.code == Code.OK and self.market.opportunity is not None:
            self._writeback("market_opportunity", self.market.opportunity)
        return result

    # ------------------------------------------------------------------
    # Python object API: Keyword -> Market -> typed market information
    # ------------------------------------------------------------------

    def require_market(self) -> Market:
        """Return this keyword's typed ``Market`` object, loading it if needed."""
        return cast(
            "Market",
            self._require_field_value("market", self.get_market()),
        )

    def require_market_stats(self) -> MarketStats:
        """Return typed market statistics directly from a Keyword."""
        return cast(
            "MarketStats",
            self._require_field_value("market_stats", self.get_market_stats()),
        )

    def require_market_profile(self) -> MarketProfile:
        """Return the typed market profile directly from a Keyword."""
        return cast(
            "MarketProfile",
            self._require_field_value("market_profile", self.get_market_profile()),
        )

    def require_market_opportunity(self) -> Opportunity:
        """Return the typed market opportunity directly from a Keyword."""
        return cast(
            "Opportunity",
            self._require_field_value(
                "market_opportunity", self.get_market_opportunity(),
            ),
        )

    @lazy_field("products")
    def get_products(self, pages: int = 2) -> Result:
        """获取该关键词的竞品列表。

        调用 competing-lookup by keyword，返回标准化后的竞品 dict 列表。
        结果写回 self.products。
        """
        market_result = self.get_market()
        if market_result.code != Code.OK:
            return market_result
        result = self.market.get_products(pages=pages)
        if result.code == Code.OK:
            self.product_refs = self.market.product_refs
            self._writeback("products", self.market.products)
        return result

    def _prepare_dependencies(self, field: str, call_params: dict) -> Result | None:
        if field in {"market_stats", "market_profile", "market_opportunity", "products"}:
            self._invalidate_field(field)
        return None

    @_with_candidate_keywords
    @lazy_field("score")
    def get_score(
        self,
        keywords: list[dict[str, Any]] | None = None,
        product_info: dict[str, Any] | None = None,
    ) -> Result:
        """针对产品事实和显式候选集合评分；未传集合时使用已有 related_keywords。"""
        from amz.analysis.keyword import keyword_score
        result = keyword_score(keywords=keywords, product_info=product_info)
        if result.code == Code.OK:
            self._writeback("score", result.data)
        return result

    def get_related_products(self, pages: int = 2) -> Result:
        """获取该关键词的竞品 Product 实体列表。

        先通过 competing-lookup 获取竞品，再将每条转为 Product 实例。
        结果写回 self.products（dict 列表），同时返回 Product 实例列表。
        """
        result = self.get_products(pages=pages)
        if result.code != Code.OK:
            return result

        products = []
        for item in (self.products or []):
            # 尝试从 _from_competitor 创建 Product 实例
            from amz.entities.product import Product
            p = Product.from_competitor(item.model_dump(mode="python"), marketplace=self.marketplace)
            if p is not None:
                products.append(p)

        return ok(data={"products": products, "count": len(products)})

    @_with_candidate_keywords
    @lazy_field("cluster")
    def get_cluster(
        self,
        keywords: list[dict[str, Any]] | None = None,
        seed_count: int = 30,
        batch_size: int = 50,
    ) -> Result:
        """对显式候选或已有 related_keywords 做意图聚类，当前词作为主词。"""
        from amz.analysis.keyword import cluster_keywords
        result = cluster_keywords(keywords=keywords, main_keyword=self.term,
                                  seed_count=seed_count, batch_size=batch_size)
        if result.code == Code.OK:
            self._writeback("cluster", result.data)
        return result
