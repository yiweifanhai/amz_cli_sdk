"""
Product 实体：ASIN 维度的一切 — Pydantic v2 模型，字段定义一次，不再需要 datatypes 层。

数据源优先级：
  1. competing-lookup（主数据源，快速）→ core 商业字段
  2. product-info（慢端点，按需 lazy）→ 富文本字段

方法 = 原子能力，支持 lazy 按需填充。
"""

from __future__ import annotations

from datetime import date, datetime
from typing import Any, ClassVar, TYPE_CHECKING, cast

from pydantic import BaseModel, Field

from amz.config import config
from amz.entities.base import Entity, EnrichSpec, lazy_field
from amz.schemas.entity_ref import EntityRef, product_ref, keyword_ref
from amz.schemas.cosmo import ProductCosmo
from amz.entities.review import ReviewItem
from amz.envelope import Result, ok, err, Code
from amz.schemas.data_outputs import (
    KeywordReverseItemOutput,
    PrimaryKeywordItemOutput,
)
from amz.schemas.voc import (
    ProductVoc,
    UnmetNeed,
    ProductVocListing,
    VocStrengthsOutput,
    VocUseInsightsOutput,
    VocWeaknessesOutput,
)

if TYPE_CHECKING:
    from amz.entities.market import Market, MarketProfile, MarketStats, Opportunity
    from amz.entities.finance import FinanceData
    from amz.entities.review import ReviewData


class ProductDetails(BaseModel):
    """``entity.product.product_details`` 的稳定输出快照。"""

    bullet_points: list[str] = Field(default_factory=list)
    description: str | None = None
    images: list[str] = Field(default_factory=list)
    variations: list[dict[str, Any]] = Field(default_factory=list)
    categories: list[str] = Field(default_factory=list)
    product_details_raw: list[dict[str, Any]] = Field(default_factory=list)
    review_insights: dict[str, Any] | None = None
    about_product: list[dict[str, Any]] = Field(default_factory=list)
    manufacturer: str | None = None
    categories_extended: list[dict[str, Any]] = Field(default_factory=list)
    aplus_images: list[str] = Field(default_factory=list)
    bsr: dict[str, Any] | None = None
    brand: str | None = None


class Product(Entity):
    """
    Product 实体 — Amazon ASIN 的完整数据聚合。

    字段分两类：
    - core: fetch() 时从 competing-lookup 填充，不设 TTL
    - lazy: 调用对应的 get_xxx() 方法时填充，逐字段 TTL
    """

    entity_type: ClassVar[str] = "product"
    identity_fields: ClassVar[tuple[str, ...]] = ("marketplace", "asin",)

    # Lazy 字段声明
    lazy_fields: ClassVar[dict[str, EnrichSpec]] = {
        "core": EnrichSpec(
            field="core", method="refresh_core",
            depends=[], source="/competing-lookup", ttl_hours=24,
        ),
        "product_details": EnrichSpec(
            field="product_details", method="get_product_details",
            depends=[], source="/product-info", ttl_hours=24,
        ),
        "reviews": EnrichSpec(
            field="reviews", method="get_reviews",
            depends=[], source="/amazon/reviews", ttl_hours=48, version="3",
        ),
        "reverse_keywords": EnrichSpec(
            field="reverse_keywords", method="get_reverse_keywords",
            depends=[], source="/keyword-reverse", ttl_hours=48,
        ),
        "competitors": EnrichSpec(
            field="competitors", method="get_competitors",
            depends=[], source="/competing-lookup", ttl_hours=24,
        ),
        "rufus_qa": EnrichSpec(
            field="rufus_qa", method="get_rufus",
            depends=[], source="/rufus", ttl_hours=24,
        ),
        "finance": EnrichSpec(
            field="finance", method="get_finance",
            depends=["core"],
            source="data.fx.rate + calc.fba.margin + calc.finance.return-on-capital", ttl_hours=1,
            version="2",
            invalidates_on=["primary_keywords"],
        ),
        "primary_keywords": EnrichSpec(
            field="primary_keywords", method="get_primary_keywords",
            depends=["reverse_keywords"], source="calc.keyword.primary", ttl_hours=48,
            version="2",
        ),
        "primary_keyword_ref": EnrichSpec(
            field="primary_keyword_ref", method="get_primary_keyword_ref",
            depends=[], optional_depends=["primary_keywords"],
            source="aggregate", ttl_hours=48,
        ),
        "market": EnrichSpec(
            field="market", method="get_market",
            depends=["primary_keyword_ref"], source="aggregate", ttl_hours=48,
            dependency_params={"primary_keyword_ref": ["marketplace", "category"]},
        ),
        "market_stats": EnrichSpec(
            field="market_stats", method="get_market_stats",
            depends=["market"], source="entity.market.stats", ttl_hours=24,
            dependency_params={"market": ["marketplace", "category"]},
        ),
        "market_profile": EnrichSpec(
            field="market_profile", method="get_market_profile",
            depends=["market_stats"], source="entity.market.profile", ttl_hours=24,
            dependency_params={"market_stats": ["marketplace", "category"]},
        ),
        "market_opportunity": EnrichSpec(
            field="market_opportunity", method="get_market_opportunity",
            depends=["market_stats"], source="entity.market.opportunity", ttl_hours=24,
            dependency_params={"market_stats": ["marketplace", "category"]},
        ),
        "copyability": EnrichSpec(
            field="copyability", method="get_copyability",
            depends=["product_details"], optional_depends=["reviews"],
            invalidates_on=["core", "title", "images"],
            source="analysis.innovation.copyability", ttl_hours=168,
        ),
        "innovation": EnrichSpec(
            field="innovation", method="assess_innovation",
            depends=["copyability"], source="analysis.innovation.copyability", ttl_hours=168,
            dependency_params={"copyability": ["innovation_desc"]},
        ),
        "cosmo": EnrichSpec(
            field="cosmo", method="get_cosmo", depends=["product_details"],
            invalidates_on=["core", "title", "images", "aplus_images"],
            source="analysis.cosmo.extract", ttl_hours=168, version="3",
        ),
        "material": EnrichSpec(
            field="material", method="get_material", depends=["product_details"],
            invalidates_on=["core", "title", "images"],
            source="analysis.material.assess", ttl_hours=168,
        ),
        "unmet_needs": EnrichSpec(
            field="unmet_needs", method="get_unmet_needs", depends=["weaknesses"],
            source="entity.product.weaknesses", ttl_hours=48,
        ),
        "praise": EnrichSpec(
            field="praise", method="get_praise",
            depends=["reviews", "product_details"], source="analysis.voc.praise", ttl_hours=48,
        ),
        "wishlist": EnrichSpec(
            field="wishlist", method="get_wishlist",
            depends=["reviews", "product_details"], source="analysis.voc.wishlist", ttl_hours=48,
        ),
        "strengths": EnrichSpec(
            field="strengths", method="get_strengths",
            depends=["product_details"],
            source="analysis.voc.strength-signals", ttl_hours=24,
        ),
        "weaknesses": EnrichSpec(
            field="weaknesses", method="get_weaknesses",
            depends=["reviews", "product_details"], source="analysis.voc.weakness-signals", ttl_hours=48,
        ),
        "use_insights": EnrichSpec(
            field="use_insights", method="get_use_insights",
            depends=["reviews", "product_details"],
            source="analysis.voc.use-signals", ttl_hours=48,
        ),
        "voc": EnrichSpec(
            field="voc", method="get_voc",
            depends=["strengths", "weaknesses", "use_insights"],
            source="aggregate", ttl_hours=48,
        ),
    }

    # -- core 字段（来自 competing-lookup，fetch() 时填充）-------------------------

    marketplace: str = Field(default="US")
    asin: str = Field(min_length=1, json_schema_extra={"alias": "asin"})
    title: str | None = Field(default=None, json_schema_extra={"alias": "title"})
    brand: str | None = Field(default=None, json_schema_extra={"alias": "brand"})
    price_usd: float | None = Field(default=None, json_schema_extra={"alias": "price"})
    rating: float | None = Field(default=None, json_schema_extra={"alias": "rating"})
    count_review: int | None = Field(default=None, json_schema_extra={"alias": "reviews"})
    monthly_sales: int | None = Field(default=None, json_schema_extra={"alias": "totalUnits"})
    seller_nation: str | None = Field(default=None, json_schema_extra={"alias": "sellerNation"})
    listing_date: str | None = Field(default=None, json_schema_extra={"alias": "availableDate"})
    available_date: str | None = Field(default=None, json_schema_extra={"alias": "availableDate"})
    weight_g: float | None = Field(default=None, json_schema_extra={"alias": "pkgWeightTag"})
    dimensions_cm: dict[str, Any] | None = Field(default=None, json_schema_extra={"alias": "pkgDimensionsTag"})
    fba_fee: float | None = Field(default=None, json_schema_extra={"alias": "fbaFee"})
    bsr: dict[str, Any] | None = Field(default=None, json_schema_extra={"alias": "rank"})
    images: list[str] = Field(default_factory=list, json_schema_extra={"alias": "imageUrlList"})
    categories: list[str] = Field(default_factory=list, json_schema_extra={"alias": "categoryPath"})

    # -- lazy 字段（来自 product-info，慢端点按需拉取）-------------------------------

    product_details: ProductDetails | None = None
    bullet_points: list[str] = Field(default_factory=list, json_schema_extra={"alias": "features"})
    description: str | None = Field(default=None, json_schema_extra={"alias": "productDescription"})
    variations: list[dict[str, Any]] = Field(default_factory=list, json_schema_extra={"alias": "variations"})
    product_details_raw: list[dict[str, Any]] = Field(default_factory=list, json_schema_extra={"alias": "productDetails"})
    review_insights: dict[str, Any] | None = Field(default=None, json_schema_extra={"alias": "reviewInsights"})
    categories_extended: list[dict[str, Any]] = Field(default_factory=list, json_schema_extra={"alias": "categoriesExtended"})
    about_product: list[dict[str, Any]] = Field(default_factory=list, json_schema_extra={"alias": "aboutProduct"})
    manufacturer: str | None = Field(default=None, json_schema_extra={"alias": "manufacturer"})
    aplus_images: list[str] = Field(default_factory=list, json_schema_extra={"alias": "aplusImageUrlList"})

    # -- 其他 lazy 字段 -----------------------------------------------------------

    reviews: ReviewData | None = None                       # 类型化的评论集实体
    reverse_keywords: list[KeywordReverseItemOutput] | None = None
    competitor_refs: list[EntityRef] | None = None
    competitors: list[Product] | None = Field(default=None, exclude=True)            # 竞品 Product 实例列表，可链式调 get_finance()
    rufus_qa: list[str] | None = None
    primary_keywords: list[PrimaryKeywordItemOutput] | None = None
    finance: FinanceData | None = None                   # 类型化的财务计算结果
    primary_keyword_ref: EntityRef | None = None
    market_ref: EntityRef | None = None
    market: Market | None = Field(default=None, exclude=True)
    market_stats: MarketStats | None = Field(default=None, exclude=True)
    market_profile: MarketProfile | None = Field(default=None, exclude=True)
    market_opportunity: Opportunity | None = Field(default=None, exclude=True)
    innovation: dict[str, Any] | None = Field(default=None, exclude=True)
    copyability: dict[str, Any] | None = None
    material: dict[str, Any] | None = None
    cosmo: ProductCosmo | None = None
    unmet_needs: list[UnmetNeed] | None = Field(default=None, exclude=True)
    competing_extra: dict[str, Any] = Field(default_factory=dict)
    praise: dict[str, Any] | None = None
    wishlist: dict[str, Any] | None = None
    strengths: VocStrengthsOutput | None = None
    weaknesses: VocWeaknessesOutput | None = None
    use_insights: VocUseInsightsOutput | None = None
    voc: ProductVoc | None = None

    def model_post_init(self, __context: Any) -> None:
        """已有详情数据构造的 Product 可直接复用，不会再次隐式 fetch。"""
        super().model_post_init(__context)
        if isinstance(__context, dict) and __context.get("entity_loading"):
            return
        if self.copyability is None and self.innovation is not None:
            legacy_innovation = self.innovation
            self.copyability = legacy_innovation
            self._mark_fetched("copyability")
            self.innovation = legacy_innovation
        detail_fields = {
            "bullet_points", "description", "product_details_raw",
            "about_product", "categories_extended", "aplus_images",
        }
        if self.product_details is None and detail_fields.intersection(self.model_fields_set):
            self.product_details = self._product_details_snapshot()
            self._mark_fetched("product_details")
        if all(
            getattr(self, field) is not None
            for field in ("price_usd", "dimensions_cm", "weight_g")
        ):
            self._mark_fetched("core")

    def _product_details_snapshot(self) -> ProductDetails:
        return ProductDetails(
            bullet_points=self.bullet_points,
            description=self.description,
            images=self.images,
            variations=self.variations,
            categories=self.categories,
            product_details_raw=self.product_details_raw,
            review_insights=self.review_insights,
            about_product=self.about_product,
            manufacturer=self.manufacturer,
            categories_extended=self.categories_extended,
            aplus_images=self.aplus_images,
            bsr=self.bsr,
            brand=self.brand,
        )

    # ------------------------------------------------------------------
    # 投影方法（composite autowire：实体 → 能力 InputModel 的类型转换）
    # ------------------------------------------------------------------

    def _project_pkg_dims(self) -> tuple[float, float, float] | None:
        """``dimensions_cm`` dict → ``(length, width, height)`` tuple。"""
        dims = self.dimensions_cm or {}
        if not dims:
            return None
        return (
            dims.get("length", 0.0),
            dims.get("width", 0.0),
            dims.get("height", 0.0),
        )

    def _project_image_url(self) -> str:
        """主图 URL（images 首张）。"""
        return self.images[0] if self.images else ""

    def _project_voc_reviews(self) -> list["ReviewItem"] | None:
        """``reviews``（ReviewData）→ 评论项列表。只读，不触发 enrich。"""
        if not self.reviews:
            return None
        return self.reviews.analysis_items()

    def to_product_info(self) -> dict[str, Any]:
        """导出 Analysis 可复用的标准产品 DTO（只读，不触发 fetch）。"""
        from amz.schemas.analysis_inputs import ProductInfoInput

        projected = self.project_to(ProductInfoInput) or {}
        return ProductInfoInput.model_validate(projected).model_dump(mode="python")

    def to_review_items(self) -> list[dict[str, Any]]:
        """导出 Product 评论字段已生成的 VOC 分星抽样 DTO。"""
        if not self.reviews:
            return []
        return [
            item.model_dump(mode="python")
            for item in self.reviews.analysis_items()
        ]

    def to_voc_listing(self) -> dict[str, Any]:
        """导出严格 Product VOC Listing，不触发取数。"""
        listing = ProductVocListing(
            asin=self.asin,
            title=self.title or "",
            bullet_points=self.bullet_points,
            details=self.product_details_raw,
            description=self.description or "",
            brand=self.brand,
            product_rating=self.rating,
            count_ratings=self.count_review,
        )
        return listing.model_dump(mode="python")

    # ------------------------------------------------------------------
    # 工厂方法
    # ------------------------------------------------------------------

    @classmethod
    def _read_cache_payload(cls, path, cache_id: str) -> dict[str, Any] | None:
        payload = super()._read_cache_payload(path, cache_id)
        if payload is None:
            return None
        entries = payload.get("fields", {})
        legacy = entries.get("innovation")
        if legacy and legacy.get("value") is not None and not entries.get("copyability", {}).get("value"):
            entries["copyability"] = {**legacy, "version": cls.lazy_fields["copyability"].version}
        return payload

    def _restore_entries(self, entries: dict[str, Any]) -> None:
        super()._restore_entries(entries)
        # The old Python field is a view of the canonical stored result.
        if self.copyability is not None:
            self.innovation = self.copyability

    @classmethod
    def fetch(cls, asin: str, force_refresh: bool = False, marketplace: str = "US") -> Product | None:
        """从 competing-lookup 获取 Product core 字段（快速）。

        competing-lookup 返回完整商业字段：价格/评分/销量/重量/尺寸/FBA费/上架日期等。
        product-info 的富文本字段（bullet_points/description/images/变体详情）通过
        lazy 字段按需拉取。
        """
        ref = product_ref(marketplace, asin)
        marketplace, asin = ref.key
        cache_id = ref.cache_id
        cached = cls.load(cache_id)
        if cached is not None and not force_refresh:
            return cached

        if marketplace != "US":
            return None
        from amz.data.market import market_competitors
        from amz.data.normalizer import normalize_competing_item

        result = market_competitors(asin=asin, pages=1)
        if result.code != Code.OK or not result.data:
            return None
        items = result.data.get("items", [])
        if not items:
            return None

        first = normalize_competing_item(items[0])

        # BSR: 用 bsrRank 构造 dict
        bsr_obj = None
        bsr_rank = first.get("bsr_rank")
        if bsr_rank is not None:
            bsr_obj = {
                "rank": int(bsr_rank),
                "category": first.get("category_name", ""),
            }

        # images: competing 只有单张主图，后续 product_details 会补全
        image_url = first.get("image_url")
        images = [image_url] if image_url else []

        # categories: competing 只有单个 categoryName，后续 product_details 补全树
        cat_name = first.get("category_name")
        categories = [cat_name] if cat_name else []

        values = dict(
            marketplace=marketplace,
            asin=first.get("asin", asin),
            title=first.get("title"),
            brand=first.get("brand"),
            price_usd=first.get("price_usd"),
            rating=first.get("rating"),
            count_review=first.get("count_review"),
            monthly_sales=first.get("monthly_sales"),
            seller_nation=first.get("seller_nation"),
            listing_date=first.get("available_date"),
            available_date=first.get("available_date"),
            weight_g=first.get("weight_g"),
            dimensions_cm=first.get("dimensions_cm"),
            fba_fee=first.get("fba_fee"),
            bsr=bsr_obj,
            images=images,
            categories=categories,
        )
        if cached is None:
            instance = cls(**values)
        else:
            instance = cached
            for field, value in values.items():
                if getattr(instance, field) != value:
                    setattr(instance, field, value)
                    instance._invalidate_dependents(field)
        instance._cache_id = cache_id
        instance._mark_fetched("core")
        instance.save()
        return instance

    @classmethod
    def from_competitor(cls, data: dict[str, Any], *, marketplace: str = "US") -> Product | None:
        """Merge an available competitor row into its local Product, without fetching."""
        from amz.data.normalizer import normalize_competing_item
        item = normalize_competing_item(data)
        asin = item.get("asin", "").strip().upper()
        if not asin:
            return None
        ref = product_ref(marketplace, asin)
        marketplace, asin = ref.key
        instance = cls.load(ref.cache_id)
        if instance is None:
            instance = cls(asin=asin, marketplace=marketplace)
        changed = False
        direct = (
            "title", "brand", "price_usd", "rating", "count_review", "monthly_sales",
            "seller_nation", "available_date", "weight_g", "dimensions_cm", "fba_fee",
        )
        values = {name: item[name] for name in direct if item.get(name) is not None}
        if item.get("available_date") or item.get("listing_date"):
            values["listing_date"] = item.get("listing_date") or item["available_date"]
        if item.get("bsr") is not None:
            values["bsr"] = item["bsr"]
        elif item.get("bsr_rank") is not None:
            values["bsr"] = {"rank": item["bsr_rank"], "category": item.get("category_name", "")}
        if not instance.images and item.get("image_url"):
            values["images"] = [item["image_url"]]
        if not instance.categories:
            values["categories"] = item.get("categories") or ([item["category_name"]] if item.get("category_name") else [])
        for name, value in values.items():
            if getattr(instance, name) != value:
                setattr(instance, name, value)
                instance._invalidate_dependents(name)
                changed = True
        extras = {name: value for name, value in item.items() if name not in cls.model_fields}
        instance.competing_extra.update(extras)
        if changed:
            instance._invalidate_dependents("core")
        instance._mark_fetched("core")
        instance.save()
        return instance

    def to_competitor(self) -> dict[str, Any]:
        """Project this Product into the legacy lightweight competitor contract."""
        names = (
            "asin", "title", "brand", "price_usd", "rating", "count_review", "monthly_sales",
            "seller_nation", "available_date", "listing_date", "weight_g", "dimensions_cm",
            "fba_fee", "bsr", "categories",
        )
        data = {**self.competing_extra, **{name: getattr(self, name) for name in names}}
        data["title"] = self.title or ""
        data["image_url"] = self.images[0] if self.images else ""
        return data

    @classmethod
    def _from_competitor(cls, data: dict[str, Any]) -> Product | None:
        """兼容旧内部名称；新代码使用 :meth:`from_competitor`。"""
        return cls.from_competitor(data)

    # ------------------------------------------------------------------
    # 实体方法 = 原子能力
    # ------------------------------------------------------------------

    def get(self) -> Result:
        """返回自身"""
        return ok(data=self.model_dump(mode="python"))

    @lazy_field("core")
    def refresh_core(self) -> Result:
        """刷新 competing-lookup 提供的 Product core 字段。"""
        refreshed = type(self).fetch(self.asin, force_refresh=True, marketplace=self.marketplace)
        if refreshed is None:
            return err(
                Code.ERROR_UPSTREAM,
                f"failed to refresh core fields for {self.asin}",
            )
        if refreshed is not self:
            self._copy_state_from(refreshed)
        self._mark_fetched("core")
        self.save()
        return ok(data={
            "asin": self.asin,
            "price_usd": self.price_usd,
            "dimensions_cm": self.dimensions_cm,
            "weight_g": self.weight_g,
        })

    @lazy_field("product_details")
    def get_product_details(self) -> Result:
        """从 product-info 拉取富文本字段（五点/描述/全量图片/变体/完整类目树等，慢端点按需）

        填充：bullet_points, description, images (全量), variations,
        categories (完整树), product_details_raw, review_insights,
        about_product, manufacturer, aplus_images。

        注意：11 个字段共享一次 API 调用，因此使用单次 _mark_fetched
        管理 TTL。如果后续要求不同字段有不同缓存时长，需要拆分。
        """
        if self.marketplace != "US":
            return err(Code.ERROR_PARAM, "upstream product data currently supports marketplace US only")
        from amz.data.product import product_get

        result = product_get(self.asin)
        if result.code != Code.OK or not result.data:
            return result

        data = result.data
        if data.get("title") and data["title"] != self.title:
            self.title = data["title"]
            self._invalidate_dependents("title")

        # 富文本
        self.bullet_points = data.get("bullet_points") or []
        self.description = data.get("description")

        # Use the current detail images when available; removed images must not linger.
        pi_images = data.get("images") or []
        if pi_images:
            self.images = list(dict.fromkeys(pi_images))

        # variations
        self.variations = data.get("variations") or []

        # categories: 用 product-info 完整树覆盖
        pi_cats = data.get("categories") or []
        if pi_cats:
            self.categories = pi_cats

        # 保留原始数据
        self.product_details_raw = data.get("product_details_raw") or []
        self.review_insights = data.get("reviewInsights") or data.get("review_insights")
        self.about_product = data.get("aboutProduct") or data.get("about_product") or []
        self.manufacturer = data.get("manufacturer")
        self.categories_extended = data.get("categories_extended") or data.get("categoriesExtended") or []
        self.aplus_images = data.get("aplusImageUrlList") or data.get("aplus_images") or []

        # BSR: 如果 product-info 有更详细的数据则覆盖
        pi_bsr = data.get("bsr")
        if pi_bsr is not None:
            self.bsr = pi_bsr

        # 兜底 brand
        if not self.brand and data.get("brand"):
            self.brand = data.get("brand")

        # 批量回填：字段本身保存稳定快照，Entity capability 的输出不再是
        # 含义模糊的 {"enriched": true}。
        details = self._product_details_snapshot()
        self._writeback("product_details", details)
        return ok(data=details)

    @lazy_field("reviews")
    def get_reviews(self, mode: str = "mid", star_filter: str = "all", max_pages: int = 1) -> Result:
        """获取评论集（mode: low/mid/high 每星 20/50/100 条，仅 star_filter="all" 时生效）。

        使用 ReviewData Entity 获取评论，获得 TTL 缓存 + single-flight。
        结果写回 self.reviews（ReviewData 实例），可链式访问 .items / .by_star() / .count。
        """
        if self.marketplace != "US":
            return err(Code.ERROR_PARAM, "upstream product data currently supports marketplace US only")
        from amz.entities.review import ReviewData
        review_data = ReviewData.fetch(
            self.asin, mode=mode, star_filter=star_filter, max_pages=max_pages,
        )
        if review_data is None:
            return err(Code.ERROR_UPSTREAM, f"failed to fetch reviews for {self.asin}")
        self._writeback("reviews", review_data)
        return ok(data={"asin": self.asin, "count": review_data.count})

    @lazy_field("reverse_keywords")
    def get_reverse_keywords(self) -> Result:
        """通过 ASIN 反查该商品的流量关键词列表（流量占比/自然占比/PPC 等）"""
        if self.marketplace != "US":
            return err(Code.ERROR_PARAM, "upstream product data currently supports marketplace US only")
        from amz.data.keyword import keyword_reverse
        result = keyword_reverse(self.asin)
        if result.code == Code.OK:
            self._writeback("reverse_keywords", (result.data or {}).get("items", []))
        return result

    @lazy_field("competitors")
    def get_competitors(self, pages: int = 1) -> Result:
        """获取竞品列表，转为 Product 实例列表。

        每个竞品从 normalized dict 转为轻量 Product 实例（core 字段已填充，
        lazy 字段可按需触发）。转换失败的单条跳过。
        """
        if self.marketplace != "US":
            return err(Code.ERROR_PARAM, "upstream product data currently supports marketplace US only")
        from amz.data.market import market_competitors
        result = market_competitors(asin=self.asin, pages=pages)
        if result.code == Code.OK:
            raw_items = (result.data or {}).get("items", [])
            products: list[Product] = []
            for item in raw_items:
                p = Product.from_competitor(item, marketplace=self.marketplace)
                if p is not None:
                    products.append(p)
            self.competitor_refs = [p.ref for p in products]
            self._writeback("competitors", products)
        return result

    @lazy_field("rufus_qa")
    def get_rufus(self) -> Result:
        """获取商品的 Rufus AI 问答"""
        if self.marketplace != "US":
            return err(Code.ERROR_PARAM, "upstream product data currently supports marketplace US only")
        from amz.data.product import product_rufus
        result = product_rufus(self.asin)
        if result.code == Code.OK:
            self._writeback("rufus_qa", (result.data or {}).get("rufus", []))
        return result

    @lazy_field("primary_keywords")
    def get_primary_keywords(self) -> Result:
        """筛选主力流量词（从 reverse_keywords 中按规则提取 3-8 个）。

        委托 calc.keyword.primary；Calc 只接收标准化词条，不读取 Product。
        """
        # 确保 reverse_keywords 已填充
        if not self._check_field("reverse_keywords"):
            result = self.get_reverse_keywords()
            if result.code != Code.OK:
                return err(Code.ERROR_UPSTREAM, "failed to fetch reverse keywords", hint=result.message)

        if not self.reverse_keywords:
            return err(Code.ERROR_UPSTREAM, "reverse_keywords is empty")

        from amz.calc.keyword import extract_primary_keywords

        data = extract_primary_keywords([
            item.model_dump(mode="python") for item in self.reverse_keywords
        ])

        self._writeback("primary_keywords", data["primary_keywords"])

        return ok(data={
            "asin": self.asin,
            "primary_keywords": data["primary_keywords"],
            "analysis": data["analysis"],
        })

    @lazy_field("finance")
    def get_finance(
        self,
        shipping_method: str = "fast",
        purchase_price: float | None = None,
        cpc: float | None = None,
        cvr: float | None = None,
        product_type: str | None = None,
        fulfillment_date: date | datetime | str | None = None,
        include_fuel_surcharge: bool = True,
        include_ads: bool = False,
        exchange_rate: float | None = None,
    ) -> Result:
        """计算利润（毛利率 M1/M2、采购毛利、FBA 费、资金效率 ROI）。

        从 self 取 price/weight/dims 字段值，委托 entities.finance.build_finance
        整合 calc.fba.margin + calc.finance.return-on-capital 两个纯函数；
        纯计算在 calc 层，整合与回填在 entities 层。
        weight_g 和 dimensions_cm 来自 competing-lookup 的 pkg 数据，
        已在 fetch() 时填充，无需额外请求。

        Args:
            cpc: 单次点击成本（$），用于计算 m2_margin_pct（平台+广告后利润率）
            cvr: 转化率（0-1），用于计算 m2_margin_pct
            product_type: non_apparel/apparel/dangerous_goods（及兼容别名）
            fulfillment_date: FBA 出库日期，用于选择旺季费率和附加费
            include_ads: 是否需要计算广告指标（cpc/cvr/cpa 与 M2 利润率）。
                True 时：显式传入的 cpc/cvr 优先；否则自动从主关键词
                （primary_keywords，未填充时级联拉取 reverse_keywords）取
                流量最大的主关键词的 exactPpc/cvr/cpa。False 时 cpc/cvr/cpa 为 null。
            exchange_rate: 人民币兑美元汇率（人民币/美元），头程单价为 RMB，
                按该汇率折算为 $；省略时自动取最新日参考汇率，非盘中成交价。
        """
        finance_fields = ["price_usd", "dimensions_cm", "weight_g"]
        missing = self._check_depends(finance_fields)
        if missing:
            return err(
                Code.ERROR_UPSTREAM,
                f"missing fields for finance calc: {missing}",
                missing=missing,
                hint="ensure Product.fetch() succeeded; weight/dims come from competing-lookup",
            )

        from amz.entities.finance import build_finance

        rate_info = {"source": "manual", "date": None, "kind": "manual", "fetched_at": None}
        if exchange_rate is None:
            from amz.data.fx import exchange_rate as fetch_exchange_rate

            rate_result = fetch_exchange_rate("USD", "CNY")
            if rate_result.code != Code.OK:
                return rate_result
            exchange_rate = rate_result.data["rate"]
            rate_info = rate_result.data
        else:
            import math

            if not math.isfinite(exchange_rate) or exchange_rate <= 0:
                return err(Code.ERROR_PARAM, "exchange_rate must be finite and > 0")

        ads_source = "none"
        ads_keyword: str | None = None
        if include_ads:
            # 显式 cpc/cvr 优先；缺任一时从主关键词补齐（未填充则级联拉取）
            if cpc is None or cvr is None:
                if not self._check_field("primary_keywords"):
                    pk_result = self.get_primary_keywords()
                    if pk_result.code != Code.OK:
                        ads_source = "unavailable"
                    else:
                        ads_source = "primary_keyword"
                else:
                    ads_source = "primary_keyword"
                if ads_source == "primary_keyword" and self.primary_keywords:
                    top = self.primary_keywords[0]
                    if cpc is None:
                        cpc = top.ppc
                    if cvr is None and cpc is not None:
                        # primary_keywords 中 cvr 为百分数（如 8.5 = 8.5%）
                        cvr = (top.cvr or 0) / 100
                    ads_keyword = top.term
            else:
                ads_source = "param"

        finance_data = build_finance(
            selling_price=self.price_usd,
            weight_g=self.weight_g,
            dimensions_cm=self.dimensions_cm,
            shipping_method=shipping_method,
            purchase_price=purchase_price, cpc=cpc, cvr=cvr,
            product_type=product_type,
            fulfillment_date=fulfillment_date,
            include_fuel_surcharge=include_fuel_surcharge,
            exchange_rate=exchange_rate,
        )
        finance_data.assumptions.update({
            "exchange_rate_source": rate_info["source"],
            "exchange_rate_date": rate_info["date"],
            "exchange_rate_kind": rate_info["kind"],
            "exchange_rate_fetched_at": rate_info["fetched_at"],
            "ads_source": ads_source,
            "ads_keyword": ads_keyword,
        })
        self._writeback("finance", finance_data)

        enriched = ["price_usd", "dimensions_cm", "weight_g"]
        if ads_source == "primary_keyword":
            enriched.append("primary_keywords")
        return ok(data=self.finance, enriched=enriched)

    @lazy_field("primary_keyword_ref")
    def get_primary_keyword_ref(
        self, marketplace: str | None = None, category: str = "",
    ) -> Result:
        """Use the first primary keyword as the sole source of the market relation."""
        candidates = self.primary_keywords or []
        if not candidates or not candidates[0].term.strip():
            return err(
                Code.ERROR_MISSING_FIELDS,
                "a primary keyword is required to choose the Product market",
                missing=["primary_keywords"],
            )
        ref = keyword_ref(marketplace or self.marketplace, category, candidates[0].term)
        self._writeback("primary_keyword_ref", ref)
        return ok(data=ref)

    @lazy_field("market")
    def get_market(self, marketplace: str | None = None, category: str = "") -> Result:
        """获取市场聚合视图（使用主力关键词），结果写回 self.market。

        委托 Market 实体处理数据获取和聚合计算，本方法只负责选取关键词。
        返回的 self.market 是 Market 实体，可链式调用 get_stats/get_profile/get_opportunity。
        """
        if self.primary_keyword_ref is None:
            return err(Code.ERROR_MISSING_FIELDS, "primary_keyword_ref was not populated", missing=["primary_keyword_ref"])
        if self.primary_keyword_ref.entity_type != "keyword":
            return err(Code.ERROR_PARAM, "primary_keyword_ref must reference a Keyword")
        identity = self.primary_keyword_ref.identity
        keyword = identity["term"]
        from amz.entities.market import Market
        market = Market.fetch(
            keyword,
            marketplace=identity["marketplace"],
            category=identity["category"],
        )
        if market is None:
            return err(Code.ERROR_UPSTREAM, f"failed to create Market for {keyword}")

        self.market_ref = market.ref
        self._writeback("market", market)
        return ok(data={"market": market, "keyword": keyword})

    @lazy_field("market_stats")
    def get_market_stats(
        self,
        marketplace: str | None = None,
        category: str = "",
    ) -> Result:
        """从 Product 直接获取 Market Stats；缺少 market 时自动级联创建。"""
        if self.market is None:
            return err(Code.ERROR_SERVER_INTERNAL, "market dependency was not populated")
        result = self.market.get_stats()
        if result.code == Code.OK and self.market.stats is not None:
            self._writeback("market_stats", self.market.stats)
        return result

    @lazy_field("market_profile")
    def get_market_profile(
        self,
        marketplace: str | None = None,
        category: str = "",
    ) -> Result:
        """从 Product 直接获取 Market Profile；自动级联 Market 与 Stats。"""
        if self.market is None:
            return err(Code.ERROR_SERVER_INTERNAL, "market dependency was not populated")
        result = self.market.get_profile()
        if result.code == Code.OK and self.market.profile is not None:
            self._writeback("market_profile", self.market.profile)
        return result

    @lazy_field("market_opportunity")
    def get_market_opportunity(
        self,
        marketplace: str | None = None,
        category: str = "",
    ) -> Result:
        """从 Product 直接获取 Market Opportunity；自动级联 Market 与 Stats。"""
        if self.market is None:
            return err(Code.ERROR_SERVER_INTERNAL, "market dependency was not populated")
        result = self.market.get_opportunity()
        if result.code == Code.OK and self.market.opportunity is not None:
            self._writeback("market_opportunity", self.market.opportunity)
        return result

    # ------------------------------------------------------------------
    # Python object API: Product -> Market -> typed market information
    # ------------------------------------------------------------------

    def require_market(
        self,
        marketplace: str | None = None,
        category: str = "",
    ) -> Market:
        """Return this product's typed ``Market`` object, loading it if necessary.

        The existing :meth:`get_market` Result contract remains the registry/CLI
        boundary.  Python callers can use this method for natural object navigation.
        """
        result = self.get_market(marketplace=marketplace, category=category)
        return cast("Market", self._require_field_value("market", result))

    def require_market_stats(
        self,
        marketplace: str | None = None,
        category: str = "",
    ) -> MarketStats:
        """Return typed market statistics directly from a Product."""
        result = self.get_market_stats(marketplace, category)
        return cast(
            "MarketStats",
            self._require_field_value("market_stats", result),
        )

    def require_market_profile(
        self,
        marketplace: str | None = None,
        category: str = "",
    ) -> MarketProfile:
        """Return the typed market profile directly from a Product."""
        result = self.get_market_profile(marketplace, category)
        return cast(
            "MarketProfile",
            self._require_field_value("market_profile", result),
        )

    def require_market_opportunity(
        self,
        marketplace: str | None = None,
        category: str = "",
    ) -> Opportunity:
        """Return the typed market opportunity directly from a Product."""
        result = self.get_market_opportunity(marketplace, category)
        return cast(
            "Opportunity",
            self._require_field_value("market_opportunity", result),
        )

    def get_related_keywords(self) -> Result:
        """获取关联关键词列表（从 reverse_keywords 构造 Keyword 实体列表）。

        需要先填充 reverse_keywords（自动级联触发）。
        返回轻量 Keyword 实例，只含 core 字段。
        """
        if not self._check_field("reverse_keywords"):
            result = self.get_reverse_keywords()
            if result.code != Code.OK:
                return err(Code.ERROR_UPSTREAM, "failed to fetch reverse keywords", hint=result.message)

        from amz.entities.keyword import Keyword
        keywords: list[Keyword] = []
        for item in (self.reverse_keywords or []):
            kw = Keyword.from_reverse(item.model_dump(mode="python"), marketplace=self.marketplace)
            if kw is not None:
                keywords.append(kw)

        return ok(data={"keywords": keywords, "count": len(keywords)})

    @lazy_field("copyability")
    def get_copyability(self, innovation_desc: str = "") -> Result:
        """创新可复制性评估，结果写回 self.copyability。

        依赖 product_details（depends 声明自动级联填充标题/图片/描述）；
        reviews 已填充时一并传入作为差评痛点来源，获取失败不阻断主分析。
        委托 analysis.innovation.assess_copyability()，支持 TTL 缓存。

        Args:
            innovation_desc: 用户认为的产品的创新点（可选）
        """
        # reviews 由 optional_depends 尽力补齐；失败不阻断主分析。
        reviews_info = None
        if self.reviews and self.reviews.items:
            reviews_info = [it.model_dump() for it in self.reviews.items]

        image_url = self.images[0] if self.images else ""
        description = self.description or ""
        if not description and self.bullet_points:
            description = "\n".join(self.bullet_points)

        from amz.analysis.innovation import assess_copyability
        result = assess_copyability(
            asin=self.asin,
            title=self.title or description or "",
            image_url=image_url,
            description=description,
            reviews=reviews_info,
            innovation_desc=innovation_desc,
        )
        if result.code == Code.OK:
            self._writeback("copyability", result.data)
        return result

    @lazy_field("innovation")
    def assess_innovation(self, innovation_desc: str = "") -> Result:
        """Compatibility projection of the canonical copyability result."""
        self._writeback("innovation", self.copyability)
        return ok(data=self.innovation)

    @lazy_field("cosmo")
    def get_cosmo(self, model: str = "lite", use_image: bool = True) -> Result:
        """Extract COSMO from Listing text and optional product/A+ image text."""
        from amz.analysis.cosmo import cosmo_extract
        use_image = use_image and config.cosmo_use_images
        product_info = self.to_product_info()
        product_info["images"] = self.images if use_image else []
        product_info["aplus_images"] = self.aplus_images if use_image else []
        if not use_image:
            product_info["image_url"] = ""
            product_info["main_image_url"] = ""
        result = cosmo_extract(
            product_info=product_info,
            image_url=self._project_image_url() if use_image else "",
            model=model,
        )
        if result.code == Code.OK:
            self._writeback("cosmo", ProductCosmo.model_validate(result.data))
        return result

    @lazy_field("material")
    def get_material(self) -> Result:
        """Assess the product's material and development difficulty from available Listing facts."""
        from amz.analysis.innovation import assess_material
        product_info = {**self.to_product_info(), "categories": self.categories}
        result = assess_material(product_info=product_info, image_url=self._project_image_url())
        if result.code == Code.OK:
            self._writeback("material", result.data)
        return result

    @lazy_field("unmet_needs")
    def get_unmet_needs(self) -> Result:
        """Project unmet needs from weaknesses without another model request."""
        self._writeback("unmet_needs", self.weaknesses.unmet_needs)
        return ok(data=self.unmet_needs)

    def _writeback(self, field: str, value: Any) -> None:
        if field == "innovation" and value != self.copyability:
            self.copyability = value
            self._mark_fetched("copyability")
        super()._writeback(field, value)

    def _invalidate_field(self, field: str) -> None:
        super()._invalidate_field(field)
        if field in {"market", "primary_keyword_ref"}:
            self.market_ref = None
        elif field == "competitors":
            self.competitor_refs = None

    def _prepare_dependencies(self, field: str, call_params: dict) -> Result | None:
        if field in {"cosmo", "material", "copyability"} and "core" in self._fetched_at and not self._check_field("core"):
            result = self.refresh_core()
            if result.code != Code.OK:
                return result
        # Compatibility projections are re-read from their owner on every access.
        if field in {"market_stats", "market_profile", "market_opportunity", "unmet_needs", "innovation"}:
            self._invalidate_field(field)
        return None

    @lazy_field("praise")
    def get_praise(self) -> Result:
        """好评深度挖掘：从 4-5 星好评中提取用户喜爱点、惊喜点、竞品对比、价值感知。

        委托 analysis.voc.praise()，结果写回 self.praise。
        依赖 reviews 字段，未填充时自动级联触发 get_reviews()。
        """
        # 确保 reviews 已填充
        if not self._check_field("reviews"):
            rev_result = self.get_reviews()
            if rev_result.code != Code.OK:
                return err(Code.ERROR_UPSTREAM, "failed to fetch reviews", hint=rev_result.message)

        from amz.analysis.voc import voc_praise

        product_info = self.to_product_info()
        reviews_dicts = self.to_review_items()

        result = voc_praise(product_info=product_info, reviews=reviews_dicts)
        if result.code == Code.OK:
            self._writeback("praise", result.data)
        return result

    @lazy_field("wishlist")
    def get_wishlist(self) -> Result:
        """用户愿望清单：从全部评论中提取功能请求、改进建议、变体需求、配件需求。

        委托 analysis.voc.wishlist()，结果写回 self.wishlist。
        依赖 reviews 字段，未填充时自动级联触发 get_reviews()。
        """
        # 确保 reviews 已填充
        if not self._check_field("reviews"):
            rev_result = self.get_reviews()
            if rev_result.code != Code.OK:
                return err(Code.ERROR_UPSTREAM, "failed to fetch reviews", hint=rev_result.message)

        from amz.analysis.voc import voc_wishlist

        product_info = self.to_product_info()
        reviews_dicts = self.to_review_items()

        result = voc_wishlist(product_info=product_info, reviews=reviews_dicts)
        if result.code == Code.OK:
            self._writeback("wishlist", result.data)
        return result

    @lazy_field("strengths")
    def get_strengths(self) -> Result:
        """创新优势分析：从 Listing 文案中找出产品真正的创新点和竞争优势。

        委托 analysis.voc.strength-signals，结果写回 self.strengths。
        该原子能力仅使用 Listing 事实，不读取评论。
        """
        from amz.analysis.voc import voc_strength_signals

        if not self.title:
            return err(
                Code.ERROR_MISSING_FIELDS,
                "missing required fields: title",
                missing=["title"],
            )
        product_info = self.to_voc_listing()

        result = voc_strength_signals(product_info=product_info)
        if result.code == Code.OK:
            self._writeback("strengths", result.data)
        return result

    @lazy_field("weaknesses")
    def get_weaknesses(self) -> Result:
        """差评 VOC 分析：从评论中提取痛点、未满足需求，带辩证分析上下文。

        先用 calc.voc.satisfaction 计算全量满意度，再委托
        analysis.voc.weakness-signals 提取语义信号并写回 self.weaknesses。
        依赖 reviews 字段，未填充时自动级联触发 get_reviews()。
        """
        if not self.title:
            return err(
                Code.ERROR_MISSING_FIELDS,
                "missing required fields: title",
                missing=["title"],
            )
        if self.reviews is None:
            return err(
                Code.ERROR_MISSING_FIELDS,
                "missing required fields: reviews",
                missing=["reviews"],
            )

        from amz.analysis.voc import voc_weakness_signals
        from amz.calc.voc import calculate_satisfaction, merge_weakness_signals

        product_info = self.to_voc_listing()
        reviews_dicts = self.to_review_items()
        satisfaction = calculate_satisfaction(
            reviews=reviews_dicts,
            review_summary=self.reviews.review_summary or None,
            total_reviews=self.reviews.count_ratings or self.count_review,
            product_rating=self.reviews.rating or self.rating,
        )
        signals = voc_weakness_signals(
            product_info=product_info,
            reviews=reviews_dicts,
            satisfaction=satisfaction.model_dump(mode="python"),
        )
        if signals.code != Code.OK:
            return signals
        try:
            weaknesses = merge_weakness_signals(signals.data, satisfaction)
        except Exception as exc:
            return err(Code.ERROR_LLM, f"invalid weakness signals: {exc}")
        self._writeback("weaknesses", weaknesses)
        return ok(data=weaknesses)

    @lazy_field("use_insights")
    def get_use_insights(self) -> Result:
        """消费者使用洞察：场景、人群画像、购买动机。

        委托 analysis.voc.use-signals，结果写回 self.use_insights。
        依赖 reviews 字段，未填充时自动级联触发 get_reviews()。
        """
        from amz.analysis.voc import voc_use_signals

        if not self.title:
            return err(
                Code.ERROR_MISSING_FIELDS,
                "missing required fields: title",
                missing=["title"],
            )
        if self.reviews is None:
            return err(
                Code.ERROR_MISSING_FIELDS,
                "missing required fields: reviews",
                missing=["reviews"],
            )

        product_info = self.to_voc_listing()
        reviews_dicts = self.to_review_items()

        result = voc_use_signals(product_info=product_info, reviews=reviews_dicts)
        if result.code == Code.OK:
            self._writeback("use_insights", result.data)
        return result

    @lazy_field("voc")
    def get_voc(self) -> Result:
        """组装 Product 三路 VOC 字段；语义分析仍由各原子能力完成。"""
        missing = [
            field
            for field in ("strengths", "weaknesses", "use_insights")
            if getattr(self, field) is None
        ]
        if missing:
            return err(
                Code.ERROR_MISSING_FIELDS,
                "missing required fields: " + ", ".join(missing),
                missing=missing,
            )
        voc = ProductVoc(
            strengths=self.strengths,
            weaknesses=self.weaknesses,
            use_insights=self.use_insights,
        )
        self._writeback("voc", voc)
        return ok(data=voc)
