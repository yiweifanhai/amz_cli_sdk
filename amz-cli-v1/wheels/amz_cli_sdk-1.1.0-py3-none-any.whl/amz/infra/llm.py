"""
LLM 调用：仅豆包分档、OpenAI 兼容接口、JSON 容错解析和缓存。

吸收 product_dev_v2 / traffic_map / market_selection_agent / listing_agent 的 LLM 实现。
"""

from __future__ import annotations

import hashlib
import json
import re
import time
from typing import Any

import httpx

from amz.config import config
from amz.envelope import LLMError
from amz.infra.cache import sqlite_get, sqlite_set


# ---------------------------------------------------------------------------
# Provider 映射（逻辑名 → base_url）
# ---------------------------------------------------------------------------

_PROVIDER_MAP: dict[str, dict] = {
    "doubao": {"base_url": "https://ark.cn-beijing.volces.com/api/v3", "env_key": "DOUBAO_API_KEY"},
    "ark": {"base_url": "https://ark.cn-beijing.volces.com/api/v3", "env_key": "ARK_API_KEY"},
}


# Shared by text and vision routes; tasks choose the budget tier.
DOUBAO_MODELS = {
    "mini": "doubao-seed-2-0-mini-260428",
    "lite": "doubao-seed-2-0-lite-260428",
    "pro": "doubao-seed-2-0-pro-260215",
}

# 模型映射：逻辑模型 → provider实际模型名
_MODEL_MAP: dict[str, dict[str, str]] = {
    "doubao": DOUBAO_MODELS,
    "ark": DOUBAO_MODELS,
}

LLM_CACHE_VERSION = "doubao-only-v1"


def _get_api_key(provider: str) -> str:
    """获取 API key：先读 config，再回退到环境变量"""
    import os
    # 优先从配置文件读取
    key = config.api_key(provider)
    if key:
        return key
    # 回退到环境变量
    info = _PROVIDER_MAP.get(provider, {})
    env_key = info.get("env_key", "")
    return os.environ.get(env_key, "")


def _resolve_model(provider: str, logical_model: str) -> str:
    """逻辑模型名 → provider 实际模型名"""
    return _MODEL_MAP.get(provider, {}).get(logical_model, logical_model)


def _has_image_content(messages: list[dict]) -> bool:
    """消息中是否含 image_url 多模态块。"""
    for message in messages:
        content = message.get("content")
        if isinstance(content, list):
            for block in content:
                if isinstance(block, dict) and block.get("type") == "image_url":
                    return True
    return False


def _resolve_effective(
    provider: str, model: str, messages: list[dict],
) -> tuple[str, str]:
    """文本和图片均只允许豆包；旧 provider 显式报错，不自动换服务。"""
    if provider not in _PROVIDER_MAP:
        raise LLMError(provider, model, "Only Doubao/Ark is supported; use provider='doubao'")
    if model not in DOUBAO_MODELS and model not in DOUBAO_MODELS.values():
        raise LLMError(provider, model, "Use mini, lite, pro, or a configured Doubao model ID")
    return provider, _resolve_model(provider, model)


# ---------------------------------------------------------------------------
# 公共接口
# ---------------------------------------------------------------------------

def _build_cache_key(messages: list[dict], model: str, temperature: float, *, kind: str = "text", cache_key: str | None = None) -> str:
    """生成 LLM 缓存 key"""
    content = json.dumps({
        "version": LLM_CACHE_VERSION,
        "kind": kind,
        "messages": messages if cache_key is None else cache_key,
        "model": model,
        "temperature": temperature,
    }, sort_keys=True, ensure_ascii=False)
    return f"llm:{hashlib.sha1(content.encode()).hexdigest()[:16]}"


def chat(
    messages: list[dict] | None = None,
    prompt: str = "",
    model: str = "lite",
    temperature: float | None = None,
    provider: str | None = None,
    cache_key: str | None = None,
    ttl_seconds: int = 0,
) -> dict:
    """infra.llm.chat

    Args:
        messages: [{"role": "user", "content": "..."}]
        prompt: 快捷方式（自动包装为 messages）
        model: 逻辑模型名 "pro" / "lite" / "mini"
        temperature: 温度（默认 config）
        provider: LLM provider（默认 config.default_backend）
        cache_key: 自定义缓存 key
        ttl_seconds: 缓存 TTL（秒）；0 不缓存

    Returns:
        {text: str}
    """
    if messages is None:
        messages = [{"role": "user", "content": prompt}]
    elif prompt and not messages:
        messages = [{"role": "user", "content": prompt}]

    temp = temperature if temperature is not None else config.llm_temperature
    prov = provider or config.llm_default_backend

    prov, actual_model = _resolve_effective(prov, model, messages)

    # 缓存
    ck = _build_cache_key(messages, actual_model, temp, cache_key=cache_key)
    if ttl_seconds > 0:
        cached = sqlite_get(ck, ttl_seconds)
        if cached is not None:
            return cached

    # 调用
    result = _call_provider(prov, actual_model, messages, temp)

    # 写缓存
    if ttl_seconds > 0:
        sqlite_set(ck, result, ttl_seconds)

    return result


def chat_json(
    messages: list[dict] | None = None,
    prompt: str = "",
    json_schema: dict | None = None,
    model: str = "lite",
    temperature: float | None = None,
    provider: str | None = None,
    cache_key: str | None = None,
    ttl_seconds: int = 0,
) -> dict:
    """infra.llm.chat-json

    强制结构化输出（JSON），含多级容错解析。

    类似 chat() 但始终返回 {json: object}。
    """
    if messages is None:
        messages = [{"role": "user", "content": prompt}]

    # 附加 JSON schema 到 prompt
    if json_schema:
        schema_hint = f"\n\nYou MUST respond with valid JSON matching this schema:\n{json.dumps(json_schema, ensure_ascii=False)}"
        messages = _append_to_last(messages, schema_hint)

    temp = temperature if temperature is not None else config.llm_temperature
    prov = provider or config.llm_default_backend
    prov, actual_model = _resolve_effective(prov, model, messages)

    # 缓存
    ck = _build_cache_key(messages, actual_model, temp, kind="json", cache_key=cache_key)
    if ttl_seconds > 0:
        cached = sqlite_get(ck, ttl_seconds)
        if cached is not None:
            return cached

    # 调用
    result = _call_provider(prov, actual_model, messages, temp)

    # 容错解析 JSON
    parsed, repaired = _parse_json_loose(result.get("text", ""))
    if not isinstance(parsed, (dict, list)):
        raise LLMError(prov, actual_model, "Model response is not a JSON object or array")
    output = {"json": parsed, "repaired": repaired}

    if ttl_seconds > 0 and parsed:
        sqlite_set(ck, output, ttl_seconds)

    return output


def parse_json(text: str) -> dict:
    """infra.llm.parse-json — LLM 输出 JSON 容错解析。

    Returns:
        {json: object|list, repaired: bool}
    """
    parsed, repaired = _parse_json_loose(text)
    return {"json": parsed if parsed is not None else {}, "repaired": repaired}


# ---------------------------------------------------------------------------
# 内部实现
# ---------------------------------------------------------------------------

def _call_provider(
    provider: str,
    model: str,
    messages: list[dict],
    temperature: float,
) -> dict:
    """调用 LLM provider"""
    provider, model = _resolve_effective(provider, model, messages)
    api_key = _get_api_key(provider)
    if not api_key:
        raise LLMError(provider, model, f"API key not found (env: {_PROVIDER_MAP.get(provider, {}).get('env_key', 'unknown')})")

    base_url = _PROVIDER_MAP.get(provider, {}).get("base_url", "")
    if not base_url:
        raise LLMError(provider, model, f"Unknown provider: {provider}")

    url = f"{base_url}/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    body = {
        "model": model,
        "messages": messages,
        "temperature": temperature,
    }

    try:
        resp = _post_with_retry(url, body, headers)
        data = resp.json()
        choice = data["choices"][0]
        if not isinstance(choice, dict):
            raise LLMError(provider, model, "Malformed API choice")
        if choice.get("finish_reason") != "stop":
            raise LLMError(provider, model, f"Incomplete response (finish_reason={choice.get('finish_reason')})")
        text = choice["message"]["content"]
        if not isinstance(text, str) or not text.strip():
            raise LLMError(provider, model, "Model returned no answer text")
        return {"text": text}
    except httpx.HTTPStatusError as e:
        raise LLMError(provider, model, f"HTTP {e.response.status_code}: {e.response.text[:200]}")
    except httpx.TimeoutException:
        raise LLMError(provider, model, "timeout")
    except httpx.RequestError as e:
        raise LLMError(provider, model, str(e))
    except (KeyError, IndexError, TypeError, ValueError) as e:
        raise LLMError(provider, model, "Malformed API response") from e


def _post_with_retry(url: str, body: dict, headers: dict) -> httpx.Response:
    """Retry transient failures at most twice, with the same model and endpoint."""
    for attempt in range(3):
        try:
            response = httpx.post(url, json=body, headers=headers, timeout=httpx.Timeout(120))
            response.raise_for_status()
            return response
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code not in {429, 500, 502, 503, 504} or attempt == 2:
                raise
        except httpx.RequestError:
            if attempt == 2:
                raise
        time.sleep(2 ** attempt)
    raise AssertionError("Retry loop exhausted without a response or error")


def _append_to_last(messages: list[dict], append: str) -> list[dict]:
    """在最后一条消息的 content 后追加文本"""
    msgs = [dict(m) for m in messages]
    last = msgs[-1]
    content = last.get("content", "")
    if isinstance(content, list):
        # OpenAI-compatible multimodal chat content。保持已有图片块不变，
        # 将 schema hint 作为新的文本块追加。
        last["content"] = [*content, {"type": "text", "text": append}]
    else:
        last["content"] = str(content) + append
    return msgs


# ---------------------------------------------------------------------------
# JSON 容错解析（product_dev_v2 parse_json_loose 移植）
# ---------------------------------------------------------------------------

def _parse_json_loose(text: str) -> tuple[Any, bool]:
    """多级容错 JSON 解析：
    1. strict parse
    2. 剥 markdown fence
    3. 平衡括号扫描
    4. 截断补全
    """
    if not text or not isinstance(text, str):
        return None, False

    text = text.strip()

    # Step 1: strict
    try:
        return json.loads(text), False
    except (json.JSONDecodeError, ValueError):
        pass

    # Step 2: 剥 markdown fence
    fence_match = re.search(r"```(?:json)?\s*([\s\S]*?)```", text)
    if fence_match:
        try:
            return json.loads(fence_match.group(1).strip()), True
        except (json.JSONDecodeError, ValueError):
            pass

    # Step 3: 平衡括号扫描（找第一个完整 JSON 对象或数组）
    extracted = _extract_json_substring(text)
    if extracted:
        try:
            return json.loads(extracted), True
        except (json.JSONDecodeError, ValueError):
            pass

    # Step 4: 截断补全
    repaired = _repair_truncated_json(text)
    if repaired:
        try:
            return json.loads(repaired), True
        except (json.JSONDecodeError, ValueError):
            pass

    return None, False


def _extract_json_substring(text: str) -> str | None:
    """从文本中提取第一个完整 JSON 对象/数组"""
    starts = [
        (text.find("{"), "{"),
        (text.find("["), "["),
    ]
    starts = [(p, c) for p, c in starts if p >= 0]
    if not starts:
        return None

    start_pos, open_char = min(starts, key=lambda x: x[0])
    close_char = "}" if open_char == "{" else "]"

    depth = 0
    in_string = False
    escape = False

    for i, ch in enumerate(text[start_pos:], start_pos):
        if escape:
            escape = False
            continue
        if ch == "\\":
            escape = True
            continue
        if ch == '"':
            in_string = not in_string
            continue
        if in_string:
            continue
        if ch == open_char:
            depth += 1
        elif ch == close_char:
            depth -= 1
            if depth == 0:
                return text[start_pos : i + 1]

    return None


def _repair_truncated_json(text: str) -> str | None:
    """补全截断的 JSON"""
    text = text.strip()
    if not text:
        return None

    # 统计未闭合的括号
    open_braces = text.count("{") - text.count("}")
    open_brackets = text.count("[") - text.count("]")

    if open_braces > 0 or open_brackets > 0:
        # 尝试移除最后一行未完成的 key-value
        lines = text.split("\n")
        if len(lines) > 1:
            last_line = lines[-1].strip().rstrip(",")
            if not last_line.endswith("}") and not last_line.endswith("]") and not last_line.endswith('"'):
                text = "\n".join(lines[:-1]).rstrip().rstrip(",")

        # 补闭合括号
        text = text + "]" * open_brackets + "}" * open_braces

    return text
