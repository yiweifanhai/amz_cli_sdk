"""
全局配置管理。

加载优先级（从低到高）：
  1. 默认值（内置）
  2. 项目 .env（项目根目录，key=value 格式）
  3. ~/.amz/config.yaml（用户级 YAML）
  4. 环境变量（AMZ_* / DOUBAO_API_KEY / ARK_API_KEY）

API keys 三种设置方式：
  - .env:         ARK_API_KEY=your-key
  - config.yaml:  api_keys: {doubao: "your-key"}
  - 环境变量:     export ARK_API_KEY=your-key
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml


DEFAULT_CONFIG_YAML = """
api_keys:
  doubao: ""
  ark: ""

data_api:
  base_url: https://amz.jxpxxzj.cn
  token: ""
  timeout_s: 60
  default_cache_ttl_s: 86400

sif:
  token_file: ~/.sif_token

cosmo:
  use_images: true

llm:
  default_backend: doubao
  backends_file: ""
  temperature: 0.2
  cache_dir: ~/.cache/amz-cli/llm
  fallback_chain:
    - pro
    - lite
    - mini

cache:
  dir: ~/.cache/amz-cli
  reuse_legacy: true
  engine: sqlite

task:
  db: ~/.amz/amz-cli.db

normalizer:
  currency_exchange:
    default: USD
  bsr_category_rules: {}
  pct_convention: "0-100"
"""


def _expand_path(path: str) -> Path:
    """展开 ~ 和 $HOME 的路径"""
    return Path(os.path.expanduser(os.path.expandvars(path)))


class _Config:
    """配置单例"""

    def __init__(self):
        self._data: dict[str, Any] = {}
        self._loaded = False
        self._config_path: Path | None = None
        self._config_stamp: tuple[int, int] | None = None

    def load(self, path: str | None = None):
        """加载配置（优先级从低到高：默认值 → ~/.amz/.env → 项目 .env → ~/.amz/config.yaml → 环境变量）"""
        if path is None:
            path = "~/.amz/config.yaml"
        config_path = _expand_path(path)

        # 从默认 YAML 开始
        self._data = yaml.safe_load(DEFAULT_CONFIG_YAML) or {}

        # 用户级 ~/.amz/.env（服务端/systemd 场景：与 cwd 无关）
        self._load_dotenv_file(_expand_path("~/.amz/.env"))

        # 项目级 .env 文件（项目根目录，优先级高于用户级）
        self._load_dotenv()

        # 用户配置文件覆盖
        if config_path.exists():
            user_config = yaml.safe_load(config_path.read_text()) or {}
            _deep_merge(self._data, user_config)

        # 环境变量覆盖（AMZ_ 前缀）
        self._apply_env_overrides()

        self._loaded = True
        self._config_path = config_path
        self._config_stamp = self._saved_config_stamp()

    def _saved_config_stamp(self) -> tuple[int, int] | None:
        if self._config_path is None:
            return None
        try:
            stat = self._config_path.stat()
            return stat.st_mtime_ns, stat.st_size
        except FileNotFoundError:
            return None

    def _load_dotenv(self):
        """从当前工作目录向上查找 .env 文件（取最近的）读取配置"""
        cwd = Path.cwd()
        for parent in [cwd] + list(cwd.parents):
            dotenv = parent / ".env"
            if dotenv.exists():
                self._parse_dotenv(dotenv)
                break

    def _load_dotenv_file(self, path: Path):
        """读取指定 .env 文件（存在时）。"""
        if path.exists():
            self._parse_dotenv(path)

    def _parse_dotenv(self, path: Path):
        """解析 .env 文件，将有对应配置项的 key 合并到 self._data"""
        import re
        # 环境变量 → 配置路径映射
        env_to_config = {
            "DOUBAO_API_KEY": ("api_keys", "doubao"),
            "ARK_API_KEY": ("api_keys", "ark"),
            "AMZ_API_TOKEN": ("data_api", "token"),
            "AMZ_LLM_BACKEND": ("llm", "default_backend"),
        }
        for line in path.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            m = re.match(r"^(\w+)\s*=\s*(.+)$", line)
            if not m:
                continue
            key, value = m.group(1), m.group(2).strip().strip('"').strip("'")
            if key in env_to_config:
                obj = self._data
                cfg_path = env_to_config[key]
                for k in cfg_path[:-1]:
                    obj = obj.setdefault(k, {})
                obj[cfg_path[-1]] = value

    def _apply_env_overrides(self):
        """环境变量 AMZ_* 覆盖配置"""
        overrides = {
            "AMZ_API_TOKEN": ("data_api", "token"),
            "AMZ_DATA_BASE_URL": ("data_api", "base_url"),
            "AMZ_LLM_BACKEND": ("llm", "default_backend"),
            "AMZ_CACHE_DIR": ("cache", "dir"),
        }
        # 各 LLM provider 的 API key 也支持环境变量覆盖
        env_key_map = {
            "DOUBAO_API_KEY": "doubao",
            "ARK_API_KEY": "ark",
        }
        for env_var, provider in env_key_map.items():
            val = os.environ.get(env_var)
            if val:
                overrides[env_var] = ("api_keys", provider)

        for env_var, path in overrides.items():
            val = os.environ.get(env_var)
            if val:
                obj = self._data
                for key in path[:-1]:
                    obj = obj.setdefault(key, {})
                obj[path[-1]] = val

    def get(self, *path: str, default: Any = None) -> Any:
        """按路径读取配置，如 config.get("data_api", "base_url")"""
        if not self._loaded:
            self.load()
        obj = self._data
        for key in path:
            if isinstance(obj, dict):
                obj = obj.get(key)
            else:
                return default
            if obj is None:
                return default
        return obj

    def all(self) -> dict:
        """返回全部配置"""
        if not self._loaded:
            self.load()
        return self._data

    # -- 便捷属性 ------------------------------------------------------------

    @property
    def data_api_base_url(self) -> str:
        return self.get("data_api", "base_url", default="https://amz.jxpxxzj.cn")

    @property
    def data_api_token(self) -> str:
        return self.get("data_api", "token", default="")

    @property
    def data_api_timeout(self) -> int:
        return self.get("data_api", "timeout_s", default=60)

    @property
    def cache_dir(self) -> Path:
        return _expand_path(self.get("cache", "dir", default="~/.cache/amz-cli"))

    @property
    def reuse_legacy_cache(self) -> bool:
        return self.get("cache", "reuse_legacy", default=True)

    @property
    def sif_token_file(self) -> Path:
        return _expand_path(self.get("sif", "token_file", default="~/.sif_token"))

    @property
    def cosmo_use_images(self) -> bool:
        # Pick up changes from a separate setup process before the next extraction.
        if self._loaded and self._saved_config_stamp() != self._config_stamp:
            self.load(str(self._config_path))
        value = self.get("cosmo", "use_images", default=True)
        if not isinstance(value, bool):
            raise ValueError("cosmo.use_images must be true or false")
        return value

    @property
    def llm_default_backend(self) -> str:
        # Old installations may still store a different default. Built-in Analysis
        # now uses Doubao; other explicit providers are rejected by the LLM client.
        backend = self.get("llm", "default_backend", default="doubao")
        return backend if backend in {"doubao", "ark"} else "doubao"

    @property
    def llm_temperature(self) -> float:
        return self.get("llm", "temperature", default=0.2)

    @property
    def llm_cache_dir(self) -> Path:
        return _expand_path(self.get("llm", "cache_dir", default="~/.cache/amz-cli/llm"))

    @property
    def llm_fallback_chain(self) -> list[str]:
        return self.get("llm", "fallback_chain", default=["pro", "lite", "mini"])

    # -- API keys ------------------------------------------------------------

    def api_key(self, provider: str) -> str:
        """获取指定 provider 的 API key"""
        if provider not in {"doubao", "ark"}:
            return ""
        key = self.get("api_keys", provider, default="")
        if not key and provider in {"doubao", "ark"}:
            alias = "ark" if provider == "doubao" else "doubao"
            key = self.get("api_keys", alias, default="")
        return key


def _deep_merge(base: dict, override: dict):
    """递归合并配置"""
    for key, val in override.items():
        if key in base and isinstance(base[key], dict) and isinstance(val, dict):
            _deep_merge(base[key], val)
        else:
            base[key] = val


# 全局单例
config = _Config()
