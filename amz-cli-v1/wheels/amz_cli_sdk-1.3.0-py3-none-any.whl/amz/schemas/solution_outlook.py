"""Contracts for the Amazon + Taobao innovative-solution outlook task.

Market validates new products, classifies both platforms' titles together,
calculates per-solution signals, then requests a generation judgement.
The task results are never persisted as Market fields.
"""
from __future__ import annotations

from datetime import date
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

Text = Annotated[str, Field(min_length=1)]
Asin = Annotated[str, Field(pattern=r"^[A-Z0-9]{10}$")]
TaobaoId = Annotated[str, Field(pattern=r"^[0-9]+$")]
Month = Annotated[str, Field(pattern=r"^[0-9]{4}-(0[1-9]|1[0-2])$")]
NonNegative = Annotated[float, Field(ge=0, allow_inf_nan=False)]
Platform = Literal["amazon", "taobao"]

# Ordered from strongest opportunity to weakest; also the ranking order.
OPPORTUNITY_TIERS = ("下一代候选", "细分补充")
Tier = Literal["下一代候选", "细分补充", "当前主流", "微改进", "伪创新", "证据不足"]
Confidence = Literal["高", "中", "低"]


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


# ---------------------------------------------------------------------------
# Step 1: joint classification (analysis.market.solution_classify)
# ---------------------------------------------------------------------------


class AmazonTitleInput(_Strict):
    asin: Asin
    title: str | None = Field(default=None, max_length=2000)

    @field_validator("asin", mode="before")
    @classmethod
    def _upper(cls, value):
        return value.strip().upper() if isinstance(value, str) else value


class TaobaoTitleInput(_Strict):
    item_id: TaobaoId
    title: str | None = Field(default=None, max_length=2000)


class SolutionClassifyInput(_Strict):
    term: str = Field(min_length=1, max_length=200)
    taobao_term: str | None = Field(default=None, max_length=200)
    amazon: list[AmazonTitleInput] = Field(min_length=1, max_length=200)
    taobao: list[TaobaoTitleInput] = Field(default_factory=list, max_length=100)
    model: str = Field(default="pro", min_length=1)

    @model_validator(mode="after")
    def _unique(self):
        for ids in ([p.asin for p in self.amazon], [p.item_id for p in self.taobao]):
            if len(set(ids)) != len(ids):
                raise ValueError("product IDs must be unique per platform")
        return self


class ClassifiedSolution(_Strict):
    name: Text
    summary: Text
    solution: Text
    amazon_ids: list[Asin]
    taobao_ids: list[TaobaoId]
    unknowns: list[Text]


class UnclassifiedItem(_Strict):
    platform: Platform
    item_id: Text
    reason: Text


class SolutionClassification(_Strict):
    term: Text
    taobao_term: str | None = None
    summary: Text
    groups: list[ClassifiedSolution]
    unclassified: list[UnclassifiedItem]
    limitations: list[Text]


# ---------------------------------------------------------------------------
# Step 2: deterministic signals (calc.market.solution_signals)
# ---------------------------------------------------------------------------


class TrendPoint(_Strict):
    month: Month
    units: int = Field(ge=0)


class OutlookProduct(_Strict):
    """One Amazon sample row prepared by Market from local Product facts."""

    asin: Asin
    parent_asin: Asin | None = None
    title: str | None = None
    price_usd: NonNegative | None = None
    monthly_units: int | None = Field(default=None, ge=0)
    monthly_revenue: NonNegative | None = None
    rating: float | None = Field(default=None, ge=0, le=5)
    count_review: int | None = Field(default=None, ge=0)
    available_date: date | None = None
    sales_trend: list[TrendPoint] = Field(default_factory=list)


class SolutionMembers(_Strict):
    name: Text
    amazon_ids: list[Asin]
    taobao_ids: list[TaobaoId] = Field(default_factory=list)


class Thresholds(_Strict):
    """A new product is verified when every condition is strictly exceeded/met."""

    min_monthly_revenue: NonNegative = 5000
    min_monthly_units: int = Field(default=200, ge=0)
    new_days: int = Field(default=180, ge=1, le=730)
    # Relist checks: an old product line under a new ASIN can pass the gates above.
    # Defaults calibrated on 4,568 cached qualifying new products (2026-11-24):
    # review rate median 2.4% / p90 13.8%; launch-month rate ratio median 0.41 / p90 2.3.
    max_review_rate_pct: NonNegative = Field(default=10, description="评论数占上架以来估算销量的上限（%）")
    min_reviews_for_rate: int = Field(default=50, ge=0, description="评论数达到该值才检查评论占比")
    max_launch_rate_ratio: NonNegative = Field(default=3, description="上架当月日均销量 ÷ 之后最佳完整月日均销量的上限")


class VerifiedProduct(_Strict):
    asin: Asin
    parent_asin: Asin | None = None
    title: str | None
    days_since_launch: int
    monthly_units: int
    monthly_revenue: float
    price_usd: float | None
    rating: float | None
    count_review: int | None


class SuspectProduct(VerifiedProduct):
    """Passed the sales gates but looks like an older product line on a new ASIN."""

    reasons: list[Text] = Field(min_length=1)


class SolutionValidationResult(_Strict):
    verified_new: list[VerifiedProduct]
    suspected_new: list[SuspectProduct] = Field(default_factory=list)


class SolutionValidationInput(_Strict):
    current_date: date
    thresholds: Thresholds = Field(default_factory=Thresholds)
    products: list[OutlookProduct] = Field(min_length=1)

    @field_validator("products")
    @classmethod
    def _unique_asins(cls, rows):
        if len({row.asin for row in rows}) != len(rows):
            raise ValueError("products must have unique ASINs")
        return rows


class CalcSolutionSignalsInput(SolutionValidationInput):
    groups: list[SolutionMembers]
    taobao_total: int = Field(default=0, ge=0)
    taobao_prices_cny: dict[TaobaoId, NonNegative | None] | None = None
    verified_new: list[VerifiedProduct] | None = None
    suspected_new: list[SuspectProduct] | None = None

    @model_validator(mode="after")
    def _membership(self):
        known = {p.asin for p in self.products}
        seen: set[str] = set()
        taobao_seen: set[str] = set()
        names: set[str] = set()
        for group in self.groups:
            if group.name in names:
                raise ValueError(f"duplicate solution name: {group.name}")
            names.add(group.name)
            for asin in group.amazon_ids:
                if asin not in known:
                    raise ValueError(f"group references unknown ASIN: {asin}")
                if asin in seen:
                    raise ValueError(f"ASIN assigned to more than one solution: {asin}")
                seen.add(asin)
            for item_id in group.taobao_ids:
                if self.taobao_prices_cny is not None and item_id not in self.taobao_prices_cny:
                    raise ValueError(f"group references unknown Taobao item: {item_id}")
                if item_id in taobao_seen:
                    raise ValueError(f"Taobao item assigned more than once: {item_id}")
                taobao_seen.add(item_id)
        if self.taobao_prices_cny is not None and len(self.taobao_prices_cny) != self.taobao_total:
            raise ValueError("Taobao price rows must match the sample size")
        if self.verified_new is not None:
            verified = {p.asin for p in self.verified_new}
            if not verified <= known or len(verified) != len(self.verified_new):
                raise ValueError("verified products must have unique ASINs from the sample")
        return self


class MonthlyUnits(_Strict):
    month: Month
    units: int | None = Field(description="有观测值的商品销量合计，本月无观测时为空")
    product_count: int


class TrendSignals(_Strict):
    """Monthly sales of the current sample members; survivorship applies."""

    series: list[MonthlyUnits]
    recent_growth_pct: float | None = Field(description="同批商品近 3 个完整月 vs 前 3 个月")
    recent_growth_products: int
    yoy_growth_pct: float | None = Field(description="同批商品近 3 个完整月 vs 去年同期")
    yoy_growth_products: int


class _SalesSignals(_Strict):
    monthly_units: int | None = Field(description="有月销量的 ASIN 合计。全缺时为空，覆盖见 missing_units")
    monthly_revenue: float | None = Field(description="有月营收的 ASIN 合计，单位为美元。全缺时为空")
    verified_parent_count: int | None = Field(default=None, description="已验证新品中，已知且不同的父 ASIN 数量")
    verified_missing_parent_count: int | None = Field(default=None, description="缺父 ASIN 的已验证新品数量")
    verified_line_count: int | None = Field(
        default=None, description="可确认独立的商品线数：已知不同父 ASIN 数，缺父 ASIN 的商品合计最多算 1 条")
    suspected_new_count: int | None = Field(default=None, description="通过销量门槛但疑似老品换新 ASIN 的商品数")
    new_count: int
    new_revenue_share_pct: float | None
    new_units_share_pct: float | None = Field(default=None, description="新品月销量占比，仅纳入上架日期和月销量均有效的商品")
    new_units_share_count: int | None = Field(default=None, description="新品销量占比分母中的商品数")
    new_ramp_days_median: float | None = Field(default=None, description="新品从上架到首次观测到月销量超过门槛的天数中位数，反映首次达标天数的上界")
    new_ramp_count: int | None = Field(default=None, description="起量天数的新品样本数")
    missing_units: int | None = None
    missing_revenue: int
    missing_date: int
    trend: TrendSignals


class SolutionSignals(_SalesSignals):
    name: Text
    amazon_count: int
    taobao_count: int
    taobao_priced_count: int | None = None
    taobao_price_min_cny: float | None = None
    taobao_price_median_cny: float | None = None
    taobao_price_max_cny: float | None = None
    revenue_share_pct: float | None
    verified_new: list[VerifiedProduct]
    verified_new_count: int | None = None
    suspected_new: list[SuspectProduct] = Field(default_factory=list)
    avg_rating: float | None = Field(description="按评论数加权")
    rated_count: int
    price_median: float | None
    price_min: float | None
    price_max: float | None


class MarketSignals(_SalesSignals):
    product_count: int
    verified_new_count: int
    taobao_count: int


class SolutionSignalsResult(_Strict):
    current_date: date
    thresholds: Thresholds
    market: MarketSignals
    solutions: list[SolutionSignals]
    unassigned_verified: list[VerifiedProduct]
    unassigned_suspected: list[SuspectProduct] = Field(default_factory=list)
    limitations: list[Text]


# ---------------------------------------------------------------------------
# Step 3: generation judgement (analysis.market.solution_outlook)
# ---------------------------------------------------------------------------


class ProductExample(_Strict):
    platform: Platform
    item_id: Text
    title: Text


def verified_lines(products: list[VerifiedProduct]) -> int:
    """Independent product lines; unknown parents may all be one line."""
    parents = {p.parent_asin for p in products if p.parent_asin}
    return len(parents) + (1 if any(p.parent_asin is None for p in products) else 0)


class OutlookSolutionInput(_Strict):
    name: Text
    summary: Text
    solution: Text
    signals: SolutionSignals
    examples: list[ProductExample] = Field(max_length=12)

    @model_validator(mode="after")
    def _verified_evidence_counts(self):
        verified = self.signals.verified_new
        if len({p.asin for p in verified}) != len(verified):
            raise ValueError("verified_new contains duplicate ASINs")
        expected = {
            "verified_new_count": len(verified),
            "verified_parent_count": len({p.parent_asin for p in verified if p.parent_asin}),
            "verified_missing_parent_count": sum(p.parent_asin is None for p in verified),
            "verified_line_count": verified_lines(verified),
        }
        for field, count in expected.items():
            supplied = getattr(self.signals, field)
            if supplied is not None and supplied != count:
                raise ValueError(f"{field} disagrees with the verified product evidence")
        return self


class SolutionOutlookInput(_Strict):
    term: Text
    taobao_term: str | None = None
    market: MarketSignals
    thresholds: Thresholds
    solutions: list[OutlookSolutionInput] = Field(min_length=1)
    model: str = Field(default="pro", min_length=1)

    @model_validator(mode="after")
    def _solution_names(self):
        names = [s.name for s in self.solutions]
        if len(set(names)) != len(names):
            raise ValueError("solution names must be unique")
        if any(s.name != s.signals.name for s in self.solutions):
            raise ValueError("solution and signal names must match")
        verified = [p.asin for s in self.solutions for p in s.signals.verified_new]
        if len(set(verified)) != len(verified) or len(verified) > self.market.verified_new_count:
            raise ValueError("assigned verified ASINs must be distinct and within the market verified count")
        return self


class JudgementDraft(_Strict):
    name: Text
    tier: Tier
    replaces: str = Field(description="对标的现有主流方案名称；本身是主流或无对标时为空")
    why_strong: list[Text] = Field(min_length=1, description="结合本方案的样本事实与常识解释分级")
    evidence_ids: list[Text] = Field(description="本方案中支撑判断的商品引用，格式为 amazon:ASIN 或 taobao:商品号")
    barriers: list[Text] = Field(description="扩散阻力：价格、习惯、专利、工艺、认知等")
    counter_evidence: list[Text] = Field(min_length=1, description="它可能不会成为主流的理由")
    confidence: Confidence


class OutlookDraft(_Strict):
    summary: Text = Field(description="这个市场当前的机会在哪里，一段话")
    judgements: list[JudgementDraft]
    unknowns: list[Text]


class SolutionJudgement(JudgementDraft):
    summary: Text
    solution: Text
    signals: SolutionSignals
    examples: list[ProductExample]


class SolutionOutlook(_Strict):
    term: Text
    taobao_term: str | None
    market_trend: Text
    summary: Text
    market: MarketSignals
    thresholds: Thresholds
    opportunities: list[SolutionJudgement] = Field(description="下一代候选与细分补充，按强弱排序")
    other_solutions: list[SolutionJudgement]
    unknowns: list[Text]
    limitations: list[Text]


class SolutionOutlookResult(SolutionOutlook):
    """Entity task envelope data: the outlook plus sample provenance."""

    current_date: date
    sample: dict
    taobao_sample: dict | None
    classification_summary: Text
    solution_members: list[SolutionMembers]
    unclassified: list[UnclassifiedItem]
    unassigned_verified: list[VerifiedProduct]
    unassigned_suspected: list[SuspectProduct] = Field(default_factory=list)
