"""Per-solution sales, rating, new-product and trend signals.

Deterministic: same input, same output. A new product is *verified* when it
was launched within ``new_days`` and its monthly revenue and monthly units
both strictly exceed the thresholds.
"""
from __future__ import annotations

from calendar import monthrange
from datetime import date
from statistics import median

from amz.calc.market.solution_validation import launch_age, validate_products
from amz.envelope import Result, ok
from amz.registry import capability
from amz.schemas.solution_outlook import (
    CalcSolutionSignalsInput, MarketSignals, MonthlyUnits, OutlookProduct, SolutionSignals,
    SolutionSignalsResult, Thresholds, TrendSignals, VerifiedProduct, verified_lines,
)

TREND_MONTHS = 12


def _shift(month: str, delta: int) -> str:
    year, mon = int(month[:4]), int(month[5:])
    index = year * 12 + (mon - 1) + delta
    return f"{index // 12:04d}-{index % 12 + 1:02d}"


def comparison_months(end: str) -> tuple[list[str], list[str], list[str]]:
    """Chronological months for the recent, previous and year-ago windows."""
    recent = [_shift(end, offset) for offset in (-2, -1, 0)]
    return recent, [_shift(month, -3) for month in recent], [_shift(month, -12) for month in recent]


def _history(row: OutlookProduct, current: date) -> dict[str, int]:
    """Upstream histories can include parent sales before this ASIN launched."""
    launch_month = row.available_date.isoformat()[:7] if row.available_date else ""
    current_month = current.isoformat()[:7]
    return {p.month: p.units for p in row.sales_trend if launch_month <= p.month < current_month}


def _pct(part: float | None, whole: float | None) -> float | None:
    if part is None or whole is None or whole == 0:
        return None
    return round(part / whole * 100, 1)


def _growth(histories: list[dict[str, int]], recent: list[str], base: list[str]) -> tuple[float | None, int]:
    """Compare the same products, so launches do not count as growth."""
    needed = set(recent) | set(base)
    recent_sum = base_sum = count = 0
    for units in histories:
        if not needed <= units.keys():
            continue
        count += 1
        recent_sum += sum(units[m] for m in recent)
        base_sum += sum(units[m] for m in base)
    if not count or base_sum <= 0:
        return None, count
    return round((recent_sum - base_sum) / base_sum * 100, 1), count


def _trend(histories: list[dict[str, int]], end: str | None) -> TrendSignals:
    if end is None:
        return TrendSignals(series=[], recent_growth_pct=None, recent_growth_products=0,
                            yoy_growth_pct=None, yoy_growth_products=0)
    window = [_shift(end, -i) for i in range(TREND_MONTHS - 1, -1, -1)]
    series = []
    for month in window:
        values = [units[month] for units in histories if month in units]
        series.append(MonthlyUnits(month=month, units=sum(values) if values else None, product_count=len(values)))
    recent, previous, year_ago = comparison_months(end)
    recent_pct, recent_n = _growth(histories, recent, previous)
    yoy_pct, yoy_n = _growth(histories, recent, year_ago)
    return TrendSignals(series=series, recent_growth_pct=recent_pct, recent_growth_products=recent_n,
                        yoy_growth_pct=yoy_pct, yoy_growth_products=yoy_n)


def _ramp_days(row: OutlookProduct, current: date, min_units: int) -> int | None:
    """Days from launch to the first observed month above the units gate."""
    launched = row.available_date
    launch_month = launched.isoformat()[:7]
    current_month = current.isoformat()[:7]
    months = [p.month for p in row.sales_trend if launch_month <= p.month < current_month and p.units > min_units]
    if months:
        first = date.fromisoformat(f"{min(months)}-01")
        observed = first.replace(day=monthrange(first.year, first.month)[1])
    elif row.monthly_units is not None and row.monthly_units > min_units:
        observed = current
    else:
        return None
    return (observed - launched).days


def _totals(rows: list[OutlookProduct], current: date, limits: Thresholds) -> dict:
    units = [r.monthly_units for r in rows if r.monthly_units is not None]
    revenues = [r.monthly_revenue for r in rows if r.monthly_revenue is not None]
    dated = [(r, age) for r in rows if (age := launch_age(r, current)) is not None]
    new_rows = [r for r, age in dated if age <= limits.new_days]
    dated_units = [r.monthly_units for r, _ in dated if r.monthly_units is not None]
    dated_revenue = sum(r.monthly_revenue for r, _ in dated if r.monthly_revenue is not None)
    new_units = sum(r.monthly_units for r in new_rows if r.monthly_units is not None)
    new_revenue = sum(r.monthly_revenue for r in new_rows if r.monthly_revenue is not None)
    ramp_days = [
        days for row in new_rows if (days := _ramp_days(row, current, limits.min_monthly_units)) is not None
    ]
    return {
        "monthly_units": sum(units) if units else None,
        "monthly_revenue": round(sum(revenues), 2) if revenues else None,
        "new_count": len(new_rows),
        "new_revenue_share_pct": _pct(new_revenue, dated_revenue),
        "new_units_share_pct": _pct(new_units, sum(dated_units)),
        "new_units_share_count": len(dated_units),
        "new_ramp_days_median": median(ramp_days) if ramp_days else None,
        "new_ramp_count": len(ramp_days),
        "missing_revenue": len(rows) - len(revenues),
        "missing_units": len(rows) - len(units),
        "missing_date": len(rows) - len(dated),
    }


def _verified_counts(products: list[VerifiedProduct]) -> dict[str, int]:
    return {
        "verified_new_count": len(products),
        "verified_parent_count": len({p.parent_asin for p in products if p.parent_asin is not None}),
        "verified_missing_parent_count": sum(p.parent_asin is None for p in products),
        "verified_line_count": verified_lines(products),
    }


@capability(
    "calc.market.solution_signals",
    description="按解决方案汇总销量、营收、评分、已验证新品和月度销量趋势",
    input_model=CalcSolutionSignalsInput, output_model=SolutionSignalsResult,
)
def solution_signals(
    current_date: date, products: list[dict], groups: list[dict],
    thresholds: dict | None = None, taobao_total: int = 0,
    verified_new: list[dict] | None = None, taobao_prices_cny: dict | None = None,
    suspected_new: list[dict] | None = None,
) -> Result:
    values = CalcSolutionSignalsInput.model_validate({
        "current_date": current_date, "products": products, "groups": groups,
        "thresholds": thresholds or {}, "taobao_total": taobao_total,
        "verified_new": verified_new, "taobao_prices_cny": taobao_prices_cny,
        "suspected_new": suspected_new,
    })
    current, limits = values.current_date, values.thresholds
    by_asin = {row.asin: row for row in values.products}
    histories = {row.asin: _history(row, current) for row in values.products}
    end = max((month for history in histories.values() for month in history), default=None)
    market_totals = _totals(values.products, current, limits)
    market_verified, market_suspected = values.verified_new, values.suspected_new
    if market_verified is None:
        # Direct internal callers may omit the preceding validation result.
        market_verified, market_suspected = validate_products(values.products, current, limits)
    market_suspected = market_suspected or []
    taobao_prices = values.taobao_prices_cny or {}

    solutions = []
    assigned: set[str] = set()
    for group in values.groups:
        rows = [by_asin[asin] for asin in group.amazon_ids]
        assigned.update(group.amazon_ids)
        totals = _totals(rows, current, limits)
        members = set(group.amazon_ids)
        verified = [p for p in market_verified if p.asin in members]
        suspected = [p for p in market_suspected if p.asin in members]
        rated = [r for r in rows if r.rating is not None and r.count_review]
        prices = [r.price_usd for r in rows if r.price_usd is not None]
        cny = [price for item_id in group.taobao_ids if (price := taobao_prices.get(item_id)) is not None]
        weight = sum(r.count_review for r in rated)
        solutions.append(SolutionSignals(
            name=group.name, amazon_count=len(rows), taobao_count=len(group.taobao_ids),
            taobao_priced_count=len(cny), taobao_price_median_cny=round(median(cny), 2) if cny else None,
            taobao_price_min_cny=min(cny) if cny else None, taobao_price_max_cny=max(cny) if cny else None,
            revenue_share_pct=_pct(totals["monthly_revenue"], market_totals["monthly_revenue"]),
            verified_new=verified, **_verified_counts(verified),
            suspected_new=suspected, suspected_new_count=len(suspected),
            avg_rating=round(sum(r.rating * r.count_review for r in rated) / weight, 2) if weight else None,
            rated_count=len(rated),
            price_median=round(median(prices), 2) if prices else None,
            price_min=min(prices) if prices else None, price_max=max(prices) if prices else None,
            trend=_trend([histories[asin] for asin in group.amazon_ids], end), **totals,
        ))
    solutions.sort(key=lambda s: (sum(v.monthly_revenue for v in s.verified_new),
                                  s.monthly_revenue if s.monthly_revenue is not None else -1), reverse=True)

    result = SolutionSignalsResult(
        current_date=current, thresholds=limits,
        market=MarketSignals(
            product_count=len(values.products), **_verified_counts(market_verified),
            suspected_new_count=len(market_suspected),
            taobao_count=values.taobao_total, trend=_trend(list(histories.values()), end), **market_totals,
        ),
        solutions=solutions,
        unassigned_verified=[v for v in market_verified if v.asin not in assigned],
        unassigned_suspected=[v for v in market_suspected if v.asin not in assigned],
        limitations=[
            "月销量、月营收和逐月销量来自第三方估算，不是亚马逊官方数据。",
            "疑似老品换新 ASIN 的商品（评论占比过高、上架当月销量异常或同父体有老商品）不计入已验证新品，单列待核实；规则是启发式，可能误判。",
            "销量和营收按样本 ASIN 加总，同父变体可能共用估算。已验证新品另列已知父 ASIN 去重数和缺父 ASIN 的商品数。",
            "趋势只汇总当前搜索样本中的商品，已下架或排名靠后的商品不在内（幸存者偏差）。",
            "增长率只比较在对比月份都有数据的同一批商品，新上架商品不计入增长。",
            "新品销量与营收占比仅使用上架日期和对应月度数据均可用的商品。销量和营收合计只包含有数据的商品。",
            "起量天数从上架计至首次观测到月销量超过门槛，历史取完整月末，当期取采样日。结果为已达销量门槛新品的天数上界中位数。",
            "亚马逊商品价格和月营收以美元计。淘宝仅计第一页供给和人民币标价，缺价不参与价格统计，无法据此推算淘宝销量。",
        ],
    )
    return ok(data=result.model_dump(mode="json"))
