"""Prepare the US Market sample and one Taobao search page for joint analysis."""
from __future__ import annotations

import json
import math
import re
from datetime import date
from typing import TYPE_CHECKING

from amz.entities.taobao import TaobaoMarket
from amz.envelope import Code, Result, err
from amz.schemas.data_outputs import CompetingItemOutput

if TYPE_CHECKING:
    from amz.entities.market.entity import Market


def _number(value) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float, str)):
        return None
    try:
        number = float(value)
    except (ValueError, OverflowError):
        return None
    return number if math.isfinite(number) and number >= 0 else None


def _date(value: str | None) -> date | None:
    if not isinstance(value, str):
        return None
    try:
        return date.fromisoformat(value[:10])
    except ValueError:
        return None


def _sales_trend(extra: dict) -> list[dict]:
    """Support both formats used by competing-lookup, including older cached rows."""
    history = extra.get("salesTrend")
    if isinstance(history, str):
        try:
            history = json.loads(history)
        except ValueError:
            history = None
    pairs = list(history.items()) if isinstance(history, dict) else []
    trends = extra.get("trends")
    if isinstance(trends, list):
        pairs.extend((row.get("dk"), row.get("sales")) for row in trends if isinstance(row, dict))

    points = {}
    for key, value in pairs:
        month = str(key)
        units = _number(value)
        if re.fullmatch(r"[0-9]{4}(0[1-9]|1[0-2])", month) and units is not None and units.is_integer():
            points[f"{month[:4]}-{month[4:]}"] = int(units)
    return [{"month": month, "units": units} for month, units in sorted(points.items())]


def _amazon_row(item: CompetingItemOutput) -> dict:
    extra = item.model_extra or {}
    missing = extra.get("missing_sample_fields") or []
    # Older projections have no presence metadata. Read their available facts
    # directly; newer snapshots exclude facts only retained from older imports.
    def observed(key):
        return None if key in missing else getattr(item, key)

    parent = str(extra.get("parent") or extra.get("parent_asin") or "").strip().upper()
    revenue = _number(extra.get("totalAmount"))
    if revenue is None:
        revenue = _number(extra.get("revenue"))
    rating = _number(observed("rating"))
    units = observed("monthly_sales")
    reviews = observed("count_review")
    launched = _date(item.available_date) or _date(extra.get("listing_date"))
    return {
        "asin": item.asin.strip().upper(),
        "parent_asin": parent if re.fullmatch(r"[A-Z0-9]{10}", parent) else None,
        "title": (observed("title") or "").strip() or None,
        "price_usd": _number(observed("price_usd")),
        "monthly_units": units if units is not None and units >= 0 else None,
        "monthly_revenue": revenue,
        "rating": rating if rating is not None and 1 <= rating <= 5 else None,
        "count_review": reviews if reviews is not None and reviews >= 0 else None,
        "available_date": launched if "available_date" not in missing else None,
        "sales_trend": _sales_trend(extra),
    }


def load_solution_sample(
    market: Market, taobao_term: str | None = None, pages: int | None = None,
) -> tuple[list[dict], list[dict], dict] | Result:
    """Read both Entity samples without fetching individual product details."""
    if market.marketplace != "US" or market.category:
        return err(Code.ERROR_PARAM, "solution outlook supports US keyword markets without a category filter")
    try:
        taobao = TaobaoMarket.fetch(market.term if taobao_term is None else taobao_term)
    except ValueError as exc:
        return err(Code.ERROR_PARAM, str(exc))

    loaded = market.get_products(pages=pages)
    if loaded.code != Code.OK:
        return loaded
    rows = [_amazon_row(item) for item in market.products or []]
    if not rows:
        return err(Code.ERROR_MISSING_FIELDS, "empty Amazon Market sample", missing=["products"])
    invalid = [row["asin"] for row in rows if not re.fullmatch(r"[A-Z0-9]{10}", row["asin"])]
    if invalid:
        return err(Code.ERROR_MISSING_FIELDS, "Amazon sample includes invalid ASINs", data=invalid, missing=["products.asin"])

    required = {"title": "title", "available_date": "available_date", "monthly_units": "monthly_sales",
                "monthly_revenue": "totalAmount"}
    if not any(all(row[key] is not None for key in required) for row in rows):
        missing = [f"products.{field}" for key, field in required.items() if all(row[key] is None for row in rows)]
        return err(Code.ERROR_MISSING_FIELDS,
                   "no Amazon product has a title, launch date, monthly units and monthly revenue together",
                   missing=missing or ["products.title/available_date/monthly_sales/monthly_revenue"])

    loaded = taobao.get_products()
    if loaded.code != Code.OK:
        return loaded
    if missing_ids := loaded.data["missing_item_ids"]:
        return err(Code.ERROR_MISSING_FIELDS, "Taobao sample references missing local products", missing=missing_ids)
    items = [
        {"item_id": item["item_id"], "title": (item.get("title") or "").strip() or None,
         "price_cny": _number(item.get("price_cny"))}
        for item in loaded.data["products"]
    ]
    if items and not any(item["title"] for item in items):
        return err(Code.ERROR_MISSING_FIELDS, "Taobao sample has no product titles", missing=["taobao.products.title"])
    if not items and taobao.sample.skipped_count:
        return err(Code.ERROR_MISSING_FIELDS, "Taobao page contained only products without IDs", missing=["taobao.products.item_id"])
    sample = {
        "term": taobao.term, "source": taobao.sample.source, "page": taobao.sample.page,
        "collected_at": taobao.sample.collected_at, "product_count": len(items),
        "skipped_count": taobao.sample.skipped_count, "missing_item_ids": [],
    }
    return rows, items, sample
