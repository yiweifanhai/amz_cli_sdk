"""Compare a Product's listing and main image with legacy solutions in its primary Market."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from datetime import date
from typing import TYPE_CHECKING

from amz.entities._core import operations
from amz.entities._core.store import entity_store
from amz.entities.product.facts import _missing
from amz.envelope import Code, Result, err, ok
from amz.schemas.entity_ref import product_ref
from amz.schemas.novelty import (
    ExistingMatch, FailedRef, NoveltySample, ProductNoveltyOutput, SkippedGroup,
)

# product-info is slow (10–30 s); bounded to stay polite to the data server.
FETCH_CONCURRENCY = 4

if TYPE_CHECKING:
    from amz.entities.product.entity import Product
    from amz.schemas.amazon_analysis import AmazonMarketSummary
    from amz.schemas.data_outputs import CompetingItemOutput


def _listing_facts(product: Product) -> dict | Result:
    failure = product._ensure_analysis_facts()
    if failure is not None:
        return failure

    bullets = [text.strip() for text in product.bullet_points if text.strip()]
    image_url = product._project_image_url().strip()
    missing = []
    if not bullets:
        missing.append("bullet_points")
    if not image_url:
        missing.append("images")
    if missing:
        return _missing(*missing)

    return {"asin": product.asin, "title": product.title, "bullet_points": bullets,
            "image_url": image_url, "listing_date": product.listing_date}


def _group_representatives(
    product: Product, summary: AmazonMarketSummary, sample: dict[str, CompetingItemOutput],
    listing_dates: dict[str, str], info: NoveltySample, max_groups: int, per_group: int,
) -> list[dict]:
    ranked = []
    for group in summary.groups:
        members = [asin for asin in group.product_ids if asin in listing_dates]
        if not members:
            info.skipped_groups.append(SkippedGroup(group_name=group.name, reason="组内没有符合年限的老品"))
            continue
        members.sort(key=lambda asin: sample[asin].monthly_sales or 0, reverse=True)
        volume = sum(sample[asin].monthly_sales or 0 for asin in members)
        # The target's title group is the likeliest place to find an existing solution.
        target_in_group = product.asin in group.product_ids
        if target_in_group:
            info.target_group = group.name
        priority = (target_in_group, volume)
        ranked.append((priority, group, members))

    info.eligible_group_count = len(ranked)
    ranked.sort(key=lambda row: row[0], reverse=True)
    # Selection equals a sequential walk (try groups in priority order until
    # max_groups have a usable representative; inside a group replace failed
    # representatives with the next legacy product). With k slots left, the next
    # k groups would all be tried anyway, so they are resolved together, and each
    # round fetches every group's shortfall concurrently.
    loaded: dict[int, list[dict]] = {}
    position = 0
    while position < len(ranked) and sum(1 for rows in loaded.values() if rows) < max_groups:
        window = list(range(position, min(len(ranked), position + max_groups - sum(1 for rows in loaded.values() if rows))))
        position += len(window)
        cursors = dict.fromkeys(window, 0)
        for index in window:
            loaded[index] = []
        while True:
            wanted = []
            for index in window:
                members = ranked[index][2]
                need = per_group - len(loaded[index])
                take = members[cursors[index]:cursors[index] + need]
                cursors[index] += len(take)
                wanted.append((index, take))
            if not any(take for _, take in wanted):
                break
            facts = _load_listing_facts(product, [asin for _, take in wanted for asin in take])
            for index, take in wanted:
                for asin in take:
                    if isinstance(facts[asin], Result):
                        info.failed_refs.append(FailedRef(asin=asin, reason=facts[asin].message or facts[asin].code.value))
                    else:
                        loaded[index].append({**facts[asin], "listing_date": listing_dates[asin],
                                             "monthly_sales": sample[asin].monthly_sales})

    groups = []
    for index, (_, group, members) in enumerate(ranked):
        if index not in loaded:
            info.skipped_groups.append(SkippedGroup(group_name=group.name, reason=f"超出 max_groups={max_groups}（本品所在组优先，其余按老品月销量排序）"))
        elif loaded[index]:
            groups.append({"group_name": group.name, "solution": group.solution,
                           "legacy_count": len(members), "members": loaded[index]})
        else:
            info.skipped_groups.append(SkippedGroup(group_name=group.name, reason="代表老品资料均无法补齐"))
    return groups


def _load_listing_facts(product: Product, asins: list[str]) -> dict[str, dict | Result]:
    """Fetch legacy Product details concurrently; each Product enriches its own fields."""
    entities = {asin: entity_store.get_or_create(product_ref(product.marketplace, asin)) for asin in asins}
    if len(entities) <= 1:
        return {asin: _listing_facts(entity) for asin, entity in entities.items()}
    results: dict[str, dict | Result] = {}
    with ThreadPoolExecutor(max_workers=min(FETCH_CONCURRENCY, len(entities))) as executor:
        futures = {asin: executor.submit(_listing_facts, entity) for asin, entity in entities.items()}
        for asin, future in futures.items():
            try:
                results[asin] = future.result()
            except Exception as exc:  # one failed Product must not abort the task
                results[asin] = err(Code.ERROR_UPSTREAM, f"{type(exc).__name__}: {exc}")
    return results


def novelty(
    product: Product,
    pages: int = 2,
    min_age_months: int = 12,
    max_groups: int = 6,
    per_group: int = 3,
    existing_cap: int = 60,
    as_of: date | None = None,
    model: str = "pro",
) -> Result:
    as_of = as_of or date.today()
    target = _listing_facts(product)
    if isinstance(target, Result):
        return target

    result = product.enrich("market")
    if result.code != Code.OK:
        return result
    market = product.market
    if market is None:
        return _missing("market")
    if market.marketplace != product.marketplace:
        return err(Code.ERROR_PARAM, "primary market must be in the Product marketplace")

    # Check age before asking a model to classify market titles.
    result = market.enrich("products", pages=pages)
    if result.code != Code.OK:
        return result
    sample = {item.asin: item for item in (market.products or []) if item.asin}
    if not sample:
        return _missing("market.products")
    split = operations.run_calc("calc.product.legacy_split", {
        "products": [
            {"asin": asin, "listing_date": getattr(item, "listing_date", None) or item.available_date}
            for asin, item in sample.items()
        ],
        "as_of": as_of, "min_age_months": min_age_months, "exclude_asins": [product.asin],
    })
    if split.code != Code.OK:
        return split
    split_data = split.data
    legacy_dates = {asin: split_data["listing_dates"][asin] for asin in split_data["legacy_asins"]}
    info = NoveltySample(
        market_term=market.term, pages=pages, product_count=len(sample), legacy_count=len(legacy_dates),
        recent_count=len(split_data["recent_asins"]), missing_date_asins=split_data["missing_date_asins"],
        eligible_group_count=0, compared_group_count=0, skipped_groups=[], failed_refs=[],
    )
    if not legacy_dates:
        return err(Code.ERROR_MISSING_FIELDS, "市场样本中没有上架日期满足要求的其他商品",
                   missing=["legacy_products"], data={"sample": info.model_dump()})
    if not any((sample[asin].title or "").strip() for asin in legacy_dates):
        return err(Code.ERROR_MISSING_FIELDS, "老品均缺少用于分组的标题",
                   missing=["legacy_products.title"], data={"sample": info.model_dump()})

    classified = market.enrich("summary", pages=pages, model=model)
    if classified.code != Code.OK:
        return classified
    summary = market.summary
    if summary is None:
        return _missing("market.summary")
    info.failed_refs.extend(
        FailedRef(asin=item.item_id, reason=item.reason)
        for item in summary.unclassified if item.item_id in legacy_dates
    )
    groups = _group_representatives(product, summary, sample, legacy_dates, info, max_groups, per_group)
    if not groups:
        return err(Code.ERROR_MISSING_FIELDS, "没有可供图文比较的老品方案组，详见 sample",
                   missing=["legacy_products"], data={"sample": info.model_dump()}, usage=classified.meta.usage)

    analysis = operations.run_analysis("analysis.product.novelty", {
        "target": target, "groups": groups, "model": model,
    })
    classification_requests = classified.meta.usage.get("llm_requests", 0)
    if classification_requests:
        # Market.summary reports request count only. Keep comparison tokens
        # scoped to that stage instead of presenting them as the task total.
        analysis.meta.usage = {
            "llm_requests": classification_requests + analysis.meta.usage.get("llm_requests", 0),
            "classification": classified.meta.usage,
            "comparison": analysis.meta.usage,
        }
    details = analysis.data if isinstance(analysis.data, dict) else {}
    info.skipped_groups.extend(SkippedGroup.model_validate(group) for group in details.get("skipped_groups", []))
    info.failed_refs.extend(FailedRef.model_validate(ref) for ref in details.get("failed_refs", []))
    if analysis.code != Code.OK:
        analysis.data = {**details, "sample": info.model_dump()}
        return analysis
    judgements = analysis.data["groups"]
    info.compared_group_count = len(judgements)
    score = operations.run_calc("calc.product.novelty_score", {"groups": judgements, "existing_cap": existing_cap})
    if score.code != Code.OK:
        score.meta.usage.update(analysis.meta.usage)
        return score
    score_data = score.data
    matches = [
        ExistingMatch(asin=asin, group_name=group["group_name"], listing_date=legacy_dates[asin])
        for group in judgements for asin in group["matched_asins"]
    ]
    closest = next(group for group in judgements if group["group_name"] == score_data["closest_group"])

    compared_count = sum(len(group["compared_asins"]) for group in judgements)
    limitations = [
        f"主关键词「{market.term}」前 {pages} 页取样 {len(sample)} 件，符合年限的老品 {len(legacy_dates)} 件。"
        f"实际比较 {info.compared_group_count} 组、{compared_count} 件代表老品；existing=false 仅表示在这些代表中未发现同类方案。",
        "按标题分组，优先比较本品所在且有老品的组，其余按组内老品月销量总和排序。每组取高销量代表老品的标题、五点和主图。",
        "existing=true 时创新分取匹配到的老品方案组得分并按 existing_cap 封顶；否则取最接近老品方案组的得分。",
        *analysis.data.get("limitations", []),
    ]
    if info.missing_date_asins:
        limitations.append(f"{len(info.missing_date_asins)} 件商品没有有效上架日期，已排除。")
    if info.target_group is None and info.eligible_group_count > max_groups:
        guidance = "可调大 max_groups（上限 12）复查。" if max_groups < 12 else "max_groups 已达到上限 12。"
        limitations.append(
            f"本品未归入含老品的 {info.eligible_group_count} 个候选组，本次按组内老品月销量排序，最多比较 {max_groups} 组。"
            f"低销量组中的相似方案可能遗漏。跳过原因见 sample.skipped_groups。{guidance}"
        )

    output = ProductNoveltyOutput(
        asin=product.asin, as_of=as_of, cutoff_date=split_data["cutoff_date"], min_age_months=min_age_months,
        existing_matches=matches, novel_points=closest["novel_points"], groups=judgements,
        sample=info, limitations=limitations, **score_data,
    )
    return ok(data=output.model_dump(mode="json"), usage=analysis.meta.usage)
