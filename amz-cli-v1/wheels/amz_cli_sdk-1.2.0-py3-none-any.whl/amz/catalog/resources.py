"""Read verified build copies from installed Python package resources."""
from __future__ import annotations

import hashlib
import json
from importlib.resources import files
from typing import Any

from pydantic import Field

from amz import __version__

from amz.catalog.models import CatalogModel


def content_hash(payload: Any) -> str:
    encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


class ResourceBundle(CatalogModel):
    schema_version: int = Field(default=1, ge=1, le=1)
    source: str
    build_version: str = __version__
    content_hash: str = Field(pattern=r"^[a-f0-9]{64}$")
    payload: dict[str, Any]


def resource_bundle(payload: dict[str, Any], source: str) -> dict[str, Any]:
    return ResourceBundle(source=source, content_hash=content_hash(payload), payload=payload).model_dump()


def load_resource(name: str) -> dict[str, Any]:
    if name not in {"metadata", "renderers"}:
        raise ValueError(f"unknown catalog resource: {name}")
    text = files("amz.catalog").joinpath("generated", name + ".json").read_text(encoding="utf-8")
    bundle = ResourceBundle.model_validate_json(text)
    if content_hash(bundle.payload) != bundle.content_hash:
        raise ValueError(f"catalog resource hash mismatch: {name}")
    return bundle.payload
