"""Strict, data-only catalog and renderer contracts shared by all hosts."""
from __future__ import annotations

from typing import Any, Literal
from copy import deepcopy

from jsonschema.validators import validator_for
from pydantic import BaseModel, ConfigDict, Field, create_model, field_validator, model_validator


class CatalogModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class FormatRef(CatalogModel):
    id: str = Field(min_length=1, pattern=r"^[A-Za-z0-9][A-Za-z0-9._-]*$")
    version: int = Field(ge=1, strict=True)


class OutputContract(FormatRef):
    schema_hash: str = Field(pattern=r"^[a-f0-9]{64}$")


class RendererRef(CatalogModel):
    id: str = Field(min_length=1, pattern=r"^[A-Za-z0-9][A-Za-z0-9._-]*$")
    version: int = Field(ge=1, strict=True)


class ViewBinding(CatalogModel):
    renderer: RendererRef
    options: dict[str, Any] = Field(default_factory=dict)


class CompositeStage(CatalogModel):
    id: str = Field(min_length=1)
    step: str = Field(min_length=1)
    title: str
    renderer: str


class CompositeViewBinding(ViewBinding):
    version: int = Field(default=1, ge=1)
    title: str
    related_skills: list[str] = Field(default_factory=list)
    stages: list[CompositeStage] = Field(default_factory=list)
    summary_fields: list[str] = Field(default_factory=list)


class AcceptedFormat(CatalogModel):
    id: str = Field(min_length=1, pattern=r"^(\*|[A-Za-z0-9][A-Za-z0-9._-]*)$")
    version: int = Field(ge=1, strict=True)


class RendererDefinition(CatalogModel):
    id: str = Field(min_length=1, pattern=r"^[A-Za-z0-9][A-Za-z0-9._-]*$")
    version: int = Field(ge=1, strict=True)
    accepts: list[AcceptedFormat] = Field(min_length=1)
    options_schema: dict[str, Any]
    component: str = Field(pattern=r"^[A-Za-z][A-Za-z0-9]*$")
    fixtures: list[str] = Field(default_factory=list)

    @field_validator("options_schema")
    @classmethod
    def check_schema(cls, value):
        validator_for(value).check_schema(value)
        return value

    @field_validator("fixtures")
    @classmethod
    def check_fixtures(cls, value):
        for path in value:
            if path.startswith(("/", "\\")) or ":" in path or ".." in path.split("/") or "\\" in path:
                raise ValueError("fixtures must be relative static file references")
        return value


class RendererManifest(CatalogModel):
    schema_version: Literal[1]
    renderers: list[RendererDefinition]

    @model_validator(mode="after")
    def unique_modules(self):
        keys = [(item.id, item.version) for item in self.renderers]
        if len(set(keys)) != len(keys):
            raise ValueError("duplicate renderer id/version")
        return self


class Group(CatalogModel):
    id: str = Field(min_length=1)
    title: str = Field(min_length=1)


class ToolMetadata(CatalogModel):
    id: str = Field(min_length=1)
    title: str = Field(min_length=1)
    description: str
    group: str
    layer: Literal["entity", "data"]
    renderer: str  # Compatibility field; new shared views use the explicit binding.
    view: ViewBinding
    publication: Literal["public", "local", "retired"] = "public"


class CatalogMetadata(CatalogModel):
    schema_version: Literal[1]
    groups: list[Group]
    featured: list[str]
    tools: list[ToolMetadata]

    @model_validator(mode="after")
    def unique_entries(self):
        for name in ("groups", "tools"):
            ids = [item.id for item in getattr(self, name)]
            if len(ids) != len(set(ids)):
                raise ValueError(f"duplicate {name} id")
        groups = {item.id for item in self.groups}
        if any(item.group not in groups for item in self.tools):
            raise ValueError("unknown group")
        ids = {item.id for item in self.tools}
        if len(set(self.featured)) != len(self.featured) or not set(self.featured) <= ids:
            raise ValueError("featured must contain unique known tool ids")
        return self


class ExecutionTarget(CatalogModel):
    kind: Literal["capability", "composite", "skill"]
    id: str = Field(pattern=r"^[A-Za-z0-9][A-Za-z0-9._-]*$")
    version: str | None = None


class ToolDefinition(CatalogModel):
    id: str
    title: str
    description: str
    group: str
    kind: Literal["capability", "composite", "skill"]
    layer: Literal["entity", "data"] | None = None
    renderer: str
    input_schema: dict[str, Any]
    output_schema: dict[str, Any]
    output_contract: OutputContract
    view: ViewBinding | CompositeViewBinding
    publication: Literal["public", "local", "retired"]
    target: ExecutionTarget
    fixtures: list[str] = Field(default_factory=list)
    developer_description: str = ""
    requires: list[str] = Field(default_factory=list)
    requires_fields: list[str] = Field(default_factory=list)
    internal_capabilities: list[str] = Field(default_factory=list)
    supported_marketplaces: list[str] = Field(default_factory=list)
    # Adapter-owned fields are explicit; steps retain their versioned plan shape.
    steps: list[dict[str, Any]] = Field(default_factory=list)
    version: str | None = None
    plan: list[dict[str, Any]] = Field(default_factory=list)
    requirements: list[str] = Field(default_factory=list)
    budget_note: str = ""


class Catalog(CatalogModel):
    schema_version: Literal[1] = 1
    tools: list[ToolDefinition]
    groups: list[Group]
    counts: dict[str, int]


PUBLIC_FIELDS = frozenset({
    "id", "title", "description", "group", "kind", "layer", "renderer", "input_schema", "output_schema", "output_contract", "view",
    "publication", "fixtures", "supported_marketplaces", "requirements", "version", "steps",
})
# A projection of the same fields, not a second hand-written schema.
PublicTool = create_model(
    "PublicTool", __base__=CatalogModel, __module__=__name__,
    **{name: (field.annotation, deepcopy(field)) for name, field in ToolDefinition.model_fields.items() if name in PUBLIC_FIELDS},
)


class PublicCatalog(CatalogModel):
    schema_version: Literal[1] = 1
    tools: list[PublicTool]
    groups: list[Group]
    counts: dict[str, int]


class RuntimeState(CatalogModel):
    supported: bool
    ready: bool | None
    can_run: bool
    available: bool
    unavailable_reason: str = ""
    readiness_reason: str = ""


class RuntimeTool(ToolDefinition, RuntimeState):
    pass


class RuntimeCatalog(CatalogModel):
    schema_version: Literal[1] = 1
    tools: list[RuntimeTool]
    groups: list[Group]
    counts: dict[str, int]
