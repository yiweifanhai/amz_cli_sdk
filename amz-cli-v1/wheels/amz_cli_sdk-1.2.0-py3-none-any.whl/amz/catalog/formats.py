"""Semantic output versions; schemas always come from the registered models."""
from __future__ import annotations

from typing import Any

from amz import registry
from amz.catalog.models import OutputContract
from amz.catalog.resources import content_hash

# These declarations own semantic versions, not a copy of any business schema.
OUTPUT_FORMATS = {
    "entity.product.reviews": ("product.reviews", 1),
    "entity.product.finance": ("product.finance", 1),
}


def output_contract(capability_id: str, schema: dict[str, Any]) -> dict[str, Any]:
    format_id, version = OUTPUT_FORMATS.get(capability_id, (capability_id + ".output", 1))
    return OutputContract(id=format_id, version=version, schema_hash=content_hash(schema)).model_dump()


def format_schemas() -> list[dict[str, Any]]:
    result = [{"id": "generic.json", "version": 1, "schema_hash": content_hash({}), "schema": {}}]
    for capability_id in OUTPUT_FORMATS:
        cap = registry.get(capability_id)
        if cap is None or cap.internal:
            raise ValueError(f"missing public format owner: {capability_id}")
        result.append({**output_contract(capability_id, cap.output_schema), "schema": cap.output_schema})
    return result
