"""Shared product catalog. No web framework or business execution dependency."""

from amz.catalog.builder import build_catalog, public_catalog
from amz.catalog.resources import resource_bundle

__all__ = ["build_catalog", "public_catalog", "resource_bundle"]
