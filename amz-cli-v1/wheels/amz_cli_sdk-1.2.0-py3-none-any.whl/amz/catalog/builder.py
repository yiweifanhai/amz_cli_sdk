"""Build a shared catalog without importing a web host or invoking capabilities."""
from __future__ import annotations

from collections import Counter
from copy import deepcopy
from functools import lru_cache
import json
from typing import Any

from jsonschema.validators import validator_for
from pydantic import TypeAdapter

from amz import registry
from amz.catalog.formats import OUTPUT_FORMATS, output_contract
from amz.catalog.models import CatalogMetadata, CompositeViewBinding, RendererManifest, ToolDefinition, ViewBinding, PUBLIC_FIELDS, PublicCatalog
from amz.catalog.resources import load_resource


def _check_schema(schema: dict[str, Any]) -> None:
    _check_schema_text(json.dumps(schema, sort_keys=True, separators=(",", ":"), allow_nan=False))


@lru_cache(maxsize=512)
def _check_schema_text(encoded: str) -> None:
    schema = json.loads(encoded)
    # Catalog data must never cause schema validation to retrieve remote URLs.
    def walk(value):
        if isinstance(value, dict):
            for key, item in value.items():
                if key in {"$ref", "$dynamicRef"} and (not isinstance(item, str) or not item.startswith("#")):
                    raise ValueError("only local JSON Schema references are allowed")
                walk(item)
        elif isinstance(value, list):
            for item in value:
                walk(item)
    walk(schema)
    validator_for(schema).check_schema(schema)


def validate_view(view: dict[str, Any], contract: dict[str, Any], manifest: RendererManifest) -> dict[str, Any]:
    binding = TypeAdapter(ViewBinding | CompositeViewBinding).validate_python(view)
    renderer = next((item for item in manifest.renderers if item.id == binding.renderer.id and item.version == binding.renderer.version), None)
    if renderer is None:
        raise ValueError(f"unknown renderer: {binding.renderer.id}@{binding.renderer.version}")
    if not any(item.id in {contract["id"], "*"} and item.version == contract["version"] for item in renderer.accepts):
        raise ValueError(f"renderer {renderer.id}@{renderer.version} does not accept {contract['id']}@{contract['version']}")
    _check_schema(renderer.options_schema)
    validator_for(renderer.options_schema)(renderer.options_schema).validate(binding.options)
    return binding.model_dump()


def _validate_manifest_formats(manifest: RendererManifest, tools: list[dict]) -> None:
    # Validate unused renderers as well: an unresolved format must not survive
    # until a future workflow happens to select the module.
    known = {OUTPUT_FORMATS.get(cap.id, (cap.id + ".output", 1)) for cap in registry.list_public()}
    known.add(("generic.json", 1))
    known.update((tool["output_contract"]["id"], tool["output_contract"]["version"]) for tool in tools)
    for renderer in manifest.renderers:
        for accepted in renderer.accepts:
            if accepted.id != "*" and (accepted.id, accepted.version) not in known:
                raise ValueError(f"renderer {renderer.id}@{renderer.version} references unknown output format: {accepted.id}@{accepted.version}")
        _check_schema(renderer.options_schema)


def _counts(tools: list[dict]) -> dict[str, int]:
    kinds = Counter(tool["kind"] for tool in tools)
    return {"total": len(tools), "capability": kinds["capability"], "composite": kinds["composite"], "skill": kinds["skill"],
            "entity": sum(tool.get("layer") == "entity" for tool in tools), "data": sum(tool.get("layer") == "data" for tool in tools)}


def build_catalog(*, metadata: dict | None = None, renderer_manifest: dict | None = None,
                  extra_tools: list[dict] | None = None) -> dict[str, Any]:
    """Join authoritative schemas with static copy; hosts supply their adapters."""
    source = CatalogMetadata.model_validate(metadata if metadata is not None else load_resource("metadata"))
    manifest = RendererManifest.model_validate(renderer_manifest if renderer_manifest is not None else load_resource("renderers"))
    groups = {group.id: index for index, group in enumerate(source.groups)}
    featured = {tool_id: index for index, tool_id in enumerate(source.featured)}
    internal: dict[str, list[str]] = {}
    for cap in registry.list_all():
        if cap.internal and cap.entity_entrypoint:
            internal.setdefault(cap.entity_entrypoint, []).append(cap.id)
    rows = []
    for item in source.tools:
        cap = registry.get(item.id)
        if cap is None:
            raise ValueError(f"catalog references missing capability: {item.id}")
        actual_layer = "entity" if cap.category == "entity" else "data" if cap.fn.__module__.startswith("amz.data.") or cap.category == "data" else None
        if cap.internal or actual_layer is None:
            raise ValueError(f"catalog references a forbidden capability layer: {item.id}")
        if item.layer != actual_layer:
            raise ValueError(f"catalog layer mismatch: {item.id}")
        contract = output_contract(cap.id, cap.output_schema)
        row = {**item.model_dump(), "kind": "capability", "input_schema": cap.input_schema, "output_schema": cap.output_schema,
               "output_contract": contract, "developer_description": cap.description,
               "requires": cap.requires, "requires_fields": cap.requires_fields,
               "internal_capabilities": sorted(internal.get(cap.id, [])),
               "target": {"id": cap.id, "kind": "capability"}}
        if cap.id.startswith(("entity.product.", "entity.keyword.", "entity.market.")):
            row["supported_marketplaces"] = ["US"]
        rows.append(row)
    atomics = {row["id"]: row for row in rows}
    for original in extra_tools or []:
        row = deepcopy(original)
        if row.get("kind") not in {"composite", "skill"}:
            raise ValueError("extra tools must come from Composite or Skill adapters")
        if row["id"] in {item["id"] for item in rows}:
            raise ValueError(f"duplicate tool id: {row['id']}")
        # Availability is owned by the host; it never enters a shared snapshot.
        for name in ("available", "unavailable_reason", "supported", "ready", "can_run", "readiness_reason"):
            row.pop(name, None)
        if row.get("kind") == "composite" and "view" in row and "renderer" not in row["view"]:
            row["view"] = {**row["view"], "renderer": {"id": "generic", "version": 1}, "options": {}}
        row.setdefault("view", {"renderer": {"id": "generic", "version": 1}, "options": {}})
        row.setdefault("publication", "public")
        row["target"] = {"id": row["id"], "kind": row["kind"], "version": str(row["version"]) if row.get("version") is not None else None}
        row["output_contract"] = output_contract(row["id"], row["output_schema"])
        for step in row.get("steps", []):
            if row["kind"] != "composite":
                continue
            capability_id = step.get("capability")
            cap = registry.get(capability_id) if isinstance(capability_id, str) else None
            if cap is None or cap.internal or not (cap.category in {"entity", "data"} or cap.fn.__module__.startswith("amz.data.")):
                raise ValueError(f"Composite step references missing or forbidden capability: {capability_id}")
            atomic = atomics.get(capability_id)
            expected = output_contract(capability_id, cap.output_schema)
            if "output_contract" in step and step["output_contract"] != expected:
                raise ValueError(f"Composite step output contract mismatch: {capability_id}")
            step.setdefault("output_contract", deepcopy(expected))
            step.setdefault("view", deepcopy(atomic["view"]) if atomic else {"renderer": {"id": "generic", "version": 1}, "options": {}})
            step["view"] = validate_view(step["view"], expected, manifest)
        rows.append(row)
    _validate_manifest_formats(manifest, rows)
    for row in rows:
        if row["group"] not in groups:
            raise ValueError(f"unknown group: {row['group']}")
        _check_schema(row["input_schema"])
        _check_schema(row["output_schema"])
        row["view"] = validate_view(row["view"], row["output_contract"], manifest)
        selected = next(item for item in manifest.renderers if (item.id, item.version) == (row["view"]["renderer"]["id"], row["view"]["renderer"]["version"]))
        row["fixtures"] = list(selected.fixtures)
        ToolDefinition.model_validate(row)
    def order(tool):
        tier = 0 if tool.get("layer") == "entity" else 1 if tool.get("layer") == "data" else 2 if tool["kind"] == "composite" else 3
        return tier, groups[tool["group"]], featured.get(tool["id"], len(featured)), tool["id"]
    rows.sort(key=order)
    return {"schema_version": 1, "tools": rows, "groups": [group.model_dump() for group in source.groups], "counts": _counts(rows)}


# Keep public projection deliberately narrower than host catalogs. Adding a
# private field to a runtime row cannot accidentally publish it on the website.
PUBLIC_STEP_FIELDS = {"id", "title", "kind", "capability", "description", "output_contract", "view", "mode", "depends"}


def public_catalog(catalog: dict[str, Any]) -> dict[str, Any]:
    tools = []
    for row in catalog["tools"]:
        if row.get("publication") != "public":
            continue
        item = {key: deepcopy(value) for key, value in row.items() if key in PUBLIC_FIELDS}
        if "steps" in item:
            item["steps"] = [{key: value for key, value in step.items() if key in PUBLIC_STEP_FIELDS} for step in item["steps"]]
            for step in item["steps"]:
                if "view" in step:
                    step["view"] = TypeAdapter(ViewBinding | CompositeViewBinding).validate_python(step["view"]).model_dump()
        tools.append(item)
    result = {"schema_version": 1, "tools": tools, "groups": deepcopy(catalog["groups"]), "counts": _counts(tools)}
    PublicCatalog.model_validate(result)
    return result
