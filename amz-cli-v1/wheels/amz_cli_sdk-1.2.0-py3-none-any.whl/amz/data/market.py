"""
Market 数据获取：competing-lookup / market-research（降级返回原始数据，聚合走 entities/calc）。
"""

from __future__ import annotations

from amz.envelope import Result, ok, Code
from amz.registry import capability
from amz.data.sources.amz_api import AmzDataApi
from amz.data.normalizer import normalize_competing_item
from amz.schemas.data_outputs import CompetitorsOutput, SnapshotOutput


_api: AmzDataApi | None = None


def _get_api() -> AmzDataApi:
    global _api
    if _api is None:
        _api = AmzDataApi()
    return _api


def _normalize_items(result: Result) -> Result:
    """对 Result.data.items 逐条标准化（camelCase 上游字段 → SDK 标准字段）。"""
    if result.code != Code.OK or not isinstance(result.data, dict):
        return result
    items = result.data.get("items")
    if isinstance(items, list):
        result.data["items"] = [
            normalize_competing_item(it) for it in items if isinstance(it, dict)
        ]
    return result


@capability("market.competitors", description="竞品查询：按关键词或 ASIN 拉竞品列表（支持多 ASIN + 分页）", output_model=CompetitorsOutput)
def market_competitors(
    keyword: str | None = None,
    asin: str | list[str] | None = None,
    page: int = 1,
    pages: int = 1,
) -> Result:
    """market.competitors — 竞品查询"""
    result = _get_api().competing_lookup(keyword=keyword, asin=asin, page=page, pages=pages)
    return _normalize_items(result)


@capability("market.snapshot", description="关键词商品市场快照：返回竞品样本，聚合计算由 Entity/Calc 完成", output_model=SnapshotOutput)
def market_snapshot(keyword: str) -> Result:
    """market.snapshot — 市场特征

    返回关键词对应的竞品样本。类目 market-research 是另一种统计对象。
    聚合计算（calculate_stats）由 entities 层或调用方负责。
    """
    api = _get_api()

    # SellerSprite market-research now describes categories, not this keyword's products.
    competitors_result = api.competing_lookup(keyword=keyword, pages=2)
    if competitors_result.code != Code.OK:
        return competitors_result

    items = (competitors_result.data or {}).get("items", [])
    items = [normalize_competing_item(it) for it in items if isinstance(it, dict)]

    return ok(
        data={
            "keyword": keyword,
            "items": items,
        },
        upstream="aggregate",
        hint="keyword product sample; use entity.market.stats for aggregation",
    )
