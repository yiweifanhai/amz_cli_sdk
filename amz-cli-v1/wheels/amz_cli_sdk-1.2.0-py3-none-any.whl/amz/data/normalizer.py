"""
字段标准化器：上游 snake/camel 字段 → SDK 标准字段 + 类型解析。

两个层级：
  1. 端点映射器（mapper）：上游字段名 → 标准字段名
  2. 字段标准化器（normalizer）：原始值 → 标准类型/单位

字段解析失败置 None，实体按需填充兜底；无法识别的 SIF 响应结构抛出 ValueError。
"""

from __future__ import annotations

from typing import Any
from html import unescape

from amz.infra import parse


# ============================================================================
# 1. 端点字段映射（upstream field → SDK standard field）
# ============================================================================

# product-info 端点上游返回格式：{"asin": "...", "items": [{item0}]}
# item0 字段名是 camelCase，但核心数据在 alt 字段中：
#   brandFormatted → brand, productRating → rating, features → bullet_points,
#   imageUrlList → images, productDescription → description,
#   categoriesExtended → categories, productDetails → bsr/dims/weight/date
# 映射表只处理直接 camelCase 映射；alt 字段在后处理中提取。
PRODUCT_INFO_MAP: dict[str, str] = {
    "asin": "asin",
    "title": "title",
    "price": "price_usd",
    "countReview": "count_review",
    "variations": "variations",
    # 以下 camelCase 字段通常为 null，映射为内部 key 避免覆盖
    "brand": "_brand_direct",
    "rating": "_rating_direct",
    "bulletPoints": "_bullet_points_direct",
    "images": "_images_direct",
    "description": "_description_direct",
    "categories": "_categories_direct",
    "listingDate": "_listing_date_direct",
    "dimensions": "_dimensions_cm_direct",
    "weight": "_weight_g_direct",
    # alt 字段 → 内部 key，后处理时提取为标准字段
    "brandFormatted": "_brand_formatted",
    "productRating": "_product_rating",
    "features": "_features_raw",
    "imageUrlList": "_images_raw",
    "productDescription": "_description_raw",
    "categoriesExtended": "_categories_extended",
    "productDetails": "_product_details",
    "retailPrice": "retail_price",
}

COMPETING_LOOKUP_MAP: dict[str, str] = {
    "asin": "asin",
    "title": "title",
    "price": "price_usd",
    "totalUnits": "monthly_sales",
    "units": "monthly_sales",
    "rating": "rating",
    "reviews": "count_review",
    "ratings": "count_review",
    "availableDate": "available_date",
    "brand": "brand",
    "sellerNation": "seller_nation",
    "fbaFee": "fba_fee",
    "fba": "fba_fee",
    "fbaAmount": "fba_fee",
    "bsrRank": "bsr_rank",
    "bsr": "bsr_rank",
    "categoryName": "category_name",
    "nodeLabelPath": "categories",
    "imageUrl": "image_url",
    # 包装重量/尺寸（用于 FBA 计算）
    "pkgWeight": "weight_g",
    "pkgDimensions": "dimensions_cm",
    "pkgWeightTag": "weight_g",
    "pkgDimensionsTag": "dimensions_cm",
    # 原始字段（仅参考，不用于计算）
    "weightTag": "_weight_raw",
    "dimensionsTag": "_dimensions_raw",
}

# keyword-reverse 实际上游字段：keywords=词条, searches=搜索量, exactPpc=精确 PPC,
# searchesTrend=趋势序列, rankPosition=自然排名。旧映射里的 term/searchVolume/ppc 并不存在。
KEYWORD_REVERSE_MAP: dict[str, str] = {
    "keywords": "term",
    "keyword": "term",
    "searches": "search_volume",
    "trafficPercentage": "traffic_pct",
    "naturalRatio": "natural_ratio",
    "adRatio": "ad_ratio",
    "rankPosition": "rank",
    "exactPpc": "ppc",
    "bid": "phrase_ppc",
    "searchesTrend": "trend",
}

# keyword-miner 实际上游字段：keyword=词条, searches=搜索量, exactPpc=精确 PPC,
# purchaseRate=购买率(≈转化率), trends=趋势序列, monopolyAsinDtos=Top 垄断 ASIN。
KEYWORD_MINER_MAP: dict[str, str] = {
    "keyword": "term",
    "searches": "search_volume",
    "exactPpc": "ppc",
    "bid": "phrase_ppc",
    "purchaseRate": "conversion_rate",
    "trends": "trend",
}

SIF_KEYWORD_MAP: dict[str, str] = {
    "keyword": "term",
    "searchVolume": "search_volume",
    "clickVolume": "clicks",
    "purchaseVolume": "purchases",
    "cpc": "cpc",
    "cpa": "cpa",
    "acos": "acos",
}


# ============================================================================
# 2. 字段标准化器（值解析）
# ============================================================================

# 标准化规则表：标准字段 → 解析函数 + 额外参数
NORMALIZE_RULES: dict[str, dict] = {
    "price_usd":     {"fn": "parse_price",   "type": "float?"},
    "rating":        {"fn": "parse_rating",  "type": "float? 0-5"},
    "count_review":  {"fn": "parse_int",     "type": "int?"},
    "monthly_sales": {"fn": "parse_int",     "type": "int?"},
    "dimensions_cm": {"fn": "parse_dims",    "type": "Dims?"},
    "weight_g":      {"fn": "parse_weight_g","type": "float?"},
    "listing_date":  {"fn": "parse_iso_date","type": "str? ISO"},
    "available_date":{"fn": "parse_iso_date","type": "str? ISO"},
    "bsr":           {"fn": "parse_bsr_obj", "type": "Bsr?"},
    "search_volume": {"fn": "parse_int",     "type": "int?"},
    "ppc":           {"fn": "parse_price",   "type": "float?"},
    "click_rate":    {"fn": "parse_pct",     "type": "float? 0-100"},
    "conversion_rate":{"fn": "parse_pct",    "type": "float? 0-100"},
    "traffic_pct":   {"fn": "parse_pct",     "type": "float? 0-100"},
    "natural_ratio": {"fn": "parse_pct",     "type": "float? 0-100"},
    "ad_ratio":      {"fn": "parse_pct",     "type": "float? 0-100"},
    "rank":          {"fn": "parse_int",     "type": "int?"},
    "seller_nation": {"fn": "parse_nation",  "type": "str? ISO3166"},
}


def normalize_field(field: str, value: Any) -> Any:
    """对单个标准字段的值执行标准化解析。

    Args:
        field: 标准字段名（如 "price_usd"）
        value: 上游原始值

    Returns:
        标准化后的值，解析失败返回 None
    """
    rule = NORMALIZE_RULES.get(field)
    if rule is None:
        return value  # 无规则，原样返回

    fn_name = rule["fn"]

    match fn_name:
        case "parse_price":
            return parse.parse_price(value)
        case "parse_rating":
            if value is None:
                return None
            if isinstance(value, (int, float)):
                return max(0.0, min(5.0, float(value)))
            if isinstance(value, str):
                # "4.5 out of 5 stars" → 4.5
                import re
                m = re.search(r"([\d.]+)", value)
                if m:
                    return max(0.0, min(5.0, float(m.group(1))))
            return None
        case "parse_int":
            return parse.parse_int(value)
        case "parse_dims":
            if isinstance(value, str):
                result = parse.parse_dimensions(value)
                if result:
                    return {
                        "length": result.get("length_cm"),
                        "width": result.get("width_cm"),
                        "height": result.get("height_cm"),
                    }
            return None
        case "parse_weight_g":
            if isinstance(value, str):
                result = parse.parse_weight(value)
                if result:
                    return result.get("value_grams")
            if isinstance(value, (int, float)):
                return float(value)
            return None
        case "parse_iso_date":
            if isinstance(value, str):
                result = parse.parse_date(value)
                if result:
                    return result.get("date")
                return None
            # 时间戳（秒或毫秒）
            if isinstance(value, (int, float)):
                from datetime import datetime, timezone
                ts = value / 1000 if value > 1e10 else value  # ms → s
                try:
                    return datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%d")
                except (ValueError, OSError):
                    return None
            return None
        case "parse_bsr_obj":
            if isinstance(value, str):
                result = parse.parse_bsr(value)
                if result:
                    return {
                        "rank": result.get("rank"),
                        "category": result.get("category", ""),
                    }
            return None
        case "parse_pct":
            return parse.parse_pct(value)
        case "parse_nation":
            return parse.parse_nation(value)
        case _:
            return value


def normalize_product_info(raw: dict) -> dict:
    """标准化 product-info 端点返回的单个 item。

    上游格式：{"asin": "...", "items": [{item0}]}，item0 为 camelCase 字段。
    同时兼容 flat dict 格式（上游直接返回蛇形字段）。

    核心数据在 alt 字段中：
      brandFormatted → brand, productRating → rating,
      features → bullet_points, imageUrlList → images,
      productDescription → description, categoriesExtended → categories,
      productDetails → bsr/dims/weight/listing_date
    """
    result = _apply_mapping_and_normalize(raw, PRODUCT_INFO_MAP)

    # -- 后处理：从内部 _* 字段提取标准值 --
    # 优先级：alt 字段 > camelCase direct > productDetails 兜底 > manufacturer 兜底

    # 1. brand: _brand_formatted > manufacturer > aboutProduct
    brand = result.get("_brand_formatted")
    if brand:
        result["brand"] = brand
    if not result.get("brand"):
        mfr = raw.get("manufacturer", "") or ""
        if mfr.startswith("Visit the "):
            result["brand"] = mfr.replace("Visit the ", "").replace(" Store", "")
        elif mfr:
            result["brand"] = mfr
    if not result.get("brand"):
        result["brand"] = _find_about_product(raw, "Brand")

    # 2. rating: _product_rating > productDetails "Customer Reviews"
    if result.get("_product_rating"):
        result["rating"] = normalize_field("rating", result["_product_rating"])
    if result.get("rating") is None:
        val = _find_product_detail(raw, "Customer Reviews")
        if val:
            result["rating"] = normalize_field("rating", val)

    # 3. bullet_points: _features_raw > camelCase bullet_points
    if result.get("_features_raw"):
        result["bullet_points"] = result["_features_raw"]
    elif not result.get("bullet_points"):
        result["bullet_points"] = []

    # 4. images: _images_raw > camelCase images
    if result.get("_images_raw"):
        result["images"] = result["_images_raw"]
    elif not result.get("images"):
        result["images"] = []

    # 5. description: _description_raw > camelCase description
    if result.get("_description_raw"):
        result["description"] = result["_description_raw"]

    # 6. categories: 从 categoriesExtended 提取 name 链
    cats_ext = result.get("_categories_extended") or raw.get("categoriesExtended") or []
    if cats_ext:
        result["categories"] = [c.get("name", "") for c in cats_ext if c.get("name")]
    elif not result.get("categories"):
        result["categories"] = []

    # 7. Flat dict 兼容：如果 flat dict 中有 snake_case 标准字段，优先使用
    for field in ("price_usd", "count_review", "listing_date", "dimensions_cm", "weight_g"):
        raw_val = raw.get(field)
        if raw_val is not None and result.get(field) is None:
            result[field] = normalize_field(field, raw_val)

    # 8. bsr / dimensions / weight / listing_date: 从 productDetails 列表提取
    details = result.get("_product_details") or raw.get("productDetails") or []
    if isinstance(details, list):
        for d in details:
            name = d.get("name", "")
            value = d.get("value", "")
            if not value:
                continue
            if "Best Sellers Rank" in name and result.get("bsr") is None:
                result["bsr"] = normalize_field("bsr", value)
            elif "Dimensions" in name and result.get("dimensions_cm") is None:
                result["dimensions_cm"] = normalize_field("dimensions_cm", value)
            elif "Weight" in name and result.get("weight_g") is None:
                result["weight_g"] = normalize_field("weight_g", value)
            elif "Date First Available" in name and result.get("listing_date") is None:
                result["listing_date"] = normalize_field("listing_date", value)

    # 9. 确保空列表字段有默认值
    for list_field in ("bullet_points", "images", "categories"):
        if result.get(list_field) is None:
            result[list_field] = []

    # 10. 清理内部临时字段，但保留有数据的关键字段
    for k in list(result.keys()):
        if not k.startswith("_"):
            continue
        # 保留原始 productDetails 和 categoriesExtended
        if k == "_product_details" and result[k]:
            result["product_details_raw"] = result[k]
        if k == "_categories_extended" and result[k]:
            result["categories_extended"] = result[k]
        del result[k]

    return result


def _find_product_detail(raw: dict, name_keyword: str) -> str | None:
    """从 productDetails 列表中按名称关键词查找值"""
    details = raw.get("productDetails") or []
    for d in details:
        if name_keyword in d.get("name", ""):
            return d.get("value")
    return None


def _find_about_product(raw: dict, name_keyword: str) -> str | None:
    """从 aboutProduct 列表中按名称关键词查找值"""
    items = raw.get("aboutProduct") or []
    for d in items:
        if name_keyword in d.get("name", ""):
            return d.get("value")
    return None


def normalize_competing_item(raw: dict) -> dict:
    """标准化 competing-lookup 端点返回的单个 item。

    上架日期（availableDate）同时作为 ``listing_date`` 供 calc.market.stats 聚合使用。
    """
    result = _apply_mapping_and_normalize(raw, COMPETING_LOOKUP_MAP)
    if isinstance(raw.get("bsr"), dict):
        result["bsr"] = dict(raw["bsr"])
    # nodeLabelPath 的真实上游类型是 ``"一级:二级:三级"``，而 SDK 的
    # CompetingItemOutput / Market.products 契约是 list[str]。不在这里收敛会
    # 令一个 120 条的竞品页产生 120 个 Pydantic categories 校验错误。
    result["categories"] = normalize_category_path(result.get("categories"))
    if not result.get("category_name") and result["categories"]:
        result["category_name"] = result["categories"][0]
    if isinstance(result.get("title"), str):
        result["title"] = unescape(result["title"])
    if result.get("available_date") and not result.get("listing_date"):
        result["listing_date"] = result["available_date"]
    return result


def normalize_category_path(value: Any) -> list[str]:
    """把竞品类目路径稳定转换为 ``list[str]``。

    同时兼容上游冒号路径、已经标准化的字符串列表，以及旧缓存中偶尔出现的
    ``{name/label: ...}`` 节点列表。
    """
    if value in (None, ""):
        return []
    if isinstance(value, str):
        return [part.strip() for part in value.split(":") if part.strip()]
    if isinstance(value, (list, tuple)):
        categories: list[str] = []
        for item in value:
            if isinstance(item, str) and item.strip():
                categories.append(item.strip())
            elif isinstance(item, dict):
                label = item.get("name") or item.get("label")
                if label not in (None, ""):
                    categories.append(str(label).strip())
        return categories
    return []


def normalize_keyword_reverse_item(raw: dict) -> dict:
    """标准化 keyword-reverse 端点返回的单个 item"""
    result = _apply_mapping_and_normalize(raw, KEYWORD_REVERSE_MAP)
    # Keep rank context for the primary-keyword rules as well as the numeric rank.
    if isinstance(raw.get("rankPosition"), dict):
        result["rankPosition"] = dict(raw["rankPosition"])
    if "trafficKeywordType" in raw and "trafficKeywordTypes" not in raw:
        value = raw["trafficKeywordType"]
        names = {"primary": "PRIMARY", "precise": "PRECISE", "preciseLongTail": "PRECISE_LONG_TAIL"}
        result["trafficKeywordTypes"] = [names.get(value, value)] if value else []
    return result


def normalize_keyword_miner_item(raw: dict) -> dict:
    """标准化 keyword-miner 端点返回的单个 item。

    top3_asins 由 monopolyAsinDtos 前 3 条 asin 提取（上游无独立 top3 字段）。
    """
    result = _apply_mapping_and_normalize(raw, KEYWORD_MINER_MAP)
    top3 = []
    for m in raw.get("monopolyAsinDtos") or []:
        a = m.get("asin") if isinstance(m, dict) else None
        if a:
            top3.append(a)
        if len(top3) >= 3:
            break
    if top3:
        result["top3_asins"] = top3
    return result


def normalize_trend_points(raw_points: list | None) -> list[dict[str, Any]]:
    """标准化 trends 端点返回的时间序列。

    上游：``[{date: ms, searches: int, rank: int, ...}]``
    标准：``[{date: "YYYY-MM-DD", value: float}]``
    """
    if not isinstance(raw_points, list):
        return []
    points: list[dict[str, Any]] = []
    for p in raw_points:
        if not isinstance(p, dict):
            continue
        points.append({
            "date": normalize_field("listing_date", p.get("date")),
            "value": normalize_field("search_volume", p.get("searches")),
        })
    return points


def normalize_sif_item(raw: dict) -> dict:
    """标准化 SIF keywordFunnel 返回的单个 item，保留广告策略区间。"""
    raw = dict(raw)
    # Compatibility with the earlier documented SIF field names.
    for old, current in (
        ("term", "keyword"), ("clickCount", "clickVolume"),
        ("orderCount", "purchaseVolume"), ("ppc", "cpc"),
    ):
        if current not in raw and old in raw:
            raw[current] = raw[old]
        raw.pop(old, None)
    result = _apply_mapping_and_normalize(raw, SIF_KEYWORD_MAP)
    for field in ("clicks", "purchases"):
        result[field] = parse.parse_int(result[field])
    return result


def normalize_sif_funnel(raw: Any) -> dict:
    """映射完整 SIF 响应；缺失数值保持未知，结构变化不得伪装成空结果。"""
    from amz.schemas.data_outputs import AdsFunnelItemOutput

    if not isinstance(raw, dict) or not isinstance(raw.get("keywords"), list):
        raise ValueError("SIF response must contain a keywords list")

    items = []
    for index, row in enumerate(raw["keywords"]):
        if not isinstance(row, dict):
            raise ValueError(f"SIF keywords[{index}] must be an object")
        item = normalize_sif_item(row)
        if not isinstance(item.get("term"), str) or not item["term"].strip():
            raise ValueError(f"SIF keywords[{index}] has no keyword")
        item["period"] = row.get("period") or row.get("weekDate") or raw.get("weekDate")
        items.append(AdsFunnelItemOutput.model_validate(item).model_dump())

    volumes = [item["search_volume"] for item in items]
    periods = {item["period"] for item in items}
    total = None
    if all(value is not None for value in volumes) and len(periods) <= 1:
        total = sum(volumes)
    return {**raw, "items": items, "total_search_volume": total}


# ============================================================================
# 内部工具
# ============================================================================

def _apply_mapping_and_normalize(raw: dict, field_map: dict[str, str]) -> dict:
    """字段映射 + 标准化"""
    result = {}
    for src, dst in field_map.items():
        value = normalize_field(dst, raw[src]) if src in raw else None
        if value is not None or dst not in result:
            result[dst] = value

    # 保留未映射的字段（带原始 key）
    for k, v in raw.items():
        if k not in field_map:
            result[k] = v

    return result
