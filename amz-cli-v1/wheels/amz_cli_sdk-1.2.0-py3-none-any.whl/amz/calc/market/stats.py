"""Market Stats calculations; inputs are prepared by Entity."""

from __future__ import annotations
import statistics
from datetime import datetime, timezone
from amz.registry import capability
from amz.schemas.analysis_inputs import CalcMarketStatsInput
from amz.schemas.data_outputs import MarketStatsOutput


@capability(
    "calc.market.stats",
    description="从标准化竞品列表计算价格、评分、评论、垄断度与卖家统计",
    input_model=CalcMarketStatsInput,
    output_model=MarketStatsOutput,
)
def calculate_stats(items: list[dict]) -> dict:
    """calc.market.stats

    从 competitors 列表生成市场画像统计。

    Args:
        items: 来自 competing-lookup 的标准化 item 列表，
               每个 item 含 price_usd, rating, count_review, listing_date, brand,
               seller_nation, monthly_sales 等。

    Returns:
        {price, rating, listing_date, reviews, monopoly, sellers, aplus_video_pct, return_rate?}
    """
    if not items:
        return _empty_stats()

    n = len(items)

    # -- 价格 --
    prices = [it.get("price_usd") for it in items if it.get("price_usd")]
    price_sorted = sorted(prices) if prices else []

    price_stats = {
        "p25": _percentile(price_sorted, 25),
        "p50": _percentile(price_sorted, 50),
        "p75": _percentile(price_sorted, 75),
        "band_count": len(_price_bands(prices)),
        "bands": _price_bands_full(prices, n),
    }

    # -- 评分 --
    ratings = [it.get("rating") for it in items if it.get("rating") is not None]
    rating_stats = {
        "avg": round(statistics.mean(ratings), 2) if ratings else None,
        "dist": _rating_distribution(ratings),
    }

    # -- 上架日期 --
    dates = [
        it.get("listing_date") for it in items
        if it.get("listing_date") and isinstance(it.get("listing_date"), str)
    ]
    now = datetime.now(timezone.utc)
    months_since = []
    for d in dates:
        try:
            dt = datetime.fromisoformat(d.replace("Z", "+00:00"))
            months_since.append((now - dt).days / 30.44)
        except (ValueError, TypeError):
            pass

    new_pct = sum(1 for m in months_since if m <= 12) / len(months_since) * 100 if months_since else None
    listing_date_stats = {
        "median_months": round(statistics.median(months_since), 1) if months_since else None,
        "new_release_pct": round(new_pct, 1) if new_pct is not None else None,
    }

    # -- 评论数 --
    reviews = [it.get("count_review") for it in items if it.get("count_review") is not None]
    reviews_stats = {
        "median": int(statistics.median(reviews)) if reviews else None,
        "count_dist": _reviews_distribution(reviews),
    }

    # -- 垄断度 --
    brands = [it.get("brand", "") or "Unknown" for it in items]
    brand_counts: dict[str, int] = {}
    for b in brands:
        brand_counts[b] = brand_counts.get(b, 0) + 1

    sorted_brands = sorted(brand_counts.values(), reverse=True)
    cr10 = sum(sorted_brands[:10]) / n * 100 if sorted_brands else None
    cr20 = sum(sorted_brands[:20]) / n * 100 if sorted_brands else None
    top_brand_share = sorted_brands[0] / n * 100 if sorted_brands else None

    monopoly_stats = {
        "cr10": round(cr10, 1) if cr10 is not None else None,
        "cr20": round(cr20, 1) if cr20 is not None else None,
        "top_brand_share": round(top_brand_share, 1) if top_brand_share is not None else None,
    }

    # -- 卖家结构 --
    nations = [it.get("seller_nation", "") or "Unknown" for it in items]
    cn_count = sum(1 for na in nations if na == "CN")
    amz_count = sum(1 for na in nations if na.lower() in ("amazon", "amz", "us") or "amazon" in na.lower())

    seller_stats = {
        "total": n,
        "cn_pct": round(cn_count / n * 100, 1),
        "amazon_pct": round(amz_count / n * 100, 1),
    }

    return {
        "price": price_stats,
        "rating": rating_stats,
        "listing_date": listing_date_stats,
        "reviews": reviews_stats,
        "monopoly": monopoly_stats,
        "sellers": seller_stats,
        "aplus_video_pct": None,   # 需额外端点支持
        "return_rate": None,       # 需额外端点支持
    }


def _percentile(sorted_data: list, p: int) -> float | None:
    """计算百分位数"""
    if not sorted_data:
        return None
    idx = int(len(sorted_data) * p / 100)
    return sorted_data[min(idx, len(sorted_data) - 1)]


def _price_bands(prices: list[float]) -> list[dict]:
    """价格分桶"""
    if not prices:
        return []
    min_p = min(prices)
    max_p = max(prices)
    if max_p == min_p:
        return [{"label": f"${min_p:.0f}", "min": min_p, "max": max_p, "count": len(prices)}]

    step = (max_p - min_p) / 4
    bands = []
    for i in range(4):
        lo = min_p + step * i
        hi = min_p + step * (i + 1)
        cnt = sum(1 for p in prices if lo <= p <= hi)
        bands.append({"label": f"${lo:.0f}-${hi:.0f}", "min": round(lo, 2), "max": round(hi, 2), "count": cnt})
    return bands


def _price_bands_full(prices: list[float], n: int) -> list[dict]:
    """价格分桶 + 占比"""
    bands = _price_bands(prices)
    for b in bands:
        b["share_pct"] = round(b["count"] / n * 100, 1) if n > 0 else 0
    return bands


def _rating_distribution(ratings: list[float]) -> dict[str, int]:
    """评分分布"""
    dist = {"5": 0, "4": 0, "3": 0, "2": 0, "1": 0}
    for r in ratings:
        bucket = str(min(5, max(1, int(r))))
        dist[bucket] = dist.get(bucket, 0) + 1
    return dist


def _reviews_distribution(reviews: list[int]) -> dict[str, int]:
    """评论数分布"""
    dist = {"<100": 0, "100-500": 0, "500-2000": 0, "2000+": 0}
    for r in reviews:
        if r < 100:
            dist["<100"] += 1
        elif r < 500:
            dist["100-500"] += 1
        elif r < 2000:
            dist["500-2000"] += 1
        else:
            dist["2000+"] += 1
    return dist


def _empty_stats() -> dict:
    return {
        "price": {"p25": None, "p50": None, "p75": None, "band_count": 0, "bands": []},
        "rating": {"avg": None, "dist": {}},
        "listing_date": {"median_months": None, "new_release_pct": None},
        "reviews": {"median": None, "count_dist": {}},
        "monopoly": {"cr10": None, "cr20": None, "top_brand_share": None},
        "sellers": {"total": 0, "cn_pct": None, "amazon_pct": None},
        "aplus_video_pct": None,
        "return_rate": None,
    }
