"""Market Opportunity calculations; inputs are prepared by Entity."""

from __future__ import annotations
from amz.registry import capability
from amz.schemas.analysis_inputs import CalcMarketOpportunityInput
from amz.schemas.data_outputs import MarketOpportunityOutput


@capability(
    "calc.market.opportunity",
    description="根据市场统计执行确定性机会评分",
    input_model=CalcMarketOpportunityInput,
    output_model=MarketOpportunityOutput,
)
def calculate_opportunity_score(stats: dict, keyword: str = "") -> dict:
    """calc.market.opportunity

    基于市场 stats 计算机会评分。确定性规则引擎。

    Returns:
        {keyword, opportunity_score, gaps, proposals}
    """
    opportunity_score = 60.0  # 基准分

    monopoly = stats.get("monopoly", {})
    if monopoly.get("cr10") is not None and monopoly["cr10"] < 50:
        opportunity_score += 15

    sellers = stats.get("sellers", {})
    cn_pct = sellers.get("cn_pct") if isinstance(sellers, dict) else None
    if cn_pct is not None and cn_pct > 30:
        opportunity_score -= 10

    return {
        "keyword": keyword,
        "opportunity_score": opportunity_score,
        "gaps": [],
        "proposals": [],
    }
