"""Market Profile calculations; inputs are prepared by Entity."""

from __future__ import annotations
from amz.registry import capability
from amz.schemas.analysis_inputs import CalcMarketProfileInput
from amz.schemas.data_outputs import MarketProfileOutput


@capability(
    "calc.market.profile",
    description="把市场统计重组为稳定的 8 维画像",
    input_model=CalcMarketProfileInput,
    output_model=MarketProfileOutput,
)
def calculate_profile(stats: dict, keyword: str = "") -> dict:
    """calc.market.profile

    将 stats 重组为 8 维市场画像结构。纯数据变换，无业务规则。

    Returns:
        {keyword, dimensions: {price, rating, reviews, monopoly, sellers, listing_date, aplus_video, return_rate}}
    """
    return {
        "keyword": keyword,
        "dimensions": {
            "price": stats.get("price", {}),
            "rating": stats.get("rating", {}),
            "reviews": stats.get("reviews", {}),
            "monopoly": stats.get("monopoly", {}),
            "sellers": stats.get("sellers", {}),
            "listing_date": stats.get("listing_date", {}),
            "aplus_video": stats.get("aplus_video_pct"),
            "return_rate": stats.get("return_rate"),
        },
        "overall_score": _profile_completeness_score(stats),
    }


def _profile_completeness_score(stats: dict) -> float:
    """画像数据完整度（0-100），避免把缺失数据误写成业务质量分。"""
    checks = (
        bool((stats.get("price") or {}).get("bands")),
        (stats.get("rating") or {}).get("avg") is not None,
        (stats.get("reviews") or {}).get("median") is not None,
        (stats.get("monopoly") or {}).get("cr10") is not None,
        (stats.get("sellers") or {}).get("total", 0) > 0,
        (stats.get("listing_date") or {}).get("median_months") is not None,
        stats.get("aplus_video_pct") is not None,
        stats.get("return_rate") is not None,
    )
    return round(sum(checks) / len(checks) * 100, 1)
