"""Estimate keyword TACOS and age-bucket margins from prepared Product facts."""

from __future__ import annotations

from datetime import date
from statistics import median

from amz.calc.product.fba import calculate_fee
from amz.calc.product.margin import calculate_margin
from amz.envelope import Result, ok
from amz.registry import capability
from amz.schemas.tacos import CalcMarketTacosInput, MarketTacosResult, TacosBucket, TacosProduct


def _bucket(products: list[TacosProduct], acos: float) -> TacosBucket:
    matched = [row for row in products if row.tacos_pct is not None]
    m1 = median(row.m1_pct for row in matched) if matched else None
    tacos = median(row.tacos_pct for row in matched) if matched else None
    return TacosBucket(
        product_count=len(products), ad_data_count=len(matched),
        m1_median_pct=round(median(row.m1_pct for row in products), 1) if products else None,
        matched_m1_median_pct=round(m1, 1) if m1 is not None else None,
        keyword_acos=acos,
        ad_ratio_median=round(median(row.ad_ratio for row in matched), 4) if matched else None,
        tacos_median_pct=round(tacos, 1) if tacos is not None else None,
        m2_pct=round(m1 - tacos, 1) if matched else None,
        insufficient_sample=len(matched) < 3,
    )


@capability(
    "calc.market.tacos", description="关键词 TACOS 估算与 3/6/12 月上架时长利润分组",
    input_model=CalcMarketTacosInput, output_model=MarketTacosResult,
)
def calculate_tacos(
    keyword: str, keyword_acos: float, products: list[dict], current_date: date,
    exchange_rate: float, shipping_method: str = "slow", referral_rate: float = 0.15,
) -> Result:
    values = CalcMarketTacosInput.model_validate(locals())
    rows = []
    for product in values.products:
        # Preserve the old tool's freight rule; FBA still uses actual package facts.
        billable = max(product.weight_g, product.dimensions_cm[0] * product.dimensions_cm[1] * product.dimensions_cm[2] / 6)
        fee = product.fba_fee
        if fee is None:
            fee = calculate_fee(product.weight_g, *product.dimensions_cm, selling_price=product.price_usd,
                                fulfillment_date=values.current_date)["fee_usd"]
        margin = calculate_margin(
            selling_price=product.price_usd, pkg_weight_g=billable,
            fba_fee_usd=fee, shipping_method=values.shipping_method,
            referral_rate=values.referral_rate, exchange_rate=values.exchange_rate,
        )
        missing = list(product.missing)
        months = None
        try:
            available = date.fromisoformat((product.available_date or "")[:10])
            if available > values.current_date:
                missing.append("available_date.future")
            else:
                months = (values.current_date - available).days / 30.44
        except ValueError:
            missing.append("available_date")
        tacos = values.keyword_acos * product.ad_ratio * 100 if product.ad_ratio is not None else None
        rows.append(TacosProduct(
            asin=product.asin, price_usd=product.price_usd, m1_pct=margin["m1_margin_pct"],
            ad_ratio=product.ad_ratio, tacos_pct=tacos,
            m2_pct=round(margin["m1_margin_pct"] - tacos, 1) if tacos is not None else None,
            months_since_available=months, fba_fee=fee,
            fba_source="product" if product.fba_fee is not None else "calculated",
            shipping_cost=margin["shipping_cost"], billable_weight_g=billable, missing=missing,
        ))
    cumulative, exclusive = {}, {}
    low = 0
    for high in (3, 6, 12):
        cumulative[f"m{high}"] = _bucket([row for row in rows if row.months_since_available is not None and row.months_since_available <= high], values.keyword_acos)
        exclusive[f"m{low}_{high}"] = _bucket([
            row for row in rows if row.months_since_available is not None
            and (row.months_since_available >= 0 if low == 0 else row.months_since_available > low)
            and row.months_since_available <= high
        ], values.keyword_acos)
        low = high
    result = MarketTacosResult(
        keyword=values.keyword, keyword_acos=values.keyword_acos, current_date=values.current_date,
        total_products=len(rows), products_with_margin=len(rows),
        products_with_ad_data=sum(row.ad_ratio is not None for row in rows),
        products_without_date=sum(row.months_since_available is None for row in rows),
        products_over_12_months=sum(row.months_since_available is not None and row.months_since_available > 12 for row in rows),
        cumulative=cumulative, exclusive=exclusive, products=rows,
        assumptions={"shipping_method": values.shipping_method, "exchange_rate": values.exchange_rate,
                     "referral_rate": values.referral_rate, "month_days": 30.44, "freight_volume_divisor_cm3_per_kg": 6000,
                     "calculated_fba_product_type": "non_apparel", "calculated_fba_fuel_surcharge": True},
        limitations=[
            "TACOS = keyword ACOS × keyword ad traffic share is an estimate; traffic share is not ad sales share.",
            "M1 and M2 exclude purchase cost, tax and other operating costs; M2 is not net profit.",
            "Buckets describe the selected search sample, not the whole market or future product performance.",
        ],
    )
    return ok(data=result.model_dump(mode="json"))
