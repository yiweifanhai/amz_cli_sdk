"""Internal deterministic calculations owned by Market."""
