"""Market Return_Rate calculations; inputs are prepared by Entity."""

from __future__ import annotations


def lookup_return_rate(keyword: str = "") -> dict:
    """calc.market.return-rate

    退货率品类查表 — 基于关键词子串匹配品类默认费率。
    当前为简化版，后续可接入实际退货率数据源。

    Returns:
        {refund_rate_pct, peer_avg_pct, risk: low|medium|high}
    """
    default_rates = {
        "clothing": (20.0, 15.0, "high"),
        "shoes": (18.0, 14.0, "high"),
        "electronics": (8.0, 6.0, "medium"),
        "home": (6.0, 5.0, "low"),
        "kitchen": (5.0, 4.0, "low"),
        "toys": (7.0, 5.5, "medium"),
        "sports": (6.5, 5.0, "medium"),
        "beauty": (4.0, 3.0, "low"),
        "default": (8.0, 6.0, "medium"),
    }

    metric = default_rates["default"]
    kw = keyword.lower()
    for cat, val in default_rates.items():
        if cat in kw:
            metric = val
            break

    refund_rate, peer_avg, risk = metric
    return {
        "refund_rate_pct": refund_rate,
        "peer_avg_pct": peer_avg,
        "risk": risk,
    }
