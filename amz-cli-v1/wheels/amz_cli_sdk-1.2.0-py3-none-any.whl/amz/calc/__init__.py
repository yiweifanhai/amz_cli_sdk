"""Internal deterministic calculations grouped by owning Entity.

Product, Market and Keyword prepare and validate public business inputs.
Pure functions accept supplied values, perform no fetching or state writes,
and remain usable for internal reuse and isolated tests. Public callers use
entity.*; packages intentionally do not re-export business functions.
"""
