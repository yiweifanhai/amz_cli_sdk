"""Keyword Score calculations; inputs are prepared by Entity."""

from __future__ import annotations
import math
from bisect import bisect_right


def _value(data: dict, *names: str, default=None):
    for name in names:
        if data.get(name) is not None:
            return data[name]
    return default


def _number(value):
    if value is None:
        return None
    if isinstance(value, bool):
        raise ValueError("keyword metrics must be finite non-negative numbers, not booleans")
    number = float(value)
    if not math.isfinite(number) or number < 0:
        raise ValueError("keyword metrics must be finite non-negative numbers")
    return number


def _normalize_keyword_row(item: dict) -> dict:
    nested_feature = item.get("feature")
    feature = item
    if isinstance(nested_feature, dict):
        feature = {**item, **{key: value for key, value in nested_feature.items() if value is not None}}
    searches = _number(_value(feature, "searches", "search_volume"))
    weekly_exposure = _number(_value(item, "weeklyExposureSum", "weekly_exposure_sum", "weekly_exposure", "exposure"))
    asin_count = _number(_value(item, "asinCount", "asin_count"))
    exposure_coverage = _number(item.get("exposure_coverage"))
    if exposure_coverage is None and weekly_exposure is not None and searches is not None and searches > 0:
        exposure_coverage = min(weekly_exposure / searches, 1)
    return {
        "keyword": str(item.get("keyword") or item.get("term") or ""),
        "searches": searches,
        "weekly_exposure": weekly_exposure,
        "purchase_rate": _number(_value(feature, "purchase_rate", "conversion_rate", "purchaseRate")),
        "cvr": _number(_value(feature, "cvr")),
        "purchases": _number(_value(feature, "purchases")),
        "supply_demand": _number(_value(feature, "supplyDemandRatio", "supply_demand_ratio", "supply_demand")),
        "spr": _number(_value(feature, "cprExact", "spr", "cpr_exact")),
        "top3": _number(_value(feature, "top3ClickingRate", "top3_clicking_rate", "top3")),
        "asin_count": asin_count,
        "exposure_coverage": exposure_coverage,
        "trend": _value(feature, "searchesTrend", "searches_trend", "trend", default=[]),
    }


SCORE_METRICS = {
    "relevance": ("asin_count", "exposure_coverage"),
    "traffic": ("searches", "weekly_exposure"),
    "conversion": ("purchase_rate", "cvr", "purchases"),
    "competition": ("supply_demand", "spr", "top3"),
}


def keyword_score_missing(rows: list[dict]) -> list[str]:
    """Identify dimensions without observed metrics; an observed zero is valid."""
    return [
        f"keywords[{index}]({row.get('keyword', '')}).{dimension}[{' or '.join(fields)}]"
        for index, row in enumerate(rows)
        for dimension, fields in SCORE_METRICS.items()
        if not any(row.get(field) is not None for field in fields)
    ]


def _percentile_to_score(percentile: float) -> float:
    percentile = min(100.0, max(0.0, percentile))
    segments = [(95, 10), (80, 8), (60, 6), (35, 4), (10, 2)]
    for index in range(len(segments) - 1):
        high_pct, high_score = segments[index]
        low_pct, low_score = segments[index + 1]
        if percentile >= low_pct:
            ratio = (percentile - low_pct) / (high_pct - low_pct)
            return min(10.0, max(1.0, low_score + ratio * (high_score - low_score)))
    return 1.0


def _percentile_lookup(values: list[float | None], reverse: bool = False):
    sorted_values = sorted(value for value in values if value is not None)

    def lookup(value: float | None) -> float | None:
        if value is None:
            return None
        if not sorted_values:
            return 5.0
        percentile = bisect_right(sorted_values, value) / len(sorted_values) * 100
        return _percentile_to_score(100 - percentile if reverse else percentile)

    return lookup


def _weighted_average(items: list[tuple[float | None, float]]) -> float:
    valid = [(value, weight) for value, weight in items if value is not None]
    if not valid:
        return 5.0
    total_weight = sum(weight for _value_, weight in valid)
    return sum(value * weight for value, weight in valid) / total_weight


def _trend_adjustment(trend: list[dict] | None) -> float:
    if not trend or len(trend) < 4:
        return 0
    values = [float(item.get("searches") or item.get("search") or 0) for item in trend]
    midpoint = len(values) // 2
    earlier = sum(values[:midpoint]) / max(1, midpoint)
    recent = sum(values[midpoint:]) / max(1, len(values) - midpoint)
    if earlier == 0:
        return 0
    change = (recent - earlier) / earlier
    if change > 1:
        return 1.0
    if change > 0.5:
        return 0.5
    if change > 0.2:
        return 0.3
    if change < -0.5:
        return -0.5
    if change < -0.2:
        return -0.3
    return 0


def score_keyword_rows(rows: list[dict], relevance_map: dict[str, dict]) -> dict:
    """Apply the existing relative score formula to explicit semantic judgments."""
    from amz.schemas.keyword_analysis import DimensionScores, ScoredKeyword, KeywordScoreOutput

    missing = keyword_score_missing(rows)
    if missing:
        raise ValueError("missing keyword scoring metrics: " + ", ".join(missing))
    for row in rows:
        for fields in SCORE_METRICS.values():
            for field in fields:
                _number(row.get(field))

    if any(relevance_map.get(row["keyword"].casefold(), {}).get("match")
           not in {"perfect", "high", "partial", "low"} for row in rows):
        raise ValueError("every candidate requires an explicit semantic match")
    lookups = {
        "searches": _percentile_lookup([row["searches"] for row in rows]),
        "exposure": _percentile_lookup([row["weekly_exposure"] for row in rows]),
        "purchase_rate": _percentile_lookup([row["purchase_rate"] for row in rows]),
        "cvr": _percentile_lookup([row["cvr"] for row in rows]),
        "purchases": _percentile_lookup([row["purchases"] for row in rows]),
        "supply_demand": _percentile_lookup([row["supply_demand"] for row in rows]),
        "spr": _percentile_lookup([row["spr"] for row in rows], reverse=True),
        "top3": _percentile_lookup([row["top3"] for row in rows], reverse=True),
        "asin_count": _percentile_lookup([row["asin_count"] for row in rows]),
        "exposure_coverage": _percentile_lookup([row["exposure_coverage"] for row in rows]),
    }
    multipliers = {
        "perfect": 1.3, "high": 1.0, "partial": 0.7,
        "low": 0.4,
    }
    scored: list[ScoredKeyword] = []
    distribution = {"S": 0, "A": 0, "B": 0, "C": 0}
    for row in rows:
        llm = relevance_map[row["keyword"].casefold()]
        match = llm["match"]
        relevance_base = _weighted_average([
            (lookups["asin_count"](row["asin_count"]), 0.5),
            (lookups["exposure_coverage"](row["exposure_coverage"]), 0.5),
        ])
        relevance = min(10, max(0, relevance_base * multipliers.get(match, 1.0)))
        traffic = _weighted_average([
            (lookups["searches"](row["searches"]), 0.6),
            (lookups["exposure"](row["weekly_exposure"]), 0.4),
        ])
        conversion = _weighted_average([
            (lookups["purchase_rate"](row["purchase_rate"]), 0.4),
            (lookups["cvr"](row["cvr"]), 0.4),
            (lookups["purchases"](row["purchases"]), 0.2),
        ])
        competition = _weighted_average([
            (lookups["supply_demand"](row["supply_demand"]), 0.4),
            (lookups["spr"](row["spr"]), 0.3),
            (lookups["top3"](row["top3"]), 0.3),
        ])
        trend = _trend_adjustment(row["trend"])
        score = round(min(10, max(0,
            relevance * 0.30 + traffic * 0.25 + conversion * 0.25 + competition * 0.20 + trend
        )), 1)
        grade = (
            "S" if score >= 8 else "A" if score >= 6 else "B" if score >= 4 else "C"
        )
        distribution[grade] += 1
        scored.append(ScoredKeyword(
            keyword=row["keyword"], score=score, grade=grade,
            dimension_scores=DimensionScores(
                relevance=round(relevance, 1), traffic=round(traffic, 1),
                conversion=round(conversion, 1), competition=round(competition, 1),
            ),
            trend_adjustment=trend, match_level=match,
            reason=str(llm.get("reason") or ""),
        ))
    average = round(sum(item.score for item in scored) / len(scored), 1) if scored else 0
    return KeywordScoreOutput(
        scored_keywords=scored, total_count=len(scored),
        grade_distribution=distribution, average_score=average,
    ).model_dump()
