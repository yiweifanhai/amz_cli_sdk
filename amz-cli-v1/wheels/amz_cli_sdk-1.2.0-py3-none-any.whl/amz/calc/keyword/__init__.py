"""Internal deterministic calculations owned by Keyword."""
