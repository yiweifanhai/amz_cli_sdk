"""Keyword Rank_Slope calculations; inputs are prepared by Entity."""

from __future__ import annotations
import statistics


def calculate_rank_slope(series: list[dict]) -> dict:
    """calc.keyword.rank-slope

    ABA rank 时间序列斜率分析：k1-k4 斜率、年化增长、突变/节日概率。

    Args:
        series: [{week: str, rank: int}, ...]

    Returns:
        {k1, k2, k3, k4, annual_growth, spike_prob, holiday_prob, emerging_score, verdict}
    """
    if len(series) < 4:
        return {
            "k1": None, "k2": None, "k3": None, "k4": None,
            "annual_growth": None, "spike_prob": None, "holiday_prob": None,
            "emerging_score": None, "verdict": "insufficient_data",
        }

    # 提取 rank 序列
    ranks = [s.get("rank") for s in series if s.get("rank") is not None]
    if len(ranks) < 4:
        return {
            "k1": None, "k2": None, "k3": None, "k4": None,
            "annual_growth": None, "spike_prob": None, "holiday_prob": None,
            "emerging_score": None, "verdict": "insufficient_data",
        }

    n = len(ranks)

    # k1: 最近 1 期变化率
    k1 = (ranks[-2] - ranks[-1]) / ranks[-2] * 100 if ranks[-2] > 0 else 0

    # k2: 最近 4 期平均变化率
    k2_vals = []
    for i in range(max(0, n - 5), n - 1):
        if ranks[i] > 0:
            k2_vals.append((ranks[i] - ranks[i + 1]) / ranks[i] * 100)
    k2 = statistics.mean(k2_vals) if k2_vals else 0

    # k3: 最近 8 期平均变化率
    k3 = k2  # 简化：数据不够 8 期复用

    # k4: 全序列趋势
    if len(ranks) >= 8:
        first_half = statistics.mean(ranks[:len(ranks)//2])
        second_half = statistics.mean(ranks[len(ranks)//2:])
        k4 = (first_half - second_half) / first_half * 100 if first_half > 0 else 0
    else:
        k4 = k2

    # 年化增长
    monthly_rate = k4 / 100  # rank 上升 = 增长（rank 变小 = 搜索频率变高 = 好）
    annual_growth = monthly_rate * 12 * 100

    # 突变概率（标准差异常）
    diffs = [ranks[i] - ranks[i + 1] for i in range(n - 1)]
    if len(diffs) >= 2:
        std = statistics.stdev(diffs)
        spike_prob = min(1.0, std / (statistics.mean([abs(d) for d in diffs]) + 0.01))
    else:
        spike_prob = 0

    # 节日概率简化
    holiday_prob = 0.1  # 后续接节日历表

    # 新兴得分
    emerging_score = (k2 * 0.5 + k4 * 0.3 + (1 - spike_prob) * 0.2)

    # 判定
    if k2 > 5:
        verdict = "rising"
    elif k2 < -5:
        verdict = "falling"
    elif spike_prob > 0.5:
        verdict = "spike"
    else:
        verdict = "stable"

    return {
        "k1": round(k1, 2),
        "k2": round(k2, 2),
        "k3": round(k3, 2),
        "k4": round(k4, 2),
        "annual_growth": round(annual_growth, 2) if annual_growth is not None else None,
        "spike_prob": round(spike_prob, 2),
        "holiday_prob": round(holiday_prob, 2),
        "emerging_score": round(emerging_score, 2),
        "verdict": verdict,
    }
