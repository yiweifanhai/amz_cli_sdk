"""Keyword Normalize calculations; inputs are prepared by Entity."""

from __future__ import annotations


def normalize_terms(
    terms: list[str],
    context: dict | None = None,
) -> dict:
    """calc.keyword.normalize

    关键词清洗/标准化：表头归一、品牌词过滤、禁用词过滤、主关键词提取。

    Returns:
        {normalized: [{term, cleaned, is_brand, is_banned, kept}]}
    """
    ctx = context or {}
    title = ctx.get("title", "")
    banned = ctx.get("banned_terms", [])

    # 从 title 提取品牌词（简单规则：title 第一个词通常是品牌）
    brand_words = set()
    if title:
        first_word = title.split()[0].lower().strip(",")
        if len(first_word) >= 2:
            brand_words.add(first_word)

    # 禁用词集合
    banned_set = {b.lower().strip() for b in banned}

    results = []
    for term in terms:
        cleaned = term.strip()
        if not cleaned:
            continue

        lowered = cleaned.lower()

        # 品牌词检测
        is_brand = any(bw in lowered for bw in brand_words)

        # 禁用词检测
        is_banned = any(bw in lowered for bw in banned_set)

        results.append({
            "term": term,
            "cleaned": cleaned,
            "is_brand": is_brand,
            "is_banned": is_banned,
            "kept": not is_brand and not is_banned,
        })

    return {"normalized": results}
