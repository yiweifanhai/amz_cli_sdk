"""Product Keyword_Gap calculations; inputs are prepared by Entity."""

from __future__ import annotations
import re
from amz.envelope import Result, ok
from amz.registry import capability
from amz.schemas.analysis_inputs import CalcKeywordGapInput
from amz.schemas.data_outputs import KeywordGapOutput


def _keyword_matches(keyword: str, text: str) -> bool:
    """按 listing_agent 原规则匹配关键词。

    多词短语要求完整连续出现；单词使用边界匹配，避免 ``set`` 命中
    ``offset``。匹配不做词干化或“任一单词”放宽。
    """
    normalized = keyword.lower().strip()
    if not normalized:
        return False
    if " " in normalized:
        # listing_agent/gap-analysis.ts 的原实验就是不带边界的连续子串匹配。
        return normalized in text.lower()
    return re.search(rf"\b{re.escape(normalized)}\b", text, flags=re.IGNORECASE) is not None


@capability("calc.keyword.gap", description="Listing 的 S/A 关键词覆盖检查（确定性）", input_model=CalcKeywordGapInput, output_model=KeywordGapOutput)
def analyze_gap(keywords: list[dict], listing_text: dict) -> Result:
    """检查 S/A 关键词在 title/BP1-5 的精确覆盖位置。"""
    segments = [("title", str(listing_text.get("title", "")))]
    segments.extend(
        (f"bp{i + 1}", str(text))
        for i, text in enumerate(listing_text.get("bullet_points", [])[:5])
    )

    covered: list[dict] = []
    missing: list[dict] = []
    for item in keywords:
        grade = str(item.get("grade", "")).upper()
        if grade not in {"S", "A"}:
            continue
        term = str(item.get("term") or item.get("keyword") or "").strip()
        if not term:
            continue
        source = str(item.get("source") or "a10")
        found_in = [position for position, text in segments if _keyword_matches(term, text)]
        base = {"keyword": term, "grade": grade, "source": source}
        if found_in:
            covered.append({**base, "found_in": found_in})
        else:
            missing.append(base)
    return ok(data={"covered": covered, "missing": missing})
