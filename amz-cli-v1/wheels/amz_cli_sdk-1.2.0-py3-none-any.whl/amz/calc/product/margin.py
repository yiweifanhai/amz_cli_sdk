"""
FBA 毛利率计算：佣金 + FBA 费 + 头程 + 采购 → 毛利/毛利率/保本价。

吸收 amz_agent fba-margin-calc.py / new_release_process run.py step1 实现。
"""

from __future__ import annotations

from datetime import date, datetime
from functools import lru_cache

from pydantic import ValidationError

from amz.calc.product.fba import calculate_fee
from amz.envelope import ParamError
from amz.registry import capability
from amz.schemas.analysis_inputs import CalcMarginInput
from amz.schemas.data_outputs import MarginOutput


# 头程物流成本估算（人民币/kg，运营报价口径）。
# 计算时按 CNY_PER_USD 汇率折算为美元（参考 market_selection_agent profit_calculator）。
SHIPPING_COST_PER_KG: dict[str, float] = {
    "slow": 8.0,       # 慢船
    "fast": 12.0,      # 快船
    "air": 30.0,       # 空运
    "express": 45.0,   # 快递
}

# 人民币兑美元汇率（人民币/美元），用于把 RMB 头程单价折算为 USD
CNY_PER_USD: float = 7.0
REFERRAL_FEE_CAP: float = 30.0


@capability(
    "calc.fba.margin",
    description="毛利率计算（佣金 + FBA + 头程 + 采购，含 M1/M2 分层利润）",
    input_model=CalcMarginInput,
    output_model=MarginOutput,
)
def calculate_margin(
    selling_price: float,
    pkg_weight_g: float = 0,
    pkg_dims_cm: tuple[float, float, float] | None = None,
    shipping_method: str = "fast",
    purchase_price: float | None = None,
    referral_rate: float = 0.15,
    cpc: float | None = None,
    cvr: float | None = None,
    product_type: str | None = None,
    fulfillment_date: date | datetime | str | None = None,
    include_fuel_surcharge: bool = True,
    fba_fee_usd: float | None = None,
    exchange_rate: float = CNY_PER_USD,
) -> dict:
    """calc.fba.margin — 毛利率计算（含 M1/M2 分层利润）

    M1 = (price - FBA - 头程 - 佣金) / price          … 平台费用后利润率（不含采购成本和广告）
    M2 = (price - FBA - 头程 - 佣金 - CPA) / price    … 平台+广告后利润率（不含采购成本）
         其中 CPA = cpc / cvr

    保本价沿用当前佣金封顶规则，并按保本价对应的售价档重新查 FBA 费；
    显式传入 fba_fee_usd 时，该费用保持固定。结果四舍五入至美分。

    Args:
        selling_price: 售价 ($)
        pkg_weight_g: 包装重量 (g)
        pkg_dims_cm: 包装尺寸 (length, width, height)
        shipping_method: 头程方式 slow/fast/air/express
        purchase_price: 采购价 ($)，未知则计算不含采购价的毛利
        referral_rate: 佣金率 (默认 15%)
        cpc: 单次点击成本 ($)，来自关键词 exactPpc 均值，用于 M2
        cvr: 转化率 (0-1)，来自关键词 purchases/clicks，用于 M2
        product_type: non_apparel/apparel/dangerous_goods（及兼容别名）
        fulfillment_date: FBA 出库日期，用于选择旺季费率和附加费
        include_fuel_surcharge: 是否应用生效日期后的 3.5% 燃油物流附加费
        fba_fee_usd: 已知的 FBA 配送费；传入时跳过本地 FBA 查表
        exchange_rate: 人民币兑美元汇率（人民币/美元），头程单价为 RMB，
            按该汇率折算为 $（默认 7.0）

    Returns:
        {referral_fee, fba_fee, shipping_cost, purchase_price, total_cost,
         gross_profit, gross_margin_pct, break_even_price,
         m1_margin_pct, m2_margin_pct, cpa, cpc, cvr}
    """
    # Apply the same contract to direct Python and Entity calls as Registry calls.
    try:
        values = CalcMarginInput.model_validate(locals())
    except ValidationError as exc:
        raise ParamError(str(exc)) from exc

    @lru_cache(maxsize=None)
    def fee_at_price(price: float) -> float:
        if values.fba_fee_usd is not None:
            return values.fba_fee_usd
        if values.pkg_dims_cm is None or values.pkg_weight_g <= 0:
            raise ParamError(
                "accurate FBA fees require pkg_weight_g and pkg_dims_cm; "
                "pass fba_fee_usd when the fee is already known"
            )
        return calculate_fee(
            values.pkg_weight_g,
            *values.pkg_dims_cm,
            values.product_type,
            selling_price=price,
            fulfillment_date=values.fulfillment_date,
            include_fuel_surcharge=values.include_fuel_surcharge,
        )["fee_usd"]

    # Keep the existing proportional referral fee with its $30 cap.
    referral_fee = min(values.selling_price * values.referral_rate, REFERRAL_FEE_CAP)
    fba_fee = fee_at_price(values.selling_price)
    shipping_cost = (
        SHIPPING_COST_PER_KG[values.shipping_method]
        * (values.pkg_weight_g / 1000)
        / values.exchange_rate
    )
    pp = values.purchase_price or 0.0
    fixed_cost = shipping_cost + pp
    total_cost = referral_fee + fba_fee + fixed_cost
    gross_profit = values.selling_price - total_cost
    gross_margin_pct = gross_profit / values.selling_price * 100

    # Solve each FBA price band from lowest to highest. FBA is fixed only when
    # supplied explicitly. Check the rounded quote too: $9.999 rounds into the
    # $10-$50 band and must use that band's fee before it can be returned.
    probes = (values.selling_price,) if values.fba_fee_usd is not None else (0.01, 10.0, 50.01)
    for probe in probes:
        candidate_fee = fee_at_price(probe)
        cost = fixed_cost + candidate_fee
        candidate = round(min(cost / (1 - values.referral_rate), cost + REFERRAL_FEE_CAP), 2)
        if fee_at_price(max(candidate, 0.01)) == candidate_fee:
            break_even_price = candidate
            break
    else:
        raise RuntimeError("no break-even price matches the bundled FBA price bands")

    m1_margin_pct = round(
        (values.selling_price - referral_fee - fba_fee - shipping_cost)
        / values.selling_price * 100, 1
    )
    m2_margin_pct = None
    cpa = None
    if values.cpc is not None and values.cvr is not None and values.cvr > 0:
        cpa = round(values.cpc / values.cvr, 2)
        m2_margin_pct = round(
            (values.selling_price - referral_fee - fba_fee - shipping_cost - cpa)
            / values.selling_price * 100, 1
        )

    return {
        "referral_fee": round(referral_fee, 2),
        "fba_fee": round(fba_fee, 2),
        "shipping_cost": round(shipping_cost, 2),
        "purchase_price": pp,
        "total_cost": round(total_cost, 2),
        "gross_profit": round(gross_profit, 2),
        "gross_margin_pct": round(gross_margin_pct, 1),
        "break_even_price": break_even_price,
        "m1_margin_pct": m1_margin_pct,
        "m2_margin_pct": m2_margin_pct,
        "cpa": cpa,
        "cpc": values.cpc,
        "cvr": values.cvr,
    }
