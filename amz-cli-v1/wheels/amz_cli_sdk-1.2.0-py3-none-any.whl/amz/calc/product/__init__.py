"""Internal deterministic calculations owned by Product."""
