"""
资金效率计算：多渠道物流成本 + ROI + 日回报率。

吸收 market_selection_agent profit_calculator.py。

纯函数：接收字段值，返回 dict。整合逻辑（合并 margin + roi 为 FinanceData）
由 ``entities.finance.build_finance`` 承担，结果模型 ``FinanceData`` 也定义在
entities 层——calc 只负责原子确定性计算，不读实体、不做整合。
"""

from __future__ import annotations

from amz.calc.product.margin import CNY_PER_USD
from amz.registry import capability
from amz.schemas.analysis_inputs import CalcReturnOnCapitalInput
from amz.schemas.data_outputs import ReturnOnCapitalOutput


# 头程单价为人民币/kg（运营报价口径），计算时按 CNY_PER_USD 汇率折算为 USD。
SHIPPING_METHODS: dict[str, dict] = {
    "slow":    {"cost_per_kg": 8.0,  "days": 30, "label": "慢船"},
    "fast":    {"cost_per_kg": 12.0, "days": 15, "label": "快船"},
    "air":     {"cost_per_kg": 30.0, "days": 7,  "label": "空运"},
    "express": {"cost_per_kg": 45.0, "days": 3,  "label": "快递"},
}


@capability(
    "calc.finance.return-on-capital",
    description="资金效率计算（4 渠道物流成本 + ROI + 日回报率）",
    input_model=CalcReturnOnCapitalInput,
    output_model=ReturnOnCapitalOutput,
)
def calculate_return_on_capital(
    selling_price: float,
    unit_cost: float,
    shipping_method: str = "fast",
    units_per_order: int = 1,
    cycle_days: int = 60,
    roi_target_pct: float = 30.0,
    weight_g: float | None = None,
    platform_cost: float | None = None,
    exchange_rate: float = CNY_PER_USD,
) -> dict:
    """calc.finance.return-on-capital

    Args:
        selling_price: 售价（$）
        unit_cost: 采购成本（$，不含头程与平台费）
        shipping_method: 物流方式 slow/fast/air/express
        units_per_order: 每单件数
        cycle_days: 资金周转天数
        roi_target_pct: 目标 ROI%
        weight_g: 商品重量（g），按实际重量计头程；None 时退回 0.5kg 起步估算
        platform_cost: 平台费用（佣金+FBA，$）；None 时只按 15% 佣金近似
        exchange_rate: 人民币兑美元汇率（人民币/美元），头程单价为 RMB，
            按该汇率折算为 $（默认 7.0）

    Returns:
        {shipping_cost, capital_per_unit, profit_per_unit, roi_pct, daily_return_pct}
    """
    if exchange_rate <= 0:
        raise ValueError("exchange_rate must be > 0")
    method = SHIPPING_METHODS.get(shipping_method, SHIPPING_METHODS["fast"])

    # 头程物流：按实际重量计（单价 RMB/kg → 汇率折算 USD）；重量未知时退回 0.5kg 起步估算
    shipping_cost = method["cost_per_kg"] * (weight_g / 1000 if weight_g else 0.5) / exchange_rate

    # 单件本金（资金占用 = 采购 + 头程）
    capital_per_unit = (unit_cost + shipping_cost) * units_per_order

    # 单件利润
    platform_cost = platform_cost if platform_cost is not None else selling_price * 0.15
    profit_per_unit = selling_price - platform_cost - unit_cost - shipping_cost

    # ROI
    roi_pct = (profit_per_unit / capital_per_unit * 100) if capital_per_unit > 0 else 0

    # 日回报率
    daily_return_pct = roi_pct / cycle_days if cycle_days > 0 else 0

    return {
        "shipping_cost": round(shipping_cost, 2),
        "capital_per_unit": round(capital_per_unit, 2),
        "profit_per_unit": round(profit_per_unit, 2),
        "roi_pct": round(roi_pct, 1),
        "daily_return_pct": round(daily_return_pct, 2),
    }
