"""Product Primary_Keywords calculations; inputs are prepared by Entity."""

from __future__ import annotations
from amz.registry import capability
from amz.schemas.analysis_inputs import CalcPrimaryKeywordsInput
from amz.schemas.data_outputs import PrimaryKeywordsOutput


def filter_primary(items: list[dict]) -> dict:
    """calc.keyword.filter-primary

    从关键词反查结果中筛选主力流量词（3-8 个），
    按流量占比/PPC/自然占比排序。

    Returns:
        {primary: [{term, traffic_pct, ppc, natural_ratio}], coverage_pct, total_traffic_pct}
    """
    if not items:
        return {"primary": [], "coverage_pct": 0, "total_traffic_pct": 0}

    # 过滤掉缺失关键字段的
    valid = [
        it for it in items
        if it.get("term") and it.get("traffic_pct") is not None
    ]

    if not valid:
        return {"primary": [], "coverage_pct": 0, "total_traffic_pct": 0}

    # 按 traffic_pct 降序
    sorted_items = sorted(valid, key=lambda x: x.get("traffic_pct", 0) or 0, reverse=True)

    # 取累积流量占比 ≥ 80% 的词，最少 3 个，最多 8 个
    total_traffic = sum(it.get("traffic_pct", 0) or 0 for it in sorted_items)
    cumulative = 0.0
    primary = []

    for it in sorted_items:
        tp = it.get("traffic_pct", 0) or 0
        cumulative += tp
        primary.append({
            "term": it["term"],
            "traffic_pct": tp,
            "ppc": it.get("ppc"),
            "natural_ratio": it.get("natural_ratio"),
        })
        # 至少 3 个且达到 80% 覆盖
        if len(primary) >= 3 and (cumulative / total_traffic) >= 0.8 if total_traffic > 0 else True:
            break
        if len(primary) >= 8:
            break

    coverage = sum(p["traffic_pct"] for p in primary)
    coverage_pct = (coverage / total_traffic * 100) if total_traffic > 0 else 0

    return {
        "primary": primary,
        "coverage_pct": round(coverage_pct, 1),
        "total_traffic_pct": round(total_traffic, 1),
    }


@capability(
    "calc.keyword.primary",
    description="从标准化反查关键词中筛选 3-8 个主力流量词",
    input_model=CalcPrimaryKeywordsInput,
    output_model=PrimaryKeywordsOutput,
)
def extract_primary_keywords(items: list[dict]) -> dict:
    """筛选主力流量词；只接受标准 DTO，不读取或修改 Product Entity。

    输入百分比和输出百分比均为 ``0-100``。为平滑迁移，函数仍能读取旧的
    camelCase item，但会在函数入口立即转成唯一的 canonical 形状。
    """
    normalized = [_canonical_reverse_item(item) for item in (items or [])]
    normalized = [item for item in normalized if item["term"]]

    candidates = [
        _candidate(item)
        for item in normalized
        if _is_candidate(item, minimum_traffic_pct=3.0)
    ]
    candidates = [
        item for item in candidates
        if not (
            len(item["term"].split()) == 1
            and item["purchase_rate"] < 3.0
        )
    ]
    deduped = _dedupe_candidates(candidates)

    # 不足三个时只放宽流量阈值，不改变其他规则。
    if len(deduped) < 3:
        known = {item["term"].lower() for item in deduped}
        for item in normalized:
            if item["term"].lower() in known or item["traffic_pct"] < 2.0:
                continue
            if len(item["term"].split()) == 1 and item["purchase_rate"] < 3.0:
                continue
            candidate = _candidate(item)
            candidate["reasons"] = ["流量占比放宽至2%"]
            deduped.append(candidate)
            known.add(item["term"].lower())
            if len(deduped) >= 3:
                break

    primary = sorted(deduped, key=lambda item: item["traffic_pct"], reverse=True)[:8]
    total_traffic = sum(item["traffic_pct"] for item in primary)
    avg_ppc = (
        sum(item["ppc"] for item in primary) / len(primary)
        if primary and all(item["ppc"] is not None for item in primary) else None
    )
    avg_natural = (
        sum(item["natural_ratio"] for item in primary) / len(primary)
        if primary else 0.0
    )
    competition = (
        "数据不足" if avg_ppc is None
        else "竞争较低" if avg_ppc < 1.0
        else "竞争中等" if avg_ppc < 2.0
        else "竞争激烈"
    )
    health = (
        "健康" if avg_natural > 80
        else "中等" if avg_natural > 50
        else "广告依赖度高"
    )

    output_items = []
    for item in primary:
        rank = (
            f"#{item['rank_pos']}" if item["rank_page"] == 1
            else f"P{item['rank_page']}#{item['rank_pos']}"
            if item["rank_page"] and item["rank_pos"]
            else ""
        )
        output_items.append({
            "term": item["term"],
            "keyword_cn": item["keyword_cn"],
            "search_volume": item["search_volume"],
            "traffic_pct": round(item["traffic_pct"], 1),
            "purchase_rate": round(item["purchase_rate"], 1),
            "cvr": round(item["cvr"], 1),
            "cpa": round(item["cpa"], 2) if item["cpa"] is not None else None,
            "ppc": round(item["ppc"], 2) if item["ppc"] is not None else None,
            "top3_clicking_rate": round(item["top3_clicking_rate"], 1),
            "top3_conversion_rate": round(item["top3_conversion_rate"], 1),
            "trend": item["trend"],
            "rank": rank,
            "types": item["types"],
            "natural_ratio": round(item["natural_ratio"], 1),
            "synonyms": item.get("synonyms", []),
            "reasons": item["reasons"],
        })

    return {
        "primary_keywords": output_items,
        "analysis": {
            "total_traffic_pct": round(total_traffic, 1),
            "avg_ppc": round(avg_ppc, 2) if avg_ppc is not None else None,
            "competition": competition,
            "avg_natural_ratio": round(avg_natural, 1),
            "health": health,
        },
    }


def _canonical_reverse_item(item: dict) -> dict:
    """兼容旧字段并立刻收敛到 canonical 0-100 DTO。"""
    rank_position = item.get("rankPosition") or {}
    canonical_rank = item.get("rank")
    return {
        "term": str(item.get("term") or item.get("keywords") or item.get("keyword") or "").strip(),
        "keyword_cn": str(item.get("keyword_cn") or item.get("keywordCn") or ""),
        "search_volume": int(item.get("search_volume") or item.get("searches") or 0),
        "traffic_pct": _canonical_pct(item, "traffic_pct", "trafficPercentage"),
        "purchase_rate": _canonical_pct(item, "purchase_rate", "purchaseRate"),
        "natural_ratio": _canonical_pct(item, "natural_ratio", "naturalRatio"),
        "ad_ratio": _canonical_pct(item, "ad_ratio", "adRatio"),
        "top3_clicking_rate": _canonical_pct(item, "top3_clicking_rate", "top3ClickingRate"),
        "top3_conversion_rate": _canonical_pct(item, "top3_conversion_rate", "top3ConversionRate"),
        "ppc": _ppc(item),
        "purchases": int(item.get("purchases") or 0),
        "clicks": int(item.get("clicks") or 0),
        "types": list(item.get("traffic_keyword_types") or item.get("trafficKeywordTypes") or []),
        "rank_page": int(rank_position.get("page") or (1 if canonical_rank else 0)),
        "rank_pos": int(rank_position.get("position") or canonical_rank or 0),
        "trend": list(item.get("trend") or item.get("searchesTrend") or []),
    }


def _ppc(item: dict) -> float | None:
    for key in ("ppc", "exactPpc"):
        if item.get(key) is not None:
            return float(item[key])
    return None


def _canonical_pct(item: dict, canonical_key: str, legacy_key: str) -> float:
    value = item.get(canonical_key)
    if value is not None:
        return float(value or 0)
    raw = item.get(legacy_key)
    if raw is None:
        return 0.0
    if isinstance(raw, str):
        text = raw.strip().replace("%", "")
        try:
            value = float(text)
        except ValueError:
            return 0.0
        return value if "%" in raw or value > 1 else value * 100
    value = float(raw or 0)
    return value * 100 if 0 < value <= 1 else value


def _is_candidate(item: dict, minimum_traffic_pct: float) -> bool:
    return (
        item["traffic_pct"] >= minimum_traffic_pct
        or bool({"PRIMARY", "PRECISE"}.intersection(item["types"]))
        or (
            item["search_volume"] >= 20_000
            and item["rank_page"] == 1
            and 0 < item["rank_pos"] <= 20
        )
    )


def _candidate(item: dict) -> dict:
    cvr = item["purchases"] / item["clicks"] * 100 if item["clicks"] else 0.0
    cpa = item["ppc"] / (cvr / 100) if cvr > 0 and item["ppc"] is not None else None
    reasons = []
    if item["traffic_pct"] >= 3:
        reasons.append(f"流量占比{item['traffic_pct']:.1f}%")
    if {"PRIMARY", "PRECISE"}.intersection(item["types"]):
        reasons.append("官方标记")
    if item["search_volume"] >= 20_000 and item["rank_page"] == 1 and 0 < item["rank_pos"] <= 20:
        reasons.append("大搜索量+首页")
    return {**item, "cvr": cvr, "cpa": cpa, "reasons": reasons}


def _dedupe_candidates(candidates: list[dict]) -> list[dict]:
    deduped: list[dict] = []
    for candidate in sorted(candidates, key=lambda item: item["traffic_pct"], reverse=True):
        words = set(candidate["term"].lower().split())
        duplicate = next((
            kept for kept in deduped
            if words.issubset(set(kept["term"].lower().split()))
            or set(kept["term"].lower().split()).issubset(words)
        ), None)
        if duplicate is None:
            deduped.append(candidate)
        else:
            duplicate.setdefault("synonyms", []).append(candidate["term"])
    return deduped
