"""淘宝商品与市场实体，以及搜索样本的管理。

TaobaoMarket 按搜索词采集第一页样本，将商品交给 TaobaoProduct 保存，
市场仅保存商品引用；市场摘要调用淘宝对应的 Analysis。
TaobaoProduct 使用已采集的本地商品资料，fetch 不额外请求商品详情接口。
两个实体共用 Entity 的字段依赖、缓存与持久化流程，并明确声明公开方法。"""

from typing import ClassVar, Literal
from pydantic import Field, field_validator
from amz.data.taobao import normalize_term
from amz.entities._core.base import EnrichSpec, Entity, lazy_field
from amz.envelope import Code, Result, err, ok
from amz.registry import capability
from amz.schemas.taobao import TaobaoItem, TaobaoSample, TaobaoSearch, taobao_product_ref
from amz.schemas.taobao_analysis import TaobaoMarketSummary


class TaobaoProduct(Entity):
    entity_type: ClassVar[str] = "taobao_product"
    identity_fields: ClassVar[tuple[str, ...]] = ("marketplace", "item_id")
    marketplace: Literal["CN"] = "CN"
    item_id: str = Field(pattern=r"^[0-9]+$")
    title: str | None = None
    image_url: str | None = None
    url: str | None = None
    collected_at: str | None = None

    @classmethod
    def from_item(cls, item: TaobaoItem, collected_at: str):
        product = cls.load(cls.compose_cache_id("CN", item.item_id))
        if product is None:
            product = cls(item_id=item.item_id)
        for name, value in item.model_dump().items():
            setattr(product, name, value)
        product.collected_at = collected_at
        product.save()
        return product

    @classmethod
    def fetch(cls, item_id: str, marketplace: Literal["CN"] = "CN"):
        """Read a previously collected product; never request a details API."""
        return cls.load(cls.compose_cache_id(marketplace, item_id))


class TaobaoMarket(Entity):
    entity_type: ClassVar[str] = "taobao_market"
    identity_fields: ClassVar[tuple[str, ...]] = ("marketplace", "term")
    marketplace: Literal["CN"] = "CN"
    term: str
    _term = field_validator("term")(normalize_term)
    sample: TaobaoSample | None = None
    summary: TaobaoMarketSummary | None = None
    summary_sources: dict[str, str | None] = Field(default_factory=dict)
    lazy_fields: ClassVar[dict[str, EnrichSpec]] = {
        "sample": EnrichSpec("sample", "get_sample", [], "data.taobao.search", ttl_hours=24),
        "summary": EnrichSpec(
            "summary", "get_summary", ["sample"], "analysis.taobao.market_classify", ttl_hours=24, version="4",
        ),
    }

    @classmethod
    def fetch(cls, term: str, marketplace: Literal["CN"] = "CN"):
        """Load or create the identity; collection happens only in get_sample."""
        term = normalize_term(term)
        cached = cls.load(cls.compose_cache_id(marketplace, term))
        return cached if cached is not None else cls(term=term, marketplace=marketplace)

    @lazy_field("sample")
    def get_sample(self) -> Result:
        """获取淘宝第一页搜索样本并保存商品引用"""
        from amz.data.taobao import taobao_search
        result = taobao_search(self.term)
        if result.code != Code.OK:
            return result
        search = TaobaoSearch.model_validate(result.data)
        refs = []
        for item in search.products:
            product = TaobaoProduct.from_item(item, search.collected_at)
            refs.append(taobao_product_ref(product.item_id))
        self._writeback("sample", TaobaoSample(source=search.source, page=search.page, collected_at=search.collected_at, product_refs=refs, skipped_count=search.skipped_count))
        return result

    def _summary_products(self):
        """Read current disk state, including updates made by another market/process."""
        if self.sample is None:
            return {}
        return {
            ref.key[1]: TaobaoProduct.load(
                TaobaoProduct.compose_cache_id(*ref.key), use_identity=False,
            )
            for ref in self.sample.product_refs
        }

    def _check_field(self, field: str, fetch_key: str | None = None) -> bool:
        if not super()._check_field(field, fetch_key):
            return False
        if field == "summary":
            products = self._summary_products()
            if any(product is None for product in products.values()):
                return False
            return self.summary_sources == {
                item_id: product.collected_at for item_id, product in products.items()
            }
        return True

    @lazy_field("summary")
    def get_summary(self, model: str = "pro") -> Result:
        """按解决方案分类淘宝样本，概述人群、场景并保留商品 ID"""
        from amz.analysis.taobao_market.classify import market_classify

        products = self._summary_products()
        missing = [item_id for item_id, product in products.items() if product is None]
        if missing:
            return err(
                Code.ERROR_MISSING_FIELDS, "Sample products missing from local cache",
                missing=missing, hint="Refresh the market sample to restore products",
            )
        sources = {item_id: product.collected_at for item_id, product in products.items()}
        result = market_classify(
            term=self.term,
            products=[{"item_id": p.item_id, "title": p.title} for p in products.values()],
            model=model,
        )
        if result.code != Code.OK:
            return result
        self.summary_sources = sources
        self._writeback("summary", TaobaoMarketSummary.model_validate(result.data))
        return result

    def get_products(self) -> Result:
        """Collect the sample if needed, then resolve product references locally."""
        result = self.get_sample()
        if result.code != Code.OK:
            return result
        products, missing = [], []
        for ref in self.sample.product_refs:
            product = TaobaoProduct.fetch(item_id=ref.key[1], marketplace=ref.key[0])
            if product is None:
                missing.append(ref.key[1])
            else:
                products.append(product.model_dump())
        return ok({"products": products, "missing_item_ids": missing}, from_cache=result.meta.from_cache)


@capability("entity.taobao_product.get", category="entity", output_model=TaobaoProduct, description="读取已由淘宝市场采集的商品，不请求详情接口")
def get_taobao_product(item_id: str, marketplace: Literal["CN"] = "CN") -> Result:
    TaobaoItem(item_id=item_id)
    product = TaobaoProduct.fetch(item_id, marketplace)
    if product is None:
        return err(Code.ERROR_CACHE_MISS, "Product not collected; search its market first")
    return ok(product.model_dump(), from_cache=True)
