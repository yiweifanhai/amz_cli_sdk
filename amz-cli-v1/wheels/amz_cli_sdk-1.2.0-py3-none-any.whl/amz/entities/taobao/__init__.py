"""淘宝实体的公开导入入口。

导出 TaobaoProduct、TaobaoMarket 和本地商品读取函数 get_taobao_product。
实体字段、采集及摘要方法都定义在 entity.py，
淘宝数据通过自己的来源和商品标识管理，不套用 Amazon ASIN。"""

from amz.entities.taobao.entity import TaobaoMarket, TaobaoProduct, get_taobao_product


__all__ = ["TaobaoProduct", "TaobaoMarket", "get_taobao_product"]
