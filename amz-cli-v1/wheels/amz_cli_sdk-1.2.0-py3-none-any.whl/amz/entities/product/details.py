"""Product 基础资料、详细页面信息和 Rufus 问答的读取。

由 Product 的字段方法调用 Data，刷新价格等基础字段，或按需获取
标题、五点、描述、图片等详情以及 Rufus 问答，再写回当前商品。
依赖与缓存有效期由 entity.py 的字段声明和 _core/base.py 统一管理；
本文件负责数据获取及字段组装，不做商品语义分析。"""

from __future__ import annotations
from typing import TYPE_CHECKING
from amz.envelope import Code, Result, err, ok

if TYPE_CHECKING:
    from amz.entities.product.entity import Product


def refresh_core(product: Product) -> Result:
    """刷新 competing-lookup 提供的 Product core 字段。"""
    refreshed = type(product).fetch(product.asin, force_refresh=True, marketplace=product.marketplace)
    if refreshed is None:
        return err(
            Code.ERROR_UPSTREAM,
            f"failed to refresh core fields for {product.asin}",
        )
    if refreshed is not product:
        product._copy_state_from(refreshed)
    product._mark_fetched("core")
    product.save()
    return ok(data=product._core_data())


def get_product_details(product: Product) -> Result:
    """从 product-info 拉取富文本字段（五点/描述/全量图片/变体/完整类目树等，慢端点按需）

    填充：bullet_points, description, images (全量), variations,
    categories (完整树), product_details_raw, review_insights,
    about_product, manufacturer, aplus_images。

    注意：11 个字段共享一次 API 调用，因此使用单次 _mark_fetched
    管理 TTL。如果后续要求不同字段有不同缓存时长，需要拆分。
    """
    if product.marketplace != "US":
        return err(Code.ERROR_PARAM, "upstream product data currently supports marketplace US only")
    from amz.data.product import product_get

    result = product_get(product.asin)
    if result.code != Code.OK or not result.data:
        return result

    data = result.data
    if data.get("title") and data["title"] != product.title:
        product.title = data["title"]
        product._invalidate_dependents("title")

    # 富文本
    product.bullet_points = data.get("bullet_points") or []
    product.description = data.get("description")

    # Use the current detail images when available; removed images must not linger.
    pi_images = data.get("images") or []
    if pi_images:
        product.images = list(dict.fromkeys(pi_images))

    # variations
    product.variations = data.get("variations") or []

    # categories: 用 product-info 完整树覆盖
    pi_cats = data.get("categories") or []
    if pi_cats:
        product.categories = pi_cats

    # 保留原始数据
    product.product_details_raw = data.get("product_details_raw") or []
    product.review_insights = data.get("reviewInsights") or data.get("review_insights")
    product.about_product = data.get("aboutProduct") or data.get("about_product") or []
    product.manufacturer = data.get("manufacturer")
    product.categories_extended = data.get("categories_extended") or data.get("categoriesExtended") or []
    product.aplus_images = data.get("aplusImageUrlList") or data.get("aplus_images") or []

    # BSR: 如果 product-info 有更详细的数据则覆盖
    pi_bsr = data.get("bsr")
    if pi_bsr is not None:
        product.bsr = pi_bsr

    # 兜底 brand
    if not product.brand and data.get("brand"):
        product.brand = data.get("brand")

    # 批量回填：字段本身保存稳定快照，Entity capability 的输出不再是
    # 含义模糊的 {"enriched": true}。
    details = product._product_details_snapshot()
    product._writeback("product_details", details)
    return ok(data=details)


def get_rufus(product: Product) -> Result:
    """获取商品的 Rufus AI 问答"""
    if product.marketplace != "US":
        return err(Code.ERROR_PARAM, "upstream product data currently supports marketplace US only")
    from amz.data.product import product_rufus
    result = product_rufus(product.asin)
    if result.code == Code.OK:
        product._writeback("rufus_qa", (result.data or {}).get("rufus", []))
    return result
