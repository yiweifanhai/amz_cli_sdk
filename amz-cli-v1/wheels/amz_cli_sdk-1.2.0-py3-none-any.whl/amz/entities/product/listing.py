"""Product 与 ProductDraft 的 Listing 文案任务。

实现整篇改写、局部改写、关键词插入与分配，以及新旧文字差异比较。
公开入口在实体类中，例如 product.listing_rewrite()；本文件函数接收同一实例，
读取并检查现有标题、五点及用户任务条件，再调用 Analysis 或 Calc。
返回的是本次任务的草稿或差异结果，不覆盖来源商品字段，也不设长期字段缓存。"""

from __future__ import annotations
from typing import Any, Literal, TYPE_CHECKING
from amz.entities._core import operations
from amz.entities.product.facts import _missing
from amz.envelope import Code, Result, err

if TYPE_CHECKING:
    from amz.entities.product.draft import ProductDraft
    from amz.entities.product.entity import Product


def listing_diff(product: Product | ProductDraft, new_text: str, part: Literal["title", "bp1", "bp2", "bp3", "bp4", "bp5", "description"] = "title") -> Result:
    """Compare proposed text with this Product or ProductDraft's saved Listing part."""
    failure = product._ensure_analysis_facts(listing=True)
    if failure is not None:
        return failure
    if part.startswith("bp"):
        index = int(part[2:]) - 1
        if index >= len(product.bullet_points):
            return _missing(part)
        old_text = product.bullet_points[index]
    else:
        old_text = getattr(product, part) or ""
    if not old_text.strip():
        return _missing(part)
    return operations.run_calc("calc.listing.word-diff", {"old_text": old_text, "new_text": new_text})


def _listing_data(product: Product | ProductDraft) -> dict[str, Any]:
    return {"title": product.title or "", "bullet_points": list(product.bullet_points)}


def _listing_policy(product: Product | ProductDraft, forbidden_terms: list[str] | None, media_title_limit: int | None) -> dict[str, Any]:
    return {"brand": product.brand or "", "forbidden_terms": forbidden_terms or [], "media_title_limit": media_title_limit}


def listing_rewrite(
    product: Product | ProductDraft, keywords: dict[str, list[str]] | None = None, feedback: str = "",
    forbidden_terms: list[str] | None = None, media_title_limit: int | None = None,
    title_differentiation: str = "",
) -> Result:
    """Rewrite this Product's current title and bullets; return a separate draft."""
    failure = product._ensure_analysis_facts(listing=True)
    if failure is not None:
        return failure
    return operations.run_analysis("analysis.listing.rewrite", {
        **product._listing_data(), **product._listing_policy(forbidden_terms, media_title_limit),
        "keywords": keywords, "feedback": feedback,
        "title_differentiation": title_differentiation,
        "price": str(product.price_usd) if product.price_usd is not None else "",
        "image_url": product._project_image_url(),
    })


def listing_micro_insert(
    product: Product | ProductDraft, insert_plan: dict[str, list[str]], feedback: str = "",
    forbidden_terms: list[str] | None = None, media_title_limit: int | None = None,
    title_differentiation: str = "",
) -> Result:
    """Insert planned keywords into this Product's current Listing."""
    if not insert_plan or not any(insert_plan.values()):
        return _missing("insert_plan")
    failure = product._ensure_analysis_facts(listing=True)
    if failure is not None:
        return failure
    valid = {"title", "title_differentiation", *(f"bp{i + 1}" for i in range(min(5, len(product.bullet_points))))}
    if any(key not in valid for key in insert_plan):
        return err(Code.ERROR_PARAM, "insert_plan must target the current title or existing bp1-bp5")
    return operations.run_analysis("analysis.listing.micro-insert", {
        **product._listing_data(), **product._listing_policy(forbidden_terms, media_title_limit),
        "insert_plan": insert_plan, "feedback": feedback,
        "title_differentiation": title_differentiation,
    })


def listing_part_rewrite(
    product: Product | ProductDraft, part: str, keywords: list[dict[str, Any]], existing_keywords: list[str] | None = None,
    forbidden_terms: list[str] | None = None, media_title_limit: int | None = None,
    title_differentiation: str = "", draft_title: str | None = None,
) -> Result:
    """Rewrite one existing title or bullet; its text is read from this Product."""
    failure = product._ensure_analysis_facts(listing=True)
    if failure is not None:
        return failure
    parts = {"title": product.title or "", "title_differentiation": title_differentiation,
             **{f"bp{i + 1}": text for i, text in enumerate(product.bullet_points[:5])}}
    part = part.strip().lower()
    if part not in parts:
        return err(Code.ERROR_PARAM, "part must be title, title_differentiation or an existing bp1-bp5")
    if not parts[part].strip():
        return _missing(part)
    if not keywords:
        return _missing("keywords")
    if draft_title is not None and (part != "title_differentiation" or not draft_title.strip()):
        return err(Code.ERROR_PARAM, "draft_title is confirmed task context for title_differentiation only")
    product_title = draft_title if draft_title is not None else product.title or ""
    if draft_title is not None:
        parts["title"] = draft_title
    return operations.run_analysis("analysis.listing.part-rewrite", {
        **product._listing_policy(forbidden_terms, media_title_limit),
        "product_title": product_title, "part_label": part, "current_text": parts[part],
        "other_parts": {key: value for key, value in parts.items() if key != part and value},
        "keywords": keywords, "existing_keywords": existing_keywords, "asin": product.asin,
        "price": str(product.price_usd) if product.price_usd is not None else "",
    })


def listing_allocate(product: Product | ProductDraft, missing_keywords: list[str], use_llm: bool = True) -> Result:
    """Allocate supplied candidates using this Product's current Listing."""
    failure = product._ensure_analysis_facts(listing=True)
    if failure is not None:
        return failure
    if not missing_keywords or any(not term.strip() for term in missing_keywords):
        return _missing("missing_keywords")
    return operations.run_analysis("analysis.listing.allocate", {
        "listing": product._listing_data(), "missing_keywords": missing_keywords, "use_llm": use_llm,
    })
