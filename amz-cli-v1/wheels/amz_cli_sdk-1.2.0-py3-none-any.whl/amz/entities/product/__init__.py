"""Product 包的公开导入入口。

导出 Product、商品详情等数据模型和常用参数类型，支持
from amz.entities.product import Product。字段和方法在 entity.py 中声明，
较长实现按职责放在同目录文件中；ProductDraft 定义在 draft.py。"""

from amz.entities.product.entity import Product
from amz.entities.product.models import (
    Assessment,
    NonNegative,
    Positive,
    PositiveInt,
    ProductDetails,
    Ratio,
    ReferralRate,
    ShippingMethod,
    Supplier,
)


__all__ = ['Product', 'ProductDetails', 'NonNegative', 'Positive', 'PositiveInt', 'Ratio', 'ReferralRate', 'ShippingMethod', 'Assessment', 'Supplier']
