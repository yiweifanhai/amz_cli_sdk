"""Product 的用户反馈（VOC）分析与结果组装。

从 Listing 准备优势分析，从评论准备痛点、使用洞察、好评和愿望清单分析，
调用相应 Analysis 后写回字段，并将三路 VOC 结果组装为商品的 voc 字段。
满意度由 Calc 计算，未满足需求复用已有弱点结果。
依赖与有效内容检查沿用 Product 的统一流程，本文件不保存另一份商品状态。"""

from __future__ import annotations
from typing import TYPE_CHECKING
from amz.entities._core import operations
from amz.entities.product.facts import _missing, _positive
from amz.envelope import Code, Result, err, ok
from amz.schemas.voc import ProductVoc, ReviewSummary

if TYPE_CHECKING:
    from amz.entities.product.entity import Product


def get_unmet_needs(product: Product) -> Result:
    """Project unmet needs from weaknesses without another model request."""
    product._writeback("unmet_needs", product.weaknesses.unmet_needs)
    return ok(data=product.unmet_needs)


def get_praise(product: Product) -> Result:
    """好评深度挖掘：从 4-5 星好评中提取用户喜爱点、惊喜点、竞品对比、价值感知。

    委托 analysis.voc.praise()，结果写回 self.praise。
    依赖 reviews 字段，未填充时自动级联触发 get_reviews()。
    """
    # 确保 reviews 已填充
    if not product._check_field("reviews"):
        rev_result = product.get_reviews()
        if rev_result.code != Code.OK:
            return err(Code.ERROR_UPSTREAM, "failed to fetch reviews", hint=rev_result.message)

    from amz.analysis.product.praise import voc_praise

    product_info = product.to_product_info()
    reviews_dicts = product.to_review_items()

    result = voc_praise(product_info=product_info, reviews=reviews_dicts)
    if result.code == Code.OK:
        product._writeback("praise", result.data)
    return result


def get_wishlist(product: Product) -> Result:
    """用户愿望清单：从全部评论中提取功能请求、改进建议、变体需求、配件需求。

    委托 analysis.voc.wishlist()，结果写回 self.wishlist。
    依赖 reviews 字段，未填充时自动级联触发 get_reviews()。
    """
    # 确保 reviews 已填充
    if not product._check_field("reviews"):
        rev_result = product.get_reviews()
        if rev_result.code != Code.OK:
            return err(Code.ERROR_UPSTREAM, "failed to fetch reviews", hint=rev_result.message)

    from amz.analysis.product.wishlist import voc_wishlist

    product_info = product.to_product_info()
    reviews_dicts = product.to_review_items()

    result = voc_wishlist(product_info=product_info, reviews=reviews_dicts)
    if result.code == Code.OK:
        product._writeback("wishlist", result.data)
    return result


def get_strengths(product: Product) -> Result:
    """创新优势分析：从 Listing 文案中找出产品真正的创新点和竞争优势。

    委托 analysis.voc.strength-signals，结果写回 self.strengths。
    该原子能力仅使用 Listing 事实，不读取评论。
    """
    from amz.analysis.product.strengths import voc_strength_signals

    if not product.title:
        return err(
            Code.ERROR_MISSING_FIELDS,
            "missing required fields: title",
            missing=["title"],
        )
    product_info = product.to_voc_listing()

    result = voc_strength_signals(product_info=product_info)
    if result.code == Code.OK:
        product._writeback("strengths", result.data)
    return result


def get_weaknesses(product: Product) -> Result:
    """差评 VOC 分析：从评论中提取痛点、未满足需求，带辩证分析上下文。

    先用 calc.voc.satisfaction 计算全量满意度，再委托
    analysis.voc.weakness-signals 提取语义信号并写回 self.weaknesses。
    依赖 reviews 字段，未填充时自动级联触发 get_reviews()。
    """
    if not product.title:
        return err(
            Code.ERROR_MISSING_FIELDS,
            "missing required fields: title",
            missing=["title"],
        )
    if product.reviews is None:
        return err(
            Code.ERROR_MISSING_FIELDS,
            "missing required fields: reviews",
            missing=["reviews"],
        )

    from amz.analysis.product.weaknesses import voc_weakness_signals
    from amz.calc.product.satisfaction import calculate_satisfaction, merge_weakness_signals

    product_info = product.to_voc_listing()
    reviews_dicts = product.to_review_items()
    satisfaction = calculate_satisfaction(
        reviews=reviews_dicts,
        review_summary=product.reviews.review_summary or None,
        total_reviews=product.reviews.count_ratings or product.count_review,
        product_rating=product.reviews.rating or product.rating,
    )
    signals = voc_weakness_signals(
        product_info=product_info,
        reviews=reviews_dicts,
        satisfaction=satisfaction.model_dump(mode="python"),
    )
    if signals.code != Code.OK:
        return signals
    try:
        weaknesses = merge_weakness_signals(signals.data, satisfaction)
    except Exception as exc:
        return err(Code.ERROR_LLM, f"invalid weakness signals: {exc}")
    product._writeback("weaknesses", weaknesses)
    return ok(data=weaknesses)


def get_use_insights(product: Product) -> Result:
    """消费者使用洞察：场景、人群画像、购买动机。

    委托 analysis.voc.use-signals，结果写回 self.use_insights。
    依赖 reviews 字段，未填充时自动级联触发 get_reviews()。
    """
    from amz.analysis.product.use_insights import voc_use_signals

    if not product.title:
        return err(
            Code.ERROR_MISSING_FIELDS,
            "missing required fields: title",
            missing=["title"],
        )
    if product.reviews is None:
        return err(
            Code.ERROR_MISSING_FIELDS,
            "missing required fields: reviews",
            missing=["reviews"],
        )

    product_info = product.to_voc_listing()
    reviews_dicts = product.to_review_items()

    result = voc_use_signals(product_info=product_info, reviews=reviews_dicts)
    if result.code == Code.OK:
        product._writeback("use_insights", result.data)
    return result


def get_voc(product: Product) -> Result:
    """组装 Product 三路 VOC 字段；语义分析仍由各原子能力完成。"""
    missing = [
        field
        for field in ("strengths", "weaknesses", "use_insights")
        if getattr(product, field) is None
    ]
    if missing:
        return err(
            Code.ERROR_MISSING_FIELDS,
            "missing required fields: " + ", ".join(missing),
            missing=missing,
        )
    voc = ProductVoc(
        strengths=product.strengths,
        weaknesses=product.weaknesses,
        use_insights=product.use_insights,
    )
    product._writeback("voc", voc)
    return ok(data=voc)


def calculate_satisfaction(product: Product) -> Result:
    """Calculate satisfaction from this Product's review summary and rating."""
    result = product.enrich("reviews")
    if result.code != Code.OK:
        return result
    reviews = product.reviews
    if reviews is None:
        return _missing("reviews")
    summary = reviews.review_summary or None
    rating = reviews.rating
    rating_source = "reviews.rating"
    if summary is not None:
        summary = ReviewSummary.model_validate(summary)
        if not any(getattr(summary, name).percentage > 0 for name in ("one_star", "two_star", "three_star", "four_star", "five_star")):
            summary = None
    if not _positive(rating) or rating > 5:
        rating = None
    core_ready = product._check_field("core")
    if rating is None and core_ready and _positive(product.rating) and product.rating <= 5:
        rating = product.rating
        rating_source = "product.rating"
    if rating is None and summary is not None:
        rating_source = "reviews.review_summary"
    if summary is None and rating is None:
        return _missing("reviews.review_summary", "reviews.rating", "rating")
    total = reviews.count_ratings
    count_source = "reviews.count_ratings"
    if total is None and summary is not None and summary.total_reviews is not None:
        total = summary.total_reviews
        count_source = "reviews.review_summary"
    if total is None and core_ready and product.count_review is not None and product.count_review >= 0:
        total = product.count_review
        count_source = "product.count_review"
    sample = product.to_review_items()
    if total is None:
        count_source = "review_sample"
    result = operations.run_calc("calc.voc.satisfaction", {
        "reviews": sample, "review_summary": summary,
        "total_reviews": total, "product_rating": rating,
    })
    if result.code == Code.OK:
        result.meta.usage["satisfaction_sources"] = {
            "rating": rating_source, "count": count_source,
            "distribution": "reviews.review_summary" if summary is not None else "unavailable",
            "sample_size": len(sample),
        }
        if summary is None:
            result.meta.hint = "未获取全量星级分布，好评率和差评率为空，未按评论样本推算。"
        if count_source == "review_sample":
            result.meta.hint += " total_reviews 仅表示当前评论样本数。"
    return result
