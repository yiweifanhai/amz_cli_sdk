"""Product 的财务数据准备、计算调用和结果组装。

FinanceData 描述利润、费用和资金效率；build_finance 组合 Calc 的计算结果。
Product 方法从当前商品读取售价、重量和尺寸，并准备所需汇率、广告数据等输入。
get_finance 写回 finance 字段；单独的 FBA 费用、利润和资金效率任务返回任务结果。
财务公式保留在 amz/calc/product/，本文件负责商品资料与计算之间的连接。"""

from __future__ import annotations
import math
from datetime import date, datetime
from typing import Any, TYPE_CHECKING
from pydantic import BaseModel, Field
from amz.calc.product.margin import CNY_PER_USD
from amz.entities._core import operations
from amz.entities.product.facts import _missing, _positive
from amz.entities.product.models import (
    NonNegative,
    Positive,
    PositiveInt,
    Ratio,
    ReferralRate,
    ShippingMethod,
)
from amz.envelope import Code, Result, err, ok

if TYPE_CHECKING:
    from amz.entities.product.entity import Product
    from amz.entities.product.finance import FinanceData


class FinanceData(BaseModel):
    """利润和资金效率计算结果。"""

    selling_price: float | None = None
    referral_fee: float | None = None
    fba_fee: float | None = None
    shipping_cost: float | None = None
    purchase_price: float | None = None
    total_cost: float | None = None
    gross_profit: float | None = None
    gross_margin_pct: float | None = None
    break_even_price: float | None = None
    m1_margin_pct: float | None = None
    m2_margin_pct: float | None = None
    cpc: float | None = None
    cvr: float | None = None
    cpa: float | None = None
    roi_pct: float | None = None
    daily_return_pct: float | None = None
    capital_per_unit: float | None = None
    profit_per_unit: float | None = None
    assumptions: dict = Field(default_factory=dict)


def build_finance(
    selling_price: float | None,
    weight_g: float | None,
    dimensions_cm: dict[str, Any] | None,
    shipping_method: str = "fast",
    purchase_price: float | None = None,
    cpc: float | None = None,
    cvr: float | None = None,
    product_type: str | None = None,
    fulfillment_date: date | datetime | str | None = None,
    include_fuel_surcharge: bool = True,
    exchange_rate: float = CNY_PER_USD,
) -> FinanceData:
    """整合 ``calc.fba.margin`` + ``calc.finance.return-on-capital`` → FinanceData。

    纯整合：接收字段值（不依赖 Product 对象），编排两个 calc 纯函数并合并为
    类型化结果。不 fetch、不回填、不写缓存——这些由 ``Product.get_finance()`` 负责。

    Args:
        selling_price: 售价（$）
        weight_g: 包装重量（g）
        dimensions_cm: 包装尺寸 dict {length, width, height}（cm）
        shipping_method: 头程方式 slow/fast/air/express
        purchase_price: 采购价（$）
        cpc / cvr: 广告指标，用于 M2
        product_type: non_apparel/apparel/dangerous_goods
        fulfillment_date: FBA 出库日期
        include_fuel_surcharge: 是否计入燃油附加费
        exchange_rate: 人民币兑美元汇率

    Returns:
        FinanceData 实例 — 类型化的全量财务指标
    """
    from amz.calc.product.finance import calculate_return_on_capital
    from amz.calc.product.margin import calculate_margin

    price = selling_price or 0
    dims = dimensions_cm or {}
    margin_result = calculate_margin(
        selling_price=price,
        pkg_weight_g=weight_g or 0,
        pkg_dims_cm=(
            dims.get("length", 0),
            dims.get("width", 0),
            dims.get("height", 0),
        ) if dims else None,
        shipping_method=shipping_method,
        purchase_price=purchase_price,
        cpc=cpc,
        cvr=cvr,
        product_type=product_type,
        fulfillment_date=fulfillment_date,
        include_fuel_surcharge=include_fuel_surcharge,
        exchange_rate=exchange_rate,
    )

    roi_result = calculate_return_on_capital(
        selling_price=price,
        unit_cost=margin_result["purchase_price"],
        shipping_method=shipping_method,
        weight_g=weight_g,
        platform_cost=margin_result["referral_fee"] + margin_result["fba_fee"],
        exchange_rate=exchange_rate,
    )

    # margin_result 和 roi_result 共享 shipping_cost，合并时去重
    merged = {**margin_result, **roi_result}
    return FinanceData(
        selling_price=price,
        **merged,
        assumptions={
            "shipping_method": shipping_method,
            "product_type": product_type or "non_apparel",
            "fulfillment_date": (
                fulfillment_date.isoformat()
                if isinstance(fulfillment_date, (date, datetime))
                else fulfillment_date
            ),
            "include_fuel_surcharge": include_fuel_surcharge,
            "exchange_rate": exchange_rate,
        },
    )


def get_finance(
    product: Product,
    shipping_method: str = "fast",
    purchase_price: float | None = None,
    cpc: float | None = None,
    cvr: float | None = None,
    product_type: str | None = None,
    fulfillment_date: date | datetime | str | None = None,
    include_fuel_surcharge: bool = True,
    include_ads: bool = False,
    exchange_rate: float | None = None,
) -> Result:
    """计算利润（毛利率 M1/M2、采购毛利、FBA 费、资金效率 ROI）。

    从 self 取 price/weight/dims 字段值，委托 entities.finance.build_finance
    整合 calc.fba.margin + calc.finance.return-on-capital 两个纯函数；
    纯计算在 calc 层，整合与回填在 entities 层。
    weight_g 和 dimensions_cm 来自 competing-lookup 的 pkg 数据，
    已在 fetch() 时填充，无需额外请求。

    Args:
        cpc: 单次点击成本（$），用于计算 m2_margin_pct（平台+广告后利润率）
        cvr: 转化率（0-1），用于计算 m2_margin_pct
        product_type: non_apparel/apparel/dangerous_goods（及兼容别名）
        fulfillment_date: FBA 出库日期，用于选择旺季费率和附加费
        include_ads: 是否需要计算广告指标（cpc/cvr/cpa 与 M2 利润率）。
            True 时：显式传入的 cpc/cvr 优先；否则自动从主关键词
            （primary_keywords，未填充时级联拉取 reverse_keywords）取
            流量最大的主关键词的 exactPpc/cvr/cpa。False 时 cpc/cvr/cpa 为 null。
        exchange_rate: 人民币兑美元汇率（人民币/美元），头程单价为 RMB，
            按该汇率折算为 $；省略时自动取最新日参考汇率，非盘中成交价。
    """
    finance_fields = ["price_usd", "dimensions_cm", "weight_g"]
    missing = product._check_depends(finance_fields)
    if missing:
        return err(
            Code.ERROR_UPSTREAM,
            f"missing fields for finance calc: {missing}",
            missing=missing,
            hint="ensure Product.fetch() succeeded; weight/dims come from competing-lookup",
        )

    from amz.entities.product.finance import build_finance

    rate_info = {"source": "manual", "date": None, "kind": "manual", "fetched_at": None}
    if exchange_rate is None:
        from amz.data.fx import exchange_rate as fetch_exchange_rate

        rate_result = fetch_exchange_rate("USD", "CNY")
        if rate_result.code != Code.OK:
            return rate_result
        exchange_rate = rate_result.data["rate"]
        rate_info = rate_result.data
    else:
        import math

        if not math.isfinite(exchange_rate) or exchange_rate <= 0:
            return err(Code.ERROR_PARAM, "exchange_rate must be finite and > 0")

    ads_source = "none"
    ads_keyword: str | None = None
    if include_ads:
        # 显式 cpc/cvr 优先；缺任一时从主关键词补齐（未填充则级联拉取）
        if cpc is None or cvr is None:
            if not product._check_field("primary_keywords"):
                pk_result = product.get_primary_keywords()
                if pk_result.code != Code.OK:
                    ads_source = "unavailable"
                else:
                    ads_source = "primary_keyword"
            else:
                ads_source = "primary_keyword"
            if ads_source == "primary_keyword" and product.primary_keywords:
                top = product.primary_keywords[0]
                if cpc is None:
                    cpc = top.ppc
                if cvr is None and cpc is not None:
                    # primary_keywords 中 cvr 为百分数（如 8.5 = 8.5%）
                    cvr = (top.cvr or 0) / 100
                ads_keyword = top.term
        else:
            ads_source = "param"

    finance_data = build_finance(
        selling_price=product.price_usd,
        weight_g=product.weight_g,
        dimensions_cm=product.dimensions_cm,
        shipping_method=shipping_method,
        purchase_price=purchase_price, cpc=cpc, cvr=cvr,
        product_type=product_type,
        fulfillment_date=fulfillment_date,
        include_fuel_surcharge=include_fuel_surcharge,
        exchange_rate=exchange_rate,
    )
    finance_data.assumptions.update({
        "exchange_rate_source": rate_info["source"],
        "exchange_rate_date": rate_info["date"],
        "exchange_rate_kind": rate_info["kind"],
        "exchange_rate_fetched_at": rate_info["fetched_at"],
        "ads_source": ads_source,
        "ads_keyword": ads_keyword,
    })
    product._writeback("finance", finance_data)

    enriched = ["price_usd", "dimensions_cm", "weight_g"]
    if ads_source == "primary_keyword":
        enriched.append("primary_keywords")
    return ok(data=product.finance, enriched=enriched)


def _check_finance_facts(product: Product) -> Result | None:
    missing = []
    if not _positive(product.price_usd):
        missing.append("price_usd")
    if not _positive(product.weight_g):
        missing.append("weight_g")
    dims = product._project_pkg_dims()
    if dims is None or not all(_positive(value) for value in dims):
        missing.append("dimensions_cm")
    if product.fba_fee is not None and (not isinstance(product.fba_fee, (int, float)) or not math.isfinite(product.fba_fee) or product.fba_fee < 0):
        missing.append("fba_fee")
    return _missing(*missing) if missing else None


def _calc_core(product: Product) -> Result | None:
    if product.marketplace != "US":
        return err(Code.ERROR_PARAM, "Product calculations currently support marketplace US only")
    result = product.enrich("core")
    return result if result.code != Code.OK else None


def _calc_exchange_rate(exchange_rate: float | None) -> float | Result:
    if exchange_rate is not None:
        return exchange_rate
    from amz.data.fx import exchange_rate as fetch_rate

    result = fetch_rate("USD", "CNY")
    return result.data["rate"] if result.code == Code.OK else result


def calculate_fba_fee(
    product: Product, product_type: str | None = None,
    fulfillment_date: date | datetime | str | None = None,
    include_fuel_surcharge: bool = True,
) -> Result:
    """Calculate FBA fees using this Product's price, package weight and dimensions."""
    failure = product._calc_core()
    if failure is not None:
        return failure
    failure = product._check_finance_facts()
    if failure is not None:
        return failure
    length, width, height = product._project_pkg_dims()
    return operations.run_calc("calc.fba.fee", {
        "selling_price": product.price_usd, "weight_grams": product.weight_g,
        "length_cm": length, "width_cm": width, "height_cm": height,
        "product_type": product_type, "fulfillment_date": fulfillment_date,
        "include_fuel_surcharge": include_fuel_surcharge,
    })


def calculate_margin(
    product: Product, purchase_price: NonNegative | None = None,
    shipping_method: ShippingMethod = "fast", referral_rate: ReferralRate = 0.15,
    cpc: NonNegative | None = None, cvr: Ratio | None = None,
    product_type: str | None = None, fulfillment_date: date | datetime | str | None = None,
    include_fuel_surcharge: bool = True, exchange_rate: Positive | None = None,
) -> Result:
    """Calculate margin from Product facts and explicit cost assumptions."""
    failure = product._calc_core()
    if failure is not None:
        return failure
    failure = product._check_finance_facts()
    if failure is not None:
        return failure
    rate = product._calc_exchange_rate(exchange_rate)
    if isinstance(rate, Result):
        return rate
    return operations.run_calc("calc.fba.margin", {
        "selling_price": product.price_usd, "pkg_weight_g": product.weight_g,
        "pkg_dims_cm": product._project_pkg_dims(), "fba_fee_usd": product.fba_fee,
        "purchase_price": purchase_price, "shipping_method": shipping_method,
        "referral_rate": referral_rate, "cpc": cpc, "cvr": cvr,
        "product_type": product_type, "fulfillment_date": fulfillment_date,
        "include_fuel_surcharge": include_fuel_surcharge, "exchange_rate": rate,
    })


def calculate_return_on_capital(
    product: Product, unit_cost: NonNegative, shipping_method: ShippingMethod = "fast",
    units_per_order: PositiveInt = 1, cycle_days: PositiveInt = 60,
    roi_target_pct: NonNegative = 30.0, exchange_rate: Positive | None = None,
    product_type: str | None = None, fulfillment_date: date | datetime | str | None = None,
    include_fuel_surcharge: bool = True,
) -> Result:
    """Calculate capital returns with this Product's price, weight and platform fees."""
    # Prepare facts before asking for an exchange rate.
    failure = product._calc_core()
    if failure is not None:
        return failure
    failure = product._check_finance_facts()
    if failure is not None:
        return failure
    rate = product._calc_exchange_rate(exchange_rate)
    if isinstance(rate, Result):
        return rate
    margin = product.calculate_margin(
        purchase_price=unit_cost, shipping_method=shipping_method, exchange_rate=rate,
        product_type=product_type, fulfillment_date=fulfillment_date,
        include_fuel_surcharge=include_fuel_surcharge,
    )
    if margin.code != Code.OK:
        return margin
    return operations.run_calc("calc.finance.return-on-capital", {
        "selling_price": product.price_usd, "unit_cost": unit_cost,
        "shipping_method": shipping_method, "units_per_order": units_per_order,
        "cycle_days": cycle_days, "roi_target_pct": roi_target_pct,
        "weight_g": product.weight_g, "exchange_rate": rate,
        "platform_cost": margin.data["referral_fee"] + margin.data["fba_fee"],
    })
