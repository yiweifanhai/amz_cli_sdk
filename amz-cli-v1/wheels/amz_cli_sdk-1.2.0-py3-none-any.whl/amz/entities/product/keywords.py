"""Product 的流量关键词及与商品有关的关键词任务。

读取 ASIN 反查词、筛选主力词，并建立关联 Keyword 和主词引用。
相关性、Listing 关键词缺口和流量维度任务先读取当前商品及所需市场事实，
再调用 Analysis 或 Calc。反查词和主词可写回字段，任务结果单独返回。
这里按商品组织调用；Keyword 自身的指标、趋势和聚类由 keyword/ 负责。"""

from __future__ import annotations
from typing import Annotated, Any, TYPE_CHECKING
from pydantic import Field
from amz.entities._core import operations
from amz.entities.product.facts import _missing, _positive
from amz.envelope import Code, Result, err, ok
from amz.schemas.entity_ref import EntityRef, keyword_ref

if TYPE_CHECKING:
    from amz.entities.market import Market
    from amz.entities.product.draft import ProductDraft
    from amz.entities.product.entity import Product


def get_reverse_keywords(product: Product) -> Result:
    """通过 ASIN 反查该商品的流量关键词列表（流量占比/自然占比/PPC 等）"""
    if product.marketplace != "US":
        return err(Code.ERROR_PARAM, "upstream product data currently supports marketplace US only")
    from amz.data.keyword import keyword_reverse
    result = keyword_reverse(product.asin)
    if result.code == Code.OK:
        product._writeback("reverse_keywords", (result.data or {}).get("items", []))
    return result


def get_primary_keywords(product: Product) -> Result:
    """筛选主力流量词（从 reverse_keywords 中按规则提取 3-8 个）。

    委托 calc.keyword.primary；Calc 只接收标准化词条，不读取 Product。
    """
    # 确保 reverse_keywords 已填充
    if not product._check_field("reverse_keywords"):
        result = product.get_reverse_keywords()
        if result.code != Code.OK:
            return err(Code.ERROR_UPSTREAM, "failed to fetch reverse keywords", hint=result.message)

    if not product.reverse_keywords:
        return err(Code.ERROR_UPSTREAM, "reverse_keywords is empty")

    from amz.calc.product.primary_keywords import extract_primary_keywords

    data = extract_primary_keywords([
        item.model_dump(mode="python") for item in product.reverse_keywords
    ])

    product._writeback("primary_keywords", data["primary_keywords"])

    return ok(data={
        "asin": product.asin,
        "primary_keywords": data["primary_keywords"],
        "analysis": data["analysis"],
    })


def get_primary_keyword_ref(
    product: Product, marketplace: str | None = None, category: str = "",
) -> Result:
    """Use the first primary keyword as the sole source of the market relation."""
    candidates = product.primary_keywords or []
    if not candidates or not candidates[0].term.strip():
        return err(
            Code.ERROR_MISSING_FIELDS,
            "a primary keyword is required to choose the Product market",
            missing=["primary_keywords"],
        )
    ref = keyword_ref(marketplace or product.marketplace, category, candidates[0].term)
    product._writeback("primary_keyword_ref", ref)
    return ok(data=ref)


def get_related_keywords(product: Product) -> Result:
    """获取关联关键词列表（从 reverse_keywords 构造 Keyword 实体列表）。

    需要先填充 reverse_keywords（自动级联触发）。
    返回轻量 Keyword 实例，只含 core 字段。
    """
    from amz.entities.keyword import Keyword
    if not product._check_field("reverse_keywords"):
        result = product.get_reverse_keywords()
        if result.code != Code.OK:
            return err(Code.ERROR_UPSTREAM, "failed to fetch reverse keywords", hint=result.message)

    from amz.entities.keyword import Keyword
    keywords: list[Keyword] = []
    for item in (product.reverse_keywords or []):
        kw = Keyword.from_reverse(item.model_dump(mode="python"), marketplace=product.marketplace)
        if kw is not None:
            keywords.append(kw)

    return ok(data={"keywords": keywords, "count": len(keywords)})


def keyword_relevance(product: Product | ProductDraft, keywords: list[str], batch_size: int = 20, max_retries: int = 2) -> Result:
    """Judge explicit keywords against this Product's prepared facts."""
    if not keywords:
        return _missing("keywords")
    failure = product._ensure_analysis_facts()
    if failure is not None:
        return failure
    return operations.run_analysis("analysis.keyword.relevance", {
        "product_info": product.to_product_info(), "keywords": keywords,
        "batch_size": batch_size, "max_retries": max_retries,
    })


def keyword_gap(product: Product | ProductDraft, keywords: list[dict[str, Any]]) -> Result:
    """Check keyword coverage in this Product's current Listing."""
    if not keywords:
        return _missing("keywords")
    failure = product._ensure_analysis_facts(listing=True)
    if failure is not None:
        return failure
    return operations.run_calc("calc.keyword.gap", {"keywords": keywords, "listing_text": product._listing_data()})


def calculate_traffic_dimensions(product: Product, market_ref: EntityRef, pages: Annotated[int, Field(ge=1, le=3)] | None = None) -> Result:
    """Assign price, rating and seller bands using Product facts and a Market sample."""
    from amz.entities._core.store import entity_store

    if market_ref.entity_type != "market" or market_ref.identity["marketplace"] != product.marketplace:
        return err(Code.ERROR_PARAM, "market_ref must identify a Market in the Product marketplace")
    failure = product._calc_core()
    if failure is not None:
        return failure
    if not _positive(product.price_usd):
        return _missing("price_usd")
    market = entity_store.get_or_create(market_ref)
    result = market.get_stats(pages=pages)
    if result.code != Code.OK:
        return result
    bands = market.stats.model_dump(mode="python")["price"].get("bands") or []
    if not bands:
        return _missing("market.stats.price.bands")
    return operations.run_calc("calc.traffic.code-dimensions", {
        "product": {"price_usd": product.price_usd, "rating": product.rating, "seller_nation": product.seller_nation},
        "price_bands": bands,
    })
