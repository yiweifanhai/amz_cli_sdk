"""没有 ASIN 的新品概念和用户商品草稿。

DraftFacts 校验用户提供的标题、卖点、图片等事实；ProductDraft 以 draft_id
保存这些资料，不伪造 ASIN，也不自动查询已上架商品。
类中明确声明可用的 Listing、分类、关键词等任务方法，部分实现与 Product 共用。
内部函数仍接收当前草稿实例；生成的 Listing 结果不会覆盖用户原始事实。"""

from __future__ import annotations
from typing import Any, ClassVar, Literal
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from amz.entities._core import operations
from amz.entities._core.base import Entity
from amz.entities._core.operations import entity_operation
from amz.entities.product import (
    attributes as attributes_methods,
    cosmo as cosmo_methods,
    facts as facts_methods,
    keywords as keywords_methods,
    listing as listing_methods,
)
from amz.envelope import Code, Result, err, ok
from amz.schemas.cosmo import CosmoClassifyOutput
from amz.schemas.entity_ref import EntityRef, normalize_marketplace
from amz.schemas.innovation import ComparativeInnovationOutput
from amz.schemas.keyword_analysis import KeywordGapOutput, RelevanceOutput
from amz.schemas.listing import (
    AllocationOutput,
    ListingOutput,
    MicroInsertOutput,
    PartRewriteOutput,
)
from amz.schemas.traffic import AsinClassificationOutput


class DraftFacts(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)
    marketplace: str = "US"
    title: str = ""
    bullet_points: list[str] = Field(default_factory=list)
    description: str = ""
    brand: str = ""
    images: list[str] = Field(default_factory=list)
    price_usd: float | None = Field(default=None, gt=0)
    source: Literal["user"] = "user"

    @field_validator("marketplace")
    @classmethod
    def normalized_marketplace(cls, value):
        return normalize_marketplace(value)

    @model_validator(mode="after")
    def require_facts(self):
        if not self.title.strip() and not any(text.strip() for text in self.bullet_points):
            raise ValueError("provide a product title or factual bullet points")
        return self


class ProductDraft(Entity):
    """A locally named concept or Listing draft; no automatic marketplace lookup."""
    entity_type: ClassVar[str] = "product_draft"
    identity_fields: ClassVar[tuple[str, ...]] = ("draft_id",)
    draft_id: str = Field(min_length=1, max_length=80, pattern=r"^[A-Za-z0-9][A-Za-z0-9_-]*$")
    facts: DraftFacts | None = None

    def __setattr__(self, name, value):
        if name == "draft_id" and self.__dict__.get(name, value) != value:
            raise ValueError("draft_id cannot change after creation")
        super().__setattr__(name, value)

    @property
    def marketplace(self):
        return self.facts.marketplace if self.facts else "US"

    @property
    def asin(self):
        return ""

    @property
    def title(self):
        return self.facts.title if self.facts else ""

    @property
    def bullet_points(self):
        return self.facts.bullet_points if self.facts else []

    @property
    def description(self):
        return self.facts.description if self.facts else ""

    @property
    def brand(self):
        return self.facts.brand if self.facts else ""

    @property
    def price_usd(self):
        return self.facts.price_usd if self.facts else None

    @entity_operation("set_facts", output_model=DraftFacts)
    def set_facts(self, facts: DraftFacts) -> Result:
        """Save explicitly supplied draft facts under a local draft_id."""
        self.facts = facts
        self.save()
        return ok(facts.model_dump(mode="json"))

    def _ensure_analysis_facts(self, *, listing: bool = False) -> Result | None:
        if self.facts is None:
            return err(Code.ERROR_MISSING_FIELDS, "set draft facts before analysis", missing=["facts"])
        return self._check_analysis_facts(listing=listing)

    def _project_image_url(self):
        return self.facts.images[0] if self.facts and self.facts.images else ""

    def to_product_info(self):
        data = self.facts.model_dump(mode="python") if self.facts else {}
        return {**data, "draft_id": self.draft_id, "image_url": self._project_image_url()}

    @entity_operation("compare", analysis_ids=("analysis.innovation.compare",), output_model=ComparativeInnovationOutput)
    def compare(self, benchmark_refs: list[EntityRef]) -> Result:
        """Compare a user supplied concept with three to five real Products."""
        from amz.entities._core.store import entity_store

        if not 3 <= len(benchmark_refs) <= 5 or len(set(benchmark_refs)) != len(benchmark_refs):
            return err(Code.ERROR_PARAM, "benchmark_refs must contain 3-5 distinct Product references")
        failure = self._ensure_analysis_facts(listing=True)
        if failure is not None:
            return failure
        if any(ref.entity_type != "product" or ref.identity["marketplace"] != self.marketplace for ref in benchmark_refs):
            return err(Code.ERROR_PARAM, "benchmarks must be Products in the draft marketplace")
        benchmarks = []
        for ref in benchmark_refs:
            product = entity_store.get_or_create(ref)
            failure = product._ensure_analysis_facts()
            if failure is not None:
                return failure
            benchmarks.append(product.to_product_info())
        return operations.run_analysis("analysis.innovation.compare", {
            "new_product": self.to_product_info(), "benchmarks": benchmarks,
        })


    def _check_analysis_facts(self, *, listing: bool = False) -> Result | None:
        return facts_methods._check_analysis_facts(self, listing=listing)

    @entity_operation("listing_diff", calc_ids=("calc.listing.word-diff",))
    def listing_diff(self, new_text: str, part: Literal["title", "bp1", "bp2", "bp3", "bp4", "bp5", "description"] = "title") -> Result:
        """Compare proposed text with this Product or ProductDraft's saved Listing part."""
        return listing_methods.listing_diff(self, new_text=new_text, part=part)

    def _listing_data(self) -> dict[str, Any]:
        return listing_methods._listing_data(self)

    def _listing_policy(self, forbidden_terms: list[str] | None, media_title_limit: int | None) -> dict[str, Any]:
        return listing_methods._listing_policy(
            self,
            forbidden_terms=forbidden_terms,
            media_title_limit=media_title_limit,
        )

    @entity_operation("listing_rewrite", analysis_ids=("analysis.listing.rewrite",), output_model=ListingOutput)
    def listing_rewrite(
        self, keywords: dict[str, list[str]] | None = None, feedback: str = "",
        forbidden_terms: list[str] | None = None, media_title_limit: int | None = None,
        title_differentiation: str = "",
    ) -> Result:
        """Rewrite this Product's current title and bullets; return a separate draft."""
        return listing_methods.listing_rewrite(
            self,
            keywords=keywords,
            feedback=feedback,
            forbidden_terms=forbidden_terms,
            media_title_limit=media_title_limit,
            title_differentiation=title_differentiation,
        )

    @entity_operation("listing_micro_insert", analysis_ids=("analysis.listing.micro-insert",), output_model=MicroInsertOutput)
    def listing_micro_insert(
        self, insert_plan: dict[str, list[str]], feedback: str = "",
        forbidden_terms: list[str] | None = None, media_title_limit: int | None = None,
        title_differentiation: str = "",
    ) -> Result:
        """Insert planned keywords into this Product's current Listing."""
        return listing_methods.listing_micro_insert(
            self,
            insert_plan=insert_plan,
            feedback=feedback,
            forbidden_terms=forbidden_terms,
            media_title_limit=media_title_limit,
            title_differentiation=title_differentiation,
        )

    @entity_operation("listing_part_rewrite", analysis_ids=("analysis.listing.part-rewrite",), output_model=PartRewriteOutput)
    def listing_part_rewrite(
        self, part: str, keywords: list[dict[str, Any]], existing_keywords: list[str] | None = None,
        forbidden_terms: list[str] | None = None, media_title_limit: int | None = None,
        title_differentiation: str = "", draft_title: str | None = None,
    ) -> Result:
        """Rewrite one existing title or bullet; its text is read from this Product."""
        return listing_methods.listing_part_rewrite(
            self,
            part=part,
            keywords=keywords,
            existing_keywords=existing_keywords,
            forbidden_terms=forbidden_terms,
            media_title_limit=media_title_limit,
            title_differentiation=title_differentiation,
            draft_title=draft_title,
        )

    @entity_operation("listing_allocate", analysis_ids=("analysis.listing.allocate",), output_model=AllocationOutput)
    def listing_allocate(self, missing_keywords: list[str], use_llm: bool = True) -> Result:
        """Allocate supplied candidates using this Product's current Listing."""
        return listing_methods.listing_allocate(self, missing_keywords=missing_keywords, use_llm=use_llm)

    @entity_operation("classify", analysis_ids=("analysis.asin.classify",), output_model=AsinClassificationOutput)
    def classify(self, dimensions: list[dict[str, Any]]) -> Result:
        """Apply explicit decision dimensions to this Product's prepared facts."""
        return attributes_methods.classify(self, dimensions=dimensions)

    @entity_operation("keyword_relevance", analysis_ids=("analysis.keyword.relevance",), output_model=RelevanceOutput)
    def keyword_relevance(self, keywords: list[str], batch_size: int = 20, max_retries: int = 2) -> Result:
        """Judge explicit keywords against this Product's prepared facts."""
        return keywords_methods.keyword_relevance(
            self,
            keywords=keywords,
            batch_size=batch_size,
            max_retries=max_retries,
        )

    @entity_operation("keyword_gap", analysis_ids=("analysis.keyword.gap",), calc_ids=("calc.keyword.gap",), output_model=KeywordGapOutput)
    def keyword_gap(self, keywords: list[dict[str, Any]]) -> Result:
        """Check keyword coverage in this Product's current Listing."""
        return keywords_methods.keyword_gap(self, keywords=keywords)

    @entity_operation("cosmo_classify", analysis_ids=("analysis.cosmo.classify",), output_model=CosmoClassifyOutput)
    def cosmo_classify(
        self, market_ref: EntityRef, pages: int | None = None, min_success: int = 1, batch_size: int = 50,
    ) -> Result:
        """Rank a Market's prepared COSMO groups for this target Product."""
        return cosmo_methods.cosmo_classify(
            self,
            market_ref=market_ref,
            pages=pages,
            min_success=min_success,
            batch_size=batch_size,
        )
