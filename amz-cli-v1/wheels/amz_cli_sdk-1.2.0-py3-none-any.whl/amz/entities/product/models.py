"""Product 使用的数据结构和参数约束。

定义商品详情 ProductDetails、评估结果 Assessment、供应商 Supplier，
以及正数、比例、物流方式等参数类型，供实体方法和内部实现共用。
这些模型描述输入或结果的形状，不负责取数、分析或实体生命周期。"""

from __future__ import annotations
from typing import Annotated, Any, Literal
from pydantic import BaseModel, Field


class ProductDetails(BaseModel):
    """``entity.product.product_details`` 的稳定输出快照。"""

    title: str = Field(default="", description="本次详情快照对应的商品标题")
    bullet_points: list[str] = Field(default_factory=list)
    description: str | None = None
    images: list[str] = Field(default_factory=list)
    variations: list[dict[str, Any]] = Field(default_factory=list)
    categories: list[str] = Field(default_factory=list)
    product_details_raw: list[dict[str, Any]] = Field(default_factory=list)
    review_insights: dict[str, Any] | None = None
    about_product: list[dict[str, Any]] = Field(default_factory=list)
    manufacturer: str | None = None
    categories_extended: list[dict[str, Any]] = Field(default_factory=list)
    aplus_images: list[str] = Field(default_factory=list)
    bsr: dict[str, Any] | None = None
    brand: str | None = None


NonNegative = Annotated[float, Field(ge=0)]


Positive = Annotated[float, Field(gt=0)]


PositiveInt = Annotated[int, Field(ge=1, strict=True)]


Ratio = Annotated[float, Field(ge=0, le=1)]


ReferralRate = Annotated[float, Field(ge=0, lt=1)]


ShippingMethod = Literal["slow", "fast", "air", "express"]


class Assessment(BaseModel):
    """单点 LLM 判断结果"""
    kind: str = ""              # 评估类型（risk/innovation/timing/demand）
    score: float = 0.0          # 0-10 或 0-100
    stop: bool = False          # 是否为硬阻
    verdict: str = ""           # GO/CAUTION/STOP
    dimensions: dict = Field(default_factory=dict)
    data: dict = Field(default_factory=dict)


class Supplier(BaseModel):
    """1688 供应商"""
    title: str = ""
    price: str = ""
    sales: int | str = 0
    similarity: float = 0.0
    image_url: str = ""
    url: str = ""
