"""Product 的创新可复制性评估与基准商品比较。

可复制性评估读取当前商品详情，写回 copyability，并提供 innovation 兼容结果。
比较任务通过 Product 引用读取 3–5 个不同且同站点的基准商品，
检查事实后交给 Analysis，返回独立的比较结果。
这些实现由 Product 方法调用，商品资料和缓存仍属于原实例。"""

from __future__ import annotations
from typing import TYPE_CHECKING
from pydantic import ValidationError
from amz.entities._core import operations
from amz.envelope import Code, Result, err, ok
from amz.schemas.entity_ref import EntityRef

if TYPE_CHECKING:
    from amz.entities.product.draft import ProductDraft
    from amz.entities.product.entity import Product


def get_copyability(product: Product, innovation_desc: str = "") -> Result:
    """创新可复制性评估，结果写回 self.copyability。

    依赖 product_details（depends 声明自动级联填充标题/图片/描述）；
    reviews 已填充时一并传入作为差评痛点来源，获取失败不阻断主分析。
    委托 analysis.product.copyability.assess_copyability()，支持 TTL 缓存。

    Args:
        innovation_desc: 用户认为的产品的创新点（可选）
    """
    # reviews 由 optional_depends 尽力补齐；失败不阻断主分析。
    reviews_info = None
    if product.reviews and product.reviews.items:
        reviews_info = [it.model_dump() for it in product.reviews.items]

    image_url = product.images[0] if product.images else ""
    description = product.description or ""
    if not description and product.bullet_points:
        description = "\n".join(product.bullet_points)

    from amz.analysis.product.copyability import assess_copyability
    result = assess_copyability(
        asin=product.asin,
        title=product.title or description or "",
        image_url=image_url,
        description=description,
        reviews=reviews_info,
        innovation_desc=innovation_desc,
    )
    if result.code == Code.OK:
        product._writeback("copyability", result.data)
    return result


def assess_innovation(product: Product, innovation_desc: str = "") -> Result:
    """Compatibility projection of the canonical copyability result."""
    product._writeback("innovation", product.copyability)
    return ok(data=product.innovation)


def compare(product: Product | ProductDraft, benchmark_refs: list[EntityRef]) -> Result:
    """Compare current product facts with three to five real benchmark Products."""
    from amz.entities._core.store import entity_store

    try:
        refs = [EntityRef.model_validate(ref) for ref in benchmark_refs]
    except (ValidationError, TypeError) as exc:
        return err(Code.ERROR_PARAM, str(exc))
    if not 3 <= len(refs) <= 5 or len(set(refs)) != len(refs):
        return err(Code.ERROR_PARAM, "benchmark_refs must contain 3-5 distinct Product references")
    if any(ref.entity_type != "product" or ref.identity["marketplace"] != product.marketplace or ref == product.ref for ref in refs):
        return err(Code.ERROR_PARAM, "benchmarks must be other Products in the same marketplace")
    failure = product._ensure_analysis_facts()
    if failure is not None:
        return failure
    benchmarks = []
    for ref in refs:
        benchmark = entity_store.get_or_create(ref)
        failure = benchmark._ensure_analysis_facts()
        if failure is not None:
            return failure
        benchmarks.append(benchmark.to_product_info())
    return operations.run_analysis("analysis.innovation.compare", {"new_product": product.to_product_info(), "benchmarks": benchmarks})
