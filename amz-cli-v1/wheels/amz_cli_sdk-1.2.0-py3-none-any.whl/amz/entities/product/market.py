"""Product 与竞品及所属 Market 的关系。

获取竞品并保存 Product 引用，依据主力关键词建立 Market 关系，
再提供读取市场统计、画像和机会评分的便捷方法。
市场数据的获取与分析由 Market 完成；本文件只连接当前商品与相关实体，
持久关系使用 EntityRef，关联对象及结果作为当前实例上的临时访问视图。"""

from __future__ import annotations
from typing import TYPE_CHECKING
from amz.envelope import Code, Result, err, ok

if TYPE_CHECKING:
    from amz.entities.market import Market
    from amz.entities.product.entity import Product


def get_competitors(product: Product, pages: int = 1) -> Result:
    """获取竞品列表，转为 Product 实例列表。

    每个竞品从 normalized dict 转为轻量 Product 实例（core 字段已填充，
    lazy 字段可按需触发）。转换失败的单条跳过。
    """
    from amz.entities.product import Product
    if product.marketplace != "US":
        return err(Code.ERROR_PARAM, "upstream product data currently supports marketplace US only")
    from amz.data.market import market_competitors
    result = market_competitors(asin=product.asin, pages=pages)
    if result.code == Code.OK:
        raw_items = (result.data or {}).get("items", [])
        products: list[Product] = []
        for item in raw_items:
            p = Product.from_competitor(item, marketplace=product.marketplace)
            if p is not None:
                products.append(p)
        product._writeback("competitors", [p.ref for p in products])
    return result


def get_market(product: Product, marketplace: str | None = None, category: str = "") -> Result:
    """获取市场聚合视图（使用主力关键词），结果写回 self.market。

    委托 Market 实体处理数据获取和聚合计算，本方法只负责选取关键词。
    返回的 self.market 是 Market 实体，可链式调用 get_stats/get_profile/get_opportunity。
    """
    from amz.entities.market import Market
    if product.primary_keyword_ref is None:
        return err(Code.ERROR_MISSING_FIELDS, "primary_keyword_ref was not populated", missing=["primary_keyword_ref"])
    if product.primary_keyword_ref.entity_type != "keyword":
        return err(Code.ERROR_PARAM, "primary_keyword_ref must reference a Keyword")
    identity = product.primary_keyword_ref.identity
    keyword = identity["term"]
    from amz.entities.market import Market
    market = Market.fetch(
        keyword,
        marketplace=identity["marketplace"],
        category=identity["category"],
    )
    if market is None:
        return err(Code.ERROR_UPSTREAM, f"failed to create Market for {keyword}")

    product.market_ref = market.ref
    product._writeback("market", market)
    return ok(data={"market": market, "keyword": keyword})


def get_market_stats(
    product: Product,
    marketplace: str | None = None,
    category: str = "",
) -> Result:
    """从 Product 直接获取 Market Stats；缺少 market 时自动级联创建。"""
    if product.market is None:
        return err(Code.ERROR_SERVER_INTERNAL, "market dependency was not populated")
    result = product.market.get_stats()
    if result.code == Code.OK and product.market.stats is not None:
        product._writeback("market_stats", product.market.stats)
    return result


def get_market_profile(
    product: Product,
    marketplace: str | None = None,
    category: str = "",
) -> Result:
    """从 Product 直接获取 Market Profile；自动级联 Market 与 Stats。"""
    if product.market is None:
        return err(Code.ERROR_SERVER_INTERNAL, "market dependency was not populated")
    result = product.market.get_profile()
    if result.code == Code.OK and product.market.profile is not None:
        product._writeback("market_profile", product.market.profile)
    return result


def get_market_opportunity(
    product: Product,
    marketplace: str | None = None,
    category: str = "",
) -> Result:
    """从 Product 直接获取 Market Opportunity；自动级联 Market 与 Stats。"""
    if product.market is None:
        return err(Code.ERROR_SERVER_INTERNAL, "market dependency was not populated")
    result = product.market.get_opportunity()
    if result.code == Code.OK and product.market.opportunity is not None:
        product._writeback("market_opportunity", product.market.opportunity)
    return result
