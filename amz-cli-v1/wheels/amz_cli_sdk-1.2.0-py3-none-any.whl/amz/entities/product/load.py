"""Product 的创建、缓存恢复和已有竞品数据导入。

由 Product.fetch() 和 Product.from_competitor() 类方法调用。
fetch 按商品身份读取缓存，必要时从 Data 获取基础资料；from_competitor
将已有竞品行合并到对应的本地 Product，不为此额外取数。
详情、评论等数据仍通过 Product 的按需加载方法获取。"""

from __future__ import annotations
from typing import Any, TYPE_CHECKING
from amz.envelope import Code
from amz.schemas.entity_ref import product_ref

if TYPE_CHECKING:
    from amz.entities.product.entity import Product


def fetch(cls: type[Product], asin: str, force_refresh: bool = False, marketplace: str = "US") -> Product | None:
    """从 competing-lookup 获取 Product core 字段（快速）。

    competing-lookup 返回完整商业字段：价格/评分/销量/重量/尺寸/FBA费/上架日期等。
    product-info 的富文本字段（bullet_points/description/images/变体详情）通过
    lazy 字段按需拉取。
    """
    ref = product_ref(marketplace, asin)
    marketplace, asin = ref.key
    cache_id = ref.cache_id
    cached = cls.load(cache_id)
    if cached is not None and not force_refresh:
        # Locally supplied facts remain usable without fetching unrelated core data.
        # A previously fetched seller core must satisfy the current cache contract.
        if "core" not in cached._fetched_at or cached._check_field("core", cached._default_field_cache_key("core")):
            return cached

    if marketplace != "US":
        return None
    from amz.data.market import market_competitors
    from amz.data.normalizer import normalize_competing_item

    result = market_competitors(asin=asin, pages=1)
    if result.code != Code.OK or not result.data:
        return None
    items = result.data.get("items", [])
    if not items:
        return None

    first = normalize_competing_item(items[0])

    # BSR: 用 bsrRank 构造 dict
    bsr_obj = None
    bsr_rank = first.get("bsr_rank")
    if bsr_rank is not None:
        bsr_obj = {
            "rank": int(bsr_rank),
            "category": first.get("category_name", ""),
        }

    # images: competing 只有单张主图，后续 product_details 会补全
    image_url = first.get("image_url")
    images = [image_url] if image_url else []

    # categories: competing 只有单个 categoryName，后续 product_details 补全树
    cat_name = first.get("category_name")
    categories = [cat_name] if cat_name else []

    values = dict(
        marketplace=marketplace,
        asin=first.get("asin", asin),
        title=first.get("title"),
        brand=first.get("brand"),
        price_usd=first.get("price_usd"),
        rating=first.get("rating"),
        count_review=first.get("count_review"),
        monthly_sales=first.get("monthly_sales"),
        seller_nation=first.get("seller_nation"),
        listing_date=first.get("available_date"),
        available_date=first.get("available_date"),
        weight_g=first.get("weight_g"),
        dimensions_cm=first.get("dimensions_cm"),
        fba_fee=first.get("fba_fee"),
        bsr=bsr_obj,
        images=images,
        categories=categories,
    )
    if cached is None:
        instance = cls(**values)
    else:
        instance = cached
        for field, value in values.items():
            if getattr(instance, field) != value:
                setattr(instance, field, value)
                instance._invalidate_dependents(field)
    instance._cache_id = cache_id
    instance._mark_fetched("core")
    instance.save()
    return instance


def from_competitor(cls: type[Product], data: dict[str, Any], *, marketplace: str = "US") -> Product | None:
    """Merge an available competitor row into its local Product, without fetching."""
    from amz.data.normalizer import normalize_competing_item
    item = normalize_competing_item(data)
    asin = item.get("asin", "").strip().upper()
    if not asin:
        return None
    ref = product_ref(marketplace, asin)
    marketplace, asin = ref.key
    instance = cls.load(ref.cache_id)
    if instance is None:
        instance = cls(asin=asin, marketplace=marketplace)
    changed = False
    direct = (
        "title", "brand", "price_usd", "rating", "count_review", "monthly_sales",
        "seller_nation", "available_date", "weight_g", "dimensions_cm", "fba_fee",
    )
    values = {name: item[name] for name in direct if item.get(name) is not None}
    if item.get("available_date") or item.get("listing_date"):
        values["listing_date"] = item.get("listing_date") or item["available_date"]
    if item.get("bsr") is not None:
        values["bsr"] = item["bsr"]
    elif item.get("bsr_rank") is not None:
        values["bsr"] = {"rank": item["bsr_rank"], "category": item.get("category_name", "")}
    if not instance.images and item.get("image_url"):
        values["images"] = [item["image_url"]]
    if not instance.categories:
        values["categories"] = item.get("categories") or ([item["category_name"]] if item.get("category_name") else [])
    for name, value in values.items():
        if getattr(instance, name) != value:
            setattr(instance, name, value)
            instance._invalidate_dependents(name)
            changed = True
    extras = {name: value for name, value in item.items() if name not in cls.model_fields}
    instance.competing_extra.update(extras)
    if changed:
        instance._invalidate_dependents("core")
    instance._mark_fetched("core")
    instance.save()
    return instance
