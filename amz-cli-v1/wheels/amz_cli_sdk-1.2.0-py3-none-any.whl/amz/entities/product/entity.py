"""Product 的身份、字段、依赖规则和公开方法。

使用 marketplace + asin 标识一个 Amazon 商品，统一声明字段缓存和任务入口。
公开方法保留完整参数与装饰器，较长实现交给同目录的 listing、finance、voc
等模块；这些函数接收当前 Product 实例，不另建一份商品状态。
对外直接调用 product.listing_rewrite() 等方法，无需实例化内部模块。"""

from __future__ import annotations
from datetime import date, datetime
from typing import Annotated, Any, ClassVar, Literal, TYPE_CHECKING, cast
from pydantic import Field
from amz.entities._core.base import EnrichSpec, Entity, lazy_field
from amz.entities._core.operations import entity_operation
from amz.entities.product import (
    attributes as attributes_methods,
    compare as compare_methods,
    cosmo as cosmo_methods,
    details as details_methods,
    facts as facts_methods,
    finance as finance_methods,
    keywords as keywords_methods,
    listing as listing_methods,
    load as load_methods,
    market as market_methods,
    reviews as reviews_methods,
    voc as voc_methods,
)
from amz.entities.product.models import (
    NonNegative,
    Positive,
    PositiveInt,
    ProductDetails,
    Ratio,
    ReferralRate,
    ShippingMethod,
)
from amz.entities.product.reviews import ReviewItem
from amz.envelope import Code, Result, err, ok
from amz.schemas.cosmo import CosmoClassifyOutput, ProductCosmo
from amz.schemas.data_outputs import KeywordReverseItemOutput, PrimaryKeywordItemOutput
from amz.schemas.entity_ref import EntityRef
from amz.schemas.innovation import ComparativeInnovationOutput
from amz.schemas.keyword_analysis import KeywordGapOutput, RelevanceOutput
from amz.schemas.listing import (
    AllocationOutput,
    ListingOutput,
    MicroInsertOutput,
    PartRewriteOutput,
)
from amz.schemas.traffic import AsinClassificationOutput
from amz.schemas.voc import (
    ProductVoc,
    ProductVocListing,
    UnmetNeed,
    VocStrengthsOutput,
    VocUseInsightsOutput,
    VocWeaknessesOutput,
)

if TYPE_CHECKING:
    from amz.entities.market import Market, MarketProfile, MarketStats, Opportunity
    from amz.entities.product.finance import FinanceData
    from amz.entities.product.reviews import ReviewData


class Product(Entity):
    """
    Product 实体 — Amazon ASIN 的完整数据聚合。

    字段分两类：
    - core: fetch() 时从 competing-lookup 填充，不设 TTL
    - lazy: 调用对应的 get_xxx() 方法时填充，逐字段 TTL
    """

    entity_type: ClassVar[str] = "product"
    identity_fields: ClassVar[tuple[str, ...]] = ("marketplace", "asin",)

    # Lazy 字段声明
    lazy_fields: ClassVar[dict[str, EnrichSpec]] = {
        "core": EnrichSpec(
            field="core", method="refresh_core",
            depends=[], source="/competing-lookup", ttl_hours=24,
        ),
        "product_details": EnrichSpec(
            field="product_details", method="get_product_details",
            depends=[], source="/product-info", ttl_hours=24, version="2",
        ),
        "reviews": EnrichSpec(
            field="reviews", method="get_reviews",
            depends=[], source="/amazon/reviews", ttl_hours=48, version="3",
        ),
        "reverse_keywords": EnrichSpec(
            field="reverse_keywords", method="get_reverse_keywords",
            depends=[], source="/keyword-reverse", ttl_hours=48,
        ),
        "competitors": EnrichSpec(
            field="competitors", method="get_competitors",
            depends=[], source="/competing-lookup", ttl_hours=24,
        ),
        "rufus_qa": EnrichSpec(
            field="rufus_qa", method="get_rufus",
            depends=[], source="/rufus", ttl_hours=24,
        ),
        "finance": EnrichSpec(
            field="finance", method="get_finance",
            depends=["core"],
            source="data.fx.rate + calc.fba.margin + calc.finance.return-on-capital", ttl_hours=1,
            version="4",
            invalidates_on=["primary_keywords"],
        ),
        "primary_keywords": EnrichSpec(
            field="primary_keywords", method="get_primary_keywords",
            depends=["reverse_keywords"], source="calc.keyword.primary", ttl_hours=48,
            version="2",
        ),
        "primary_keyword_ref": EnrichSpec(
            field="primary_keyword_ref", method="get_primary_keyword_ref",
            depends=[], optional_depends=["primary_keywords"],
            source="aggregate", ttl_hours=48,
        ),
        "market": EnrichSpec(
            field="market", method="get_market",
            depends=["primary_keyword_ref"], source="aggregate", ttl_hours=48,
            dependency_params={"primary_keyword_ref": ["marketplace", "category"]},
        ),
        "market_stats": EnrichSpec(
            field="market_stats", method="get_market_stats",
            depends=["market"], source="entity.market.stats", ttl_hours=24,
            dependency_params={"market": ["marketplace", "category"]},
        ),
        "market_profile": EnrichSpec(
            field="market_profile", method="get_market_profile",
            depends=["market_stats"], source="entity.market.profile", ttl_hours=24,
            dependency_params={"market_stats": ["marketplace", "category"]},
        ),
        "market_opportunity": EnrichSpec(
            field="market_opportunity", method="get_market_opportunity",
            depends=["market_stats"], source="entity.market.opportunity", ttl_hours=24,
            dependency_params={"market_stats": ["marketplace", "category"]},
        ),
        "copyability": EnrichSpec(
            field="copyability", method="get_copyability",
            depends=["product_details"], optional_depends=["reviews"],
            invalidates_on=["core", "title", "images"],
            source="analysis.innovation.copyability", ttl_hours=168, version="2",
        ),
        "innovation": EnrichSpec(
            field="innovation", method="assess_innovation",
            depends=["copyability"], source="analysis.innovation.copyability", ttl_hours=168,
            dependency_params={"copyability": ["innovation_desc"]},
        ),
        "cosmo": EnrichSpec(
            field="cosmo", method="get_cosmo", depends=["product_details"],
            invalidates_on=["core", "title", "images", "aplus_images"],
            source="analysis.cosmo.extract", ttl_hours=168, version="4",
        ),
        "material": EnrichSpec(
            field="material", method="get_material", depends=["product_details"],
            invalidates_on=["core", "title", "images"],
            source="analysis.material.assess", ttl_hours=168, version="2",
        ),
        "unmet_needs": EnrichSpec(
            field="unmet_needs", method="get_unmet_needs", depends=["weaknesses"],
            source="entity.product.weaknesses", ttl_hours=48,
        ),
        "praise": EnrichSpec(
            field="praise", method="get_praise",
            depends=["reviews", "product_details"], source="analysis.voc.praise", ttl_hours=48, version="2",
        ),
        "wishlist": EnrichSpec(
            field="wishlist", method="get_wishlist",
            depends=["reviews", "product_details"], source="analysis.voc.wishlist", ttl_hours=48, version="2",
        ),
        "strengths": EnrichSpec(
            field="strengths", method="get_strengths",
            depends=["product_details"],
            source="analysis.voc.strength-signals", ttl_hours=24, version="2",
        ),
        "weaknesses": EnrichSpec(
            field="weaknesses", method="get_weaknesses",
            depends=["reviews", "product_details"], source="analysis.voc.weakness-signals", ttl_hours=48, version="2",
        ),
        "use_insights": EnrichSpec(
            field="use_insights", method="get_use_insights",
            depends=["reviews", "product_details"],
            source="analysis.voc.use-signals", ttl_hours=48, version="2",
        ),
        "voc": EnrichSpec(
            field="voc", method="get_voc",
            depends=["reviews", "strengths", "weaknesses", "use_insights"],
            source="aggregate", ttl_hours=48, version="2",
        ),
    }

    # -- core 字段（来自 competing-lookup，fetch() 时填充）-------------------------

    marketplace: str = Field(default="US")
    asin: str = Field(min_length=1, json_schema_extra={"alias": "asin"})
    title: str | None = Field(default=None, json_schema_extra={"alias": "title"})
    brand: str | None = Field(default=None, json_schema_extra={"alias": "brand"})
    price_usd: float | None = Field(default=None, json_schema_extra={"alias": "price"})
    rating: float | None = Field(default=None, json_schema_extra={"alias": "rating"})
    count_review: int | None = Field(default=None, json_schema_extra={"alias": "reviews"})
    monthly_sales: int | None = Field(default=None, json_schema_extra={"alias": "totalUnits"})
    seller_nation: str | None = Field(default=None, json_schema_extra={"alias": "sellerNation"})
    listing_date: str | None = Field(default=None, json_schema_extra={"alias": "availableDate"})
    available_date: str | None = Field(default=None, json_schema_extra={"alias": "availableDate"})
    weight_g: float | None = Field(default=None, json_schema_extra={"alias": "pkgWeightTag"})
    dimensions_cm: dict[str, Any] | None = Field(default=None, json_schema_extra={"alias": "pkgDimensionsTag"})
    fba_fee: float | None = Field(default=None, json_schema_extra={"alias": "fbaFee"})
    bsr: dict[str, Any] | None = Field(default=None, json_schema_extra={"alias": "rank"})
    images: list[str] = Field(default_factory=list, json_schema_extra={"alias": "imageUrlList"})
    categories: list[str] = Field(default_factory=list, json_schema_extra={"alias": "categoryPath"})

    # -- lazy 字段（来自 product-info，慢端点按需拉取）-------------------------------

    product_details: ProductDetails | None = None
    bullet_points: list[str] = Field(default_factory=list, json_schema_extra={"alias": "features"})
    description: str | None = Field(default=None, json_schema_extra={"alias": "productDescription"})
    variations: list[dict[str, Any]] = Field(default_factory=list, json_schema_extra={"alias": "variations"})
    product_details_raw: list[dict[str, Any]] = Field(default_factory=list, json_schema_extra={"alias": "productDetails"})
    review_insights: dict[str, Any] | None = Field(default=None, json_schema_extra={"alias": "reviewInsights"})
    categories_extended: list[dict[str, Any]] = Field(default_factory=list, json_schema_extra={"alias": "categoriesExtended"})
    about_product: list[dict[str, Any]] = Field(default_factory=list, json_schema_extra={"alias": "aboutProduct"})
    manufacturer: str | None = Field(default=None, json_schema_extra={"alias": "manufacturer"})
    aplus_images: list[str] = Field(default_factory=list, json_schema_extra={"alias": "aplusImageUrlList"})

    # -- 其他 lazy 字段 -----------------------------------------------------------

    reviews: ReviewData | None = None                       # 类型化的评论集实体
    reverse_keywords: list[KeywordReverseItemOutput] | None = None
    competitor_refs: list[EntityRef] | None = None
    rufus_qa: list[str] | None = None
    primary_keywords: list[PrimaryKeywordItemOutput] | None = None
    finance: FinanceData | None = None                   # 类型化的财务计算结果
    primary_keyword_ref: EntityRef | None = None
    market_ref: EntityRef | None = None
    market: Market | None = Field(default=None, exclude=True)
    market_stats: MarketStats | None = Field(default=None, exclude=True)
    market_profile: MarketProfile | None = Field(default=None, exclude=True)
    market_opportunity: Opportunity | None = Field(default=None, exclude=True)
    innovation: dict[str, Any] | None = Field(default=None, exclude=True)
    copyability: dict[str, Any] | None = None
    material: dict[str, Any] | None = None
    cosmo: ProductCosmo | None = None
    unmet_needs: list[UnmetNeed] | None = Field(default=None, exclude=True)
    competing_extra: dict[str, Any] = Field(default_factory=dict)
    praise: dict[str, Any] | None = None
    wishlist: dict[str, Any] | None = None
    strengths: VocStrengthsOutput | None = None
    weaknesses: VocWeaknessesOutput | None = None
    use_insights: VocUseInsightsOutput | None = None
    voc: ProductVoc | None = None

    def model_post_init(self, __context: Any) -> None:
        """已有详情数据构造的 Product 可直接复用，不会再次隐式 fetch。"""
        super().model_post_init(__context)
        if isinstance(__context, dict) and __context.get("entity_loading"):
            return
        if self.copyability is None and self.innovation is not None:
            legacy_innovation = self.innovation
            self.copyability = legacy_innovation
            self._mark_fetched("copyability")
            self.innovation = legacy_innovation
        detail_fields = {
            "bullet_points", "description", "product_details_raw",
            "about_product", "categories_extended", "aplus_images",
        }
        if self.product_details is None and detail_fields.intersection(self.model_fields_set):
            self.product_details = self._product_details_snapshot()
            self._mark_fetched("product_details")
        if all(
            getattr(self, field) is not None
            for field in ("price_usd", "dimensions_cm", "weight_g")
        ):
            self._mark_fetched("core")

    def _product_details_snapshot(self) -> ProductDetails:
        return ProductDetails(
            title=self.title or "",
            bullet_points=self.bullet_points,
            description=self.description,
            images=self.images,
            variations=self.variations,
            categories=self.categories,
            product_details_raw=self.product_details_raw,
            review_insights=self.review_insights,
            about_product=self.about_product,
            manufacturer=self.manufacturer,
            categories_extended=self.categories_extended,
            aplus_images=self.aplus_images,
            bsr=self.bsr,
            brand=self.brand,
        )

    # ------------------------------------------------------------------
    # 投影方法（composite autowire：实体 → 能力 InputModel 的类型转换）
    # ------------------------------------------------------------------

    def _project_pkg_dims(self) -> tuple[float, float, float] | None:
        """``dimensions_cm`` dict → ``(length, width, height)`` tuple。"""
        dims = self.dimensions_cm or {}
        if not dims:
            return None
        return (
            dims.get("length", 0.0),
            dims.get("width", 0.0),
            dims.get("height", 0.0),
        )

    def _project_image_url(self) -> str:
        """主图 URL（images 首张）。"""
        return self.images[0] if self.images else ""

    def _project_voc_reviews(self) -> list["ReviewItem"] | None:
        """``reviews``（ReviewData）→ 评论项列表。只读，不触发 enrich。"""
        if not self.reviews:
            return None
        return self.reviews.analysis_items()

    def to_product_info(self) -> dict[str, Any]:
        """导出 Analysis 可复用的标准产品 DTO（只读，不触发 fetch）。"""
        from amz.schemas.analysis_inputs import ProductInfoInput

        projected = self.project_to(ProductInfoInput) or {}
        return ProductInfoInput.model_validate(projected).model_dump(mode="python")

    def to_review_items(self) -> list[dict[str, Any]]:
        """导出 Product 评论字段已生成的 VOC 分星抽样 DTO。"""
        if not self.reviews:
            return []
        return [
            item.model_dump(mode="python")
            for item in self.reviews.analysis_items()
        ]

    def to_voc_listing(self) -> dict[str, Any]:
        """导出严格 Product VOC Listing，不触发取数。"""
        listing = ProductVocListing(
            asin=self.asin,
            title=self.title or "",
            bullet_points=self.bullet_points,
            details=self.product_details_raw,
            description=self.description or "",
            brand=self.brand,
            product_rating=self.rating,
            count_ratings=self.count_review,
        )
        return listing.model_dump(mode="python")

    # ------------------------------------------------------------------
    # 工厂方法
    # ------------------------------------------------------------------

    @classmethod
    def _read_cache_payload(cls, path, cache_id: str) -> dict[str, Any] | None:
        payload = super()._read_cache_payload(path, cache_id)
        if payload is None:
            return None
        entries = payload.get("fields", {})
        legacy = entries.get("innovation")
        if legacy and legacy.get("value") is not None and not entries.get("copyability", {}).get("value"):
            entries["copyability"] = {**legacy, "version": cls.lazy_fields["copyability"].version}
        return payload

    def _restore_entries(self, entries: dict[str, Any]) -> None:
        super()._restore_entries(entries)
        # The old Python field is a view of the canonical stored result.
        if self.copyability is not None:
            self.innovation = self.copyability

    @classmethod
    def fetch(cls, asin: str, force_refresh: bool = False, marketplace: str = "US") -> Product | None:
        """从 competing-lookup 获取 Product core 字段（快速）。

        competing-lookup 返回完整商业字段：价格/评分/销量/重量/尺寸/FBA费/上架日期等。
        product-info 的富文本字段（bullet_points/description/images/变体详情）通过
        lazy 字段按需拉取。
        """
        return load_methods.fetch(cls, asin=asin, force_refresh=force_refresh, marketplace=marketplace)

    @classmethod
    def from_competitor(cls, data: dict[str, Any], *, marketplace: str = "US") -> Product | None:
        """Merge an available competitor row into its local Product, without fetching."""
        return load_methods.from_competitor(cls, data=data, marketplace=marketplace)

    def to_competitor(self) -> dict[str, Any]:
        """Project this Product into the legacy lightweight competitor contract."""
        names = (
            "asin", "title", "brand", "price_usd", "rating", "count_review", "monthly_sales",
            "seller_nation", "available_date", "listing_date", "weight_g", "dimensions_cm",
            "fba_fee", "bsr", "categories",
        )
        data = {**self.competing_extra, **{name: getattr(self, name) for name in names}}
        data["title"] = self.title or ""
        data["image_url"] = self.images[0] if self.images else ""
        return data

    @classmethod
    def _from_competitor(cls, data: dict[str, Any]) -> Product | None:
        """兼容旧内部名称；新代码使用 :meth:`from_competitor`。"""
        return cls.from_competitor(data)

    # ------------------------------------------------------------------
    # 实体方法 = 原子能力
    # ------------------------------------------------------------------

    def get(self) -> Result:
        """返回自身"""
        return ok(data=self.model_dump(mode="python"))

    def _core_data(self) -> dict[str, Any]:
        """Project current core facts independently of the virtual cache payload."""
        return self.model_dump(mode="json", include={
            "marketplace", "asin", "title", "brand", "price_usd", "rating",
            "count_review", "monthly_sales", "seller_nation", "listing_date",
            "available_date", "weight_g", "dimensions_cm", "fba_fee", "bsr",
            "images", "categories",
        })

    def _field_result_data(self, field: str, fallback: Any) -> Any:
        if field == "core":
            return self._core_data()
        return super()._field_result_data(field, fallback)

    @lazy_field("core")
    def refresh_core(self) -> Result:
        """刷新 competing-lookup 提供的 Product core 字段。"""
        return details_methods.refresh_core(self)

    @lazy_field("product_details")
    def get_product_details(self) -> Result:
        """从 product-info 拉取富文本字段（五点/描述/全量图片/变体/完整类目树等，慢端点按需）

        填充：bullet_points, description, images (全量), variations,
        categories (完整树), product_details_raw, review_insights,
        about_product, manufacturer, aplus_images。

        注意：11 个字段共享一次 API 调用，因此使用单次 _mark_fetched
        管理 TTL。如果后续要求不同字段有不同缓存时长，需要拆分。
        """
        return details_methods.get_product_details(self)

    @lazy_field("reviews")
    def get_reviews(self, mode: str = "mid", star_filter: str = "all", max_pages: int = 1) -> Result:
        """获取评论集（mode: low/mid/high 每星 20/50/100 条，仅 star_filter="all" 时生效）。

        使用 ReviewData Entity 获取评论，获得 TTL 缓存 + single-flight。
        结果写回 self.reviews（ReviewData 实例），可链式访问 .items / .by_star() / .count。
        """
        return reviews_methods.get_reviews(self, mode=mode, star_filter=star_filter, max_pages=max_pages)

    @lazy_field("reverse_keywords")
    def get_reverse_keywords(self) -> Result:
        """通过 ASIN 反查该商品的流量关键词列表（流量占比/自然占比/PPC 等）"""
        return keywords_methods.get_reverse_keywords(self)

    reference_fields = {"competitors": "competitor_refs"}

    @property
    def competitors(self) -> list[Product] | None:
        """Resolve competitor refs from local state without storing an Entity graph."""
        if self.competitor_refs is None:
            return None
        return [product for ref in self.competitor_refs
                if (product := Product.load(ref.cache_id)) is not None]

    @lazy_field("competitors")
    def get_competitors(self, pages: int = 1) -> Result:
        """获取竞品列表，转为 Product 实例列表。

        每个竞品从 normalized dict 转为轻量 Product 实例（core 字段已填充，
        lazy 字段可按需触发）。转换失败的单条跳过。
        """
        return market_methods.get_competitors(self, pages=pages)

    @lazy_field("rufus_qa")
    def get_rufus(self) -> Result:
        """获取商品的 Rufus AI 问答"""
        return details_methods.get_rufus(self)

    @lazy_field("primary_keywords")
    def get_primary_keywords(self) -> Result:
        """筛选主力流量词（从 reverse_keywords 中按规则提取 3-8 个）。

        委托 calc.keyword.primary；Calc 只接收标准化词条，不读取 Product。
        """
        return keywords_methods.get_primary_keywords(self)

    @lazy_field("finance")
    def get_finance(
        self,
        shipping_method: str = "fast",
        purchase_price: float | None = None,
        cpc: float | None = None,
        cvr: float | None = None,
        product_type: str | None = None,
        fulfillment_date: date | datetime | str | None = None,
        include_fuel_surcharge: bool = True,
        include_ads: bool = False,
        exchange_rate: float | None = None,
    ) -> Result:
        """计算利润（毛利率 M1/M2、采购毛利、FBA 费、资金效率 ROI）。

        从 self 取 price/weight/dims 字段值，委托 entities.finance.build_finance
        整合 calc.fba.margin + calc.finance.return-on-capital 两个纯函数；
        纯计算在 calc 层，整合与回填在 entities 层。
        weight_g 和 dimensions_cm 来自 competing-lookup 的 pkg 数据，
        已在 fetch() 时填充，无需额外请求。

        Args:
            cpc: 单次点击成本（$），用于计算 m2_margin_pct（平台+广告后利润率）
            cvr: 转化率（0-1），用于计算 m2_margin_pct
            product_type: non_apparel/apparel/dangerous_goods（及兼容别名）
            fulfillment_date: FBA 出库日期，用于选择旺季费率和附加费
            include_ads: 是否需要计算广告指标（cpc/cvr/cpa 与 M2 利润率）。
                True 时：显式传入的 cpc/cvr 优先；否则自动从主关键词
                （primary_keywords，未填充时级联拉取 reverse_keywords）取
                流量最大的主关键词的 exactPpc/cvr/cpa。False 时 cpc/cvr/cpa 为 null。
            exchange_rate: 人民币兑美元汇率（人民币/美元），头程单价为 RMB，
                按该汇率折算为 $；省略时自动取最新日参考汇率，非盘中成交价。
        """
        return finance_methods.get_finance(
            self,
            shipping_method=shipping_method,
            purchase_price=purchase_price,
            cpc=cpc,
            cvr=cvr,
            product_type=product_type,
            fulfillment_date=fulfillment_date,
            include_fuel_surcharge=include_fuel_surcharge,
            include_ads=include_ads,
            exchange_rate=exchange_rate,
        )

    @lazy_field("primary_keyword_ref")
    def get_primary_keyword_ref(
        self, marketplace: str | None = None, category: str = "",
    ) -> Result:
        """Use the first primary keyword as the sole source of the market relation."""
        return keywords_methods.get_primary_keyword_ref(self, marketplace=marketplace, category=category)

    @lazy_field("market")
    def get_market(self, marketplace: str | None = None, category: str = "") -> Result:
        """获取市场聚合视图（使用主力关键词），结果写回 self.market。

        委托 Market 实体处理数据获取和聚合计算，本方法只负责选取关键词。
        返回的 self.market 是 Market 实体，可链式调用 get_stats/get_profile/get_opportunity。
        """
        return market_methods.get_market(self, marketplace=marketplace, category=category)

    @lazy_field("market_stats")
    def get_market_stats(
        self,
        marketplace: str | None = None,
        category: str = "",
    ) -> Result:
        """从 Product 直接获取 Market Stats；缺少 market 时自动级联创建。"""
        return market_methods.get_market_stats(self, marketplace=marketplace, category=category)

    @lazy_field("market_profile")
    def get_market_profile(
        self,
        marketplace: str | None = None,
        category: str = "",
    ) -> Result:
        """从 Product 直接获取 Market Profile；自动级联 Market 与 Stats。"""
        return market_methods.get_market_profile(self, marketplace=marketplace, category=category)

    @lazy_field("market_opportunity")
    def get_market_opportunity(
        self,
        marketplace: str | None = None,
        category: str = "",
    ) -> Result:
        """从 Product 直接获取 Market Opportunity；自动级联 Market 与 Stats。"""
        return market_methods.get_market_opportunity(self, marketplace=marketplace, category=category)

    # ------------------------------------------------------------------
    # Python object API: Product -> Market -> typed market information
    # ------------------------------------------------------------------

    def require_market(
        self,
        marketplace: str | None = None,
        category: str = "",
    ) -> Market:
        """Return this product's typed ``Market`` object, loading it if necessary.

        The existing :meth:`get_market` Result contract remains the registry/CLI
        boundary.  Python callers can use this method for natural object navigation.
        """
        result = self.get_market(marketplace=marketplace, category=category)
        return cast("Market", self._require_field_value("market", result))

    def require_market_stats(
        self,
        marketplace: str | None = None,
        category: str = "",
    ) -> MarketStats:
        """Return typed market statistics directly from a Product."""
        result = self.get_market_stats(marketplace, category)
        return cast(
            "MarketStats",
            self._require_field_value("market_stats", result),
        )

    def require_market_profile(
        self,
        marketplace: str | None = None,
        category: str = "",
    ) -> MarketProfile:
        """Return the typed market profile directly from a Product."""
        result = self.get_market_profile(marketplace, category)
        return cast(
            "MarketProfile",
            self._require_field_value("market_profile", result),
        )

    def require_market_opportunity(
        self,
        marketplace: str | None = None,
        category: str = "",
    ) -> Opportunity:
        """Return the typed market opportunity directly from a Product."""
        result = self.get_market_opportunity(marketplace, category)
        return cast(
            "Opportunity",
            self._require_field_value("market_opportunity", result),
        )

    def get_related_keywords(self) -> Result:
        """获取关联关键词列表（从 reverse_keywords 构造 Keyword 实体列表）。

        需要先填充 reverse_keywords（自动级联触发）。
        返回轻量 Keyword 实例，只含 core 字段。
        """
        return keywords_methods.get_related_keywords(self)

    @lazy_field("copyability")
    def get_copyability(self, innovation_desc: str = "") -> Result:
        """创新可复制性评估，结果写回 self.copyability。

        依赖 product_details（depends 声明自动级联填充标题/图片/描述）；
        reviews 已填充时一并传入作为差评痛点来源，获取失败不阻断主分析。
        委托 analysis.product.copyability.assess_copyability()，支持 TTL 缓存。

        Args:
            innovation_desc: 用户认为的产品的创新点（可选）
        """
        return compare_methods.get_copyability(self, innovation_desc=innovation_desc)

    @lazy_field("innovation")
    def assess_innovation(self, innovation_desc: str = "") -> Result:
        """Compatibility projection of the canonical copyability result."""
        return compare_methods.assess_innovation(self, innovation_desc=innovation_desc)

    @lazy_field("cosmo")
    def get_cosmo(self, model: str = "lite", use_image: bool = True) -> Result:
        """Extract COSMO from Listing text and optional product/A+ image text."""
        return cosmo_methods.get_cosmo(self, model=model, use_image=use_image)

    @lazy_field("material")
    def get_material(self) -> Result:
        """Assess the product's material and development difficulty from available Listing facts."""
        return attributes_methods.get_material(self)

    @lazy_field("unmet_needs")
    def get_unmet_needs(self) -> Result:
        """Project unmet needs from weaknesses without another model request."""
        return voc_methods.get_unmet_needs(self)

    def _writeback(self, field: str, value: Any) -> None:
        if field == "innovation" and value != self.copyability:
            self.copyability = value
            self._mark_fetched("copyability")
        super()._writeback(field, value)

    def _invalidate_field(self, field: str) -> None:
        super()._invalidate_field(field)
        if field in {"market", "primary_keyword_ref"}:
            self.market_ref = None
        elif field == "competitors":
            self.competitor_refs = None

    def _prepare_dependencies(self, field: str, call_params: dict) -> Result | None:
        if field == "core" and self._loaded_fields is not None:
            needed = set(self._core_data()) - self._loaded_fields
            if needed:
                restored = type(self).load(self._cache_id, use_identity=False,
                                          fields=sorted(self._loaded_fields | needed))
                if restored is not None:
                    self._copy_state_from(restored)
        if field == "competitors" and self.competitor_refs is not None:
            # A Ref is not evidence if the referenced local Product was removed.
            if any(Product.load(ref.cache_id) is None for ref in self.competitor_refs):
                self._invalidate_field(field)
        if field == "finance":
            failure = self._check_finance_facts()
            if failure is not None:
                self._invalidate_field(field)
                return failure
        if field in {"cosmo", "material", "copyability"} and "core" in self._fetched_at and not self._check_field("core"):
            result = self.refresh_core()
            if result.code != Code.OK:
                return result
        # Validate before returning a cached result too: fetched empty data is not
        # evidence, and old successful empty VOC results cannot satisfy a task.
        fact_fields = {"cosmo", "material", "copyability", "strengths", "praise", "wishlist", "weaknesses", "use_insights", "voc"}
        if field in fact_fields:
            failure = self._check_analysis_facts()
            if field == "copyability" and ((self.description or "").strip() or any(text.strip() for text in self.bullet_points)):
                failure = None
            if failure is not None:
                self._invalidate_field(field)
                return failure
        if field in {"praise", "wishlist", "weaknesses", "use_insights", "voc"}:
            reviews = [item for item in self.to_review_items() if any(str(item.get(key) or "").strip() for key in ("text", "title"))]
            if field == "praise":
                reviews = [item for item in reviews if (item.get("rating") or 0) >= 4]
            if not reviews:
                self._invalidate_field(field)
                name = "positive_reviews" if field == "praise" else "reviews"
                return err(Code.ERROR_MISSING_FIELDS, f"{field} requires non-empty {name} evidence", missing=[name])
        # Compatibility projections are re-read from their owner on every access.
        if field in {"market_stats", "market_profile", "market_opportunity", "unmet_needs", "innovation"}:
            self._invalidate_field(field)
        return None

    @lazy_field("praise")
    def get_praise(self) -> Result:
        """好评深度挖掘：从 4-5 星好评中提取用户喜爱点、惊喜点、竞品对比、价值感知。

        委托 analysis.voc.praise()，结果写回 self.praise。
        依赖 reviews 字段，未填充时自动级联触发 get_reviews()。
        """
        return voc_methods.get_praise(self)

    @lazy_field("wishlist")
    def get_wishlist(self) -> Result:
        """用户愿望清单：从全部评论中提取功能请求、改进建议、变体需求、配件需求。

        委托 analysis.voc.wishlist()，结果写回 self.wishlist。
        依赖 reviews 字段，未填充时自动级联触发 get_reviews()。
        """
        return voc_methods.get_wishlist(self)

    @lazy_field("strengths")
    def get_strengths(self) -> Result:
        """创新优势分析：从 Listing 文案中找出产品真正的创新点和竞争优势。

        委托 analysis.voc.strength-signals，结果写回 self.strengths。
        该原子能力仅使用 Listing 事实，不读取评论。
        """
        return voc_methods.get_strengths(self)

    @lazy_field("weaknesses")
    def get_weaknesses(self) -> Result:
        """差评 VOC 分析：从评论中提取痛点、未满足需求，带辩证分析上下文。

        先用 calc.voc.satisfaction 计算全量满意度，再委托
        analysis.voc.weakness-signals 提取语义信号并写回 self.weaknesses。
        依赖 reviews 字段，未填充时自动级联触发 get_reviews()。
        """
        return voc_methods.get_weaknesses(self)

    @lazy_field("use_insights")
    def get_use_insights(self) -> Result:
        """消费者使用洞察：场景、人群画像、购买动机。

        委托 analysis.voc.use-signals，结果写回 self.use_insights。
        依赖 reviews 字段，未填充时自动级联触发 get_reviews()。
        """
        return voc_methods.get_use_insights(self)

    @lazy_field("voc")
    def get_voc(self) -> Result:
        """组装 Product 三路 VOC 字段；语义分析仍由各原子能力完成。"""
        return voc_methods.get_voc(self)

    def _check_analysis_facts(self, *, listing: bool = False) -> Result | None:
        return facts_methods._check_analysis_facts(self, listing=listing)

    def _ensure_analysis_facts(self, *, listing: bool = False) -> Result | None:
        return facts_methods._ensure_analysis_facts(self, listing=listing)

    @entity_operation("listing_diff", calc_ids=("calc.listing.word-diff",))
    def listing_diff(self, new_text: str, part: Literal["title", "bp1", "bp2", "bp3", "bp4", "bp5", "description"] = "title") -> Result:
        """Compare proposed text with this Product or ProductDraft's saved Listing part."""
        return listing_methods.listing_diff(self, new_text=new_text, part=part)

    def _listing_data(self) -> dict[str, Any]:
        return listing_methods._listing_data(self)

    def _listing_policy(self, forbidden_terms: list[str] | None, media_title_limit: int | None) -> dict[str, Any]:
        return listing_methods._listing_policy(
            self,
            forbidden_terms=forbidden_terms,
            media_title_limit=media_title_limit,
        )

    @entity_operation("listing_rewrite", analysis_ids=("analysis.listing.rewrite",), output_model=ListingOutput)
    def listing_rewrite(
        self, keywords: dict[str, list[str]] | None = None, feedback: str = "",
        forbidden_terms: list[str] | None = None, media_title_limit: int | None = None,
        title_differentiation: str = "",
    ) -> Result:
        """Rewrite this Product's current title and bullets; return a separate draft."""
        return listing_methods.listing_rewrite(
            self,
            keywords=keywords,
            feedback=feedback,
            forbidden_terms=forbidden_terms,
            media_title_limit=media_title_limit,
            title_differentiation=title_differentiation,
        )

    @entity_operation("listing_micro_insert", analysis_ids=("analysis.listing.micro-insert",), output_model=MicroInsertOutput)
    def listing_micro_insert(
        self, insert_plan: dict[str, list[str]], feedback: str = "",
        forbidden_terms: list[str] | None = None, media_title_limit: int | None = None,
        title_differentiation: str = "",
    ) -> Result:
        """Insert planned keywords into this Product's current Listing."""
        return listing_methods.listing_micro_insert(
            self,
            insert_plan=insert_plan,
            feedback=feedback,
            forbidden_terms=forbidden_terms,
            media_title_limit=media_title_limit,
            title_differentiation=title_differentiation,
        )

    @entity_operation("listing_part_rewrite", analysis_ids=("analysis.listing.part-rewrite",), output_model=PartRewriteOutput)
    def listing_part_rewrite(
        self, part: str, keywords: list[dict[str, Any]], existing_keywords: list[str] | None = None,
        forbidden_terms: list[str] | None = None, media_title_limit: int | None = None,
        title_differentiation: str = "", draft_title: str | None = None,
    ) -> Result:
        """Rewrite one existing title or bullet; its text is read from this Product."""
        return listing_methods.listing_part_rewrite(
            self,
            part=part,
            keywords=keywords,
            existing_keywords=existing_keywords,
            forbidden_terms=forbidden_terms,
            media_title_limit=media_title_limit,
            title_differentiation=title_differentiation,
            draft_title=draft_title,
        )

    @entity_operation("listing_allocate", analysis_ids=("analysis.listing.allocate",), output_model=AllocationOutput)
    def listing_allocate(self, missing_keywords: list[str], use_llm: bool = True) -> Result:
        """Allocate supplied candidates using this Product's current Listing."""
        return listing_methods.listing_allocate(self, missing_keywords=missing_keywords, use_llm=use_llm)

    @entity_operation("compare", analysis_ids=("analysis.innovation.compare",), output_model=ComparativeInnovationOutput)
    def compare(self, benchmark_refs: list[EntityRef]) -> Result:
        """Compare current product facts with three to five real benchmark Products."""
        return compare_methods.compare(self, benchmark_refs=benchmark_refs)

    @entity_operation("classify", analysis_ids=("analysis.asin.classify",), output_model=AsinClassificationOutput)
    def classify(self, dimensions: list[dict[str, Any]]) -> Result:
        """Apply explicit decision dimensions to this Product's prepared facts."""
        return attributes_methods.classify(self, dimensions=dimensions)

    @entity_operation("keyword_relevance", analysis_ids=("analysis.keyword.relevance",), output_model=RelevanceOutput)
    def keyword_relevance(self, keywords: list[str], batch_size: int = 20, max_retries: int = 2) -> Result:
        """Judge explicit keywords against this Product's prepared facts."""
        return keywords_methods.keyword_relevance(
            self,
            keywords=keywords,
            batch_size=batch_size,
            max_retries=max_retries,
        )

    @entity_operation("keyword_gap", analysis_ids=("analysis.keyword.gap",), calc_ids=("calc.keyword.gap",), output_model=KeywordGapOutput)
    def keyword_gap(self, keywords: list[dict[str, Any]]) -> Result:
        """Check keyword coverage in this Product's current Listing."""
        return keywords_methods.keyword_gap(self, keywords=keywords)

    @entity_operation("cosmo_classify", analysis_ids=("analysis.cosmo.classify",), output_model=CosmoClassifyOutput)
    def cosmo_classify(
        self, market_ref: EntityRef, pages: int | None = None, min_success: int = 1, batch_size: int = 50,
    ) -> Result:
        """Rank a Market's prepared COSMO groups for this target Product."""
        return cosmo_methods.cosmo_classify(
            self,
            market_ref=market_ref,
            pages=pages,
            min_success=min_success,
            batch_size=batch_size,
        )

    def _check_finance_facts(self) -> Result | None:
        return finance_methods._check_finance_facts(self)

    def _calc_core(self) -> Result | None:
        return finance_methods._calc_core(self)

    @staticmethod
    def _calc_exchange_rate(exchange_rate: float | None) -> float | Result:
        return finance_methods._calc_exchange_rate(exchange_rate=exchange_rate)

    @entity_operation("fba_fee", calc_ids=("calc.fba.fee",))
    def calculate_fba_fee(
        self, product_type: str | None = None,
        fulfillment_date: date | datetime | str | None = None,
        include_fuel_surcharge: bool = True,
    ) -> Result:
        """Calculate FBA fees using this Product's price, package weight and dimensions."""
        return finance_methods.calculate_fba_fee(
            self,
            product_type=product_type,
            fulfillment_date=fulfillment_date,
            include_fuel_surcharge=include_fuel_surcharge,
        )

    @entity_operation("margin", calc_ids=("calc.fba.margin",))
    def calculate_margin(
        self, purchase_price: NonNegative | None = None,
        shipping_method: ShippingMethod = "fast", referral_rate: ReferralRate = 0.15,
        cpc: NonNegative | None = None, cvr: Ratio | None = None,
        product_type: str | None = None, fulfillment_date: date | datetime | str | None = None,
        include_fuel_surcharge: bool = True, exchange_rate: Positive | None = None,
    ) -> Result:
        """Calculate margin from Product facts and explicit cost assumptions."""
        return finance_methods.calculate_margin(
            self,
            purchase_price=purchase_price,
            shipping_method=shipping_method,
            referral_rate=referral_rate,
            cpc=cpc,
            cvr=cvr,
            product_type=product_type,
            fulfillment_date=fulfillment_date,
            include_fuel_surcharge=include_fuel_surcharge,
            exchange_rate=exchange_rate,
        )

    @entity_operation("return_on_capital", calc_ids=("calc.finance.return-on-capital",))
    def calculate_return_on_capital(
        self, unit_cost: NonNegative, shipping_method: ShippingMethod = "fast",
        units_per_order: PositiveInt = 1, cycle_days: PositiveInt = 60,
        roi_target_pct: NonNegative = 30.0, exchange_rate: Positive | None = None,
        product_type: str | None = None, fulfillment_date: date | datetime | str | None = None,
        include_fuel_surcharge: bool = True,
    ) -> Result:
        """Calculate capital returns with this Product's price, weight and platform fees."""
        return finance_methods.calculate_return_on_capital(
            self,
            unit_cost=unit_cost,
            shipping_method=shipping_method,
            units_per_order=units_per_order,
            cycle_days=cycle_days,
            roi_target_pct=roi_target_pct,
            exchange_rate=exchange_rate,
            product_type=product_type,
            fulfillment_date=fulfillment_date,
            include_fuel_surcharge=include_fuel_surcharge,
        )

    @entity_operation("satisfaction", calc_ids=("calc.voc.satisfaction",))
    def calculate_satisfaction(self) -> Result:
        """Calculate satisfaction from this Product's review summary and rating."""
        return voc_methods.calculate_satisfaction(self)

    @entity_operation("material_eligibility", calc_ids=("calc.material.eligibility",))
    def calculate_material_eligibility(self) -> Result:
        """Apply material rules to this Product's prepared material assessment."""
        return attributes_methods.calculate_material_eligibility(self)

    @entity_operation("traffic_dimensions", calc_ids=("calc.traffic.code-dimensions",))
    def calculate_traffic_dimensions(self, market_ref: EntityRef, pages: Annotated[int, Field(ge=1, le=3)] | None = None) -> Result:
        """Assign price, rating and seller bands using Product facts and a Market sample."""
        return keywords_methods.calculate_traffic_dimensions(self, market_ref=market_ref, pages=pages)
