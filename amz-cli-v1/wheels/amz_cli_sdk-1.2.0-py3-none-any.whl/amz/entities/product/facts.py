"""Product 与 ProductDraft 共用的商品事实检查。

提供缺失字段错误、有效正数判断，以及分析前的标题和 Listing 文本检查。
Product 通过这里补齐或刷新所需详情，再检查是否有可用内容；
ProductDraft 复用事实检查，资料仍以用户输入为准。
缺少有效事实时提前返回具体缺项，不在这里调用模型分析。"""

from __future__ import annotations
import math
from typing import TYPE_CHECKING
from amz.envelope import Code, Result, err

if TYPE_CHECKING:
    from amz.entities.product.draft import ProductDraft
    from amz.entities.product.entity import Product


def _missing(*fields: str) -> Result:
    return err(Code.ERROR_MISSING_FIELDS, "missing valid calculation facts: " + ", ".join(fields), missing=list(fields))


def _positive(value) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and value > 0


def _check_analysis_facts(product: Product | ProductDraft, *, listing: bool = False) -> Result | None:
    missing = []
    has_title = bool((product.title or "").strip())
    has_bullets = any(text.strip() for text in product.bullet_points)
    if listing and not (has_title or has_bullets):
        missing.append("listing")
    elif not listing and not has_title:
        missing.append("title")
    return _missing(*missing) if missing else None


def _ensure_analysis_facts(product: Product | ProductDraft, *, listing: bool = False) -> Result | None:
    if "core" in product._fetched_at and not product._check_field("core"):
        result = product.enrich("core")
        if result.code != Code.OK:
            return result
    result = product.enrich("product_details")
    if result.code != Code.OK:
        return result
    return product._check_analysis_facts(listing=listing)
