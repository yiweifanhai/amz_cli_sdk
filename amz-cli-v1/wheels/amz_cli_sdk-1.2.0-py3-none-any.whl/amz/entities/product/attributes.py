"""Product 的材质评估、维度分类和材质准入检查。

由 Product 的对应方法传入当前实例，准备商品事实后调用 Analysis 或 Calc；
ProductDraft 的分类方法也复用这里的实现。
材质评估写回 material 字段；显式维度分类和材质准入检查返回本次任务结果。
具体语义分析和准入规则分别保留在 amz/analysis/ 与 amz/calc/。"""

from __future__ import annotations
from typing import Any, TYPE_CHECKING
from amz.entities._core import operations
from amz.entities.product.facts import _missing
from amz.envelope import Code, Result

if TYPE_CHECKING:
    from amz.entities.product.draft import ProductDraft
    from amz.entities.product.entity import Product


def get_material(product: Product) -> Result:
    """Assess the product's material and development difficulty from available Listing facts."""
    from amz.analysis.product.material import assess_material
    product_info = {**product.to_product_info(), "categories": product.categories}
    result = assess_material(product_info=product_info, image_url=product._project_image_url())
    if result.code == Code.OK:
        product._writeback("material", result.data)
    return result


def classify(product: Product | ProductDraft, dimensions: list[dict[str, Any]]) -> Result:
    """Apply explicit decision dimensions to this Product's prepared facts."""
    if not dimensions:
        return _missing("dimensions")
    failure = product._ensure_analysis_facts()
    if failure is not None:
        return failure
    facts = {**product.to_product_info(), "price_usd": product.price_usd}
    facts["raw_text"] = "\n".join([*product.bullet_points, product.description or ""])
    return operations.run_analysis("analysis.asin.classify", {"product": facts, "dimensions": dimensions})


def calculate_material_eligibility(product: Product) -> Result:
    """Apply material rules to this Product's prepared material assessment."""
    result = product.enrich("material")
    if result.code != Code.OK:
        return result
    material = product.material or {}
    if "easy_to_develop_mark" not in material or not any(str(material.get(key) or "").strip() for key in ("material_reason", "material_conclusion", "easy_to_develop_reason")):
        return _missing("material")
    return operations.run_calc("calc.material.eligibility", {"material_analysis": material})
