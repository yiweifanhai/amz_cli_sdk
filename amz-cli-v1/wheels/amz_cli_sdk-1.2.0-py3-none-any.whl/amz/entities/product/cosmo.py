"""Product 的 COSMO 提取与市场分组匹配。

从当前商品的 Listing 和可选图片信息准备分析输入，将提取结果写回 cosmo 字段。
分组匹配任务读取指定 Market 的 COSMO 结果，为目标商品匹配并排序分组；
ProductDraft 也可使用这一匹配任务。实际提取和匹配由 Analysis 完成。
COSMO 是商品的一项能力，不是需要单独创建的 Entity。"""

from __future__ import annotations
from typing import TYPE_CHECKING
from pydantic import ValidationError
from amz.config import config
from amz.entities._core import operations
from amz.entities.product.facts import _missing
from amz.envelope import Code, Result, err
from amz.schemas.cosmo import ProductCosmo, TermGroup
from amz.schemas.entity_ref import EntityRef

if TYPE_CHECKING:
    from amz.entities.market import Market
    from amz.entities.product.draft import ProductDraft
    from amz.entities.product.entity import Product


def get_cosmo(product: Product, model: str = "lite", use_image: bool = True) -> Result:
    """Extract COSMO from Listing text and optional product/A+ image text."""
    from amz.analysis.product.cosmo import cosmo_extract
    use_image = use_image and config.cosmo_use_images
    product_info = product.to_product_info()
    product_info["images"] = product.images if use_image else []
    product_info["aplus_images"] = product.aplus_images if use_image else []
    if not use_image:
        product_info["image_url"] = ""
        product_info["main_image_url"] = ""
    result = cosmo_extract(
        product_info=product_info,
        image_url=product._project_image_url() if use_image else "",
        model=model,
    )
    if result.code == Code.OK:
        product._writeback("cosmo", ProductCosmo.model_validate(result.data))
    return result


def cosmo_classify(
    product: Product | ProductDraft, market_ref: EntityRef, pages: int | None = None, min_success: int = 1, batch_size: int = 50,
) -> Result:
    """Rank a Market's prepared COSMO groups for this target Product."""
    from amz.entities._core.store import entity_store

    try:
        ref = EntityRef.model_validate(market_ref)
    except (ValidationError, TypeError) as exc:
        return err(Code.ERROR_PARAM, str(exc))
    if ref.entity_type != "market" or ref.identity["marketplace"] != product.marketplace:
        return err(Code.ERROR_PARAM, "market_ref must name a Market in the Product marketplace")
    if pages is not None and not 1 <= pages <= 3:
        return err(Code.ERROR_PARAM, "pages must be between 1 and 3")
    if min_success < 1 or batch_size < 1:
        return err(Code.ERROR_PARAM, "min_success and batch_size must be positive")
    failure = product._ensure_analysis_facts()
    if failure is not None:
        return failure
    market = entity_store.get_or_create(ref)
    result = market.enrich("cosmo", pages=pages, min_success=min_success)
    if result.code != Code.OK:
        return result
    if market.cosmo is None or not market.cosmo.groups:
        return _missing("market.cosmo.groups")
    groups = []
    for group in market.cosmo.groups:
        counts = group.position_counts
        groups.append(TermGroup(
            group_id=group.group_id, representative_term=group.representative_term,
            representative_term_cn=group.representative_term_cn,
            cosmo_category=group.cosmo_category, cosmo_field=group.cosmo_field,
            synonyms=[member.term for member in group.members], count=group.mention_count,
            title_count=counts.get("title", 0), bullet_points_count=counts.get("bullet_points", 0),
            a_plus_count=counts.get("description_or_a_plus", 0), image_description_count=counts.get("image", 0),
            weighted_score=group.weighted_score, asins=[ref.identity["asin"] for ref in group.product_refs],
            needs_review=group.needs_review, warnings=group.warnings,
        ).model_dump(mode="python"))
    return operations.run_analysis("analysis.cosmo.classify", {
        "groups": groups, "total_asins": market.cosmo.coverage_denominator,
        "product_info": product.to_product_info(), "batch_size": batch_size,
    })
