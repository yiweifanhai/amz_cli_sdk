"""一次性 Entity 任务的声明、参数校验与内部能力调用。

entity_operation 根据方法签名校验输入，并在声明结果模型时校验输出；
这些规则也适用于直接的 Python 方法调用。任务结果不作为长期字段缓存。
业务方法先准备并检查数据，再通过 run_calc 或 run_analysis 调用内部实现。
本文件记录任务与 Calc / Analysis 的对应关系，不实现具体业务算法。"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache, wraps
import inspect
from typing import Any, Callable, get_type_hints

from pydantic import BaseModel, ConfigDict, ValidationError, create_model

from amz.envelope import Code, ParamError, Result, err


@dataclass(frozen=True)
class OperationSpec:
    name: str
    analysis_ids: tuple[str, ...]
    output_model: type[BaseModel] | None = None
    calc_ids: tuple[str, ...] = ()

    @property
    def implementation_ids(self) -> tuple[str, ...]:
        return self.calc_ids + self.analysis_ids


@lru_cache(maxsize=None)
def operation_input_model(method: Callable) -> type[BaseModel]:
    loader = getattr(method, "__entity_operation_loader__", method)
    hints = get_type_hints(loader, include_extras=True)
    fields = {}
    for name, parameter in inspect.signature(loader).parameters.items():
        if name == "self":
            continue
        if parameter.kind in (parameter.VAR_POSITIONAL, parameter.VAR_KEYWORD):
            raise TypeError("Entity operations require explicit named parameters")
        default = ... if parameter.default is inspect.Parameter.empty else parameter.default
        fields[name] = (hints.get(name, Any), default)
    return create_model(
        f"{loader.__qualname__.replace('.', '_')}_input",
        __config__=ConfigDict(extra="forbid", allow_inf_nan=False),
        **fields,
    )


def entity_operation(name: str, *, analysis_ids=(), calc_ids=(), output_model=None):
    """Expose a task method without adding a persistent Entity field.

    The method owns dependency preparation and evidence checks. This wrapper
    validates even direct Python calls. Result caching is deliberately absent:
    task parameters must never overwrite or reuse an unrelated field result.
    """
    spec = OperationSpec(name, tuple(analysis_ids), output_model, tuple(calc_ids))

    def decorate(method):
        @wraps(method)
        def wrapper(self, *args, **kwargs) -> Result:
            try:
                bound = inspect.signature(method).bind(self, *args, **kwargs)
                values = {key: value for key, value in bound.arguments.items() if key != "self"}
                inputs = operation_input_model(method).model_validate(values)
                result = method(self, **{key: getattr(inputs, key) for key in type(inputs).model_fields})
                if not isinstance(result, Result):
                    return err(Code.ERROR_SERVER_INTERNAL, f"{name} did not return a Result")
                if result.code == Code.OK and output_model is not None:
                    try:
                        result = result.model_copy(update={"data": output_model.model_validate(result.data).model_dump(mode="json")})
                    except ValidationError as exc:
                        return err(Code.ERROR_SERVER_INTERNAL, f"invalid Entity operation result: {exc}")
                return result
            except (TypeError, ValueError, ValidationError, ParamError) as exc:
                return err(Code.ERROR_PARAM, str(exc))

        wrapper.__entity_operation__ = spec
        wrapper.__entity_operation_loader__ = method
        return wrapper

    return decorate


def run_analysis(capability_id: str, params: dict[str, Any]) -> Result:
    """Internal dispatch after an Entity has prepared and checked its inputs."""
    from amz.registry import registry

    if not capability_id.startswith("analysis."):
        return err(Code.ERROR_PARAM, "run_analysis accepts only internal analysis capabilities")
    return registry.invoke_internal(capability_id, params)


def run_calc(capability_id: str, params: dict[str, Any]) -> Result:
    """Dispatch a calculation only after its Entity has prepared the inputs."""
    from amz.registry import registry

    if not capability_id.startswith("calc."):
        return err(Code.ERROR_PARAM, "run_calc accepts only internal calc capabilities")
    return registry.invoke_internal(capability_id, params)
