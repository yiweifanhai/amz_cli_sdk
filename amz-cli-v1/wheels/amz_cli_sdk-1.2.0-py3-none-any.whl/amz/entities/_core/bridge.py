"""把 Entity 的字段方法和任务方法注册为公开能力。

扫描实体上的 lazy_field 和 entity_operation 标记，生成输入与输出 Schema，
将字段方法注册为 entity.{type}.{field}，任务方法注册为
entity.{type}.{operation}。输入由实体身份和方法参数组成，
输出为字段值或任务结果；实际执行仍调用实体方法，复用其依赖与缓存流程。
CLI、HTTP 和 MCP 等入口因此可以使用同一套业务能力。

用法::

    registry.invoke("entity.product.finance", {"asin": "B0XXX", "shipping_method": "fast"})
    registry.invoke("entity.keyword.trends", {"term": "portable blender", "marketplace": "US"})"""

from __future__ import annotations

import inspect
import types
from typing import Any, Union, get_args, get_origin

from pydantic import ConfigDict, TypeAdapter, create_model

from amz.envelope import Code, Result, err
from amz.registry import registry
from amz.entities._core.base import Entity


def _getter_signature(loader: Any) -> tuple[list[str], dict[str, Any]]:
    """返回 getter 的 (必填参数列表, 默认值映射) —— 剔除 self。"""
    required: list[str] = []
    defaults: dict[str, Any] = {}
    try:
        sig = inspect.signature(loader)
    except (TypeError, ValueError):
        return required, defaults
    for name, param in sig.parameters.items():
        if name == "self":
            continue
        if param.kind in {
            inspect.Parameter.VAR_POSITIONAL,
            inspect.Parameter.VAR_KEYWORD,
        }:
            continue
        if param.default is inspect.Parameter.empty:
            required.append(name)
        else:
            defaults[name] = param.default
    return required, defaults


def _doc_summary(doc: str | None) -> str:
    """取 getter docstring 首行作为一句话用途摘要（去掉结尾句号/冒号等）。"""
    if not doc:
        return ""
    first = doc.strip().split("\n", 1)[0].strip()
    return first.rstrip("。.；;：: ")


def _identity_annotation(entity_cls: type[Entity], name: str) -> Any:
    field_info = entity_cls.model_fields.get(name)
    if field_info is not None and field_info.annotation is not None:
        return field_info.annotation
    return str


def _field_output_contract(entity_cls: type[Entity], field: str, spec) -> Any | None:
    """实体字段类型优先；裸 dict 字段复用其 Analysis/Calc 原子输出类型。"""
    field_info = entity_cls.model_fields.get(field)
    annotation = field_info.annotation if field_info is not None else None
    if field in entity_cls.reference_fields:
        relation = getattr(entity_cls, field)
        annotation = inspect.get_annotations(relation.fget, eval_str=True).get("return")
    candidate = annotation
    origin = get_origin(candidate)
    if origin in (Union, types.UnionType):
        args = [arg for arg in get_args(candidate) if arg is not type(None)]
        candidate = args[0] if len(args) == 1 else candidate
        origin = get_origin(candidate)
    if candidate in (dict, Any) or origin is dict:
        source_cap = registry.get(spec.source)
        if source_cap is not None and source_cap.output_type is not None:
            return source_cap.output_type
    # lazy getter 成功时字段已填充，公开输出不应继续声明为 null。
    return candidate


def _field_output_schema(entity_cls: type[Entity], field: str, spec) -> dict:
    """从实体字段注解生成输出 JSON Schema（嵌套实体自动带 $defs）。"""
    field_info = entity_cls.model_fields.get(field)
    if field_info is None and field not in entity_cls.reference_fields:
        return {
            "type": "object",
            "description": f"virtual lazy field '{field}'（一次调用回填多个子字段，见能力描述）",
        }
    annotation = _field_output_contract(entity_cls, field, spec)
    if annotation is None:
        return {"type": "object"}
    try:
        return TypeAdapter(annotation).json_schema()
    except Exception:
        return {"type": "object", "description": str(annotation)}


def _field_output_type(entity_cls: type[Entity], field: str, spec) -> Any | None:
    """返回可供 Registry 运行时校验的实体字段类型。"""
    return _field_output_contract(entity_cls, field, spec)


def _fetch_entity(entity_cls: type[Entity], identity: dict, extra: dict) -> Entity | None:
    """fetch() 实体；无 fetch 时退回 load()。extra 只传 fetch 接受的参数。"""
    fetch = getattr(entity_cls, "fetch", None)
    if fetch is not None:
        try:
            accepted = set(inspect.signature(fetch).parameters)
        except (TypeError, ValueError):
            accepted = set()
        kwargs = dict(identity)
        for key, value in extra.items():
            if key in accepted:
                kwargs[key] = value
        return fetch(**kwargs)
    cache_id = entity_cls.compose_cache_id(
        *(identity.get(name) for name in entity_cls.identity_fields)
    )
    return entity_cls.load(cache_id)


def _register_one(entity_cls: type[Entity], field: str, spec) -> str:
    """注册单个 ``entity.{type}.{field}`` 能力，返回能力 ID。"""
    method = getattr(entity_cls, spec.method, None)
    loader = getattr(method, "__entity_loader__", None) or method

    # 声明式前置依赖：把 EnrichSpec.depends 拆成两类 ——
    #   lazy 字段 → 同实体的 entity.{type}.{field} 能力（调用时自动级联）
    #   core 字段 → 基础对象上的字段（由 entity fetch 保证，非能力）
    requires = [
        f"entity.{entity_cls.entity_type}.{dep}"
        for dep in spec.depends
        if dep in entity_cls.lazy_fields
    ]
    requires_fields = [
        dep for dep in spec.depends if dep not in entity_cls.lazy_fields
    ]

    required, defaults = _getter_signature(loader)
    hints: dict[str, Any] = {}
    try:
        hints = inspect.get_annotations(loader, eval_str=True)
    except Exception:
        pass

    # 输入模型：identity 字段 + getter 参数（按签名）。
    # identity 字段里，fetch() 带默认值的（如 marketplace="US"/category=""）设为可选；
    # 只有 fetch() 必填的（如 term/asin）才强制要求，避免前端省略空 category 时报
    # "missing required fields: category"。
    fetch_fn = getattr(entity_cls, "fetch", None)
    fetch_defaults: dict[str, Any] = {}
    if fetch_fn is not None:
        try:
            for name, param in inspect.signature(fetch_fn).parameters.items():
                if param.default is not inspect.Parameter.empty:
                    fetch_defaults[name] = param.default
        except (TypeError, ValueError):
            pass

    fields: dict[str, tuple[Any, Any]] = {}
    for name in entity_cls.identity_fields:
        annotation = _identity_annotation(entity_cls, name)
        if name in fetch_defaults:
            fields[name] = (annotation, fetch_defaults[name])
        else:
            fields[name] = (annotation, ...)
    # ``force_refresh`` 属于 Entity enrich 协议，不是 getter 业务参数。
    # 所有实体原子能力都支持刷新 lazy 字段；使用 fetch 的入口还会刷新 core。
    fields["force_refresh"] = (bool, False)
    for name, param in inspect.signature(loader).parameters.items():
        if name == "self" or name in entity_cls.identity_fields:
            continue
        if param.kind in {
            inspect.Parameter.VAR_POSITIONAL,
            inspect.Parameter.VAR_KEYWORD,
        }:
            continue
        annotation = hints.get(name, param.annotation)
        if annotation is inspect.Parameter.empty:
            annotation = Any
        default = param.default
        if default is inspect.Parameter.empty:
            default = ...
        fields[name] = (annotation, default)
    input_model = create_model(
        f"{entity_cls.entity_type}_{field}_input",
        __config__=ConfigDict(extra="forbid", allow_inf_nan=False), **fields
    )

    cap_id = f"entity.{entity_cls.entity_type}.{field}"
    identity_names = tuple(entity_cls.identity_fields)

    def fn(**kwargs) -> Result:
        identity = {}
        for name in identity_names:
            if name in kwargs:
                identity[name] = kwargs.pop(name)
        if not identity:
            return err(
                Code.ERROR_PARAM,
                f"missing identity fields: {', '.join(identity_names)}",
                capability=cap_id,
            )
        # Entity 刷新参数不传给 getter。
        extra = {}
        for name in ("force_refresh",):
            if name in kwargs:
                extra[name] = kwargs.pop(name)
        if cap_id in {"entity.keyword.score", "entity.keyword.cluster"}:
            # These analyses consume explicit or cached candidates. Loading core
            # metrics first would add an unrelated network request.
            from amz.entities._core.store import entity_store
            from amz.schemas.entity_ref import keyword_ref

            try:
                ref = keyword_ref(
                    identity.get("marketplace", "US"),
                    identity.get("category", ""),
                    identity.get("term", ""),
                )
                entity = entity_store.get_or_create(ref)
            except ValueError as exc:
                return err(Code.ERROR_PARAM, str(exc), capability=cap_id)
        else:
            entity = _fetch_entity(entity_cls, identity, extra)
        if entity is None:
            if entity_cls.entity_type in {"product", "keyword"} and (
                identity.get("marketplace", "US").upper() != "US" or identity.get("category")
            ):
                return err(Code.ERROR_PARAM, "upstream data currently supports marketplace US and no category filter only", capability=cap_id)
            return err(
                Code.ERROR_UPSTREAM,
                f"failed to load {entity_cls.entity_type} {identity}",
                hint="check AMZ_API_TOKEN / upstream availability",
                capability=cap_id,
            )
        getter = getattr(entity, spec.method, None)
        if getter is None:
            return err(
                Code.ERROR_SERVER_INTERNAL,
                f"method '{spec.method}' not found on {entity_cls.entity_type}",
                capability=cap_id,
            )
        # An identity parameter may also control a compatibility getter (marketplace).
        # Keep it in both calls so the bridge cannot silently fall back to US.
        getter_names = set(inspect.signature(loader).parameters)
        for name, value in identity.items():
            if name in getter_names:
                kwargs[name] = value
        if extra.get("force_refresh") and isinstance(entity, Entity):
            return entity.refresh(field, **kwargs)
        return getter(**kwargs)

    # 描述优先取 getter docstring 首行（真实用途），拿不到再退回通用模板。
    summary = _doc_summary(loader.__doc__)
    if summary:
        description = f"{summary} — lazy 按需填充 + TTL 回填（{spec.source}）"
    else:
        description = (
            f"实体能力：{entity_cls.entity_type}.{field} — lazy 按需填充 + TTL 回填"
            f"（{spec.source}）"
        )

    registry.register(
        cap_id,
        description=description,
        category="entity",
        input_model=input_model,
        output_schema=_field_output_schema(entity_cls, field, spec),
        output_type=_field_output_type(entity_cls, field, spec),
        requires=requires,
        requires_fields=requires_fields,
    )(fn)
    return cap_id


def register_entity_capabilities() -> int:
    """把已注册实体的 lazy getter 注册为能力。幂等，返回本次新增数量。"""
    from amz.entities._core.store import entity_registry

    added = 0
    for entity_cls in entity_registry.classes():
        for field, spec in entity_cls.lazy_fields.items():
            cap_id = f"entity.{entity_cls.entity_type}.{field}"
            source = registry.get(spec.source)
            if source is not None and source.internal and source.entity_entrypoint is None:
                source.entity_entrypoint = cap_id
            if registry.get(cap_id) is not None:
                continue
            _register_one(entity_cls, field, spec)
            added += 1
        for method_name in dir(entity_cls):
            method = getattr(entity_cls, method_name, None)
            operation = getattr(method, "__entity_operation__", None)
            if operation is None:
                continue
            cap_id = f"entity.{entity_cls.entity_type}.{operation.name}"
            if registry.get(cap_id) is None:
                _register_operation(entity_cls, method_name, method, operation)
                added += 1
    # Historical IDs share the owning Entity business operation; they do not
    # create extra persistent fields or duplicate analysis implementations.
    aliases = {
        "analysis.voc.strengths": "entity.product.strengths",
        "analysis.voc.weaknesses": "entity.product.weaknesses",
        "analysis.voc.use-insights": "entity.product.use_insights",
        "analysis.cosmo.merge": "entity.market.cosmo_merge",
        "analysis.cosmo.aggregate": "entity.market.cosmo_aggregate",
    }
    for analysis_id, entrypoint in aliases.items():
        cap = registry.get(analysis_id)
        if cap is not None:
            cap.entity_entrypoint = entrypoint
    return added


def _register_operation(entity_cls, method_name, method, operation):
    """Register a contextual Entity method; identity creation never fetches data."""
    from amz.entities._core.operations import operation_input_model

    arguments = operation_input_model(method)
    fields = {}
    for name in entity_cls.identity_fields:
        field = entity_cls.model_fields[name]
        fields[name] = (field.annotation, field)
    for name, field in arguments.model_fields.items():
        if name in fields:
            raise TypeError(f"operation {method_name} shadows identity field {name}")
        fields[name] = (field.annotation, field)
    input_model = create_model(
        f"{entity_cls.entity_type}_{operation.name}_input",
        __config__=ConfigDict(extra="forbid", allow_inf_nan=False), **fields,
    )

    def execute(**values):
        identity = {name: values.pop(name) for name in entity_cls.identity_fields}
        from amz.entities._core.store import entity_store
        from amz.schemas.entity_ref import product_ref, keyword_ref, market_ref

        if entity_cls.entity_type == "product":
            ref = product_ref(**identity)
        elif entity_cls.entity_type == "keyword":
            ref = keyword_ref(**identity)
        elif entity_cls.entity_type == "market":
            ref = market_ref(**identity)
        else:
            cache_id = entity_cls.compose_cache_id(*(identity[name] for name in entity_cls.identity_fields))
            entity = entity_cls.load(cache_id) or entity_cls(**identity)
            return getattr(entity, method_name)(**values)
        entity = entity_store.get_or_create(ref)
        return getattr(entity, method_name)(**values)

    output_type = operation.output_model
    if output_type is None and operation.implementation_ids:
        source = registry.get(operation.implementation_ids[0])
        output_type = source.output_type if source else None
    cap_id = f"entity.{entity_cls.entity_type}.{operation.name}"
    registry.register(
        cap_id, description=_doc_summary(method.__doc__) + " — Entity prepares required evidence; task result is not cached",
        category="entity", input_model=input_model, output_type=output_type,
    )(execute)
    for implementation_id in operation.implementation_ids:
        implementation = registry.get(implementation_id)
        if implementation is not None and implementation.entity_entrypoint is None:
            implementation.entity_entrypoint = cap_id
