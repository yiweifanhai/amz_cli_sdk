"""Entity 共用的基础代码目录。

base.py 管字段依赖和缓存，store.py 管本地对象与字段存储，
operations.py 管一次性任务的参数与结果校验，bridge.py 管公开能力注册。
这里不定义 Product、Market 等业务对象，也不保存业务公式或分析提示词。"""
