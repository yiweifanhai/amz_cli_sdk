"""Entity 基类：字段声明、依赖加载、缓存和持久化。

基于 Pydantic 定义实体模型，用 EnrichSpec 声明字段的依赖、有效期和版本。
所有按需加载方法都通过 @lazy_field 进入同一条处理流程，使直接调用
get_xxx() 与 entity.enrich("xxx") 使用相同的检查和缓存规则。
同时处理并发请求合并（single-flight）、文件锁、原子写入和缓存恢复；
具体业务的数据获取、计算和分析由各实体的方法完成。"""

from __future__ import annotations

import hashlib
import inspect
import json
import os
import tempfile
import threading
import weakref
from contextlib import contextmanager
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path
from typing import Any, Callable, ClassVar

from pydantic import BaseModel, ConfigDict, PrivateAttr
from pydantic_core import PydanticUndefined

from amz.config import config
from amz.envelope import AmzError, Code, ParamError, Result, err, ok
from amz.schemas.entity_ref import EntityRef
from amz.infra.paths import PathBoundaryError, cache_path, confined_path, validate_component


ENTITY_CACHE_SCHEMA = "amz.entity.v3"
_SELLER_SOURCES = {"/competing-lookup", "/keyword-reverse", "/keyword-miner", "/seller-sprite/trends"}


class EnrichSpec:
    """Lazy 字段声明。"""

    def __init__(
        self,
        field: str,
        method: str,
        depends: list[str],
        source: str,
        ttl_hours: int = 24,
        version: str = "1",
        optional_depends: list[str] | None = None,
        invalidates_on: list[str] | None = None,
        dependency_params: dict[str, list[str]] | None = None,
    ):
        self.field = field
        self.method = method
        self.depends = depends
        self.optional_depends = optional_depends or []
        self.invalidates_on = invalidates_on or []
        self.dependency_params = dependency_params or {}
        self.source = source
        self.ttl_hours = ttl_hours
        self.version = version

    @property
    def invalidation_dependencies(self) -> tuple[str, ...]:
        """All fields whose refresh makes this derived value stale."""
        return tuple(dict.fromkeys([
            *self.depends,
            *self.optional_depends,
            *self.invalidates_on,
        ]))


def lazy_field(field: str):
    """把实体 getter 接入统一 lazy resolver。"""

    def decorator(loader: Callable[..., Result]):
        @wraps(loader)
        def wrapper(self: "Entity", *args, **kwargs) -> Result:
            return self._resolve_lazy(field, loader, args, kwargs)

        wrapper.__entity_lazy_field__ = field
        wrapper.__entity_loader__ = loader
        return wrapper

    return decorator


class Entity(BaseModel):
    """Pydantic 模型与领域聚合根的统一基类。"""

    model_config = ConfigDict(
        validate_assignment=True,
        extra="ignore",
        arbitrary_types_allowed=True,
    )

    entity_type: ClassVar[str] = "entity"
    identity_fields: ClassVar[tuple[str, ...]] = ()
    lazy_fields: ClassVar[dict[str, EnrichSpec]] = {}
    # Lazy relationship properties resolve locally; only their refs are stored.
    reference_fields: ClassVar[dict[str, str]] = {}

    _cache_id: str = PrivateAttr(default="")
    _fetched_at: dict[str, str] = PrivateAttr(default_factory=dict)
    _fetch_keys: dict[str, str] = PrivateAttr(default_factory=dict)
    _result_data: dict[str, Any] = PrivateAttr(default_factory=dict)
    _active_fetch_keys: dict[str, str] = PrivateAttr(default_factory=dict)
    _active_params: dict[str, dict[str, Any]] = PrivateAttr(default_factory=dict)
    _last_params: dict[str, dict[str, Any]] = PrivateAttr(default_factory=dict)
    _saved_state: dict[str, Any] = PrivateAttr(default_factory=dict)
    _dirty_fields: set[str] = PrivateAttr(default_factory=set)
    _loaded_fields: set[str] | None = PrivateAttr(default=None)
    _disk_stamp: int | None = PrivateAttr(default=None)
    _provided_fields: set[str] = PrivateAttr(default_factory=set)

    _inflight: ClassVar[dict[str, threading.Event]] = {}
    _inflight_lock: ClassVar[threading.Lock] = threading.Lock()
    _save_locks: ClassVar[dict[str, threading.Lock]] = {}
    _save_locks_guard: ClassVar[threading.Lock] = threading.Lock()
    _identity_map: ClassVar[weakref.WeakValueDictionary] = weakref.WeakValueDictionary()
    _identity_lock: ClassVar[threading.RLock] = threading.RLock()
    _resolve_local: ClassVar[threading.local] = threading.local()

    @classmethod
    def __pydantic_init_subclass__(cls, **kwargs: Any) -> None:
        """Validate the lazy dependency graph once the Pydantic model is ready."""
        super().__pydantic_init_subclass__(**kwargs)
        cls._validate_lazy_specs()

    @classmethod
    def _validate_lazy_specs(cls) -> None:
        """Fail fast for broken lazy declarations instead of at first production call."""
        known_fields = set(cls.model_fields) | set(cls.lazy_fields)
        for identity in cls.identity_fields:
            if identity not in cls.model_fields:
                raise TypeError(
                    f"{cls.__name__}.identity_fields references unknown field '{identity}'"
                )

        graph: dict[str, list[str]] = {}
        for field, spec in cls.lazy_fields.items():
            if spec.field != field:
                raise TypeError(
                    f"{cls.__name__}.lazy_fields['{field}'] declares field "
                    f"'{spec.field}'"
                )

            method = getattr(cls, spec.method, None)
            if method is None:
                raise TypeError(
                    f"{cls.__name__}.{spec.method} is required by lazy field '{field}'"
                )
            if getattr(method, "__entity_lazy_field__", None) != field:
                raise TypeError(
                    f"{cls.__name__}.{spec.method} must use @lazy_field('{field}')"
                )

            dependencies = [*spec.depends, *spec.optional_depends, *spec.invalidates_on]
            unknown = sorted(set(dependencies) - known_fields)
            if unknown:
                raise TypeError(
                    f"{cls.__name__}.{field} references unknown dependencies: {unknown}"
                )

            enrich_dependencies = [*spec.depends, *spec.optional_depends]
            unknown_parameter_targets = sorted(
                set(spec.dependency_params) - set(enrich_dependencies)
            )
            if unknown_parameter_targets:
                raise TypeError(
                    f"{cls.__name__}.{field} forwards parameters to non-enriched "
                    f"dependencies: {unknown_parameter_targets}"
                )
            graph[field] = [dep for dep in enrich_dependencies if dep in cls.lazy_fields]
            for dependency in graph[field]:
                dependency_spec = cls.lazy_fields[dependency]
                dependency_method = getattr(cls, dependency_spec.method)
                loader = (
                    getattr(dependency_method, "__entity_loader__", None)
                    or dependency_method
                )
                forwarded = set(spec.dependency_params.get(dependency, []))
                required = [
                    name
                    for name, parameter in inspect.signature(loader).parameters.items()
                    if name != "self"
                    and parameter.kind
                    not in {
                        inspect.Parameter.VAR_POSITIONAL,
                        inspect.Parameter.VAR_KEYWORD,
                    }
                    and parameter.default is inspect.Parameter.empty
                    and name not in forwarded
                ]
                if required:
                    raise TypeError(
                        f"{cls.__name__}.{field} cannot auto-enrich '{dependency}'; "
                        f"{dependency_spec.method} requires arguments {required}"
                    )
                target_loader = getattr(method, "__entity_loader__", None) or method
                target_parameters = set(inspect.signature(target_loader).parameters) - {"self"}
                dependency_parameters = set(inspect.signature(loader).parameters) - {"self"}
                missing_from_target = sorted(forwarded - target_parameters)
                missing_from_dependency = sorted(forwarded - dependency_parameters)
                if missing_from_target or missing_from_dependency:
                    raise TypeError(
                        f"{cls.__name__}.{field} has invalid parameter forwarding for "
                        f"'{dependency}': target_missing={missing_from_target}, "
                        f"dependency_missing={missing_from_dependency}"
                    )

        visiting: set[str] = set()
        visited: set[str] = set()

        def visit(field: str, path: list[str]) -> None:
            if field in visiting:
                start = path.index(field)
                cycle = " -> ".join([*path[start:], field])
                raise TypeError(f"{cls.__name__} has cyclic lazy dependencies: {cycle}")
            if field in visited:
                return
            visiting.add(field)
            path.append(field)
            for dependency in graph.get(field, []):
                visit(dependency, path)
            path.pop()
            visiting.remove(field)
            visited.add(field)

        for field in graph:
            visit(field, [])

    def model_post_init(self, __context: Any) -> None:
        if self.entity_type in {"product", "market", "keyword"}:
            ref = self.ref
            for name, value in ref.identity.items():
                if name in type(self).model_fields:
                    object.__setattr__(self, name, value)
            self._cache_id = ref.cache_id
        if not self._cache_id and self.identity_fields:
            values = [getattr(self, name, None) for name in self.identity_fields]
            if any(value not in (None, "") for value in values):
                self._cache_id = self.compose_cache_id(*values)

        # 显式传入的 lazy 值视为已填充，便于用已有数据构造只读实体。
        for field in self.lazy_fields:
            if not (__context and __context.get("entity_loading")) and field in self.model_fields_set and getattr(self, field, None) is not None:
                self._fetched_at[field] = _utc_now()
                self._provided_fields.add(field)
                default_key = self._default_field_cache_key(field)
                if default_key:
                    self._fetch_keys[field] = default_key

        self._remember()
        self._saved_state = self._state_snapshot()
        self._dirty_fields = set(self.model_fields_set) | set(self._fetched_at)

    # ------------------------------------------------------------------
    # 实体身份与缓存持久化
    # ------------------------------------------------------------------

    @staticmethod
    def compose_cache_id(*parts: Any) -> str:
        normalized = ["" if part is None else str(part) for part in parts]
        if len(normalized) == 1:
            return normalized[0]
        return json.dumps(normalized, ensure_ascii=False, separators=(",", ":"))

    @classmethod
    def cache_id_for(cls, **values: Any) -> str:
        if cls.entity_type in {"product", "market", "keyword"}:
            names = ("marketplace", "asin") if cls.entity_type == "product" else ("marketplace", "category", "term")
            defaults = {"marketplace": "US", "category": ""}
            return EntityRef(entity_type=cls.entity_type, key=tuple(values.get(name, defaults.get(name, "")) for name in names)).cache_id
        return cls.compose_cache_id(*(values.get(name) for name in cls.identity_fields))

    @property
    def ref(self) -> EntityRef:
        names = ("marketplace", "asin") if self.entity_type == "product" else ("marketplace", "category", "term")
        defaults = {"marketplace": "US", "category": ""}
        return EntityRef(entity_type=self.entity_type, key=tuple(getattr(self, name, defaults.get(name, "")) for name in names))

    @classmethod
    def _ref_for_cache_id(cls, cache_id: str) -> EntityRef | None:
        if cls.entity_type not in {"product", "market", "keyword"}:
            return None
        try:
            parts = json.loads(cache_id)
        except (ValueError, TypeError):
            parts = ["US", cache_id] if cls.entity_type == "product" else None
        if not isinstance(parts, list):
            raise ValueError("invalid entity cache identity")
        return EntityRef(entity_type=cls.entity_type, key=tuple(parts))

    def project_to(self, input_cls: type[Any]) -> dict | None:
        """按 input_model 的投影元数据从本实体构造输入 dict（只读）。

        供 composite autowire 使用：把聚合根投影成某个能力的 InputModel，
        **绝不触发 enrich** —— 必填字段取不到就返回 None（调用方决定报错
        还是先补齐依赖）；可选字段取不到则跳过，留给 params / 默认值。

        Args:
            input_cls: 能力的 input_model（Pydantic 模型类）。

        Returns:
            投影输入 dict；不可投影时返回 None。
        """
        from amz.schemas.projection import project

        return project(self, input_cls)

    def _remember(self) -> None:
        if not self._cache_id:
            return
        key = (str(config.cache_dir), type(self), self._cache_id)
        with self._identity_lock:
            self._identity_map[key] = self

    @classmethod
    def _live(cls, cache_id: str) -> "Entity | None":
        with cls._identity_lock:
            return cls._identity_map.get((str(config.cache_dir), cls, cache_id))

    @classmethod
    def _cache_file(cls, cache_id: str) -> Path:
        entity_dir = cache_path("entities", validate_component(cls.entity_type, label="entity type"))
        ref = cls._ref_for_cache_id(cache_id)
        digest = ref.file_id if ref is not None else hashlib.sha256(cache_id.encode("utf-8")).hexdigest()
        path = confined_path(entity_dir, f"{digest}.json")
        entity_dir.mkdir(parents=True, exist_ok=True)
        return path

    @classmethod
    def _legacy_cache_file(cls, cache_id: str) -> Path | None:
        # 只兼容读取不会逃逸目录的旧文件名。
        if not cache_id or cache_id in {".", ".."}:
            return None
        if Path(cache_id).name != cache_id or "/" in cache_id or "\\" in cache_id:
            return None
        try:
            validate_component(cache_id, label="legacy cache key")
        except PathBoundaryError:
            return None
        return cache_path("entities", validate_component(cls.entity_type, label="entity type"), f"{cache_id}.json")

    def _entity_cache_path(self) -> Path:
        if not self._cache_id:
            raise ValueError(f"{self.entity_type} entity has no cache identity")
        ref = type(self)._ref_for_cache_id(self._cache_id)
        if ref is not None:
            if ref != self.ref:
                raise ValueError("entity identity cannot change after construction")
            self._cache_id = ref.cache_id
        return type(self)._cache_file(self._cache_id)

    def save(self) -> None:
        """Merge changed fields under a process lock, preserving other writers."""
        path = self._entity_cache_path()
        current = self._state_snapshot()
        changed = {name for name, value in current.items() if value != self._saved_state.get(name)} | self._dirty_fields
        with self._save_lock(path), _file_lock(path):
            existing = self._read_cache_payload(path, self._cache_id) if path.exists() else None
            if path.exists() and existing is None:
                raise ValueError("refusing to overwrite invalid entity cache")
            entries = dict(existing.get("fields", {})) if existing else {}
            for name in changed:
                if name in current:
                    entries[name] = current[name]
            if not existing:
                entries.update(current)
            for name, info in type(self).model_fields.items():
                if info.exclude:
                    entries.pop(name, None)
            payload = self._payload(entries)
            _atomic_write(path, payload)
            self._disk_stamp = path.stat().st_mtime_ns if all(entries.get(name) == value for name, value in current.items()) else None
        self._saved_state = current
        self._dirty_fields.clear()
        self._remember()
        self._record_in_runtime()

    def _state_snapshot(self) -> dict[str, Any]:
        names = set(type(self).model_fields) | set(self.lazy_fields)
        if self._loaded_fields is not None:
            names &= self._loaded_fields | self._dirty_fields
        entries = {}
        for name in names:
            info = type(self).model_fields.get(name)
            if info is not None and info.exclude:
                continue
            # A relationship keeps its value in the declared Ref field. Its lazy
            # entry stores freshness only, never an expanded Entity graph.
            value = None if name in self.reference_fields else getattr(self, name, self._result_data.get(name))
            spec = self.lazy_fields.get(name)
            entries[name] = {
                "state": "ready" if (name in self._fetched_at if spec else value is not None) else "missing",
                "updated_at": self._fetched_at.get(name),
                "last_params": _json_value(self._last_params.get(name, {})),
                "fetch_key": self._fetch_keys.get(name),
                "version": spec.version if spec else None,
                "provided": name in self._provided_fields,
                "value": _serialize_value(value),
            }
        return entries

    def _payload(self, entries: dict[str, Any]) -> dict[str, Any]:
        payload = {"schema": ENTITY_CACHE_SCHEMA, "entity_type": self.entity_type,
                   "cache_id": self._cache_id, "saved_at": _utc_now(), "fields": entries}
        ref = type(self)._ref_for_cache_id(self._cache_id)
        if ref is not None:
            payload["ref"] = ref.model_dump(mode="json")
        return payload

    @classmethod
    def _read_cache_payload(cls, path: Path, cache_id: str) -> dict[str, Any] | None:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(data, dict) or not isinstance(data.get("fields"), dict):
                return None
            ref = cls._ref_for_cache_id(cache_id)
            if data.get("entity_type", cls.entity_type) != cls.entity_type:
                return None
            if data.get("schema") == ENTITY_CACHE_SCHEMA:
                if not all(isinstance(entry, dict) and entry.get("state") in {"ready", "missing", "failed"}
                           for entry in data["fields"].values()):
                    return None
                if ref is not None and EntityRef.model_validate(data.get("ref")) != ref:
                    return None
                if ref is None and data.get("cache_id", cache_id) != cache_id:
                    return None
                return data
            fields = data.get("fields", {})
            if ref is not None:
                # ASIN-only caches without a known marketplace cannot be attributed.
                if cls.entity_type == "product" and not fields.get("marketplace"):
                    return None
                identity = cls.cache_id_for(**fields)
                if identity != ref.cache_id:
                    return None
            entries = {}
            for name in set(fields) | set(data.get("fetched_at", {})):
                stamp = data.get("fetched_at", {}).get(name)
                spec = cls.lazy_fields.get(name)
                value = fields.get(name, data.get("result_data", {}).get(name))
                entries[name] = {"state": "ready" if (stamp if spec else value is not None) else "missing",
                                 "updated_at": stamp, "last_params": {},
                                 "fetch_key": data.get("fetch_keys", {}).get(name),
                                 "version": spec.version if spec else None, "value": value}
            return {**data, "fields": entries}
        except (OSError, ValueError, TypeError, KeyError, AttributeError):
            return None

    def _record_in_runtime(self) -> None:
        """若当前上下文有 Runtime，把实体缓存文件登记到任务 manifest（失败不影响保存）。"""
        from amz.infra.runtime import get_current

        rt = get_current()
        if rt is None:
            return
        try:
            path = self._entity_cache_path()
            try:
                rel = path.relative_to(config.cache_dir)
            except ValueError:
                rel = path
            rt.record(
                kind="entity",
                name=f"{self.entity_type}:{self._cache_id}",
                rel_path=str(rel),
                schema=ENTITY_CACHE_SCHEMA,
            )
        except Exception:
            pass

    @classmethod
    def _save_lock(cls, path: Path) -> threading.Lock:
        key = str(path)
        with cls._save_locks_guard:
            return cls._save_locks.setdefault(key, threading.Lock())

    @classmethod
    def _cache_candidates(cls, cache_id: str) -> list[Path]:
        ref = cls._ref_for_cache_id(cache_id)
        cache_id = ref.cache_id if ref is not None else cache_id
        candidates = [cls._cache_file(cache_id)]
        # Read the former cache-id hash location, but write only canonical files.
        old_dir = candidates[0].parent
        candidates.append(old_dir / f"{hashlib.sha256(cache_id.encode('utf-8')).hexdigest()}.json")
        if ref is not None and cls.entity_type == "product":
            candidates.append(old_dir / f"{hashlib.sha256(ref.key[1].encode('utf-8')).hexdigest()}.json")
        legacy = cls._legacy_cache_file(cache_id)
        if legacy is not None and legacy != candidates[0]:
            candidates.append(legacy)
        if ref is not None and cls.entity_type == "product":
            legacy = cls._legacy_cache_file(ref.key[1])
            if legacy is not None:
                candidates.append(legacy)
        return list(dict.fromkeys(candidates))

    @classmethod
    def load(cls, cache_id: str, *, use_identity: bool = True, fields: list[str] | None = None) -> "Entity | None":
        ref = cls._ref_for_cache_id(cache_id)
        cache_id = ref.cache_id if ref is not None else cache_id
        candidates = cls._cache_candidates(cache_id)

        live = cls._live(cache_id) if use_identity else None
        for path in dict.fromkeys(candidates):
            if not path.exists():
                continue
            requested = set(fields) | set(cls.identity_fields) if fields is not None else None
            if live is not None and live._disk_stamp == path.stat().st_mtime_ns:
                if live._loaded_fields is None or (requested is not None and requested <= live._loaded_fields):
                    return live
            data = cls._read_cache_payload(path, cache_id)
            if data is None:
                if path == candidates[0]:
                    return None
                continue
            try:
                local_changes = {}
                if live is not None:
                    local_changes = {name: entry for name, entry in live._state_snapshot().items()
                                     if name in live._dirty_fields or entry != live._saved_state.get(name)}
                selected = set(data["fields"]) if fields is None else set(fields) | set(cls.identity_fields)
                if live is not None and live._loaded_fields is not None:
                    selected |= live._loaded_fields
                elif live is not None:
                    selected |= set(data["fields"])
                entries = {name: value for name, value in data["fields"].items() if name in selected}
                entries.update(local_changes)
                selected.update(local_changes)
                values = {name: _deserialize_value(entry.get("value")) for name, entry in entries.items()
                          if name in cls.model_fields and not cls.model_fields[name].exclude and entry.get("state") == "ready"}
                if ref is not None:
                    values.update(ref.identity)
                instance = cls.model_validate(values, context={"entity_loading": True})
                instance._cache_id = cache_id
                instance._restore_entries(entries)
                instance._loaded_fields = selected
                instance._disk_stamp = path.stat().st_mtime_ns
                instance._saved_state = instance._state_snapshot()
                instance._dirty_fields = set(local_changes)
                if live is not None:
                    live._copy_state_from(instance)
                    instance = live
                instance._remember()
                return instance
            except (OSError, ValueError, KeyError, TypeError):
                continue
        if not any(candidate.exists() for candidate in candidates) and live is not None and live._disk_stamp is None:
            return live
        return None

    def _restore_entries(self, entries: dict[str, Any]) -> None:
        excluded = {name for name, info in type(self).model_fields.items() if info.exclude}
        self._fetched_at = {name: entry["updated_at"] for name, entry in entries.items()
                            if name not in excluded and entry.get("state") == "ready" and entry.get("updated_at")}
        self._fetch_keys = {name: entry["fetch_key"] for name, entry in entries.items()
                            if name not in excluded and entry.get("fetch_key")}
        self._last_params = {name: entry.get("last_params", {}) for name, entry in entries.items() if name not in excluded}
        self._provided_fields = {name for name, entry in entries.items() if entry.get("provided") and name not in excluded}
        self._result_data = {name: _deserialize_value(entry.get("value")) for name, entry in entries.items()
                            if name in self.lazy_fields and name not in type(self).model_fields and name not in self.reference_fields}
        for name, spec in self.lazy_fields.items():
            if name in entries and entries[name].get("version") != spec.version:
                self._fetched_at.pop(name, None)
        self._backfill_fetch_keys()

    def _copy_state_from(self, other: "Entity") -> None:
        for name in type(self).model_fields:
            setattr(self, name, getattr(other, name))
        self._cache_id = other._cache_id
        self._fetched_at = dict(other._fetched_at)
        self._fetch_keys = dict(other._fetch_keys)
        self._result_data = dict(other._result_data)
        self._last_params = dict(other._last_params)
        self._loaded_fields = None if other._loaded_fields is None else set(other._loaded_fields)
        self._disk_stamp = other._disk_stamp
        self._saved_state = dict(other._saved_state)
        self._dirty_fields = set(other._dirty_fields)
        self._provided_fields = set(other._provided_fields)
        self._remember()

    # ------------------------------------------------------------------
    # TTL、依赖和失效传播
    # ------------------------------------------------------------------

    def _check_field(self, field: str, fetch_key: str | None = None) -> bool:
        spec = self.lazy_fields.get(field)
        value_field = self.reference_fields.get(field, field)
        field_declared = value_field in type(self).model_fields
        value = getattr(self, value_field, None) if field_declared else None
        if field in self.reference_fields and value is None:
            return False

        if field_declared and value is None and not (spec and field in self._fetched_at):
            return False
        if spec is None:
            return field_declared and value is not None

        # 虚拟 lazy 字段没有模型属性，以时间戳作为已填充标记。
        if field not in self._fetched_at:
            return False
        if fetch_key is not None and self._fetch_keys.get(field) != fetch_key:
            return False

        try:
            fetched_at = datetime.fromisoformat(
                self._fetched_at[field].replace("Z", "+00:00")
            )
            if (datetime.now(timezone.utc) - fetched_at).total_seconds() > spec.ttl_hours * 3600:
                return False
        except (ValueError, KeyError, TypeError):
            return False

        # Every cached node must also have valid ancestors. This is a read-only
        # walk: only the resolver may fetch an invalid dependency.
        checking = getattr(self._resolve_local, "checking", set())
        token = (id(self), field)
        if token in checking:
            return False
        self._resolve_local.checking = checking | {token}
        try:
            params = self._last_params.get(field, {})
            for dependency in spec.invalidation_dependencies:
                if field in self._provided_fields and dependency not in self._fetched_at:
                    continue
                if dependency not in spec.depends and dependency not in self._fetched_at:
                    continue
                dependency_params = {name: params[name] for name in spec.dependency_params.get(dependency, []) if name in params}
                key = self._field_cache_key(dependency, dependency_params) if dependency in self.lazy_fields else None
                if not self._check_field(dependency, key):
                    return False
                source_stamp = self._fetched_at.get(dependency)
                if source_stamp and source_stamp > self._fetched_at[field]:
                    return False
        finally:
            self._resolve_local.checking = checking

        # 嵌套实体若已有字段过期，父字段也视为过期。
        if isinstance(value, Entity) and not (type(self).model_fields.get(field) and type(self).model_fields[field].exclude):
            for child_field in value._fetched_at:
                if child_field in value.lazy_fields:
                    child_key = value._fetch_keys.get(child_field)
                    if not value._check_field(child_field, child_key):
                        return False
        return True

    def _check_depends(self, depends: list[str]) -> list[str]:
        return [field for field in depends if not self._check_field(field)]

    def _mark_fetched(self, field: str, fetch_key: str | None = None) -> None:
        self._invalidate_dependents(field)
        self._provided_fields.discard(field)
        self._fetched_at[field] = _utc_now()
        if field in self._active_params:
            self._last_params[field] = dict(self._active_params[field])
        self._dirty_fields.add(field)
        if self._loaded_fields is not None:
            self._loaded_fields.add(field)
        key = fetch_key or self._active_fetch_keys.get(field)
        if key is None and field in self.lazy_fields:
            key = self._default_field_cache_key(field)
        if key is not None:
            self._fetch_keys[field] = key

    def _writeback(self, field: str, value: Any) -> None:
        value_field = self.reference_fields.get(field, field)
        if value_field not in type(self).model_fields:
            raise ValueError(f"unknown entity field: {field}")
        setattr(self, value_field, value)
        self._dirty_fields.add(value_field)
        if self._loaded_fields is not None:
            self._loaded_fields.add(value_field)
        self._mark_fetched(field)
        self.save()

    def invalidate(self, field: str | None = None) -> None:
        targets = [field] if field else list(self.lazy_fields)
        for target in targets:
            self._invalidate_field(target)
        self.save()

    def _invalidate_dependents(self, field: str, visited: set[str] | None = None) -> None:
        visited = visited or set()
        if field in visited:
            return
        visited.add(field)
        for child, spec in self.lazy_fields.items():
            if field in spec.invalidation_dependencies:
                self._invalidate_field(child)
                self._invalidate_dependents(child, visited)

    def _invalidate_field(self, field: str) -> None:
        self._dirty_fields.add(field)
        self._fetched_at.pop(field, None)
        self._fetch_keys.pop(field, None)
        self._result_data.pop(field, None)
        self._last_params.pop(field, None)
        value_field = self.reference_fields.get(field, field)
        field_info = type(self).model_fields.get(value_field)
        if field_info is None:
            return
        default = field_info.get_default(call_default_factory=True)
        if default is PydanticUndefined:
            default = None
        setattr(self, value_field, default)
        self._dirty_fields.add(value_field)

    # ------------------------------------------------------------------
    # 统一 lazy 调度
    # ------------------------------------------------------------------

    def enrich(self, field: str, **kwargs) -> Result:
        spec = self.lazy_fields.get(field)
        if spec is None:
            return err(Code.ERROR_PARAM, f"unknown lazy field: {field}")
        method = getattr(self, spec.method, None)
        if method is None:
            return err(
                Code.ERROR_SERVER_INTERNAL,
                f"method '{spec.method}' not found on {self.entity_type}",
            )
        if getattr(method, "__entity_lazy_field__", None) != field:
            return err(
                Code.ERROR_SERVER_INTERNAL,
                f"method '{spec.method}' must use @lazy_field('{field}')",
            )
        return method(**kwargs)

    def refresh(self, field: str, **kwargs) -> Result:
        """强制刷新一个 lazy 字段并返回该字段的规范值。

        这是 SDK 的显式刷新入口；与直接操作 ``_fetched_at`` 相比，它会同时
        清理参数指纹、缓存结果和下游依赖，然后复用正常的 enrich 调度链。
        """
        if field not in self.lazy_fields:
            return err(Code.ERROR_PARAM, f"unknown lazy field: {field}")
        self.invalidate(field)
        return self.enrich(field, **kwargs)

    def _require_field_value(self, field: str, result: Result) -> Any:
        """Return a populated entity field or raise a Python-facing error.

        Entity getters keep returning :class:`Result` for registry/CLI callers.  Typed
        convenience methods use this helper to expose normal object-oriented return
        values without duplicating error handling in every entity.
        """
        if result.code != Code.OK:
            detail = result.message or result.meta.hint or "lazy enrichment failed"
            raise AmzError(f"{self.entity_type}.{field} [{result.code.value}]: {detail}")

        value = getattr(self, field, None)
        if value is None:
            raise AmzError(
                f"{self.entity_type}.{field} [{Code.ERROR_SERVER_INTERNAL.value}]: "
                "getter succeeded without a populated field"
            )
        return value

    def _resolve_lazy(
        self,
        field: str,
        loader: Callable[..., Result],
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> Result:
        spec = self.lazy_fields.get(field)
        if spec is None:
            return err(Code.ERROR_PARAM, f"unknown lazy field: {field}")

        if self._loaded_fields is not None:
            needed = {field, *spec.invalidation_dependencies}
            needed.update(self.reference_fields[name] for name in tuple(needed) if name in self.reference_fields)
            needed -= self._loaded_fields
            if needed:
                restored = type(self).load(
                    self._cache_id, use_identity=False,
                    fields=sorted(self._loaded_fields | needed),
                )
                if restored is not None:
                    self._copy_state_from(restored)

        try:
            fetch_key = self._make_call_key(
                loader, args, kwargs, version=spec.version, source=spec.source,
            )
            bound = inspect.signature(loader).bind(self, *args, **kwargs)
            bound.apply_defaults()
            target_params = {
                name: value
                for name, value in bound.arguments.items()
                if name != "self"
            }
        except TypeError as exc:
            return err(Code.ERROR_PARAM, str(exc))

        token = (id(self), field, fetch_key)
        stack = getattr(self._resolve_local, "stack", [])
        if token in stack:
            return err(Code.ERROR_SERVER_INTERNAL, f"cyclic enrich dependency at {field}")
        stack.append(token)
        self._resolve_local.stack = stack

        try:
            # 先检查依赖，再检查目标，保证依赖刷新后能正确失效下游。
            for dependency in spec.depends:
                dependency_kwargs = {
                    name: target_params[name]
                    for name in spec.dependency_params.get(dependency, [])
                    if name in target_params
                }
                dependency_key = self._field_cache_key(
                    dependency, dependency_kwargs,
                ) if dependency in self.lazy_fields else None
                if self._check_field(dependency, dependency_key):
                    continue
                if dependency not in self.lazy_fields:
                    return err(
                        Code.ERROR_UPSTREAM,
                        f"missing fields for {field}: [{dependency}]",
                        missing=[dependency],
                    )
                dependency_result = self.enrich(dependency, **dependency_kwargs)
                if dependency_result.code != Code.OK:
                    return dependency_result

            # 可选依赖只在首次计算时尽力补齐；失败不阻断目标能力。若它曾经
            # 填充但现已过期，则目标结果也必须失效，随后用刷新结果（或无该
            # 可选输入）重新计算。这样既避免缓存不一致，也不会让可选数据源
            # 的失败拖垮主分析。
            target_cached = self._check_field(field, fetch_key)
            for dependency in spec.optional_depends:
                dependency_kwargs = {
                    name: target_params[name]
                    for name in spec.dependency_params.get(dependency, [])
                    if name in target_params
                }
                dependency_key = self._field_cache_key(
                    dependency, dependency_kwargs,
                ) if dependency in self.lazy_fields else None
                if self._check_field(dependency, dependency_key):
                    continue
                was_fetched = (
                    dependency in self._fetched_at
                    or getattr(self, dependency, None) is not None
                )
                if target_cached and not was_fetched:
                    continue
                if was_fetched:
                    self._invalidate_field(field)
                    target_cached = False
                if dependency in self.lazy_fields:
                    self.enrich(dependency, **dependency_kwargs)

            # 只观察、不主动 fetch 的输入（例如已有评论作为 strengths 的补充
            # 证据）过期时同样使目标失效。
            for dependency in spec.invalidates_on:
                if dependency not in self._fetched_at:
                    continue
                dependency_key = (
                    self._default_field_cache_key(dependency)
                    if dependency in self.lazy_fields else None
                )
                if not self._check_field(dependency, dependency_key):
                    self._invalidate_field(field)

            prepared = self._prepare_dependencies(field, target_params)
            if prepared is not None and prepared.code != Code.OK:
                return prepared

            if self._check_field(field, fetch_key):
                return self._cached_result(field, spec)

            flight_key = self._flight_key(field)
            while True:
                flight_state = self._single_flight(flight_key)
                if flight_state == "leader":
                    break
                if flight_state == "timeout":
                    return err(Code.ERROR_UPSTREAM, f"timed out waiting for {field}")
                refreshed = type(self).load(self._cache_id, use_identity=False)
                if refreshed is not None:
                    self._copy_state_from(refreshed)
                if self._check_field(field, fetch_key):
                    return self._cached_result(field, spec, waited=True)
                # 另一组参数刚执行完；重新竞争同一字段的执行权。

            self._active_fetch_keys[field] = fetch_key
            self._active_params[field] = _json_value(target_params)
            try:
                result = loader(self, *args, **kwargs)
                if not isinstance(result, Result):
                    return err(
                        Code.ERROR_SERVER_INTERNAL,
                        f"{spec.method} returned {type(result).__name__}, expected Result",
                    )
                if result.code != Code.OK:
                    return result
                if not self._check_field(field, fetch_key):
                    return err(
                        Code.ERROR_SERVER_INTERNAL,
                        f"{spec.method} succeeded without writing back '{field}'",
                    )

                # Entity 原子能力的公开契约就是字段声明本身。loader 可以用任意
                # 临时响应完成回填，但调用方永远拿到与 Entity schema 一致的值。
                # 虚拟 lazy 字段（一次回填多个字段）没有模型属性，保留 loader
                # 声明的响应数据。
                canonical_data = _json_value(self._field_result_data(field, result.data))
                if field not in self.reference_fields:
                    self._result_data[field] = canonical_data
                self.save()
                meta = result.meta.model_copy(deep=True)
                meta.from_cache = False
                meta.upstream = meta.upstream or spec.source
                if field not in meta.enriched:
                    meta.enriched.append(field)
                return result.model_copy(update={"data": canonical_data, "meta": meta})
            except ParamError as exc:
                return err(Code.ERROR_PARAM, str(exc))
            except Exception as exc:
                return err(
                    Code.ERROR_SERVER_INTERNAL,
                    f"{self.entity_type}.{spec.method} failed: {exc}",
                )
            finally:
                self._active_fetch_keys.pop(field, None)
                self._active_params.pop(field, None)
                self._single_flight_done(flight_key)
        finally:
            stack.pop()

    def _prepare_dependencies(self, field: str, call_params: dict[str, Any]) -> Result | None:
        """Prepare explicit cross-entity inputs before returning a field cache."""
        return None

    def _field_result_data(self, field: str, fallback: Any) -> Any:
        """Project current facts for both fresh and cached capability responses."""
        if field in type(self).model_fields or field in self.reference_fields:
            return getattr(self, field)
        return fallback

    def _cached_result(self, field: str, spec: EnrichSpec, waited: bool = False) -> Result:
        # 声明字段始终以当前 Entity 值为准；这也会自动纠正旧缓存中保存的
        # wrapper 响应（例如 {"market": ...}）与字段 schema 不一致的问题。
        fallback = self._result_data.get(field, {"field": field, "enriched": True})
        data = _json_value(self._field_result_data(field, fallback))
        result = ok(data=data, from_cache=True, upstream=spec.source)
        if waited:
            result.meta.usage["single_flight_waited"] = True
        return result

    def _make_call_key(
        self,
        loader: Callable[..., Result],
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
        *,
        version: str = "1",
        source: str | None = None,
    ) -> str:
        bound = inspect.signature(loader).bind(self, *args, **kwargs)
        bound.apply_defaults()
        params = {
            name: _json_value(value)
            for name, value in bound.arguments.items()
            if name != "self"
        }
        payload = {"version": version, "params": params}
        if source is None and self is not None:
            source = next((spec.source for spec in self.lazy_fields.values() if spec.method == loader.__name__), "")
        if source in _SELLER_SOURCES:
            config.refresh_saved()
            payload["seller_data"] = {"version": "3", "url": config.data_api_base_url.rstrip("/")}
        if source in {"analysis.cosmo.extract", "analysis.market.cosmo"}:
            payload["cosmo_use_images"] = config.cosmo_use_images
        if source and source.startswith("analysis."):
            payload["llm"] = _analysis_cache_scope(params)
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def _default_field_cache_key(self, field: str) -> str | None:
        return self._field_cache_key(field, {})

    def _field_cache_key(
        self,
        field: str,
        kwargs: dict[str, Any],
    ) -> str | None:
        spec = self.lazy_fields.get(field)
        method = getattr(self, spec.method, None) if spec else None
        loader = getattr(method, "__entity_loader__", None)
        if loader is None:
            return None
        try:
            return self._make_call_key(loader, (), kwargs, version=spec.version, source=spec.source)
        except TypeError:
            return None

    def _backfill_fetch_keys(self) -> None:
        for field in self._fetched_at:
            if field not in self._fetch_keys:
                spec = self.lazy_fields.get(field)
                if spec and spec.source in _SELLER_SOURCES:
                    # A pre-version cache cannot prove which seller response it used.
                    continue
                key = self._default_field_cache_key(field)
                if key:
                    self._fetch_keys[field] = key

    def _flight_key(self, field: str) -> str:
        identity = self._cache_id or f"memory:{id(self)}"
        digest = hashlib.sha256(identity.encode("utf-8")).hexdigest()[:20]
        return f"{self.entity_type}:{digest}:{field}"

    @classmethod
    def _single_flight(cls, key: str) -> str:
        with cls._inflight_lock:
            if key in cls._inflight:
                event = cls._inflight[key]
                leader = False
            else:
                cls._inflight[key] = threading.Event()
                leader = True
        if leader:
            return "leader"
        return "waited" if event.wait(timeout=120) else "timeout"

    @classmethod
    def _single_flight_done(cls, key: str) -> None:
        with cls._inflight_lock:
            event = cls._inflight.pop(key, None)
        if event:
            event.set()

    # ------------------------------------------------------------------
    # 批量与构造工具
    # ------------------------------------------------------------------

    @classmethod
    def batch_fetch(cls, cache_ids: list[str], concurrency: int = 5) -> dict[str, "Entity"]:
        results: dict[str, Entity] = {}
        with ThreadPoolExecutor(max_workers=max(1, concurrency)) as executor:
            futures = {executor.submit(cls.fetch, cache_id): cache_id for cache_id in cache_ids}
            for future in as_completed(futures):
                cache_id = futures[future]
                try:
                    entity = future.result()
                    if entity is not None:
                        results[cache_id] = entity
                except Exception:
                    pass
        return results

    @classmethod
    def _from_dict(cls, data: dict[str, Any]) -> "Entity | None":
        try:
            valid_fields = {
                key: value for key, value in data.items()
                if key in cls.model_fields
            }
            return cls(**valid_fields)
        except Exception:
            return None


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _analysis_cache_scope(params: dict[str, Any]) -> dict[str, Any]:
    """Record only public routing choices, never credentials or input contents."""
    from amz.envelope import LLMError
    from amz.infra.llm import LLM_CACHE_VERSION, _resolve_effective, _resolve_model

    provider = config.llm_default_backend
    aliases = {"pro", "lite", "mini"}
    aliases.update(value for name, value in params.items()
                   if (name == "model" or name.endswith("_model")) and isinstance(value, str))
    text_models = {alias: _resolve_model(provider, alias) for alias in sorted(aliases)}
    vision_models = {}
    for alias in sorted(aliases):
        try:
            route = _resolve_effective(provider, alias, [{"content": [{"type": "image_url"}]}])
        except LLMError:
            route = None
        vision_models[alias] = route
    return {"version": LLM_CACHE_VERSION, "provider": provider, "models": text_models, "vision_models": vision_models}


@contextmanager
def _file_lock(path: Path):
    """Use a stable sidecar file so atomic replacement cannot release the lock."""
    lock_path = path.with_suffix(path.suffix + ".lock")
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with lock_path.open("a+b") as handle:
        if os.name == "nt":
            import msvcrt
            if handle.seek(0, os.SEEK_END) == 0:
                handle.write(b"0")
                handle.flush()
            handle.seek(0)
            msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
            try:
                yield
            finally:
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def _atomic_write(path: Path, payload: dict[str, Any]) -> None:
    temp_path = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent,
                                         prefix=f".{path.name}.", suffix=".tmp", delete=False) as handle:
            json.dump(payload, handle, ensure_ascii=False, default=str)
            handle.flush()
            os.fsync(handle.fileno())
            temp_path = Path(handle.name)
        os.replace(temp_path, path)
        temp_path = None
    finally:
        if temp_path is not None:
            temp_path.unlink(missing_ok=True)


def _json_value(value: Any) -> Any:
    if isinstance(value, BaseModel):
        return value.model_dump(mode="json")
    if isinstance(value, dict):
        return {str(key): _json_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_json_value(item) for item in value]
    if isinstance(value, Path):
        return str(value)
    return value


def _serialize_value(value: Any) -> Any:
    if isinstance(value, Entity):
        if value.entity_type in {"product", "market", "keyword"}:
            raise ValueError("entity relationships must store EntityRef, not Entity fields")
        return {
            "__amz_entity__": True,
            "entity_type": value.entity_type,
            "cache_id": value._cache_id,
            "fetched_at": dict(value._fetched_at),
            "fetch_keys": dict(value._fetch_keys),
            "result_data": _serialize_value(value._result_data),
            "fields": {
                name: _serialize_value(getattr(value, name))
                for name in type(value).model_fields
            },
        }
    if isinstance(value, BaseModel):
        return value.model_dump(mode="json")
    if isinstance(value, dict):
        return {str(key): _serialize_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_serialize_value(item) for item in value]
    return value


def _deserialize_value(value: Any) -> Any:
    if isinstance(value, list):
        return [_deserialize_value(item) for item in value]
    if not isinstance(value, dict):
        return value
    if value.get("__amz_entity__") is True:
        entity_cls = _find_entity_class(value.get("entity_type", ""))
        fields = _deserialize_value(value.get("fields", {}))
        if entity_cls is None:
            return fields
        cache_id = value.get("cache_id", "")
        live = entity_cls._live(cache_id) if cache_id else None
        if live is not None:
            return live
        instance = entity_cls.model_validate(fields)
        instance._cache_id = cache_id
        instance._fetched_at = dict(value.get("fetched_at", {}))
        instance._fetch_keys = dict(value.get("fetch_keys", {}))
        instance._result_data = _deserialize_value(value.get("result_data", {}))
        instance._backfill_fetch_keys()
        instance._remember()
        return instance
    return {key: _deserialize_value(item) for key, item in value.items()}


def _find_entity_class(entity_type: str) -> type[Entity] | None:
    pending = list(Entity.__subclasses__())
    while pending:
        candidate = pending.pop()
        if candidate.entity_type == entity_type:
            return candidate
        pending.extend(candidate.__subclasses__())
    return None
