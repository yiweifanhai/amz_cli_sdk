"""Keyword 的基础指标、扩展词和时间序列读取。

调用 Data 获取搜索量等指标、相关词和搜索趋势，或从指定 ABA 文件读取排名序列，
检查并写回当前 Keyword 的对应字段。上游支持的站点和类目范围在取数前检查。
由 Keyword 方法进入，缓存规则沿用实体声明；本文件不做关键词评分或意图聚类。"""

from __future__ import annotations
from typing import TYPE_CHECKING
from pydantic import ValidationError
from amz.envelope import Code, Result, err

if TYPE_CHECKING:
    from amz.entities.keyword.entity import Keyword


def get_metrics(keyword: Keyword) -> Result:
    """获取关键词特征（core 字段刷新）"""
    if keyword.marketplace != "US" or keyword.category:
        return err(Code.ERROR_PARAM, "upstream keyword data currently supports marketplace US and no category filter only")
    from amz.data.keyword import keyword_miner
    result = keyword_miner(keyword.term)
    if result.code == Code.OK:
        items = (result.data or {}).get("items", [])
        if items:
            try:
                rows, values = keyword._validate_metrics(items, keyword.term)
            except (ValidationError, ValueError) as exc:
                return err(Code.ERROR_UPSTREAM, f"invalid keyword metrics: {exc}")
            keyword._save_metrics(rows, values)
        else:
            return err(Code.ERROR_NOT_FOUND, f"no metrics found for {keyword.term}")
    return result


def expand(keyword: Keyword) -> Result:
    """拓展关键词"""
    if keyword.marketplace != "US" or keyword.category:
        return err(Code.ERROR_PARAM, "upstream keyword data currently supports marketplace US and no category filter only")
    from amz.data.keyword import keyword_miner
    result = keyword_miner(keyword.term)
    if result.code == Code.OK:
        keyword._writeback("related_keywords", (result.data or {}).get("items", []))
    return result


def get_trends(keyword: Keyword) -> Result:
    """获取关键词搜索量趋势时间序列（写入 self.trends）"""
    if keyword.marketplace != "US" or keyword.category:
        return err(Code.ERROR_PARAM, "upstream keyword data currently supports marketplace US and no category filter only")
    from amz.data.keyword import keyword_trends
    result = keyword_trends(keyword.term)
    if result.code == Code.OK:
        keyword._writeback("trends", (result.data or {}).get("points", []))
    return result


def get_aba_series(keyword: Keyword, csv_path: str = "") -> Result:
    """获取关键词 ABA 周排名序列（需 csv_path 指向 ABA CSV 文件）"""
    from amz.data.sources.aba_file import read_aba
    if not csv_path:
        return err(Code.ERROR_PARAM, "csv_path required for ABA data")
    result = read_aba(csv_path)
    if result.code == Code.OK:
        keyword._writeback("aba_series", (result.data or {}).get("rows", []))
    return result
