"""Keyword 使用的数据模型。

定义搜索趋势点、ABA 排名点，以及关键词评分和聚类的结果结构，
供实体和调用方表达这些数据。模型本身不获取指标、不调用分析，
也不单独管理 Keyword 的身份或缓存。"""

from __future__ import annotations
from pydantic import BaseModel, Field


class TrendPoint(BaseModel):
    """趋势数据点"""
    date: str = ""          # ISO 日期
    value: float | None = None


class Abapoint(BaseModel):
    """ABA 周数据点"""
    week: str = ""          # 周标识
    rank: int | None = None


class KeywordScore(BaseModel):
    """关键词四维评分结果"""
    keyword: str = ""
    score: float = 0.0          # 0-10
    grade: str = "C"            # S/A/B/C
    dimension_scores: dict[str, float] = Field(default_factory=dict)
    match_level: str = ""       # perfect/high/partial/low
    reason: str = ""


class KeywordCluster(BaseModel):
    """关键词聚类结果"""
    label: str = ""
    members: list[str] = Field(default_factory=list)
    weighted_traffic: float = 0.0
    trend: str = ""
    competition: str = ""
    members_count: int = 0
