"""Keyword 与对应 Market 及商品样本的关系。

按当前词、站点和类目创建或恢复 Market，并通过它获取市场统计、画像、
机会评分和商品样本；也可将样本转为可继续调用方法的 Product 实例。
由 Keyword 的公开方法传入当前实例，持久保存市场和商品引用，
关联对象及结果作为临时访问视图；市场分析的正式实现仍属于 Market。"""

from __future__ import annotations
from typing import TYPE_CHECKING
from amz.envelope import Code, Result, err, ok

if TYPE_CHECKING:
    from amz.entities.keyword.entity import Keyword
    from amz.entities.market import Market


def get_market(keyword: Keyword) -> Result:
    """获取该关键词的市场分析实体。

    只创建并写回 Market 对象；Stats、Profile 与 Opportunity 由各自的
    lazy 方法按需级联，避免仅访问对象时提前拉取竞品数据。
    """
    from amz.entities.market import Market
    from amz.entities.market import Market
    market = Market.fetch(
        keyword.term,
        marketplace=keyword.marketplace,
        category=keyword.category,
    )
    if market is None:
        return err(Code.ERROR_UPSTREAM, f"failed to create Market for {keyword.term}")

    keyword.market_ref = market.ref
    keyword._writeback("market", market)
    return ok(data={"market": market})


def get_market_stats(keyword: Keyword) -> Result:
    """从 Keyword 直接获取 Market Stats；缺少 Market 时自动级联创建。"""
    if keyword.market is None:
        return err(Code.ERROR_SERVER_INTERNAL, "market dependency was not populated")
    result = keyword.market.get_stats()
    if result.code == Code.OK and keyword.market.stats is not None:
        keyword._writeback("market_stats", keyword.market.stats)
    return result


def get_market_profile(keyword: Keyword) -> Result:
    """从 Keyword 直接获取 Market Profile；自动级联 Market 与 Stats。"""
    if keyword.market is None:
        return err(Code.ERROR_SERVER_INTERNAL, "market dependency was not populated")
    result = keyword.market.get_profile()
    if result.code == Code.OK and keyword.market.profile is not None:
        keyword._writeback("market_profile", keyword.market.profile)
    return result


def get_market_opportunity(keyword: Keyword) -> Result:
    """从 Keyword 直接获取 Market Opportunity；自动级联 Market 与 Stats。"""
    if keyword.market is None:
        return err(Code.ERROR_SERVER_INTERNAL, "market dependency was not populated")
    result = keyword.market.get_opportunity()
    if result.code == Code.OK and keyword.market.opportunity is not None:
        keyword._writeback("market_opportunity", keyword.market.opportunity)
    return result


def get_products(keyword: Keyword, pages: int | None = None) -> Result:
    """获取该关键词的竞品列表。

    调用 competing-lookup by keyword，返回标准化后的竞品 dict 列表。
    结果写回 self.products。
    """
    market_result = keyword.get_market()
    if market_result.code != Code.OK:
        return market_result
    result = keyword.market.get_products(pages=pages)
    if result.code == Code.OK:
        keyword.product_refs = keyword.market.product_refs
        keyword._writeback("products", keyword.market.products)
    return result


def get_related_products(keyword: Keyword, pages: int | None = None) -> Result:
    """获取该关键词的竞品 Product 实体列表。

    先通过 competing-lookup 获取竞品，再将每条转为 Product 实例。
    结果写回 self.products（dict 列表），同时返回 Product 实例列表。
    """
    from amz.entities.product import Product
    result = keyword.get_products(pages=pages)
    if result.code != Code.OK:
        return result

    products = []
    for item in (keyword.products or []):
        # 尝试从 _from_competitor 创建 Product 实例
        from amz.entities.product import Product
        p = Product.from_competitor(item.model_dump(mode="python"), marketplace=keyword.marketplace)
        if p is not None:
            products.append(p)

    return ok(data={"products": products, "count": len(products)})
