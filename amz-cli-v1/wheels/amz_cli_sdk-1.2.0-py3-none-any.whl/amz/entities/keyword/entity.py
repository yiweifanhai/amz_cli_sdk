"""Keyword 的身份、指标字段、依赖规则和公开方法。

使用 marketplace + category + term 标识关键词，管理指标、趋势、聚类和实体引用。
公开方法在这里声明参数与装饰器，再将当前实例交给 metrics、score 或 market。
聚类前规范候选集合，使缓存与本次候选对应；针对目标商品的评分属于一次性任务。
拆分内部文件不会改变 keyword.get_trends() 等直接调用方式。"""

from __future__ import annotations
import inspect
from copy import deepcopy
from functools import wraps
from typing import Any, ClassVar, TYPE_CHECKING, cast
from pydantic import Field, TypeAdapter, ValidationError
from amz.entities._core.base import EnrichSpec, Entity, lazy_field
from amz.entities._core.operations import entity_operation
from amz.entities.keyword import (
    market as market_methods,
    metrics as metrics_methods,
    score as score_methods,
)
from amz.entities.keyword.models import Abapoint, TrendPoint
from amz.envelope import Code, Result, err
from amz.schemas.data_outputs import CompetingItemOutput
from amz.schemas.entity_ref import EntityRef, keyword_ref, normalize_term

if TYPE_CHECKING:
    from amz.entities.market import Market, MarketProfile, MarketStats, Opportunity


def _with_candidate_keywords(method):
    """Resolve supplied candidate data before the lazy cache key is built."""
    @wraps(method)
    def wrapper(self, *args, **kwargs):
        try:
            bound = inspect.signature(method).bind(self, *args, **kwargs)
            bound.apply_defaults()
        except TypeError as exc:
            return err(Code.ERROR_PARAM, str(exc))
        candidates = bound.arguments.get("keywords")
        if candidates is None:
            candidates = self.related_keywords
        if not candidates:
            return err(Code.ERROR_MISSING_FIELDS,
                       "keywords or existing related_keywords required; no candidate set was supplied",
                       missing=["keywords"])
        if not isinstance(candidates, list) or any(not isinstance(item, dict) for item in candidates):
            return err(Code.ERROR_PARAM, "keywords must be a list of keyword objects")
        try:
            terms = [normalize_term(str(item.get("term") or item.get("keyword") or "")) for item in candidates]
        except ValueError as exc:
            return err(Code.ERROR_PARAM, str(exc))
        if any(not term for term in terms) or len(set(terms)) != len(terms):
            return err(Code.ERROR_PARAM, "candidate terms must be non-empty and unique")
        if self.term.casefold() not in terms:
            return err(Code.ERROR_PARAM, "current Keyword.term must belong to the candidate set")
        bound.arguments["keywords"] = deepcopy(candidates)
        return method(*bound.args, **bound.kwargs)
    return wrapper

class Keyword(Entity):
    """Keyword 实体 — 搜索词的完整数据聚合"""

    entity_type: ClassVar[str] = "keyword"
    identity_fields: ClassVar[tuple[str, ...]] = ("marketplace", "category", "term")
    metric_fields: ClassVar[tuple[str, ...]] = (
        "search_volume", "competition", "ppc", "click_rate",
        "conversion_rate", "top3_asins",
    )

    lazy_fields: ClassVar[dict[str, EnrichSpec]] = {
        "metrics": EnrichSpec(
            field="metrics", method="get_metrics",
            depends=[], source="/keyword-miner", ttl_hours=48, version="2",
        ),
        "trends": EnrichSpec(
            field="trends", method="get_trends",
            depends=[], source="/seller-sprite/trends", ttl_hours=48,
        ),
        "aba_series": EnrichSpec(
            field="aba_series", method="get_aba_series",
            depends=[], source="aba_file", ttl_hours=168,
        ),
        "cluster": EnrichSpec(
            field="cluster", method="get_cluster",
            depends=[], invalidates_on=["related_keywords"],
            source="analysis.cluster.keywords", ttl_hours=24, version="2",
        ),
        "market": EnrichSpec(
            field="market", method="get_market",
            depends=[], source="entity.market", ttl_hours=24,
        ),
        "market_stats": EnrichSpec(
            field="market_stats", method="get_market_stats",
            depends=["market"], source="entity.market.stats", ttl_hours=24,
        ),
        "market_profile": EnrichSpec(
            field="market_profile", method="get_market_profile",
            depends=["market_stats"], source="entity.market.profile", ttl_hours=24,
        ),
        "market_opportunity": EnrichSpec(
            field="market_opportunity", method="get_market_opportunity",
            depends=["market_stats"], source="entity.market.opportunity", ttl_hours=24,
        ),
        "products": EnrichSpec(
            field="products", method="get_products",
            depends=[], source="/competing-lookup", ttl_hours=24,
        ),
    }

    # -- 核心字段 ----------------------------------------------------------------

    term: str = Field(min_length=1, json_schema_extra={"alias": "term"})
    marketplace: str = Field(default="US", json_schema_extra={"alias": "marketplace"})
    category: str = Field(default="", json_schema_extra={"alias": "category"})

    search_volume: int | None = Field(default=None, json_schema_extra={"alias": "searchVolume"})
    competition: float | None = Field(default=None, json_schema_extra={"alias": "competition"})
    ppc: float | None = Field(default=None, json_schema_extra={"alias": "ppc"})
    click_rate: float | None = Field(default=None, json_schema_extra={"alias": "clickRate"})
    conversion_rate: float | None = Field(default=None, json_schema_extra={"alias": "conversionRate"})
    top3_asins: list[str] = Field(default_factory=list, json_schema_extra={"alias": "topAsins"})

    # ABA 排名
    aba_rank: int | None = Field(default=None, json_schema_extra={"alias": "abaRank"})
    aba_history: list[Abapoint] = Field(default_factory=list, json_schema_extra={"alias": "abaHistory"})

    # 趋势
    sv_trend: list[TrendPoint] = Field(default_factory=list, json_schema_extra={"alias": "svTrend"})

    # 来自反向查找
    traffic_pct: float | None = Field(default=None, json_schema_extra={"alias": "trafficPercentage"})
    natural_ratio: float | None = Field(default=None, json_schema_extra={"alias": "naturalRatio"})
    ad_ratio: float | None = Field(default=None, json_schema_extra={"alias": "adRatio"})
    rank: int | None = Field(default=None, json_schema_extra={"alias": "rankPosition"})

    # -- lazy 字段 ---------------------------------------------------------------

    related_keywords: list[dict[str, Any]] | None = None
    trends: list[dict[str, Any]] | None = None
    aba_series: list[dict[str, Any]] | None = None
    cluster: dict[str, Any] | None = None
    market_ref: EntityRef | None = None
    market: Market | None = Field(default=None, exclude=True)                          # 该词的市场分析实体
    market_stats: MarketStats | None = Field(default=None, exclude=True)
    market_profile: MarketProfile | None = Field(default=None, exclude=True)
    market_opportunity: Opportunity | None = Field(default=None, exclude=True)
    product_refs: list[EntityRef] | None = None
    products: list[CompetingItemOutput] | None = Field(default=None, exclude=True)

    # ------------------------------------------------------------------
    # 工厂方法
    # ------------------------------------------------------------------

    @classmethod
    def fetch(
        cls,
        term: str,
        marketplace: str = "US",
        category: str = "",
        force_refresh: bool = False,
    ) -> Keyword | None:
        """从 API 获取 Keyword（core 字段）"""
        ref = keyword_ref(marketplace, category, term)
        marketplace, category, term = ref.key
        cache_id = ref.cache_id
        cached = cls.load(cache_id)
        if cached is not None and not force_refresh and cached._check_field("metrics", cached._default_field_cache_key("metrics")):
            return cached

        if marketplace != "US" or category:
            return None
        from amz.data.keyword import keyword_miner
        result = keyword_miner(term)
        if result.code != Code.OK or not result.data:
            return None
        items = (result.data or {}).get("items", [])
        if not items:
            return None
        try:
            items, values = cls._validate_metrics(items, term)
        except (ValidationError, ValueError):
            return None
        if cached is None:
            instance = cls(term=term, marketplace=marketplace, category=category)
        else:
            instance = cached
        instance._cache_id = cache_id
        instance._save_metrics(items, values)
        return instance

    @classmethod
    def _validate_metrics(cls, items: Any, term: str) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        """Validate the full update before touching identity, relations or metrics."""
        rows = TypeAdapter(list[dict[str, Any]]).validate_python(items)
        if not rows:
            raise ValueError("keyword metrics require at least one item")
        matched = next((row for row in rows if normalize_term(str(
            row.get("term") or row.get("keyword") or ""
        )) == normalize_term(term)), None)
        if matched is None:
            raise ValueError("keyword metrics do not contain the requested keyword")
        values = {}
        for name in cls.metric_fields:
            field = cls.model_fields[name]
            value = matched.get(name, field.get_default(call_default_factory=True))
            values[name] = TypeAdapter(field.rebuild_annotation()).validate_python(value)
        return deepcopy(rows), values

    def _save_metrics(self, items: list[dict[str, Any]], values: dict[str, Any]) -> None:
        for name, value in values.items():
            if getattr(self, name) != value:
                setattr(self, name, value)
                self._invalidate_dependents(name)
        self.related_keywords = items
        self._mark_fetched("related_keywords")
        self._mark_fetched("metrics")
        self.save()

    def _field_result_data(self, field: str, fallback: Any) -> Any:
        if field == "metrics":
            # Metrics are a virtual lazy field that fills several owned facts.
            # Read those facts for cold calls and legacy caches alike.
            return self.model_dump(include=set(self.identity_fields + self.metric_fields), mode="json")
        return super()._field_result_data(field, fallback)

    @classmethod
    def from_reverse(
        cls,
        data: dict[str, Any],
        *,
        marketplace: str = "US",
        category: str = "",
    ) -> Keyword | None:
        """从 reverse_keywords 的 dict item 构造轻量 Keyword 实例。

        不触发 API 调用，仅使用已有的反向查找数据。
        """
        try:
            term = data.get("term") or data.get("keywords") or data.get("keyword") or ""
            if not term:
                return None
            instance = cls(
                term=term,
                marketplace=marketplace,
                category=category,
                search_volume=data.get("searches") or data.get("search_volume"),
                competition=data.get("competition"),
                ppc=data.get("ppc") if data.get("ppc") is not None else data.get("exactPpc"),
                traffic_pct=(
                    data.get("trafficPercentage")
                    or data.get("traffic_pct")
                ),
                natural_ratio=data.get("naturalRatio") or data.get("natural_ratio"),
                ad_ratio=data.get("adRatio") or data.get("ad_ratio"),
                rank=data.get("rankExactSearches") or data.get("rank"),
                top3_asins=data.get("topAsins") or data.get("top3_asins", []),
            )
            instance._cache_id = instance.ref.cache_id
            instance._remember()
            return instance
        except Exception:
            return None

    @classmethod
    def _from_reverse(cls, data: dict[str, Any]) -> Keyword | None:
        """兼容旧内部名称；新代码使用 :meth:`from_reverse`。"""
        return cls.from_reverse(data)

    # ------------------------------------------------------------------
    # 实体方法
    # ------------------------------------------------------------------

    @lazy_field("metrics")
    def get_metrics(self) -> Result:
        """获取关键词特征（core 字段刷新）"""
        return metrics_methods.get_metrics(self)

    def expand(self) -> Result:
        """拓展关键词"""
        return metrics_methods.expand(self)

    @lazy_field("trends")
    def get_trends(self) -> Result:
        """获取关键词搜索量趋势时间序列（写入 self.trends）"""
        return metrics_methods.get_trends(self)

    @lazy_field("aba_series")
    def get_aba_series(self, csv_path: str = "") -> Result:
        """获取关键词 ABA 周排名序列（需 csv_path 指向 ABA CSV 文件）"""
        return metrics_methods.get_aba_series(self, csv_path=csv_path)

    @lazy_field("market")
    def get_market(self) -> Result:
        """获取该关键词的市场分析实体。

        只创建并写回 Market 对象；Stats、Profile 与 Opportunity 由各自的
        lazy 方法按需级联，避免仅访问对象时提前拉取竞品数据。
        """
        return market_methods.get_market(self)

    @lazy_field("market_stats")
    def get_market_stats(self) -> Result:
        """从 Keyword 直接获取 Market Stats；缺少 Market 时自动级联创建。"""
        return market_methods.get_market_stats(self)

    @lazy_field("market_profile")
    def get_market_profile(self) -> Result:
        """从 Keyword 直接获取 Market Profile；自动级联 Market 与 Stats。"""
        return market_methods.get_market_profile(self)

    @lazy_field("market_opportunity")
    def get_market_opportunity(self) -> Result:
        """从 Keyword 直接获取 Market Opportunity；自动级联 Market 与 Stats。"""
        return market_methods.get_market_opportunity(self)

    # ------------------------------------------------------------------
    # Python object API: Keyword -> Market -> typed market information
    # ------------------------------------------------------------------

    def require_market(self) -> Market:
        """Return this keyword's typed ``Market`` object, loading it if needed."""
        return cast(
            "Market",
            self._require_field_value("market", self.get_market()),
        )

    def require_market_stats(self) -> MarketStats:
        """Return typed market statistics directly from a Keyword."""
        return cast(
            "MarketStats",
            self._require_field_value("market_stats", self.get_market_stats()),
        )

    def require_market_profile(self) -> MarketProfile:
        """Return the typed market profile directly from a Keyword."""
        return cast(
            "MarketProfile",
            self._require_field_value("market_profile", self.get_market_profile()),
        )

    def require_market_opportunity(self) -> Opportunity:
        """Return the typed market opportunity directly from a Keyword."""
        return cast(
            "Opportunity",
            self._require_field_value(
                "market_opportunity", self.get_market_opportunity(),
            ),
        )

    @lazy_field("products")
    def get_products(self, pages: int | None = None) -> Result:
        """获取该关键词的竞品列表。

        调用 competing-lookup by keyword，返回标准化后的竞品 dict 列表。
        结果写回 self.products。
        """
        return market_methods.get_products(self, pages=pages)

    def _prepare_dependencies(self, field: str, call_params: dict) -> Result | None:
        if field in {"market_stats", "market_profile", "market_opportunity", "products"}:
            self._invalidate_field(field)
        return None

    @_with_candidate_keywords
    @entity_operation("score", analysis_ids=("analysis.keyword.score",))
    def get_score(
        self,
        product_ref: EntityRef,
        keywords: list[dict[str, Any]] | None = None,
    ) -> Result:
        """补齐目标商品和候选词四维评分指标；结果属于本次任务，不保存为全局分数。"""
        return score_methods.get_score(self, product_ref=product_ref, keywords=keywords)

    def get_related_products(self, pages: int | None = None) -> Result:
        """获取该关键词的竞品 Product 实体列表。

        先通过 competing-lookup 获取竞品，再将每条转为 Product 实例。
        结果写回 self.products（dict 列表），同时返回 Product 实例列表。
        """
        return market_methods.get_related_products(self, pages=pages)

    @_with_candidate_keywords
    @lazy_field("cluster")
    def get_cluster(
        self,
        keywords: list[dict[str, Any]] | None = None,
        seed_count: int = 30,
        batch_size: int = 50,
    ) -> Result:
        """对显式候选或已有 related_keywords 做意图聚类，当前词作为主词。"""
        return score_methods.get_cluster(
            self,
            keywords=keywords,
            seed_count=seed_count,
            batch_size=batch_size,
        )
