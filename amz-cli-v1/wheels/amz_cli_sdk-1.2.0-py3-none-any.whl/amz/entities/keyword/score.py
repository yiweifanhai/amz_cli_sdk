"""Keyword 的任务评分和意图聚类。

评分准备目标商品、候选词及所需指标，再调用 Analysis；结果只属于本次任务，
不保存为关键词的全局分数。聚类使用显式候选或已有 related_keywords，
以当前词为主词，并将成功结果写回 cluster 字段。
两种能力均从 Keyword 的公开方法进入，候选检查与缓存规则由实体声明配合完成。"""

from __future__ import annotations
from typing import Any, TYPE_CHECKING
from amz.entities._core import operations
from amz.envelope import Code, Result, err
from amz.schemas.entity_ref import EntityRef, keyword_ref, normalize_term

if TYPE_CHECKING:
    from amz.entities.keyword.entity import Keyword


def get_score(
    keyword: Keyword,
    product_ref: EntityRef,
    keywords: list[dict[str, Any]] | None = None,
) -> Result:
    """补齐目标商品和候选词四维评分指标；结果属于本次任务，不保存为全局分数。"""
    from amz.entities._core.store import entity_store
    from amz.calc.keyword.score import SCORE_METRICS, _normalize_keyword_row, keyword_score_missing
    if product_ref.entity_type != "product" or product_ref.identity["marketplace"] != keyword.marketplace:
        return err(Code.ERROR_PARAM, "product_ref must identify a Product in the same marketplace")
    try:
        rows = [_normalize_keyword_row(item) for item in keywords]
    except (TypeError, ValueError, OverflowError) as exc:
        return err(Code.ERROR_PARAM, f"invalid keyword metrics: {exc}")
    product = entity_store.get_or_create(product_ref)
    result = product.get_product_details()
    if result.code != Code.OK:
        return result
    failure = product._check_analysis_facts(listing=True)
    if failure is not None:
        return failure
    failures = []
    metric_fields = {name for fields in SCORE_METRICS.values() for name in fields}
    for row in rows:
        if not keyword_score_missing([row]):
            continue
        term = normalize_term(row["keyword"])
        candidate = entity_store.get_or_create(keyword_ref(keyword.marketplace, keyword.category, term))
        metrics = candidate.get_metrics()
        if metrics.code != Code.OK:
            failures.append({"keyword": term, "code": metrics.code, "message": metrics.message})
            continue
        # A miner may return related words. Only the exact candidate can
        # supply that candidate's facts; never use the first unrelated row.
        source_item = next((item for item in (candidate.related_keywords or [])
                            if str(item.get("term") or item.get("keyword") or "").strip()
                            and normalize_term(str(item.get("term") or item.get("keyword"))) == term), None)
        if source_item is None:
            failures.append({"keyword": term, "message": "source did not return the requested keyword"})
            continue
        try:
            source = _normalize_keyword_row(source_item)
        except (TypeError, ValueError, OverflowError) as exc:
            failures.append({"keyword": term, "message": f"invalid source metrics: {exc}"})
            continue
        for name in metric_fields:
            if row.get(name) is None:
                row[name] = source.get(name)
        # Coverage can become available after merging real volume and exposure.
        row.update(_normalize_keyword_row(row))
    missing = keyword_score_missing(rows)
    if missing:
        return err(Code.ERROR_MISSING_FIELDS, "candidate keyword metrics could not satisfy all scoring dimensions",
                   data={"unavailable_sources": failures}, missing=missing)
    return operations.run_analysis("analysis.keyword.score", {
        "keywords": rows, "product_info": product.to_product_info(),
    })


def get_cluster(
    keyword: Keyword,
    keywords: list[dict[str, Any]] | None = None,
    seed_count: int = 30,
    batch_size: int = 50,
) -> Result:
    """对显式候选或已有 related_keywords 做意图聚类，当前词作为主词。"""
    from amz.analysis.keyword.cluster import cluster_keywords
    result = cluster_keywords(keywords=keywords, main_keyword=keyword.term,
                              seed_count=seed_count, batch_size=batch_size)
    if result.code == Code.OK:
        keyword._writeback("cluster", result.data)
    return result
