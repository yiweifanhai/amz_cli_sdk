"""Entity 层的统一导入入口，以及实体类型注册。

对外提供 Product、Keyword、Market、ProductDraft 和淘宝实体及相关数据模型。
导入完成后解析模型之间的类型引用，并向本地 EntityStore 注册实体类型；
公开能力的注册由 _core/bridge.py 负责。业务实现按所属实体放在各自目录中，
调用者仍通过同一个实例访问字段和方法，例如 product.listing_rewrite()。"""

from amz.entities._core.base import Entity, EnrichSpec, lazy_field
from amz.entities._core.store import entity_registry, entity_store
from amz.schemas.entity_ref import EntityRef, product_ref, market_ref, keyword_ref
from amz.entities.product import Product, ProductDetails
from amz.entities.product.draft import ProductDraft, DraftFacts
from amz.entities.keyword import Keyword, KeywordScore, KeywordCluster, TrendPoint, Abapoint
from amz.entities.market import Market, MarketStats, MarketProfile, Opportunity, PriceBand, PriceStats, RatingStats, MonopolyStats, SellerStats
from amz.entities.product.models import Supplier
from amz.entities.product.reviews import ReviewData, ReviewItem
from amz.entities.product.finance import FinanceData
from amz.entities.product.models import Assessment
from amz.entities.taobao import TaobaoProduct, TaobaoMarket

# -- 解决跨模块前向引用 -----------------------------------------------------------
# Product 引用了 ReviewData / FinanceData / Market，Keyword 引用了 Market，
# 这些类型定义在独立模块中。model_rebuild() 在全部导入完成后解析前向引用。
Product.model_rebuild()
Keyword.model_rebuild()
Market.model_rebuild()
ReviewData.model_rebuild()

for _entity_cls in (Product, Keyword, Market, ReviewData, TaobaoProduct, TaobaoMarket, ProductDraft):
    entity_registry.register(_entity_cls)

__all__ = [
    "Entity", "EnrichSpec", "lazy_field", "entity_registry", "entity_store",
    "EntityRef", "product_ref", "market_ref", "keyword_ref",
    "TaobaoProduct", "TaobaoMarket",
    "Product", "ProductDetails",
    "ProductDraft", "DraftFacts",
    "Keyword", "KeywordScore", "KeywordCluster", "TrendPoint", "Abapoint",
    "Market", "MarketStats", "MarketProfile", "Opportunity",
    "PriceBand", "PriceStats", "RatingStats", "MonopolyStats", "SellerStats",
    "Supplier",
    "ReviewData", "ReviewItem",
    "FinanceData",
    "Assessment",
]
