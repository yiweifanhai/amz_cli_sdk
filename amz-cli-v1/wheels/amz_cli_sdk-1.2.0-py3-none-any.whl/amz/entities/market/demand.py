"""Market 需求评分的数据准备与证据检查。

接收明确的 Google 趋势证据，补齐或校验 Amazon 搜索趋势与市场样本数据，
检查词、站点、日期和连续月份是否匹配，再调用 Calc 的需求评分。
返回结果附带来源和样本信息，缺失的可选观察值保持未知。
由 Market.demand() 调用，结果属于本次任务，不保存为长期市场字段。"""

from __future__ import annotations
import math
from datetime import date
from typing import Annotated, TYPE_CHECKING
from pydantic import Field
from amz.entities._core import operations
from amz.entities.market.models import (
    EvidenceSource,
    GoogleDemandEvidence,
    MarketDemandEvidence,
    MarketEvidence,
    TrendEvidence,
)
from amz.envelope import Code, Result, err
from amz.schemas.entity_ref import EntityRef, keyword_ref, product_ref

if TYPE_CHECKING:
    from amz.entities.market.entity import Market


def _demand_amazon(market: Market, amazon_evidence: TrendEvidence | None, evidence: MarketEvidence):
    from amz.entities._core.store import entity_store
    ref = None
    if amazon_evidence is None:
        ref = keyword_ref(market.marketplace, market.category, market.term)
        keyword = entity_store.get_or_create(ref)
        result = keyword.get_trends()
        if result.code != Code.OK:
            return result
        try:
            amazon_evidence = TrendEvidence(
                term=market.term, marketplace=market.marketplace, source="entity.keyword.trends",
                observed_at=date.today(), points=keyword.trends or [],
            )
        except ValueError:
            return market._action_missing("demand requires valid Amazon search-volume observations", "amazon_trends", evidence)
    if " ".join(amazon_evidence.term.split()).casefold() != market.term or amazon_evidence.marketplace.upper() != market.marketplace:
        return err(Code.ERROR_PARAM, "Amazon evidence must match the Market term and marketplace")
    if amazon_evidence.observed_at > date.today():
        return err(Code.ERROR_PARAM, "Amazon evidence cannot be observed in the future")
    months = {}
    for point in amazon_evidence.points:
        key = point.date.year * 12 + point.date.month
        if key in months:
            return err(Code.ERROR_PARAM, "Amazon demand evidence must have one search-volume observation per month")
        months[key] = point.value
    latest = max(months)
    if any(month not in months for month in range(latest - 12, latest + 1)):
        return market._action_missing("demand needs 13 consecutive monthly Amazon observations for a year-over-year comparison", "amazon_trends.13_months", evidence)
    if months[latest - 12] <= 0:
        return market._action_missing("last-year Amazon search volume must be positive to calculate year-over-year change", "amazon_trends.previous_year", evidence)
    yoy = (months[latest] / months[latest - 12] - 1) * 100
    if not math.isfinite(yoy):
        return err(Code.ERROR_PARAM, "Amazon year-over-year change must be finite")
    evidence.sources.append(EvidenceSource(
        source=amazon_evidence.source, ref=ref, fields=["amazon_trends"], updated_at=amazon_evidence.observed_at.isoformat(),
        detail=f"13 consecutive months; comparison {amazon_evidence.points[-1].date.isoformat()}; yoy_pct={yoy:.6g}",
    ))
    return {"yoy_pct": yoy, "source": amazon_evidence.source, "observed_at": amazon_evidence.observed_at.isoformat(),
            "points": [point.model_dump(mode="json") for point in amazon_evidence.points]}


def _demand_market(market: Market, market_evidence: MarketDemandEvidence | None, evidence: MarketEvidence, pages: int | None):
    if market_evidence is not None:
        if " ".join(market_evidence.term.split()).casefold() != market.term or market_evidence.marketplace.upper() != market.marketplace:
            return err(Code.ERROR_PARAM, "market demand evidence must match the Market term and marketplace")
        evidence.sources.append(EvidenceSource(source=market_evidence.source, fields=["market_data"], updated_at=market_evidence.observed_at.isoformat()))
        return market_evidence.model_dump(mode="json", include={"monthly_avg_revenue_usd", "search_purchase_ratio_permille"})
    result = market.get_stats(pages=pages)
    if result.code != Code.OK:
        return result
    rows = market.products or []
    evidence.sample_size = len(rows)
    valid = [row for row in rows if row.price_usd is not None and math.isfinite(row.price_usd) and row.price_usd > 0
             and row.monthly_sales is not None and row.monthly_sales >= 0]
    evidence.used_count = len(valid)
    if len(rows) < 3 or len(valid) != len(rows):
        return market._action_missing("market demand needs at least 3 sample Products, each with a price and observed monthly sales", "products.price_usd/monthly_sales", evidence)
    mean_revenue = sum(row.price_usd * row.monthly_sales for row in valid) / len(valid)
    if not math.isfinite(mean_revenue):
        return err(Code.ERROR_PARAM, "sample monthly revenue must be finite")
    stamps = {EntityRef.model_validate(item["ref"]): item.get("updated_at") for item in market.product_sources}
    evidence.sources.extend(EvidenceSource(
        source="entity.product.core", ref=product_ref(market.marketplace, row.asin), fields=["price_usd", "monthly_sales"],
        updated_at=stamps.get(product_ref(market.marketplace, row.asin)),
        detail=f"price_usd={row.price_usd}; monthly_sales={row.monthly_sales}",
    ) for row in valid)
    evidence.sources.append(EvidenceSource(source="entity.market.stats/products", ref=market.ref, fields=["stats", "products"], updated_at=market._fetched_at.get("stats"),
                                           detail="sample mean of Product price_usd × monthly_sales; purchase/search ratio is unavailable"))
    return {"monthly_avg_revenue_usd": mean_revenue, "search_purchase_ratio_permille": None}


def demand(market: Market, google_evidence: GoogleDemandEvidence, amazon_evidence: TrendEvidence | None = None,
           market_evidence: MarketDemandEvidence | None = None, pages: Annotated[int, Field(ge=1, le=3)] | None = None) -> Result:
    """Prepare real Google, Amazon year-over-year, and market sample evidence."""
    if " ".join(google_evidence.term.split()).casefold() != market.term or google_evidence.marketplace.upper() != market.marketplace:
        return err(Code.ERROR_PARAM, "Google demand evidence must match the Market term and marketplace")
    evidence = MarketEvidence(market_ref=market.ref, sources=[EvidenceSource(
        source=google_evidence.source, fields=["google_trends"], updated_at=google_evidence.observed_at.isoformat(),
        detail=f"{google_evidence.period_start}/{google_evidence.period_end}; baseline={google_evidence.baseline_term}",
    )])
    amazon = market._demand_amazon(amazon_evidence, evidence)
    if isinstance(amazon, Result):
        return amazon
    market_data = market._demand_market(market_evidence, evidence, pages)
    if isinstance(market_data, Result):
        return market_data
    optional_metrics = {"slope_pct", "has_seasonality", "peak_month", "season_ratio", "yearly", "yoy"}
    metrics = google_evidence.model_dump(mode="json", exclude_none=True,
                                        include={"target_avg", "baseline_avg", "cagr_3y", "trend_direction"} | optional_metrics)
    result = operations.run_calc("calc.demand.score", {
        "keyword": market.term, "google_trends": metrics, "amazon_trend": amazon, "market_data": market_data,
    })
    if result.code == Code.OK:
        # Optional context is not part of the scoring formula. Preserve unknown
        # observations instead of exposing the legacy Calc's neutral defaults.
        for name in optional_metrics:
            if getattr(google_evidence, name) is None:
                result.data["data"][name] = None
    return market._with_action_evidence(result, evidence)
