"""Market 多商品任务共用的样本与证据检查。

检查 Product 引用的类型、站点和去重后数量，逐个取得有效评论与 VOC，
记录使用数量、数据来源和失败原因，供缺口、成功因子、提案等任务共用。
样本不足时返回具体缺项；成功时可将证据附到任务结果。
本文件只提供内部辅助函数，不直接注册公开能力或保存新的市场分析字段。"""

from __future__ import annotations
from typing import TYPE_CHECKING
from amz.entities.market.models import EvidenceSource, MarketEvidence
from amz.envelope import Code, Result, err
from amz.schemas.entity_ref import EntityRef

if TYPE_CHECKING:
    from amz.entities.market.entity import Market


def _action_refs(market: Market, sample_refs: list[EntityRef] | None, pages: int) -> list[EntityRef] | Result:
    if sample_refs is None:
        result = market.get_product_refs(pages=pages)
        if result.code != Code.OK:
            return result
        sample_refs = market.product_refs or []
    refs = list(dict.fromkeys(sample_refs))
    if any(ref.entity_type != "product" or ref.identity["marketplace"] != market.marketplace for ref in refs):
        return err(Code.ERROR_PARAM, "sample_refs must be Product references in the Market marketplace")
    if len(refs) < 3:
        return err(Code.ERROR_MISSING_FIELDS, "market analysis requires at least 3 distinct Product references", missing=["sample_refs"])
    return refs


def _action_voc(market: Market, sample_refs: list[EntityRef] | None, pages: int):
    from amz.entities._core.store import entity_store
    refs = market._action_refs(sample_refs, pages)
    if isinstance(refs, Result):
        return refs
    products = []
    evidence = MarketEvidence(market_ref=market.ref, sample_size=len(refs))
    for ref in refs:
        product = entity_store.get_or_create(ref)
        result = product.get_reviews()
        note = EvidenceSource(source="entity.product.voc", ref=ref, fields=["reviews", "voc"])
        evidence.sources.append(note)
        if result.code != Code.OK:
            note.state, note.detail = result.code.value, result.message
            continue
        reviews = product.to_review_items()
        if not any(str(item.get("text") or "").strip() for item in reviews):
            note.state, note.detail = "no_evidence", "no review text"
            continue
        result = product.get_voc()
        if result.code != Code.OK or product.voc is None:
            note.state, note.detail = result.code.value, result.message or "VOC missing"
            continue
        note.updated_at = product._fetched_at.get("voc")
        products.append(product)
    evidence.used_count = len(products)
    if len(products) < 3:
        return market._action_missing("market analysis requires at least 3 Products with review text and complete VOC", "reviews/voc", evidence)
    return products, evidence


def _action_missing(message: str, field: str, evidence: MarketEvidence) -> Result:
    return err(Code.ERROR_MISSING_FIELDS, message, missing=[field], data={"evidence": evidence.model_dump(mode="json")})


def _with_action_evidence(result: Result, evidence: MarketEvidence) -> Result:
    if result.code == Code.OK:
        result.data = {**result.data, "evidence": evidence.model_dump(mode="json")}
    return result
