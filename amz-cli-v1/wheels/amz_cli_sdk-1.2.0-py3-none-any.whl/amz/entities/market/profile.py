"""Market 的统计、画像、机会评分和样本摘要。

从已准备的商品样本调用 Calc 计算统计、画像与机会分，
调用 Analysis 概述样本的解决方案、人群和场景，并将结果写回对应字段。
由 Market 的字段方法进入，依赖加载和缓存有效期由实体统一管理；
独立业务公式和语义分析仍放在 Calc 与 Analysis 中。"""

from __future__ import annotations
from typing import TYPE_CHECKING
from amz.entities.market.models import SummaryPages
from amz.envelope import Code, Result, ok
from amz.schemas.amazon_analysis import AmazonMarketSummary

if TYPE_CHECKING:
    from amz.entities.market.entity import Market


def get_stats(market: Market, pages: SummaryPages | None = None) -> Result:
    """计算市场画像统计（价格带/评分/上架时间/垄断度/卖家结构）"""
    from amz.calc.market.stats import calculate_stats
    stats = calculate_stats([
        item.model_dump(mode="python") for item in (market.products or [])
    ])
    stats["sample"] = market._sample_info()
    market._writeback("stats", stats)
    return ok(data=market.stats)


def get_profile(market: Market, pages: SummaryPages | None = None) -> Result:
    """8 维市场画像（综合评分，委托 calc.market.calculate_profile）"""
    from amz.calc.market.profile import calculate_profile
    profile = calculate_profile(
        market.stats.model_dump(mode="python"), keyword=market.term,
    )
    profile["sample"] = market.stats.sample
    market._writeback("profile", profile)
    return ok(data=market.profile)


def get_opportunity(market: Market, pages: SummaryPages | None = None) -> Result:
    """市场机会/缺口分析（gap + 微改造提案 + 机会分，委托 calc.market.opportunity）"""
    from amz.calc.market.opportunity import calculate_opportunity_score
    opportunity = calculate_opportunity_score(
        market.stats.model_dump(mode="python"), keyword=market.term,
    )
    opportunity["sample"] = market.stats.sample
    market._writeback("opportunity", opportunity)
    return ok(data=market.opportunity)


def get_summary(market: Market, pages: SummaryPages | None = None, model: str = "pro") -> Result:
    """按解决方案分类竞品样本，概述人群、场景并保留 ASIN"""
    from amz.analysis.market.classify import market_classify

    result = market_classify(
        term=market.term,
        products=[{"asin": p.asin, "title": p.title} for p in (market.products or [])],
        model=model,
    )
    if result.code == Code.OK:
        market._writeback("summary", AmazonMarketSummary.model_validate(result.data))
    return result
