"""Prepare the selected Products and SIF evidence for a Market TACOS task."""

from __future__ import annotations

from datetime import date, datetime
import math
from typing import TYPE_CHECKING
from zoneinfo import ZoneInfo

from amz.entities._core.operations import run_calc
from amz.envelope import Code, Result, err
from amz.schemas.entity_ref import EntityRef, normalize_term
from amz.schemas.tacos import TacosFailure

if TYPE_CHECKING:
    from amz.entities.market.entity import Market


def _number(value, maximum=None):
    if type(value) not in (int, float) or not math.isfinite(value) or value < 0:
        return None
    return float(value) if maximum is None or value <= maximum else None


def _acos(data: dict, term: str, strategy: str, category_id: str | None):
    matches = [row for row in data.get("items", []) if row.get("term") and normalize_term(row["term"]) == normalize_term(term)]
    if len(matches) != 1:
        return None, None
    row = matches[0]
    value = row.get("acos")
    if isinstance(value, dict):
        entries = value.get(strategy)
        if not isinstance(entries, list):
            return None, row.get("period")
        if category_id is not None:
            entries = [entry for entry in entries if isinstance(entry, dict) and str(entry.get("categoryid")) == category_id]
        if len(entries) != 1 or not isinstance(entries[0], dict):
            return None, row.get("period")
        value = entries[0].get("median")
    return _number(value), row.get("period")


def _ad_ratio(items, term):
    matches = [row for row in items or [] if row.term and normalize_term(row.term) == normalize_term(term)]
    if len(matches) != 1:
        return None, "reverse_keywords.target_keyword"
    row = matches[0]
    if row.ad_ratio is not None:
        value = _number(row.ad_ratio, 100)
        return (value / 100, None) if value is not None else (None, "reverse_keywords.ad_ratio")
    value = _number(row.natural_ratio, 100)
    return (1 - value / 100, None) if value is not None else (None, "reverse_keywords.ad_ratio")


def calculate_tacos(
    market: Market, sample_refs: list[EntityRef] | None = None, pages: int | None = None,
    current_date: date | None = None, shipping_method: str = "slow",
    exchange_rate: float | None = None, referral_rate: float = 0.15,
    acos_strategy: str = "legacyForSales_exact", acos_category_id: str | None = None,
) -> Result:
    if market.marketplace != "US" or market.category:
        return err(Code.ERROR_PARAM, "TACOS currently supports marketplace US and no category filter only")
    explicit_sample = sample_refs is not None
    if sample_refs is None:
        selected = market.get_product_refs(pages=pages if pages is not None else market._selected_pages())
        if selected.code != Code.OK:
            return selected
        sample_refs = market.product_refs or []
    refs = list(dict.fromkeys(sample_refs))
    if any(ref.entity_type != "product" or ref.identity["marketplace"] != market.marketplace for ref in refs):
        return err(Code.ERROR_PARAM, "sample_refs must identify Products in the Market marketplace")
    if not refs:
        return err(Code.ERROR_MISSING_FIELDS, "no Products in the market sample", missing=["sample_refs"])

    from amz.entities._core.store import entity_store
    prepared, failed, sources = [], [], []
    for ref in refs:
        product = entity_store.get_or_create(ref)
        failure = product._calc_core()
        if failure is None:
            failure = product._check_finance_facts()
        if failure is not None:
            failed.append(TacosFailure(ref=ref, code=failure.code.value, message=failure.message, missing=failure.meta.missing or []))
            continue
        prepared.append(product)
    if not prepared:
        return err(Code.ERROR_MISSING_FIELDS, "no Products with valid price, package weight and dimensions",
                   missing=["products.finance_facts"], data={"failed": [row.model_dump(mode="json") for row in failed]})

    from amz.data.ads import ads_keyword_funnel
    funnel = ads_keyword_funnel([market.term])
    if funnel.code != Code.OK:
        return funnel
    acos, period = _acos(funnel.data or {}, market.term, acos_strategy, acos_category_id)
    if acos is None:
        return err(Code.ERROR_MISSING_FIELDS, "target keyword ACOS is missing or ambiguous; select acos_strategy and acos_category_id",
                   missing=["keyword_acos"], data={"keyword": market.term, "strategy": acos_strategy, "category_id": acos_category_id})
    rate_info = {"source": "manual"}
    if exchange_rate is None:
        from amz.data.fx import exchange_rate as fetch_rate
        rate = fetch_rate("USD", "CNY")
        if rate.code != Code.OK:
            return rate
        exchange_rate, rate_info = rate.data["rate"], rate.data

    rows = []
    for product in prepared:
        reverse = product.get_reverse_keywords()
        ratio, missing = (None, "reverse_keywords")
        if reverse.code == Code.OK:
            ratio, missing = _ad_ratio(product.reverse_keywords, market.term)
        else:
            failed.append(TacosFailure(ref=product.ref, code=reverse.code.value, message=reverse.message, missing=["reverse_keywords"]))
        rows.append({
            "asin": product.asin, "price_usd": product.price_usd, "weight_g": product.weight_g,
            "dimensions_cm": product._project_pkg_dims(), "fba_fee": product.fba_fee,
            "available_date": product.available_date or product.listing_date,
            "ad_ratio": ratio, "missing": [missing] if missing else [],
        })
        sources.append({
            "ref": product.ref.model_dump(mode="json"), "core_updated_at": product._fetched_at.get("core"),
            "reverse_keywords_updated_at": product._fetched_at.get("reverse_keywords"),
            "ad_ratio_source": "ad_ratio" if ratio is not None and any(
                row.term and normalize_term(row.term) == normalize_term(market.term) and row.ad_ratio is not None
                for row in product.reverse_keywords or []
            ) else "natural_ratio" if ratio is not None else "missing",
            "reverse_keywords_state": reverse.code.value,
        })
    today = current_date or datetime.now(ZoneInfo("Asia/Shanghai")).date()
    result = run_calc("calc.market.tacos", {
        "keyword": market.term, "keyword_acos": acos, "products": rows, "current_date": today,
        "exchange_rate": exchange_rate, "shipping_method": shipping_method, "referral_rate": referral_rate,
    })
    if result.code != Code.OK:
        return result
    result.data.update({"total_products": len(refs), "failed": [row.model_dump(mode="json") for row in failed], "sources": sources})
    result.data["assumptions"].update({
        "acos_source": "ads.keyword-funnel", "acos_strategy": acos_strategy, "acos_category_id": acos_category_id,
        "acos_period": period, "exchange_rate_source": rate_info,
        "sample": {"source": "explicit_product_refs", "product_count": len(refs)} if explicit_sample else market._sample_info().model_dump(mode="json"),
    })
    if not result.data["products_with_ad_data"]:
        return err(Code.ERROR_MISSING_FIELDS, "no Products with valid ad share for the target keyword",
                   missing=["reverse_keywords.ad_ratio"], data=result.data)
    return result
