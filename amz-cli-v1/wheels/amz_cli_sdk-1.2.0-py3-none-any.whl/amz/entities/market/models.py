"""Market 的统计、分析结果、证据和参数模型。

定义价格带、评分与卖家结构、市场画像、机会评分，以及需求、时机、提案、
维度和 COSMO 任务的输入输出结构。证据模型记录来源、样本和观察时间，
参数类型约束页数、数量等条件。
这些模型用于校验与表达数据，实际取数和分析由 Market 方法组织。"""

from __future__ import annotations
from datetime import date
from typing import Annotated, Any, Literal
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    StringConstraints,
    field_validator,
    model_validator,
)
from amz.schemas.cosmo import CosmoAggregateOutput, CosmoMergeOutput, CosmoSource
from amz.schemas.demand import DemandOutput, TimingOutput
from amz.schemas.entity_ref import EntityRef
from amz.schemas.market_analysis import MarketGapOutput, ProposalsOutput, SuccessFactorsOutput
from amz.schemas.traffic import DimensionsOutput, PrimaryDimensionOutput


SummaryPages = Annotated[int, Field(ge=1, le=3)]


MinSuccess = Annotated[int, Field(ge=1)]


class PriceBand(BaseModel):
    """价格带"""
    label: str = ""
    min: float = 0.0
    max: float = 0.0
    count: int = 0
    share_pct: float = 0.0


class PriceStats(BaseModel):
    """价格统计"""
    p25: float | None = None
    p50: float | None = None
    p75: float | None = None
    band_count: int = 0
    bands: list[PriceBand] = Field(default_factory=list)


class RatingStats(BaseModel):
    """评分统计"""
    avg: float | None = None
    dist: dict[str, int] = Field(default_factory=dict)


class MonopolyStats(BaseModel):
    """垄断度统计"""
    cr10: float | None = None       # Top10 品牌份额
    cr20: float | None = None       # Top20 品牌份额
    top_brand_share: float | None = None


class SellerStats(BaseModel):
    """卖家结构"""
    total: int = 0
    cn_pct: float | None = None
    amazon_pct: float | None = None


class MarketSample(BaseModel):
    """The selected local sample used to calculate a market result."""
    term: str
    marketplace: str
    category: str = ""
    pages: int | None = None
    product_count: int = 0
    source: str
    updated_at: str | None = None


class MarketStats(BaseModel):
    """市场画像统计（calc.market.stats 输出）"""
    price: PriceStats = Field(default_factory=PriceStats)
    rating: RatingStats = Field(default_factory=RatingStats)
    listing_date: dict[str, Any] = Field(default_factory=dict)    # {median, new_release_pct}
    reviews: dict[str, Any] = Field(default_factory=dict)         # {median, count_dist}
    monopoly: MonopolyStats = Field(default_factory=MonopolyStats)
    sellers: SellerStats = Field(default_factory=SellerStats)
    aplus_video_pct: float | None = None
    return_rate: dict[str, Any] | None = None                     # {pct, risk}
    sample: MarketSample | None = None


class MarketProfile(BaseModel):
    """8 维市场画像"""
    keyword: str = ""
    dimensions: dict[str, Any] = Field(default_factory=dict)
    overall_score: float = 0.0
    sample: MarketSample | None = None


class Opportunity(BaseModel):
    """市场机会"""
    keyword: str = ""
    gaps: list[dict[str, Any]] = Field(default_factory=list)
    proposals: list[dict[str, Any]] = Field(default_factory=list)
    opportunity_score: float = 0.0
    sample: MarketSample | None = None


class _EvidenceModel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True, allow_inf_nan=False)


class EvidenceSource(_EvidenceModel):
    source: str
    ref: EntityRef | None = None
    fields: list[str] = Field(default_factory=list)
    updated_at: str | None = None
    state: str = "ready"
    detail: str = ""


class MarketEvidence(_EvidenceModel):
    market_ref: EntityRef
    sample_size: int = 0
    used_count: int = 0
    sources: list[EvidenceSource] = Field(default_factory=list)


class SuccessFactorsResult(SuccessFactorsOutput):
    evidence: MarketEvidence


class GapResult(MarketGapOutput):
    evidence: MarketEvidence


class ProposalsResult(ProposalsOutput):
    success_factors: SuccessFactorsOutput
    market_gap: MarketGapOutput
    evidence: MarketEvidence


class TimingResult(TimingOutput):
    evidence: MarketEvidence


class DemandResult(DemandOutput):
    evidence: MarketEvidence


class PriceDimensionResult(PrimaryDimensionOutput):
    evidence: MarketEvidence


class DimensionsResult(DimensionsOutput):
    evidence: MarketEvidence


class TrendObservation(_EvidenceModel):
    date: date
    value: Annotated[float, Field(ge=0, strict=True)]

    @field_validator("date", mode="before")
    @classmethod
    def accept_month(cls, value):
        if isinstance(value, str) and len(value) == 7:
            return value + "-01"
        return value


class TrendEvidence(_EvidenceModel):
    """Externally collected observations, explicitly scoped to this market."""
    term: str = Field(min_length=1)
    marketplace: str = Field(min_length=2, max_length=2)
    source: str = Field(min_length=1)
    observed_at: date
    points: list[TrendObservation] = Field(min_length=2)

    @model_validator(mode="after")
    def unique_dates(self):
        dates = [point.date for point in self.points]
        if len(dates) != len(set(dates)):
            raise ValueError("trend observation dates must be unique")
        if any(point > self.observed_at for point in dates):
            raise ValueError("trend observation dates must not exceed observed_at")
        self.points.sort(key=lambda point: point.date)
        return self


class GoogleDemandEvidence(_EvidenceModel):
    """Source-backed Google metrics; no default values stand in for missing data."""
    term: str = Field(min_length=1)
    marketplace: str = Field(min_length=2, max_length=2)
    baseline_term: str = Field(min_length=1)
    source: str = Field(min_length=1)
    observed_at: date
    period_start: date
    period_end: date
    target_avg: Annotated[float, Field(ge=0, strict=True)]
    baseline_avg: Annotated[float, Field(gt=0, strict=True)]
    cagr_3y: Annotated[float, Field(strict=True)]
    trend_direction: Literal["上升", "下降", "持平", "rising", "declining", "stable"]
    slope_pct: Annotated[float, Field(strict=True)] | None = None
    has_seasonality: Annotated[bool, Field(strict=True)] | None = None
    peak_month: Annotated[int, Field(ge=1, le=12, strict=True)] | None = None
    season_ratio: Annotated[float, Field(gt=0, strict=True)] | None = None
    yearly: dict[str, Annotated[float, Field(ge=0, strict=True)]] | None = None
    yoy: dict[str, Annotated[float, Field(strict=True)]] | None = None

    @model_validator(mode="after")
    def valid_period(self):
        if not self.period_start < self.period_end <= self.observed_at:
            raise ValueError("demand period must have start < end <= observed_at")
        if (self.period_end - self.period_start).days < 1095:
            raise ValueError("three-year demand metrics need at least three years of observations")
        if self.observed_at > date.today():
            raise ValueError("observed_at cannot be in the future")
        return self


class MarketDemandEvidence(_EvidenceModel):
    """Explicit market-size measurements when no local product sample is available."""
    term: str = Field(min_length=1)
    marketplace: str = Field(min_length=2, max_length=2)
    source: str = Field(min_length=1)
    observed_at: date
    monthly_avg_revenue_usd: Annotated[float, Field(ge=0, strict=True)]
    search_purchase_ratio_permille: Annotated[float, Field(ge=0, strict=True)] | None = None

    @model_validator(mode="after")
    def valid_date(self):
        if self.observed_at > date.today():
            raise ValueError("observed_at cannot be in the future")
        return self


class MarketKeyword(_EvidenceModel):
    term: str = Field(min_length=1)
    search_volume: Annotated[int, Field(ge=0, strict=True)] | None = None


PositiveCount = Annotated[int, Field(ge=1, strict=True)]


SamplePages = Annotated[int, Field(ge=1, le=3, strict=True)]


ModelName = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1)]


class CosmoActionEvidence(BaseModel):
    market_ref: EntityRef
    used_product_refs: list[EntityRef]
    failed_product_refs: list[EntityRef]
    sources: list[CosmoSource]
    sample_count: int
    min_success: int
    target_product_ref: EntityRef | None = None
    target_updated_at: str | None = None


class CosmoMergeResult(CosmoMergeOutput):
    evidence: CosmoActionEvidence


class CosmoAggregateResult(CosmoAggregateOutput):
    evidence: CosmoActionEvidence
