"""Market 的成功因子、共同缺口和产品改进提案。

通过共用证据流程准备至少三个有有效评论与 VOC 的商品，
再调用 Analysis 识别优势和缺口；生成提案时复用同一批样本及中间结果。
由 Market 的任务方法调用，结果带来源和样本信息，单独返回给调用方，
不自动写成常驻的市场 VOC 或提案字段。"""

from __future__ import annotations
from typing import Annotated, TYPE_CHECKING
from pydantic import Field
from amz.entities._core import operations
from amz.envelope import Code, Result
from amz.schemas.entity_ref import EntityRef

if TYPE_CHECKING:
    from amz.entities.market.entity import Market


def _has_gap(product) -> bool:
    weakness = product.voc.weaknesses
    return any(item.pain_point.strip() and item.evidence.strip() and item.cnt > 0 for item in weakness.top_issues) or any(
        item.unmet_need.strip() and item.evidence.strip() and item.cnt > 0 for item in weakness.unmet_needs
    )


def _run_gap(market: Market, products, evidence):
    selected = [product for product in products if market._has_gap(product)]
    if len(selected) < 3:
        return market._action_missing("market gap requires observed pain points or unmet needs from at least 3 Products", "voc.weaknesses", evidence)
    return operations.run_analysis("analysis.market.gap-analysis", {
        "weaknesses": [{"asin": p.asin, "weaknesses": p.voc.weaknesses.model_dump(mode="json")} for p in selected],
        "use_insights": [{"asin": p.asin, "use_insights": p.voc.use_insights.model_dump(mode="json")} for p in selected],
    })


def _run_success_factors(market: Market, products, evidence):
    selected = [p for p in products if any(
        advantage.innovation_summary.strip() and advantage.detail.strip()
        for advantage in p.voc.strengths.innovation_and_competitive_advantages
    )]
    if len(selected) < 3:
        return market._action_missing("success factors require concrete strengths from at least 3 Products with reviews", "voc.strengths", evidence)
    return operations.run_analysis("analysis.market.success-factors", {
        "leaders": [{"asin": p.asin, "strengths": p.voc.strengths.model_dump(mode="json")} for p in selected],
    })


def success_factors(market: Market, sample_refs: list[EntityRef] | None = None, pages: Annotated[int, Field(ge=1, le=3)] = 2) -> Result:
    """Fetch and verify at least three reviewed Products, then compare strengths."""
    prepared = market._action_voc(sample_refs, pages)
    if isinstance(prepared, Result):
        return prepared
    products, evidence = prepared
    return market._with_action_evidence(market._run_success_factors(products, evidence), evidence)


def gap(market: Market, sample_refs: list[EntityRef] | None = None, pages: Annotated[int, Field(ge=1, le=3)] = 2) -> Result:
    """Find common gaps only after three Products supply actual review evidence."""
    prepared = market._action_voc(sample_refs, pages)
    if isinstance(prepared, Result):
        return prepared
    products, evidence = prepared
    return market._with_action_evidence(market._run_gap(products, evidence), evidence)


def proposals(market: Market, sample_refs: list[EntityRef] | None = None, pages: Annotated[int, Field(ge=1, le=3)] = 2) -> Result:
    """Prepare VOC, gaps, and strengths for one sample before proposing changes."""
    prepared = market._action_voc(sample_refs, pages)
    if isinstance(prepared, Result):
        return prepared
    products, evidence = prepared
    gaps = market._run_gap(products, evidence)
    if gaps.code != Code.OK:
        return gaps
    if not gaps.data.get("problem_points") and not gaps.data.get("opportunity_points"):
        return market._action_missing("no observed market gap supports a renovation proposal", "gap", evidence)
    strengths = market._run_success_factors(products, evidence)
    if strengths.code != Code.OK:
        return strengths
    result = operations.run_analysis("analysis.market.renovation-proposal", {
        "success_factors": strengths.data["market_leaders_success_factors"],
        "problem_points": gaps.data["problem_points"],
        "opportunity_points": gaps.data["opportunity_points"],
        "use_insights": gaps.data.get("market_use_insights", {}),
    })
    if result.code == Code.OK:
        result.data = {
            **result.data,
            "success_factors": strengths.data,
            "market_gap": gaps.data,
        }
    return market._with_action_evidence(result, evidence)
