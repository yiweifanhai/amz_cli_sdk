"""Market 的身份、样本引用、字段和公开方法。

使用 marketplace + category + term 标识市场，声明统计、画像、COSMO 等字段，
以及需求、时机、缺口和提案等任务入口，统一管理依赖与样本变化后的缓存失效。
较长实现交给同目录模块，并传入当前 Market 实例。
样本关系保存为 Product 引用；商品事实由对应 Product 提供。"""

from __future__ import annotations
import inspect
from datetime import date
from typing import Annotated, Any, Callable, ClassVar, cast
from pydantic import BaseModel, Field, PrivateAttr
from amz.entities._core.base import EnrichSpec, Entity, lazy_field
from amz.entities._core.operations import entity_operation
from amz.entities.market import (
    cosmo as cosmo_methods,
    demand as demand_methods,
    dimensions as dimensions_methods,
    evidence as evidence_methods,
    profile as profile_methods,
    proposals as proposals_methods,
    sample as sample_methods,
    tacos as tacos_methods,
    timing as timing_methods,
)
from amz.entities.market.models import (
    CosmoActionEvidence,
    CosmoAggregateResult,
    CosmoMergeResult,
    DemandResult,
    DimensionsResult,
    GapResult,
    GoogleDemandEvidence,
    MarketDemandEvidence,
    MarketEvidence,
    MarketKeyword,
    MarketProfile,
    MarketSample,
    MarketStats,
    MinSuccess,
    ModelName,
    Opportunity,
    PositiveCount,
    PriceDimensionResult,
    ProposalsResult,
    SamplePages,
    SuccessFactorsResult,
    SummaryPages,
    TimingResult,
    TrendEvidence,
)
from amz.envelope import Code, Result, err
from amz.schemas.amazon_analysis import AmazonMarketSummary
from amz.schemas.cosmo import MarketCosmo
from amz.schemas.data_outputs import CompetingItemOutput
from amz.schemas.entity_ref import EntityRef, market_ref, product_ref
from amz.schemas.tacos import MarketTacosResult, Positive, ReferralRate, ShippingMethod


class Market(Entity):
    """Market 实体 — 以 keyword term 为标识的市场竞争格局"""

    entity_type: ClassVar[str] = "market"
    identity_fields: ClassVar[tuple[str, ...]] = ("marketplace", "category", "term")
    _sample_fields: ClassVar[frozenset[str]] = frozenset({
        "products", "stats", "profile", "opportunity", "summary", "cosmo",
    })

    lazy_fields: ClassVar[dict[str, EnrichSpec]] = {
        "product_refs": EnrichSpec(
            field="product_refs", method="get_product_refs", depends=[],
            source="/competing-lookup", ttl_hours=24,
        ),
        "products": EnrichSpec(
            field="products", method="get_products", depends=["product_refs"],
            source="entity.product", ttl_hours=24,
            dependency_params={"product_refs": ["pages"]},
        ),
        "stats": EnrichSpec(
            field="stats", method="get_stats",
            depends=["products"], source="calc.market.stats", ttl_hours=24,
            dependency_params={"products": ["pages"]}, version="3",
        ),
        "profile": EnrichSpec(
            field="profile", method="get_profile",
            depends=["stats"], source="calc.market.profile", ttl_hours=24,
            dependency_params={"stats": ["pages"]}, version="3",
        ),
        "opportunity": EnrichSpec(
            field="opportunity", method="get_opportunity",
            depends=["stats"], source="calc.market.opportunity", ttl_hours=24,
            dependency_params={"stats": ["pages"]}, version="3",
        ),
        "summary": EnrichSpec(
            field="summary", method="get_summary", depends=["products"],
            source="analysis.market.classify", ttl_hours=24,
            dependency_params={"products": ["pages"]},
            version="3",
        ),
        "cosmo": EnrichSpec(
            field="cosmo", method="get_cosmo", depends=["product_refs"],
            source="analysis.market.cosmo", ttl_hours=168,
            dependency_params={"product_refs": ["pages"]},
        ),
    }

    # -- 核心字段 ----------------------------------------------------------------

    term: str = Field(min_length=1, json_schema_extra={"alias": "term"})
    marketplace: str = Field(default="US", json_schema_extra={"alias": "marketplace"})
    category: str = Field(default="", json_schema_extra={"alias": "category"})

    # -- lazy 字段 ---------------------------------------------------------------

    product_refs: list[EntityRef] | None = None
    products: list[CompetingItemOutput] | None = Field(default=None, exclude=True)
    product_sources: list[dict[str, Any]] = Field(default_factory=list)
    cosmo_sources: list[dict[str, Any]] = Field(default_factory=list)
    cosmo: MarketCosmo | None = None
    _cosmo_inputs: list[dict[str, Any]] = PrivateAttr(default_factory=list)
    _cosmo_failed: list[dict[str, Any]] = PrivateAttr(default_factory=list)
    stats: MarketStats | None = None              # 类型化的市场画像统计
    profile: MarketProfile | None = None           # 类型化的 8 维市场画像
    opportunity: Opportunity | None = None          # 类型化的市场机会分析
    summary: AmazonMarketSummary | None = None

    # ------------------------------------------------------------------
    # 工厂方法
    # ------------------------------------------------------------------

    @classmethod
    def fetch(cls, term: str, marketplace: str = "US", category: str = "") -> Market | None:
        """创建 Market 实体（不立即拉取数据）"""
        ref = market_ref(marketplace, category, term)
        cached = cls.load(ref.cache_id)
        if cached:
            return cached
        instance = cls(**ref.identity)
        instance.save()
        return instance

    # ------------------------------------------------------------------
    # 实体方法
    # ------------------------------------------------------------------

    def _selected_pages(self) -> int:
        """Keep the persisted sample selection when a caller omits pages."""
        return self._last_params.get("product_refs", {}).get("pages", 2)

    def _field_cache_key(self, field: str, kwargs: dict[str, Any]) -> str | None:
        if field in self._sample_fields and kwargs.get("pages") is None:
            kwargs = {**kwargs, "pages": self._selected_pages()}
        return super()._field_cache_key(field, kwargs)

    def _resolve_lazy(
        self, field: str, loader: Callable[..., Result],
        args: tuple[Any, ...], kwargs: dict[str, Any],
    ) -> Result:
        if field in self._sample_fields or field == "product_refs":
            # A partial load may omit sample metadata; read it before choosing a
            # default. This remains a local cache read, not an upstream request.
            if self._loaded_fields is not None and "product_refs" not in self._loaded_fields:
                restored = type(self).load(
                    self._cache_id, use_identity=False,
                    fields=sorted(self._loaded_fields | {"product_refs"}),
                )
                if restored is not None:
                    self._copy_state_from(restored)
            try:
                bound = inspect.signature(loader).bind(self, *args, **kwargs)
                bound.apply_defaults()
            except TypeError as exc:
                return err(Code.ERROR_PARAM, str(exc))
            params = {name: value for name, value in bound.arguments.items() if name != "self"}
            if field in self._sample_fields and params["pages"] is None:
                params["pages"] = self._selected_pages()
            if type(params["pages"]) is not int or not 1 <= params["pages"] <= 3:
                return err(Code.ERROR_PARAM, "pages must be an integer between 1 and 3")
            args, kwargs = (), params
        return super()._resolve_lazy(field, loader, args, kwargs)

    def _sample_info(self) -> MarketSample:
        pages = self._last_params.get("product_refs", {}).get("pages")
        return MarketSample(
            term=self.term, marketplace=self.marketplace, category=self.category,
            pages=pages, product_count=len(self.product_refs or []),
            source=self.lazy_fields["product_refs"].source if pages is not None else "local_product_refs",
            updated_at=self._fetched_at.get("product_refs"),
        )

    def model_post_init(self, __context: Any) -> None:
        super().model_post_init(__context)
        if isinstance(__context, dict) and __context.get("entity_loading"):
            return
        if self.products is not None and self.product_refs is None:
            self.product_refs = self._store_products(self.products)
            self._mark_fetched("product_refs")
            # Declared products are a ready local projection of the supplied sample.
            self._set_products_projection()

    def _store_products(self, rows: list) -> list[EntityRef]:
        from amz.entities.product import Product
        refs = []
        for row in rows:
            data = row.model_dump(mode="python") if isinstance(row, BaseModel) else row
            product = Product.from_competitor(data, marketplace=self.marketplace)
            if product is not None and product.ref not in refs:
                refs.append(product.ref)
        return refs

    def _writeback(self, field: str, value: Any) -> None:
        if field == "products":
            self.product_refs = self._store_products(value)
            self._last_params.pop("product_refs", None)
            self._mark_fetched("product_refs")
            self._set_products_projection()
            self.save()
            return
        super()._writeback(field, value)

    def _set_products_projection(self) -> Result | None:
        """Load the current local Product facts without persisting copies in Market."""
        from amz.entities.product import Product
        rows = []
        sources = []
        for ref in self.product_refs or []:
            if ref.entity_type != "product" or ref.identity["marketplace"] != self.marketplace:
                return err(Code.ERROR_PARAM, "market product references must match the marketplace")
            product = Product.load(ref.cache_id)
            if product is None:
                return err(Code.ERROR_MISSING_FIELDS, "referenced Product is not available locally", missing=[ref.cache_id])
            rows.append(CompetingItemOutput.model_validate(product.to_competitor()))
            sources.append({
                "ref": ref.model_dump(mode="json"),
                "updated_at": product._fetched_at.get("core"),
                "fetch_key": product._fetch_keys.get("core"),
            })
        stamps = sources
        if stamps != self.product_sources:
            self._invalidate_dependents("products")
            self.product_sources = stamps
        self.products = rows
        self._fetched_at["products"] = self._fetched_at.get("product_refs", "")
        pages = self._last_params.get("product_refs", {}).get("pages", 2)
        self._last_params["products"] = {"pages": pages}
        self._fetch_keys["products"] = (
            self._active_fetch_keys.get("products")
            or self._field_cache_key("products", {"pages": pages})
        )
        return None

    @lazy_field("product_refs")
    def get_product_refs(self, pages: SummaryPages = 2) -> Result:
        """Fetch the market sample and save only Product references on this Market."""
        return sample_methods.get_product_refs(self, pages=pages)

    @entity_operation("tacos", calc_ids=("calc.market.tacos",), output_model=MarketTacosResult)
    def calculate_tacos(
        self, sample_refs: list[EntityRef] | None = None, pages: SummaryPages | None = None,
        current_date: date | None = None, shipping_method: ShippingMethod = "slow",
        exchange_rate: Positive | None = None, referral_rate: ReferralRate = 0.15,
        acos_strategy: Annotated[str, Field(min_length=1)] = "legacyForSales_exact",
        acos_category_id: Annotated[str, Field(min_length=1)] | None = None,
    ) -> Result:
        """关键词 TACOS 估算及 3/6/12 月利润分组（不含采购成本，不是净利润）。"""
        return tacos_methods.calculate_tacos(
            self, sample_refs=sample_refs, pages=pages, current_date=current_date,
            shipping_method=shipping_method, exchange_rate=exchange_rate, referral_rate=referral_rate,
            acos_strategy=acos_strategy, acos_category_id=acos_category_id,
        )

    @lazy_field("products")
    def get_products(self, pages: SummaryPages | None = None) -> Result:
        """Return the legacy competitor rows projected from locally stored Products."""
        return sample_methods.get_products(self, pages=pages)

    def _prepare_dependencies(self, field: str, call_params: dict) -> Result | None:
        if field in {"products", "stats", "summary", "profile", "opportunity"} and self.product_refs is not None:
            failure = self._set_products_projection()
            if failure is not None:
                return failure
        if field in {"stats", "profile", "opportunity"} and not self.products:
            self._invalidate_field(field)
            return err(Code.ERROR_MISSING_FIELDS, "market calculations require a non-empty Product sample", missing=["products"])
        if field in {"stats", "profile", "opportunity"} and not any(
            any(getattr(item, key, None) is not None for key in ("price_usd", "rating", "count_review", "monthly_sales"))
            or item.brand or item.seller_nation
            for item in self.products
        ):
            self._invalidate_field(field)
            return err(Code.ERROR_MISSING_FIELDS, "market sample has no usable calculation facts", missing=["products.metrics"])
        if field in {"profile", "opportunity"} and self.stats is None:
            result = self.get_stats(pages=call_params.get("pages"))
            if result.code != Code.OK:
                return result
        if field != "cosmo":
            return None
        if call_params.get("min_success", 1) < 1:
            return err(Code.ERROR_PARAM, "min_success must be at least 1")
        return self._prepare_cosmo(call_params)

    def _prepare_cosmo(self, call_params: dict) -> Result | None:
        return cosmo_methods._prepare_cosmo(self, call_params=call_params)

    @lazy_field("cosmo")
    def get_cosmo(
        self,
        pages: SummaryPages | None = None,
        min_success: MinSuccess = 1,
        model: str = "lite",
        product_model: str = "lite",
        use_image: bool = True,
    ) -> Result:
        """Aggregate verified Product COSMO results with explicit partial-failure coverage."""
        return cosmo_methods.get_cosmo(
            self,
            pages=pages,
            min_success=min_success,
            model=model,
            product_model=product_model,
            use_image=use_image,
        )

    @lazy_field("stats")
    def get_stats(self, pages: SummaryPages | None = None) -> Result:
        """计算市场画像统计（价格带/评分/上架时间/垄断度/卖家结构）"""
        return profile_methods.get_stats(self, pages=pages)

    @lazy_field("profile")
    def get_profile(self, pages: SummaryPages | None = None) -> Result:
        """8 维市场画像（综合评分，委托 calc.market.calculate_profile）"""
        return profile_methods.get_profile(self, pages=pages)

    @lazy_field("opportunity")
    def get_opportunity(self, pages: SummaryPages | None = None) -> Result:
        """市场机会/缺口分析（gap + 微改造提案 + 机会分，委托 calc.market.opportunity）"""
        return profile_methods.get_opportunity(self, pages=pages)

    @lazy_field("summary")
    def get_summary(self, pages: SummaryPages | None = None, model: str = "pro") -> Result:
        """按解决方案分类竞品样本，概述人群、场景并保留 ASIN"""
        return profile_methods.get_summary(self, pages=pages, model=model)

    # ------------------------------------------------------------------
    # Python object API
    # ------------------------------------------------------------------

    def require_products(self, pages: SummaryPages | None = None) -> list[CompetingItemOutput]:
        """Return lightweight competitors, fetching them when needed.

        These are deliberately summaries rather than full ``Product`` entities so a
        ``Product -> Market -> products`` traversal cannot recursively embed another
        complete Product/Market object graph.
        """
        return cast(
            list[CompetingItemOutput],
            self._require_field_value("products", self.get_products(pages=pages)),
        )

    def require_stats(self, pages: SummaryPages | None = None) -> MarketStats:
        """Return typed market statistics, loading products first when needed."""
        return cast(
            MarketStats,
            self._require_field_value("stats", self.get_stats(pages=pages)),
        )

    def require_profile(self, pages: SummaryPages | None = None) -> MarketProfile:
        """Return the typed eight-dimension market profile."""
        return cast(
            MarketProfile,
            self._require_field_value("profile", self.get_profile(pages=pages)),
        )

    def require_opportunity(self, pages: SummaryPages | None = None) -> Opportunity:
        """Return the typed market opportunity assessment."""
        return cast(
            Opportunity,
            self._require_field_value("opportunity", self.get_opportunity(pages=pages)),
        )

    def require_summary(self, pages: SummaryPages | None = None, model: str = "pro") -> AmazonMarketSummary:
        """Return the typed solution summary, loading its product sample when needed."""
        return cast(
            AmazonMarketSummary,
            self._require_field_value("summary", self.get_summary(pages=pages, model=model)),
        )

    def _action_refs(self, sample_refs: list[EntityRef] | None, pages: int) -> list[EntityRef] | Result:
        return evidence_methods._action_refs(self, sample_refs=sample_refs, pages=pages)

    def _action_voc(self, sample_refs: list[EntityRef] | None, pages: int):
        return evidence_methods._action_voc(self, sample_refs=sample_refs, pages=pages)

    @staticmethod
    def _action_missing(message: str, field: str, evidence: MarketEvidence) -> Result:
        return evidence_methods._action_missing(message=message, field=field, evidence=evidence)

    @staticmethod
    def _with_action_evidence(result: Result, evidence: MarketEvidence) -> Result:
        return evidence_methods._with_action_evidence(result=result, evidence=evidence)

    @staticmethod
    def _has_gap(product) -> bool:
        return proposals_methods._has_gap(product=product)

    def _run_gap(self, products, evidence):
        return proposals_methods._run_gap(self, products=products, evidence=evidence)

    def _run_success_factors(self, products, evidence):
        return proposals_methods._run_success_factors(self, products=products, evidence=evidence)

    @entity_operation("success_factors", analysis_ids=("analysis.market.success-factors",), output_model=SuccessFactorsResult)
    def success_factors(self, sample_refs: list[EntityRef] | None = None, pages: Annotated[int, Field(ge=1, le=3)] = 2) -> Result:
        """Fetch and verify at least three reviewed Products, then compare strengths."""
        return proposals_methods.success_factors(self, sample_refs=sample_refs, pages=pages)

    @entity_operation("gap", analysis_ids=("analysis.market.gap-analysis", "analysis.market.gap"), output_model=GapResult)
    def gap(self, sample_refs: list[EntityRef] | None = None, pages: Annotated[int, Field(ge=1, le=3)] = 2) -> Result:
        """Find common gaps only after three Products supply actual review evidence."""
        return proposals_methods.gap(self, sample_refs=sample_refs, pages=pages)

    @entity_operation("proposals", analysis_ids=("analysis.market.renovation-proposal", "analysis.market.proposals"), output_model=ProposalsResult)
    def proposals(self, sample_refs: list[EntityRef] | None = None, pages: Annotated[int, Field(ge=1, le=3)] = 2) -> Result:
        """Prepare VOC, gaps, and strengths for one sample before proposing changes."""
        return proposals_methods.proposals(self, sample_refs=sample_refs, pages=pages)

    @entity_operation("timing", analysis_ids=("analysis.market.timing",), output_model=TimingResult)
    def timing(self, current_date: date, preparation_months: Annotated[int, Field(ge=0, le=24, strict=True)], trend_evidence: TrendEvidence | None = None, product_ref: EntityRef | None = None) -> Result:
        """Use real dated trends and explicit launch context; never infer from a word alone."""
        return timing_methods.timing(
            self,
            current_date=current_date,
            preparation_months=preparation_months,
            trend_evidence=trend_evidence,
            product_ref=product_ref,
        )

    def _demand_amazon(self, amazon_evidence: TrendEvidence | None, evidence: MarketEvidence):
        return demand_methods._demand_amazon(self, amazon_evidence=amazon_evidence, evidence=evidence)

    def _demand_market(self, market_evidence: MarketDemandEvidence | None, evidence: MarketEvidence, pages: int | None):
        return demand_methods._demand_market(
            self,
            market_evidence=market_evidence,
            evidence=evidence,
            pages=pages,
        )

    @entity_operation("demand", analysis_ids=("analysis.demand.assess",), calc_ids=("calc.demand.score",), output_model=DemandResult)
    def demand(self, google_evidence: GoogleDemandEvidence, amazon_evidence: TrendEvidence | None = None,
               market_evidence: MarketDemandEvidence | None = None, pages: Annotated[int, Field(ge=1, le=3)] | None = None) -> Result:
        """Prepare real Google, Amazon year-over-year, and market sample evidence."""
        return demand_methods.demand(
            self,
            google_evidence=google_evidence,
            amazon_evidence=amazon_evidence,
            market_evidence=market_evidence,
            pages=pages,
        )

    def _action_dimensions(self, keywords: list[MarketKeyword], sample_refs: list[EntityRef] | None, pages: int):
        return dimensions_methods._action_dimensions(
            self,
            keywords=keywords,
            sample_refs=sample_refs,
            pages=pages,
        )

    @entity_operation("primary_pricing_dimension", analysis_ids=("analysis.asin.primary-pricing-dimension",), output_model=PriceDimensionResult)
    def primary_pricing_dimension(self, keywords: Annotated[list[MarketKeyword], Field(min_length=1)], sample_refs: list[EntityRef] | None = None, pages: Annotated[int, Field(ge=1, le=3)] = 2) -> Result:
        """Prepare Product prices and Keyword clusters before choosing a price dimension."""
        return dimensions_methods.primary_pricing_dimension(
            self,
            keywords=keywords,
            sample_refs=sample_refs,
            pages=pages,
        )

    @entity_operation("discover_dimensions", analysis_ids=("analysis.asin.discover-dimensions",), output_model=DimensionsResult)
    def discover_dimensions(self, keywords: Annotated[list[MarketKeyword], Field(min_length=1)], sample_refs: list[EntityRef] | None = None, pages: Annotated[int, Field(ge=1, le=3)] = 2) -> Result:
        """Prepare one sample and its primary price dimension before other dimensions."""
        return dimensions_methods.discover_dimensions(
            self,
            keywords=keywords,
            sample_refs=sample_refs,
            pages=pages,
        )

    def _cosmo_action_inputs(
        self, sample_refs: list[EntityRef] | None, pages: int | None,
        min_success: int, product_model: str, use_image: bool,
    ) -> tuple[list[dict[str, Any]], CosmoActionEvidence] | Result:
        return cosmo_methods._cosmo_action_inputs(
            self,
            sample_refs=sample_refs,
            pages=pages,
            min_success=min_success,
            product_model=product_model,
            use_image=use_image,
        )

    @staticmethod
    def _cosmo_action_result(result: Result, evidence: CosmoActionEvidence) -> Result:
        return cosmo_methods._cosmo_action_result(result=result, evidence=evidence)

    @entity_operation("cosmo_merge", analysis_ids=("analysis.cosmo.merge",), calc_ids=("calc.cosmo.merge",), output_model=CosmoMergeResult)
    def cosmo_merge(
        self, sample_refs: list[EntityRef] | None = None, pages: SamplePages | None = None,
        min_success: PositiveCount = 1, product_model: ModelName = "lite", use_image: bool = True,
    ) -> Result:
        """Merge prepared Product COSMO into exact term and location counts without semantic grouping."""
        return cosmo_methods.cosmo_merge(
            self,
            sample_refs=sample_refs,
            pages=pages,
            min_success=min_success,
            product_model=product_model,
            use_image=use_image,
        )

    @entity_operation("cosmo_aggregate", analysis_ids=("analysis.cosmo.aggregate",), output_model=CosmoAggregateResult)
    def cosmo_aggregate(
        self, sample_refs: list[EntityRef] | None = None, pages: SamplePages | None = None,
        min_count: PositiveCount = 1, target_product_ref: EntityRef | None = None,
        model: ModelName = "lite", min_success: PositiveCount = 1,
        product_model: ModelName = "lite", use_image: bool = True,
    ) -> Result:
        """Group Product COSMO terms with a count threshold and optional target Product facts."""
        return cosmo_methods.cosmo_aggregate(
            self,
            sample_refs=sample_refs,
            pages=pages,
            min_count=min_count,
            target_product_ref=target_product_ref,
            model=model,
            min_success=min_success,
            product_model=product_model,
            use_image=use_image,
        )
