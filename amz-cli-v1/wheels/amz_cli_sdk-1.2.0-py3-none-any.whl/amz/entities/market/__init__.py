"""Market 包的公开导入入口。

导出 Market、统计画像、任务结果、证据模型和参数类型。
市场身份、字段与方法在 entity.py 中声明；样本、画像、需求、COSMO 等
内部模块由同一个 Market 实例调用，不需要调用方分别创建对象。"""

from amz.entities.market.entity import Market
from amz.entities.market.models import (
    CosmoActionEvidence,
    CosmoAggregateResult,
    CosmoMergeResult,
    DemandResult,
    DimensionsResult,
    EvidenceSource,
    GapResult,
    GoogleDemandEvidence,
    MarketDemandEvidence,
    MarketEvidence,
    MarketKeyword,
    MarketProfile,
    MarketSample,
    MarketStats,
    MinSuccess,
    ModelName,
    MonopolyStats,
    Opportunity,
    PositiveCount,
    PriceBand,
    PriceDimensionResult,
    PriceStats,
    ProposalsResult,
    RatingStats,
    SamplePages,
    SellerStats,
    SuccessFactorsResult,
    SummaryPages,
    TimingResult,
    TrendEvidence,
    TrendObservation,
)


__all__ = ['Market', 'SummaryPages', 'MinSuccess', 'PriceBand', 'PriceStats', 'RatingStats', 'MonopolyStats', 'SellerStats', 'MarketSample', 'MarketStats', 'MarketProfile', 'Opportunity', 'EvidenceSource', 'MarketEvidence', 'SuccessFactorsResult', 'GapResult', 'ProposalsResult', 'TimingResult', 'DemandResult', 'PriceDimensionResult', 'DimensionsResult', 'TrendObservation', 'TrendEvidence', 'GoogleDemandEvidence', 'MarketDemandEvidence', 'MarketKeyword', 'PositiveCount', 'SamplePages', 'ModelName', 'CosmoActionEvidence', 'CosmoMergeResult', 'CosmoAggregateResult']
