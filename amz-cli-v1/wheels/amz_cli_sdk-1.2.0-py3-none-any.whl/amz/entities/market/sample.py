"""Market 的商品样本采集与本地读取。

调用 Data 获取竞品样本，将各行合并到对应 Product，再在 Market 保存商品引用。
get_products 从这些本地 Product 生成供统计等方法使用的样本行。
由 Market 字段方法调用；样本身份通过 EntityRef 管理，
不把另一个 Product 的完整状态嵌入 Market 缓存。"""

from __future__ import annotations
from typing import TYPE_CHECKING
from amz.entities.market.models import SummaryPages
from amz.envelope import Code, Result, err, ok

if TYPE_CHECKING:
    from amz.entities.market.entity import Market


def get_product_refs(market: Market, pages: SummaryPages = 2) -> Result:
    """Fetch the market sample and save only Product references on this Market."""
    if market.marketplace != "US" or market.category:
        return err(Code.ERROR_PARAM, "upstream market data currently supports marketplace US and no category filter only")
    from amz.data.market import market_competitors
    result = market_competitors(keyword=market.term, pages=pages)
    if result.code == Code.OK:
        refs = market._store_products((result.data or {}).get("items", []))
        market._writeback("product_refs", refs)
    return result


def get_products(market: Market, pages: SummaryPages | None = None) -> Result:
    """Return the legacy competitor rows projected from locally stored Products."""
    failure = market._set_products_projection()
    if failure is not None:
        return failure
    market.save()
    return ok(data=market.products)
