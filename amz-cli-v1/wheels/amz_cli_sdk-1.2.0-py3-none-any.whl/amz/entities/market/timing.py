"""Market 进入时机分析的趋势与任务资料准备。

收集对应 Keyword 的实际趋势，并检查观察日期、有效数据和明确的上市条件，
再调用 Analysis 评估市场时机，结果附带证据来源。
由 Market.timing() 传入当前市场及任务参数；不只凭关键词猜测趋势，
也不把这次上市条件下的结论保存为通用市场字段。"""

from __future__ import annotations
from datetime import date
from typing import Annotated, TYPE_CHECKING
from pydantic import Field
from amz.entities._core import operations
from amz.entities.market.models import EvidenceSource, MarketEvidence, TrendEvidence
from amz.envelope import Code, Result, err
from amz.schemas.entity_ref import EntityRef, keyword_ref, product_ref

if TYPE_CHECKING:
    from amz.entities.market.entity import Market


def timing(market: Market, current_date: date, preparation_months: Annotated[int, Field(ge=0, le=24, strict=True)], trend_evidence: TrendEvidence | None = None, product_ref: EntityRef | None = None) -> Result:
    """Use real dated trends and explicit launch context; never infer from a word alone."""
    from amz.entities._core.store import entity_store
    evidence = MarketEvidence(market_ref=market.ref)
    if trend_evidence is None:
        ref = keyword_ref(market.marketplace, market.category, market.term)
        keyword = entity_store.get_or_create(ref)
        result = keyword.get_trends()
        if result.code != Code.OK:
            return result
        try:
            trend_evidence = TrendEvidence(
                term=market.term, marketplace=market.marketplace, source="entity.keyword.trends",
                observed_at=date.today(), points=keyword.trends or [],
            )
        except ValueError:
            return market._action_missing("timing requires at least 2 valid dated Keyword trend observations", "keyword.trends", evidence)
        note = EvidenceSource(source=trend_evidence.source, ref=ref, fields=["trends"], updated_at=keyword._fetched_at.get("trends"))
    else:
        note = EvidenceSource(source=trend_evidence.source, fields=["trends"], updated_at=trend_evidence.observed_at.isoformat())
    if " ".join(trend_evidence.term.split()).casefold() != market.term or trend_evidence.marketplace.upper() != market.marketplace:
        return err(Code.ERROR_PARAM, "trend evidence must match the Market term and marketplace")
    if trend_evidence.observed_at > date.today() or any(point.date > current_date for point in trend_evidence.points):
        return err(Code.ERROR_PARAM, "trend observations must not be later than current_date or today")
    evidence.sources.append(note)
    product_info = {}
    if product_ref is not None:
        if product_ref.entity_type != "product" or product_ref.identity["marketplace"] != market.marketplace:
            return err(Code.ERROR_PARAM, "product_ref must be a Product in the Market marketplace")
        product = entity_store.get_or_create(product_ref)
        result = product.get_product_details()
        if result.code != Code.OK:
            return result
        if not (product.title or "").strip():
            return market._action_missing("timing product context requires a non-empty title", "product.title", evidence)
        product_info = {"title": product.title, "bullet_points": product.bullet_points, "description": product.description or ""}
        evidence.sources.append(EvidenceSource(source="entity.product.product_details", ref=product_ref, fields=["product_details"], updated_at=product._fetched_at.get("product_details")))
    result = operations.run_analysis("analysis.market.timing", {
        "keyword": market.term, "asin": product_ref.identity["asin"] if product_ref else "",
        "product_info": product_info,
        "market_data": {"trends": [point.model_dump(mode="json") for point in trend_evidence.points], "source": trend_evidence.source, "observed_at": trend_evidence.observed_at.isoformat(), "marketplace": market.marketplace},
        "current_date": current_date.isoformat(), "preparation_months": preparation_months,
    })
    return market._with_action_evidence(result, evidence)
