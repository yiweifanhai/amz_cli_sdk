"""Market 的商品 COSMO 准备、汇总和分组任务。

通过 Product 引用取得各商品的 COSMO，记录来源、更新时间和失败样本，
满足最低成功数量后再调用 Analysis。get_cosmo 将市场汇总写回 cosmo 字段。
显式样本的合并与分组方法返回独立任务结果及证据，不覆盖该长期字段。
这里属于 Market 的内部实现，单品 COSMO 提取由 Product 负责。"""

from __future__ import annotations
from typing import Any, TYPE_CHECKING
from amz.config import config
from amz.entities._core import operations
from amz.entities.market.models import (
    CosmoActionEvidence,
    MinSuccess,
    ModelName,
    PositiveCount,
    SamplePages,
    SummaryPages,
)
from amz.envelope import Code, Result, err
from amz.schemas.cosmo import CosmoSource, MarketCosmo, MarketProductCosmoInput
from amz.schemas.entity_ref import EntityRef

if TYPE_CHECKING:
    from amz.entities.market.entity import Market


def _prepare_cosmo(market: Market, call_params: dict) -> Result | None:
    from amz.entities._core.store import entity_store
    use_image = bool(call_params.get("use_image", True) and config.cosmo_use_images)
    products = []
    failed = []
    stamps = []
    for ref in market.product_refs or []:
        if ref.entity_type != "product" or ref.identity["marketplace"] != market.marketplace:
            return err(Code.ERROR_PARAM, "market product references must match the marketplace")
        try:
            product = entity_store.get_or_create(ref)
            result = product.get_cosmo(
                model=call_params.get("product_model", "lite"),
                use_image=use_image,
            )
        except (OSError, ValueError, RuntimeError) as exc:
            failed.append(ref.model_dump(mode="json"))
            stamps.append({"ref": ref.model_dump(mode="json"), "state": "error", "error": str(exc)})
            continue
        stamp = {
            "ref": ref.model_dump(mode="json"),
            "state": result.code.value,
            "updated_at": product._fetched_at.get("cosmo"),
            "fetch_key": product._fetch_keys.get("cosmo"),
            "details_updated_at": product._fetched_at.get("product_details"),
        }
        stamps.append(stamp)
        if result.code != Code.OK or product.cosmo is None:
            failed.append(ref.model_dump(mode="json"))
            continue
        has_image = bool(use_image and (product.images or product.aplus_images))
        products.append({
            "ref": ref.model_dump(mode="json"),
            "cosmo": product.cosmo.model_dump(mode="json"),
            "updated_at": stamp["updated_at"] or "",
            "source": "listing_and_image" if has_image else "listing",
        })
    market._cosmo_inputs = products
    market._cosmo_failed = failed
    if stamps != market.cosmo_sources:
        market._invalidate_field("cosmo")
        market.cosmo_sources = stamps
        market.save()
    minimum = call_params.get("min_success", 1)
    if len(products) < minimum:
        market._invalidate_field("cosmo")
        market.save()
        return err(Code.ERROR_UPSTREAM, f"COSMO has {len(products)} successful products; requires at least {minimum}")
    return None


def get_cosmo(
    market: Market,
    pages: SummaryPages | None = None,
    min_success: MinSuccess = 1,
    model: str = "lite",
    product_model: str = "lite",
    use_image: bool = True,
) -> Result:
    """Aggregate verified Product COSMO results with explicit partial-failure coverage."""
    if min_success < 1:
        return err(Code.ERROR_PARAM, "min_success must be at least 1")
    from amz.analysis.market.cosmo import market_cosmo
    result = market_cosmo(
        products=market._cosmo_inputs,
        failed_product_refs=market._cosmo_failed,
        min_success=min_success,
        model=model,
    )
    if result.code == Code.OK:
        market._writeback("cosmo", MarketCosmo.model_validate(result.data))
    return result


def _cosmo_action_inputs(
    market: Market, sample_refs: list[EntityRef] | None, pages: int | None,
    min_success: int, product_model: str, use_image: bool,
) -> tuple[list[dict[str, Any]], CosmoActionEvidence] | Result:
    from amz.entities._core.store import entity_store

    if sample_refs is None:
        if pages is None and market._loaded_fields is not None and "product_refs" not in market._loaded_fields:
            restored = type(market).load(market._cache_id, use_identity=False, fields=["product_refs"])
            if restored is not None:
                pages = restored._selected_pages()
        result = market.enrich("product_refs", pages=pages if pages is not None else market._selected_pages())
        if result.code != Code.OK:
            return result
        sample_refs = market.product_refs or []
    refs = list(sample_refs)
    if not refs:
        return err(Code.ERROR_MISSING_FIELDS, "COSMO requires a non-empty Product sample", missing=["sample_refs"])
    if len(refs) > 200 or len(set(refs)) != len(refs):
        return err(Code.ERROR_PARAM, "COSMO sample must contain at most 200 distinct Product references")
    if any(ref.entity_type != "product" or ref.identity["marketplace"] != market.marketplace for ref in refs):
        return err(Code.ERROR_PARAM, "COSMO sample references must be Products in the Market marketplace")
    if min_success > len(refs):
        return err(Code.ERROR_MISSING_FIELDS, "COSMO sample is smaller than min_success", missing=["sample_refs"])
    evidence = CosmoActionEvidence(
        market_ref=market.ref, used_product_refs=[], failed_product_refs=[], sources=[],
        sample_count=len(refs), min_success=min_success,
    )
    rows = []
    for ref in refs:
        product = entity_store.get_or_create(ref)
        result = product.get_cosmo(model=product_model, use_image=use_image)
        if result.code != Code.OK or product.cosmo is None:
            evidence.failed_product_refs.append(ref)
            continue
        image_source = use_image and config.cosmo_use_images and bool(product.images or product.aplus_images)
        row = MarketProductCosmoInput(
            ref=ref, cosmo=product.cosmo,
            updated_at=product._fetched_at.get("cosmo") or "",
            source="listing_and_image" if image_source else "listing",
        )
        evidence.used_product_refs.append(ref)
        evidence.sources.append(CosmoSource(product_ref=ref, updated_at=row.updated_at, source=row.source))
        rows.append({"asin": ref.identity["asin"], "cosmo": row.cosmo.model_dump(mode="json")})
    if len(rows) < min_success:
        return err(Code.ERROR_MISSING_FIELDS, "not enough successful Product COSMO inputs", missing=["product.cosmo"],
                   data={"evidence": evidence.model_dump(mode="json")})
    return rows, evidence


def _cosmo_action_result(result: Result, evidence: CosmoActionEvidence) -> Result:
    if result.code == Code.OK:
        result.data = {**result.data, "evidence": evidence.model_dump(mode="json")}
    return result


def cosmo_merge(
    market: Market, sample_refs: list[EntityRef] | None = None, pages: SamplePages | None = None,
    min_success: PositiveCount = 1, product_model: ModelName = "lite", use_image: bool = True,
) -> Result:
    """Merge prepared Product COSMO into exact term and location counts without semantic grouping."""
    prepared = market._cosmo_action_inputs(sample_refs, pages, min_success, product_model, use_image)
    if isinstance(prepared, Result):
        return prepared
    rows, evidence = prepared
    return market._cosmo_action_result(operations.run_analysis("analysis.cosmo.merge", {"cosmo_outputs": rows}), evidence)


def cosmo_aggregate(
    market: Market, sample_refs: list[EntityRef] | None = None, pages: SamplePages | None = None,
    min_count: PositiveCount = 1, target_product_ref: EntityRef | None = None,
    model: ModelName = "lite", min_success: PositiveCount = 1,
    product_model: ModelName = "lite", use_image: bool = True,
) -> Result:
    """Group Product COSMO terms with a count threshold and optional target Product facts."""
    from amz.entities._core.store import entity_store

    if target_product_ref is not None and (
        target_product_ref.entity_type != "product" or target_product_ref.identity["marketplace"] != market.marketplace
    ):
        return err(Code.ERROR_PARAM, "target_product_ref must identify a Product in the Market marketplace")
    target_product = ""
    target_updated_at = None
    if target_product_ref is not None:
        target = entity_store.get_or_create(target_product_ref)
        failure = target._ensure_analysis_facts(listing=True)
        if failure is not None:
            return failure
        target_product = "\n".join(text for text in [target.title or "", *target.bullet_points, target.description or ""] if text.strip())
        target_updated_at = target._fetched_at.get("product_details")
    prepared = market._cosmo_action_inputs(sample_refs, pages, min_success, product_model, use_image)
    if isinstance(prepared, Result):
        return prepared
    rows, evidence = prepared
    evidence.target_product_ref = target_product_ref
    evidence.target_updated_at = target_updated_at
    return market._cosmo_action_result(operations.run_analysis("analysis.cosmo.aggregate", {
        "cosmo_outputs": rows, "min_count": min_count, "target_product": target_product, "model": model,
    }), evidence)
