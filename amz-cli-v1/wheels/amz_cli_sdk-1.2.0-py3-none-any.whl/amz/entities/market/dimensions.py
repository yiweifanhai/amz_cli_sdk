"""Market 的主要定价维度和其他分类维度发现。

准备样本 Product 的价格等事实与 Keyword 聚类，交给 Analysis 判断
主要定价维度；发现其他维度时复用同一样本和主要维度结果。
由 Market 的任务方法调用，返回分析结果及证据，不另建维度实体或长期缓存字段。"""

from __future__ import annotations
import math
from typing import Annotated, TYPE_CHECKING
from pydantic import Field
from amz.entities._core import operations
from amz.entities.market.models import EvidenceSource, MarketEvidence, MarketKeyword
from amz.envelope import Code, Result, err
from amz.schemas.entity_ref import EntityRef, keyword_ref

if TYPE_CHECKING:
    from amz.entities.market.entity import Market


def _action_dimensions(market: Market, keywords: list[MarketKeyword], sample_refs: list[EntityRef] | None, pages: int):
    from amz.entities._core.store import entity_store
    refs = market._action_refs(sample_refs, pages)
    if isinstance(refs, Result):
        return refs
    if len({item.term.casefold() for item in keywords}) != len(keywords) or market.term not in {item.term.casefold() for item in keywords}:
        return err(Code.ERROR_PARAM, "keywords must be unique and include Market.term")
    evidence = MarketEvidence(market_ref=market.ref, sample_size=len(refs))
    products = []
    for ref in refs:
        product = entity_store.get_or_create(ref)
        for loader in (product.refresh_core, product.get_product_details):
            result = loader()
            if result.code != Code.OK:
                return result
        if not (product.title or "").strip() or product.price_usd is None or not math.isfinite(product.price_usd) or product.price_usd <= 0:
            return market._action_missing("each dimension sample needs a title and a positive finite price", "product.title/price_usd", evidence)
        products.append({"asin": product.asin, "title": product.title, "price_usd": product.price_usd, "description": product.description or ""})
        evidence.sources.append(EvidenceSource(source="entity.product", ref=ref, fields=["core", "product_details"], updated_at=product._fetched_at.get("product_details")))
    evidence.used_count = len(products)
    ref = keyword_ref(market.marketplace, market.category, market.term)
    keyword = entity_store.get_or_create(ref)
    result = keyword.get_cluster(keywords=[item.model_dump(exclude_none=True) for item in keywords])
    if result.code != Code.OK:
        return result
    if not result.data or not result.data.get("clusters"):
        return market._action_missing("dimension discovery needs non-empty Keyword clusters", "keyword.cluster", evidence)
    evidence.sources.append(EvidenceSource(source="entity.keyword.cluster", ref=ref, fields=["cluster"], updated_at=keyword._fetched_at.get("cluster")))
    from amz.calc.market.stats import calculate_stats
    stats = calculate_stats(products)
    params = {"main_keyword": market.term, "products": products, "price_bands": stats["price"]["bands"], "refinement_dimensions": {}, "keyword_clusters": result.data}
    return params, evidence


def primary_pricing_dimension(market: Market, keywords: Annotated[list[MarketKeyword], Field(min_length=1)], sample_refs: list[EntityRef] | None = None, pages: Annotated[int, Field(ge=1, le=3)] = 2) -> Result:
    """Prepare Product prices and Keyword clusters before choosing a price dimension."""
    prepared = market._action_dimensions(keywords, sample_refs, pages)
    if isinstance(prepared, Result):
        return prepared
    params, evidence = prepared
    return market._with_action_evidence(operations.run_analysis("analysis.asin.primary-pricing-dimension", params), evidence)


def discover_dimensions(market: Market, keywords: Annotated[list[MarketKeyword], Field(min_length=1)], sample_refs: list[EntityRef] | None = None, pages: Annotated[int, Field(ge=1, le=3)] = 2) -> Result:
    """Prepare one sample and its primary price dimension before other dimensions."""
    prepared = market._action_dimensions(keywords, sample_refs, pages)
    if isinstance(prepared, Result):
        return prepared
    params, evidence = prepared
    primary = operations.run_analysis("analysis.asin.primary-pricing-dimension", params)
    if primary.code != Code.OK:
        return primary
    result = operations.run_analysis("analysis.asin.discover-dimensions", {**params, "primary_dimension": primary.data["primary_pricing_dimension"]})
    return market._with_action_evidence(result, evidence)
