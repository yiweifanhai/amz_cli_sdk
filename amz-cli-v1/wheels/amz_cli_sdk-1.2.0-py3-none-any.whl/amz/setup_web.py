"""本机 API Key 配置页。

页面只监听 127.0.0.1。所有密钥字段均为空；空值表示保留已有配置。
"""

from __future__ import annotations

import html
import json
import os
import secrets
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, quote, urlparse

import yaml
from amz.config import validate_sellersprite_token


PROVIDERS = ("doubao", "ark")
PROVIDER_LABELS = {
    "doubao": "豆包 / 火山方舟",
    "ark": "火山方舟 Ark",
}


def user_config_path() -> Path:
    return Path.home() / ".amz" / "config.yaml"


def load_saved_config(path: Path | None = None) -> dict[str, Any]:
    target = path or user_config_path()
    if not target.exists():
        return {}
    data = yaml.safe_load(target.read_text(encoding="utf-8")) or {}
    if not isinstance(data, dict):
        raise ValueError("现有配置文件格式无效")
    return data


def write_saved_config(data: dict[str, Any], path: Path | None = None) -> None:
    """原子写入用户配置，并把 Unix 权限固定为仅当前用户可读写。"""
    target = path or user_config_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    temp_path = target.with_name(f".{target.name}.{secrets.token_hex(4)}.tmp")
    try:
        temp_path.write_text(
            yaml.safe_dump(data, allow_unicode=True, sort_keys=False),
            encoding="utf-8",
        )
        if os.name != "nt":
            os.chmod(temp_path, 0o600)
        os.replace(temp_path, target)
        if os.name != "nt":
            os.chmod(target, 0o600)
    finally:
        if temp_path.exists():
            temp_path.unlink()


def sellersprite_token_path(data: dict[str, Any]) -> Path:
    value = data.get("sellersprite", {}).get("token_file", "~/.sellersprite_token")
    if not isinstance(value, str) or not value:
        raise ValueError("SellerSprite Token 文件路径无效")
    return Path(os.path.expandvars(value)).expanduser()


def save_sellersprite_token(values: dict[str, str], data: dict[str, Any]) -> None:
    """Save only an explicitly submitted secret; empty input keeps the old value."""
    value = values.get("sellersprite_token", "").strip()
    action = values.get("sellersprite_action", "keep")
    if action not in {"keep", "clear"}:
        raise ValueError("SellerSprite Token 操作无效")
    if not value and action == "keep":
        return
    target = sellersprite_token_path(data)
    if action == "clear":
        target.unlink(missing_ok=True)
    else:
        value = validate_sellersprite_token(value)
        target.parent.mkdir(parents=True, exist_ok=True)
        temp = target.with_name(f".{target.name}.{secrets.token_hex(8)}.tmp")
        try:
            fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(value)
            os.replace(temp, target)
        finally:
            temp.unlink(missing_ok=True)
    section = data.setdefault("sellersprite", {})
    section["enabled"] = action != "clear"
    section.pop("token", None)
    headers = data.get("data_api", {}).get("headers", {})
    for name in list(headers):
        if name.lower() == "x-sellersprite-token":
            del headers[name]


def save_form(values: dict[str, str], path: Path | None = None) -> dict[str, Any]:
    """保存网页提交的数据。空密钥保留原值，且从不返回密钥。"""
    target = path or user_config_path()
    data = load_saved_config(target)

    if "cosmo_use_images" in values:
        value = values["cosmo_use_images"]
        if value not in {"true", "false"}:
            raise ValueError("COSMO 图片开关必须选择开启或关闭")
        section = data.setdefault("cosmo", {})
        if not isinstance(section, dict):
            raise ValueError("现有 COSMO 配置格式无效")
        section["use_images"] = value == "true"

    base_url = values.get("data_api_base_url", "").strip()
    if base_url:
        parsed = urlparse(base_url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ValueError("AMZ 服务地址必须是有效的 http 或 https 地址")
        data.setdefault("data_api", {})["base_url"] = base_url

    data_token = values.get("data_api_token", "").strip()
    if data_token:
        data.setdefault("data_api", {})["token"] = data_token

    backend = values.get("default_backend", "").strip()
    if backend:
        if backend not in PROVIDERS:
            raise ValueError("默认模型服务不受支持")
        data.setdefault("llm", {})["default_backend"] = backend

    api_keys = data.setdefault("api_keys", {})
    if not isinstance(api_keys, dict):
        api_keys = {}
        data["api_keys"] = api_keys
    for provider in PROVIDERS:
        value = values.get(f"api_key_{provider}", "").strip()
        if value:
            api_keys[provider] = value

    if values.get("api_key_doubao", "").strip() or values.get("api_key_ark", "").strip():
        data.setdefault("llm", {})["default_backend"] = "doubao"

    save_sellersprite_token(values, data)
    write_saved_config(data, target)
    return saved_status(data)


def saved_status(data: dict[str, Any] | None = None) -> dict[str, Any]:
    """只返回配置状态，不返回任何密钥或 token。"""
    if data is None:
        data = load_saved_config()
    data_api = data.get("data_api") if isinstance(data.get("data_api"), dict) else {}
    api_keys = data.get("api_keys") if isinstance(data.get("api_keys"), dict) else {}
    llm = data.get("llm") if isinstance(data.get("llm"), dict) else {}
    backend = llm.get("default_backend", "doubao")
    if backend not in {"doubao", "ark"}:
        backend = "doubao"
    key_status = {provider: bool(api_keys.get(provider)) for provider in PROVIDERS}
    key_status["doubao"] = key_status["doubao"] or key_status["ark"]
    cosmo = data.get("cosmo") if isinstance(data.get("cosmo"), dict) else {}
    seller = data.get("sellersprite") if isinstance(data.get("sellersprite"), dict) else {}
    try:
        file = sellersprite_token_path(data)
        has_seller = file.is_file() and file.stat().st_size > 0
    except (OSError, ValueError):
        has_seller = False
    has_seller = seller.get("enabled", True) is not False and bool(
        has_seller or seller.get("token") or any(
            value for name, value in data_api.get("headers", {}).items() if name.lower() == "x-sellersprite-token"
        )
    )
    return {
        "data_api_token": bool(data_api.get("token")),
        "sellersprite_token": has_seller,
        "default_backend": backend,
        "api_keys": key_status,
        "cosmo_use_images": cosmo.get("use_images", False),
    }


def _badge(configured: bool) -> str:
    label = "已配置" if configured else "未配置"
    css = "ok" if configured else "missing"
    return f'<span class="badge {css}">{label}</span>'


def render_form(session_token: str, message: str = "", error: str = "") -> str:
    data = load_saved_config()
    status = saved_status(data)
    data_api = data.get("data_api") if isinstance(data.get("data_api"), dict) else {}
    base_url = html.escape(str(data_api.get("base_url", "https://amz.jxpxxzj.cn")), quote=True)
    key_fields = "".join(
        f"""
        <label>
          <span>{html.escape(PROVIDER_LABELS[provider])} API Key {_badge(status['api_keys'][provider])}</span>
          <input type="password" name="api_key_{provider}" autocomplete="off"
                 placeholder="留空会保留已有密钥">
        </label>
        """
        for provider in ("doubao",)
    )
    notice = ""
    if message:
        notice = f'<div class="notice okbox">{html.escape(message)}</div>'
    elif error:
        notice = f'<div class="notice errorbox">{html.escape(error)}</div>'
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>配置 amz-cli</title>
  <style>
    :root {{ color-scheme: light; --blue:#2563eb; --line:#dbe2ea; --muted:#667085; }}
    * {{ box-sizing:border-box; }}
    body {{ margin:0; padding:32px 16px; background:#f4f7fb; color:#172033;
      font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC",sans-serif; }}
    main {{ max-width:680px; margin:auto; background:white; border:1px solid var(--line);
      border-radius:16px; padding:28px; box-shadow:0 14px 45px rgba(20,40,80,.08); }}
    h1 {{ margin:0 0 8px; font-size:26px; }}
    p {{ color:var(--muted); line-height:1.6; }}
    fieldset {{ border:0; padding:0; margin:28px 0 0; }}
    legend {{ font-size:17px; font-weight:700; margin-bottom:14px; }}
    label {{ display:block; margin:0 0 16px; font-weight:600; }}
    label > span {{ display:flex; align-items:center; gap:8px; margin-bottom:7px; }}
    input,select {{ width:100%; padding:11px 12px; border:1px solid #c8d1dc;
      border-radius:8px; font:inherit; background:white; }}
    input:focus,select:focus {{ outline:2px solid #bfdbfe; border-color:var(--blue); }}
    .badge {{ font-size:12px; font-weight:600; padding:2px 7px; border-radius:999px; }}
    .badge.ok {{ color:#067647; background:#ecfdf3; }}
    .badge.missing {{ color:#b54708; background:#fffaeb; }}
    .notice {{ border-radius:8px; padding:12px; margin:18px 0; }}
    .okbox {{ color:#067647; background:#ecfdf3; }}
    .errorbox {{ color:#b42318; background:#fef3f2; }}
    button {{ width:100%; border:0; border-radius:9px; padding:12px 16px; color:white;
      background:var(--blue); font-size:16px; font-weight:700; cursor:pointer; }}
    .safe {{ font-size:13px; margin-top:16px; }}
  </style>
</head>
<body>
<main>
  <h1>配置 amz-cli</h1>
  <p>只填写你使用的服务。密钥直接保存到这台电脑，不会发送给 Agent。留空会保留已有值。</p>
  {notice}
  <form method="post" action="/save">
    <input type="hidden" name="session_token" value="{html.escape(session_token, quote=True)}">
    <fieldset>
      <legend>Amazon 数据服务</legend>
      <label><span>AMZ API Token {_badge(status['data_api_token'])}</span>
        <input type="password" name="data_api_token" autocomplete="off" placeholder="留空会保留已有 token">
      </label>
      <label><span>服务地址</span>
        <input type="url" name="data_api_base_url" value="{base_url}" required>
      </label>
      <label><span>SellerSprite MCP Token（可选） {_badge(status['sellersprite_token'])}</span>
        <input type="password" name="sellersprite_token" autocomplete="off" placeholder="粘贴自己的 MCP Token；留空保留已有值">
      </label>
      <p>填写后，卖家精灵数据回源使用你的 MCP 额度；缓存命中不重复调用。不填写则使用服务端默认数据源。</p>
      <label><span>已保存的 SellerSprite Token</span>
        <select name="sellersprite_action">
          <option value="keep">保留</option>
          <option value="clear">清除，恢复服务端默认数据源</option>
        </select>
      </label>
    </fieldset>
    <fieldset>
      <legend>大模型服务</legend>
      <input type="hidden" name="default_backend" value="doubao">
      <p>使用豆包 API Key：COSMO 图文抽取和常规分析用 Lite，复杂分析用 Pro。</p>
      {key_fields}
    </fieldset>
    <fieldset>
      <legend>COSMO 抽取设置</legend>
      <label><span>COSMO 图片关键词抽取</span>
        <select name="cosmo_use_images" aria-describedby="cosmo-image-help">
          <option value="true" {'selected' if status['cosmo_use_images'] else ''}>开启：使用全部商品图和 A+ 图</option>
          <option value="false" {'' if status['cosmo_use_images'] else 'selected'}>关闭：只分析文字</option>
        </select>
      </label>
      <p id="cosmo-image-help">开启后，从全部主图、附图和 A+ 图中的文字提取关键词，与 Listing 一起分析。
      关闭后，只分析标题、五点、参数和文字描述。修改后从下一次 COSMO 抽取生效。</p>
    </fieldset>
    <button type="submit">安全保存配置</button>
  </form>
  <p class="safe">此页面仅在本机 127.0.0.1 临时运行，保存后会自动关闭服务。</p>
</main>
</body>
</html>"""


def render_success(status: dict[str, Any]) -> str:
    configured = [
        PROVIDER_LABELS[name] for name in ("doubao",) if status["api_keys"].get(name)
    ]
    model_text = "、".join(configured) if configured else "暂未配置大模型密钥"
    data_text = "AMZ 数据 Token 已配置" if status["data_api_token"] else "AMZ 数据 Token 未配置"
    data_text += "；SellerSprite MCP Token " + ("已配置" if status["sellersprite_token"] else "未配置（可选）")
    return f"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>配置完成</title>
<style>body{{font-family:-apple-system,"Segoe UI","PingFang SC",sans-serif;background:#f4f7fb;
padding:50px 18px;color:#172033}}main{{max-width:560px;margin:auto;background:white;padding:32px;
border-radius:16px;border:1px solid #dbe2ea}}h1{{color:#067647}}p{{line-height:1.7;color:#475467}}</style>
</head><body><main><h1>配置已保存</h1><p>{html.escape(data_text)}；大模型：{html.escape(model_text)}。</p>
<p>可以关闭此页面，回到 Agent 继续使用。</p></main></body></html>"""


class _SetupServer(HTTPServer):
    session_token: str
    saved = False


class _Handler(BaseHTTPRequestHandler):
    server: _SetupServer

    def _send_html(self, body: str, status: int = 200) -> None:
        payload = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'",
        )
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self) -> None:  # noqa: N802
        parsed = urlparse(self.path)
        session = parse_qs(parsed.query).get("session", [""])[0]
        if parsed.path != "/" or not secrets.compare_digest(session, self.server.session_token):
            self._send_html("<h1>链接无效或已过期</h1>", 403)
            return
        self._send_html(render_form(self.server.session_token))

    def do_POST(self) -> None:  # noqa: N802
        if self.path != "/save":
            self._send_html("<h1>页面不存在</h1>", 404)
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if length <= 0 or length > 65536:
            self._send_html("<h1>提交内容无效</h1>", 400)
            return
        raw = self.rfile.read(length).decode("utf-8")
        form = {key: values[-1] for key, values in parse_qs(raw, keep_blank_values=True).items()}
        token = form.pop("session_token", "")
        if not secrets.compare_digest(token, self.server.session_token):
            self._send_html("<h1>链接无效或已过期</h1>", 403)
            return
        try:
            status = save_form(form)
        except (OSError, ValueError, yaml.YAMLError) as exc:
            self._send_html(render_form(self.server.session_token, error=str(exc)), 400)
            return
        self.server.saved = True
        self._send_html(render_success(status))
        threading.Thread(target=self.server.shutdown, daemon=True).start()

    def log_message(self, format: str, *args: object) -> None:
        return


def run_web_setup(*, open_browser: bool = True, timeout_seconds: int = 900) -> int:
    """启动一次性本机配置页。保存成功或超时后退出。"""
    server = _SetupServer(("127.0.0.1", 0), _Handler)
    server.session_token = secrets.token_urlsafe(24)
    port = server.server_address[1]
    url = f"http://127.0.0.1:{port}/?session={quote(server.session_token)}"
    print("amz 安全配置页面已准备好。", flush=True)
    print(url, flush=True)
    if open_browser:
        try:
            webbrowser.open(url)
        except webbrowser.Error:
            pass
    timer = threading.Timer(timeout_seconds, server.shutdown)
    timer.daemon = True
    timer.start()
    try:
        server.serve_forever(poll_interval=0.2)
    finally:
        timer.cancel()
        server.server_close()
    if server.saved:
        print(json.dumps(saved_status(), ensure_ascii=False), flush=True)
        return 0
    print("配置页面已超时，请让 Agent 重新打开。", flush=True)
    return 1
