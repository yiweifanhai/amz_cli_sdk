"""
PipelineSpec — composite 层的中间表示（IR）。

这是三条创作路径（自然语言 / 拖拽 / 手写 Python）共同收敛的**唯一真相源**：

- 可 JSON/YAML 序列化（用于落盘、传给 harness、拖拽编辑）
- 可校验（``validate`` 做结构化校验 + 可选能力存在性校验）
- 可 codegen（``to_python`` 生成可手工改造的 ``pipeline.py`` 骨架）

``StepSpec`` 只含声明式字段（能力 ID + 数据流接线），不含 Python 可调用对象：
手写 ``fn`` 的路径属于运行时的 ``Step``（见 ``base.py``），经 ``Pipeline.to_spec()``
转换为 spec 时，``fn`` 步骤的 ``capability`` 为 None（可视化降级为通用渲染器）。
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator

from amz.config import config
from amz.infra.paths import validate_component


# ---------------------------------------------------------------------------
# 端口接线
# ---------------------------------------------------------------------------

class PortBinding(BaseModel):
    """一块积木的某个输入，从哪个上游/参数取。

    例如 ``PortBinding(source="product_info", field="items")`` 表示该输入取
    ``product_info`` 步骤产物的 ``items`` 字段；``PortBinding(source="params",
    key="asins")`` 表示取 run 参数里的 ``asins``。
    """

    source: str = ""  # 上游 step 名 | "params"
    field: str = ""   # 取上游 artifact 的哪个字段；空 = 整个 data
    key: str = ""     # source == "params" 时的参数键名


# ---------------------------------------------------------------------------
# StepSpec
# ---------------------------------------------------------------------------

class StepSpec(BaseModel):
    """单步的声明式描述。

    与 ``base.Step`` 的差异：不含 ``fn``（Callable），因此可 JSON 序列化。
    """

    name: str
    capability: str | None = None  # registry 能力 ID（含 entity.* / composite.*）
    mode: Literal["batch", "map", "reduce"] = "batch"
    item_key: str = ""             # map 模式匹配 item 的字段（如 "asin"）
    map_from: str = ""             # "params" | 上游 step 名；默认 depends[0]
    list_key: str = ""             # map_from="params" 时显式列表键名
    depends: list[str] = Field(default_factory=list)
    inputs: dict[str, PortBinding] = Field(default_factory=dict)  # 显式端口接线
    output_schema: dict | None = None  # 未填则从 capability.output_schema 解析
    description: str = ""          # 「说明」：这块干什么，web 平台直接展示
    concurrency: int = 5
    optional: bool = False
    ttl_hours: int = 24
    retry: int = 0
    timeout_s: float = 0.0

    @model_validator(mode="before")
    @classmethod
    def reject_managed_fn(cls, value: Any) -> Any:
        if config.is_managed and isinstance(value, dict) and "fn" in value:
            raise ValueError("managed composite steps cannot define fn")
        return value


# ---------------------------------------------------------------------------
# PipelineSpec
# ---------------------------------------------------------------------------

class PipelineSpec(BaseModel):
    """整条 pipeline 的声明式描述。"""

    name: str
    description: str = ""
    category: str = ""
    version: str = "v1"
    params_schema: dict = Field(default_factory=dict)  # run 参数 JSON Schema
    steps: list[StepSpec] = Field(default_factory=list)

    def validate_managed(self) -> None:
        """Validate data-only discovery; empty scaffolds are valid editable specs."""
        if not config.is_managed:
            return
        validate_component(self.name, label="pipeline name")
        for step in self.steps:
            validate_component(step.name, label="step name")
            if not step.capability:
                raise ValueError(f"step '{step.name}': managed composite requires a capability")
            validate_component(step.capability, label="capability")

    # ------------------------------------------------------------------
    # 校验
    # ------------------------------------------------------------------

    def validate(self, check_capabilities: bool = False) -> list[str]:
        """结构化校验，返回错误列表（空 = 通过）。

        Args:
            check_capabilities: True 时额外校验每个 capability ID 已在 registry 注册。
        """
        errors: list[str] = []
        try:
            self.validate_managed()
        except ValueError as exc:
            errors.append(str(exc))
        if not self.name:
            errors.append("pipeline name is empty")
        if not self.steps:
            errors.append("no steps defined")

        names: list[str] = []
        for s in self.steps:
            if s.name in names:
                errors.append(f"duplicate step name '{s.name}'")
            names.append(s.name)

        name_set = set(names)
        for s in self.steps:
            # 依赖存在性
            for dep in s.depends:
                if dep not in name_set:
                    errors.append(f"step '{s.name}' depends on unknown step '{dep}'")
            # 能力 ID 必须非空（若有）
            if s.capability is not None and not s.capability.strip():
                errors.append(f"step '{s.name}': capability is empty string (use null for custom fn)")
            # map 模式需要 item_key
            if s.mode == "map" and not s.item_key:
                errors.append(f"step '{s.name}': mode='map' requires item_key")
            # map/reduce 需要数据源
            if s.mode in ("map", "reduce"):
                source = s.map_from or (s.depends[0] if s.depends else "")
                if not source:
                    errors.append(
                        f"step '{s.name}': mode='{s.mode}' requires map_from or depends"
                    )
                elif source != "params" and source not in name_set:
                    errors.append(
                        f"step '{s.name}': map_from '{source}' is not a step nor 'params'"
                    )
            # map_from 指向的步骤是否存在
            if s.map_from and s.map_from != "params" and s.map_from not in name_set:
                errors.append(
                    f"step '{s.name}': map_from '{s.map_from}' is not a known step"
                )
            # concurrency
            if s.concurrency < 1:
                errors.append(f"step '{s.name}': concurrency must be >= 1, got {s.concurrency}")

        # 环检测
        if name_set and not errors:
            if _has_cycle(self.steps):
                errors.append("circular dependency detected")

        # 能力存在性（可选）
        if check_capabilities:
            from amz.registry import registry

            for s in self.steps:
                if s.capability and registry.get(s.capability) is None:
                    errors.append(
                        f"step '{s.name}': unknown capability '{s.capability}'"
                    )
                elif s.capability and registry.get(s.capability).internal:
                    cap = registry.get(s.capability)
                    errors.append(f"step '{s.name}': {s.capability} is internal; use {cap.entity_entrypoint or 'its Entity entrypoint'}")

        return errors

    @property
    def step_names(self) -> list[str]:
        return [s.name for s in self.steps]

    # ------------------------------------------------------------------
    # codegen
    # ------------------------------------------------------------------

    def to_python(self) -> str:
        """生成 ``pipeline.py`` 骨架（供 NL/拖拽产出后手工改造）。"""
        lines: list[str] = []
        lines.append('"""')
        lines.append(self.description or self.name)
        lines.append("")
        lines.append("由 PipelineSpec 生成；可手工改造。")
        lines.append('"""')
        lines.append("from amz.composite.base import Pipeline, Step")
        lines.append("")
        lines.append("PIPELINE = Pipeline(")
        lines.append(f"    name={self.name!r},")
        lines.append(f"    description={self.description!r},")
        lines.append(f"    category={self.category!r},")
        lines.append(f"    version={self.version!r},")
        lines.append(f"    params_schema={_fmt(self.params_schema)},")
        lines.append("    steps=[")
        for s in self.steps:
            lines.append(_fmt_step(s))
        lines.append("    ],")
        lines.append(")")
        return "\n".join(lines) + "\n"


def _fmt_step(s: StepSpec) -> str:
    args: list[str] = [f"name={s.name!r}"]
    if s.capability is not None:
        args.append(f"capability={s.capability!r}")
    if s.mode != "batch":
        args.append(f"mode={s.mode!r}")
    if s.item_key:
        args.append(f"item_key={s.item_key!r}")
    if s.map_from:
        args.append(f"map_from={s.map_from!r}")
    if s.list_key:
        args.append(f"list_key={s.list_key!r}")
    if s.depends:
        args.append(f"depends={s.depends!r}")
    if s.description:
        args.append(f"description={s.description!r}")
    if s.concurrency != 5:
        args.append(f"concurrency={s.concurrency}")
    if s.optional:
        args.append(f"optional={s.optional!r}")
    if s.ttl_hours != 24:
        args.append(f"ttl_hours={s.ttl_hours}")
    if s.retry:
        args.append(f"retry={s.retry}")
    if s.timeout_s:
        args.append(f"timeout_s={s.timeout_s}")
    if s.output_schema is not None:
        args.append(f"output_schema={_fmt(s.output_schema)}")
    return f"        Step({', '.join(args)}),"


def _fmt(value: Any) -> str:
    import json

    return json.dumps(value, ensure_ascii=False, default=str, indent=None)


# ---------------------------------------------------------------------------
# 环检测（本地实现，避免与 base.py 循环 import）
# ---------------------------------------------------------------------------

def _has_cycle(steps: list[StepSpec]) -> bool:
    """拓扑层数 < 总步数即存在环。"""
    name_set = {s.name for s in steps}
    in_degree = {s.name: 0 for s in steps}
    dependents: dict[str, list[str]] = {s.name: [] for s in steps}
    for s in steps:
        for dep in s.depends:
            if dep in name_set:
                in_degree[s.name] += 1
                dependents[dep].append(s.name)

    queue = [n for n, d in in_degree.items() if d == 0]
    seen = 0
    while queue:
        name = queue.pop(0)
        seen += 1
        for dep_name in dependents[name]:
            in_degree[dep_name] -= 1
            if in_degree[dep_name] == 0:
                queue.append(dep_name)
    return seen != len(steps)
