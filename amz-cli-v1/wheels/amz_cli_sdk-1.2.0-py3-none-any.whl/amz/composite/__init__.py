"""
L3 Composite 层 — 固定 SOP Workflow 框架。

核心定位：步骤通过 Entity 业务方法使用 LLM（如 entity.product.voc），步骤间的编排关系（谁先谁后、
谁依赖谁）是写死的——开发者预声明 DAG，运行时严格按 DAG 执行，不做 LLM 分支决策。

与 agents/ 的区别：
  - composite：编排关系固定（SOP），步骤内部可调 LLM。同输入必定同路径，100% 可复现
  - agents：编排关系由 LLM 实时决定（选步骤/判条件/做循环），步骤内部也可调 LLM

框架化的三条创作路径（都收敛到 ``PipelineSpec``）：
  1. 自然语言 → harness 依 ``agents/composite-authoring/SKILL.md`` 产出 spec
     → ``composite.validate`` 自检 → ``composite.compile`` 落地
  2. 可视化拖拽 → 写回 spec.json
  3. 手写 Python → ``Pipeline`` 对象（``to_spec()`` 导出，可与 spec 互转）

发现机制：多根目录（用户 ``~/.amz/composite/`` > ``AMZ_COMPOSITE_DIR`` > entry
points > 内置），见 ``loader.py``。
"""

from __future__ import annotations

from typing import Any, Callable

from pydantic import BaseModel, ConfigDict

from amz.envelope import Code, err, ok
from amz.registry import registry
from amz.composite.spec import PipelineSpec
from amz.composite.base import PipelineRunner, spec_to_pipeline
from amz.composite.loader import (
    builtin_root,
    get_pipeline_spec,
    list_pipeline_specs,
    pipeline_roots,
)
from amz.composite.schema_registry import resolve_output_schema


class _CompositeInput(BaseModel):
    """composite pipeline 能力输入：任意参数透传（``extra="allow"``）。"""

    model_config = ConfigDict(extra="allow")


# composite.<name> 能力的输出：run 摘要（中间产物仍落盘供可视化）
_PIPELINE_OUTPUT = {
    "type": "object",
    "properties": {
        "run_id": {"type": "string"},
        "pipeline": {"type": "string"},
        "success": {"type": "boolean"},
        "errors": {"type": "object", "additionalProperties": {"type": "string"}},
        "steps": {"type": "object", "additionalProperties": {"type": "string"}},
        "result": {},
    },
}


def _pipeline_input_schema(spec: PipelineSpec) -> dict:
    """推导 pipeline 能力的输入 schema（满足「有 properties」的约定）。"""
    if spec.params_schema and spec.params_schema.get("properties"):
        schema = dict(spec.params_schema)
        schema.setdefault("type", "object")
        schema.setdefault("additionalProperties", True)
        return schema

    # 从 map_from="params" 的入口步骤推导列表参数
    props: dict[str, Any] = {}
    for s in spec.steps:
        if s.map_from == "params":
            key = s.list_key or (s.item_key + "s" if s.item_key else "")
            if key and key not in props:
                props[key] = {"type": "array", "items": {"type": "string"}}
    if props:
        return {"type": "object", "properties": props, "additionalProperties": True}

    # 无入口参数：声明一个语义化 force 键（fn 忽略，仅满足 schema 约定）
    return {
        "type": "object",
        "properties": {"force": {"type": "boolean", "default": False}},
        "additionalProperties": True,
    }


# ---------------------------------------------------------------------------
# 发现
# ---------------------------------------------------------------------------

def list_pipelines() -> list[dict]:
    """列出全部已发现 pipeline 的元数据。"""
    return [
        {
            "name": s.name,
            "description": s.description,
            "category": s.category,
            "version": s.version,
            "steps": len(s.steps),
        }
        for s in list_pipeline_specs()
    ]


def get_pipeline(name: str):
    """按名称取可执行的运行时 Pipeline 对象（供 serve/runner 使用）。"""
    return spec_to_pipeline(get_pipeline_spec(name))


def get_spec(name: str) -> PipelineSpec:
    """按名称取 PipelineSpec（唯一真相源，声明式 spec）。"""
    return get_pipeline_spec(name)


def get_runtime_pipeline(name: str):
    """别名：同 get_pipeline，返回运行时 Pipeline。"""
    return get_pipeline(name)


# ---------------------------------------------------------------------------
# 执行
# ---------------------------------------------------------------------------

def run_pipeline(
    name: str,
    params: dict | None = None,
    force: bool = False,
    on_event: Callable | None = None,
):
    """运行一条 pipeline，返回 RunResult。"""
    spec = get_pipeline_spec(name)
    runner = PipelineRunner(spec_to_pipeline(spec))
    return runner.run(params or {}, force=force, on_event=on_event)


# ---------------------------------------------------------------------------
# 注册进 registry（composite.<name> 能力）
# ---------------------------------------------------------------------------

def register_pipeline(spec: PipelineSpec) -> str:
    """把 PipelineSpec 注册为 ``composite.<name>`` 能力（幂等），返回能力 ID。"""
    spec.validate_managed()
    cap_id = f"composite.{spec.name}"
    if registry.get(cap_id) is not None:
        return cap_id

    final_step = spec.steps[-1] if spec.steps else None

    def fn(**params: Any):
        runner = PipelineRunner(spec_to_pipeline(spec))
        result = runner.run(params)
        steps = {name: a.status for name, a in result.artifacts.items()}
        final = None
        if final_step and final_step.name in result.artifacts:
            final = result.artifacts[final_step.name].data
        summary = {
            "run_id": result.run_id,
            "pipeline": spec.name,
            "success": result.success,
            "errors": result.errors,
            "steps": steps,
            "result": final,
        }
        if not result.success:
            return err(Code.ERROR_UPSTREAM, "composite pipeline failed", data=summary)
        return ok(data=summary)

    registry.register(
        cap_id,
        description=spec.description or f"composite pipeline: {spec.name}",
        category="composite",
        input_model=_CompositeInput,
        input_schema=_pipeline_input_schema(spec),
        output_schema=_PIPELINE_OUTPUT,
    )(fn)
    return cap_id


def register_pipelines() -> int:
    """注册全部已发现 pipeline（幂等），返回本次新增数量。"""
    added = 0
    for spec in list_pipeline_specs():
        cap_id = f"composite.{spec.name}"
        if registry.get(cap_id) is None:
            register_pipeline(spec)
            added += 1
    return added


__all__ = [
    "list_pipelines",
    "get_pipeline",
    "get_runtime_pipeline",
    "run_pipeline",
    "register_pipeline",
    "register_pipelines",
    "builtin_root",
    "pipeline_roots",
]
