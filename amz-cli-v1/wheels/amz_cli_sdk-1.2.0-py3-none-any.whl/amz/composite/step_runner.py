"""Shared fixed-step operators using Entity refs and the caller's Runtime.

These operators never cache step results or create another job. They are the
small execution subset used by Product Dev; the legacy v1 runner is unchanged.
"""
from __future__ import annotations

import contextvars
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from typing import Any, Generic, Literal, TypeVar

from pydantic import BaseModel, ConfigDict, Field, TypeAdapter, ValidationError

from amz.envelope import Code, Meta, Result, err
from amz.registry import registry
from amz.schemas.entity_ref import EntityRef

T = TypeVar("T")


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)


class StepPlan(StrictModel):
    name: str = Field(pattern=r"^[a-z][a-z0-9_]{0,63}$")
    title: str
    description: str
    capability: str
    mode: Literal["map", "reduce", "batch"]
    from_step: str | None = None
    min_success: int = Field(default=3, ge=1)
    concurrency: int = Field(default=3, ge=1, le=6)
    renderer: str


def validate_plan(plans: tuple[StepPlan, ...]) -> None:
    """This release supports a fixed linear plan, not the full proposed DAG."""
    if not plans or len({plan.name for plan in plans}) != len(plans):
        raise ValueError("Plan needs unique steps")
    previous = None
    for plan in plans:
        if plan.from_step != previous:
            raise ValueError("Only explicit linear step dependencies are supported")
        if not plan.capability.startswith("entity."):
            raise ValueError("Business steps must call Entity capabilities")
        previous = plan.name


class Failure(StrictModel):
    step: str
    ref: EntityRef | None = None
    code: Code
    message: str
    missing: list[str] = Field(default_factory=list)
    details: Any = Field(default=None, description="失败能力返回的原始诊断；不作为后续业务输入")


class ItemOutput(StrictModel, Generic[T]):
    ref: EntityRef
    state: Literal["ok", "failed"]
    data: T | None = None
    error: Failure | None = None
    meta: Meta = Field(default_factory=Meta)


class StepOutput(StrictModel, Generic[T]):
    name: str
    title: str
    capability: str
    mode: Literal["map", "reduce", "batch"]
    state: Literal["queued", "running", "succeeded", "partial", "failed", "blocked"] = "queued"
    input_count: int = Field(default=0, ge=0, description="本步骤实际接收的商品数")
    success_count: int = Field(default=0, ge=0)
    failed_count: int = Field(default=0, ge=0)
    items: list[ItemOutput[T]] = Field(default_factory=list)
    data: T | None = None
    error: Failure | None = None
    started_at: str | None = None
    finished_at: str | None = None


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def failure(step: str, result: Result, ref: EntityRef | None = None) -> Failure:
    return Failure(step=step, ref=ref, code=result.code, message=result.message,
                   missing=result.meta.missing, details=result.data)


def invoke_checked(context: Any, plan: StepPlan, params: dict, output_type: Any) -> Result:
    cap = registry.get(plan.capability)
    if cap is None or cap.internal or not plan.capability.startswith("entity."):
        return err(Code.ERROR_PARAM, "固定业务步骤必须使用已注册的 Entity 入口")
    try:
        result = context.invoke(plan.capability, params)
        if result.code == Code.OK:
            value = TypeAdapter(output_type).validate_python(result.data)
            result = result.model_copy(update={"data": TypeAdapter(output_type).dump_python(value, mode="json")})
        return result
    except ValidationError as exc:
        return err(Code.ERROR_SERVER_INTERNAL, "步骤输出不符合 Schema", data=exc.errors(include_context=False))
    except Exception as exc:
        return err(Code.ERROR_SERVER_INTERNAL, f"{type(exc).__name__}: {exc}")


def publish_step(context: Any, output: StepOutput) -> None:
    context.step(output.name, output.title, output.state,
                 result=output.model_dump(mode="json"),
                 error=output.error.message if output.error else "")


def run_map(plan: StepPlan, refs: list[EntityRef], context: Any, output_type: Any) -> StepOutput:
    """Preserve order and every failed item; publish real item progress."""
    if plan.mode != "map" or len(set(refs)) != len(refs):
        raise ValueError("Map needs unique Entity refs")
    output = StepOutput[output_type](**plan.model_dump(include={"name", "title", "capability", "mode"}),
                                    state="running", input_count=len(refs), started_at=now())
    publish_step(context, output)
    items: dict[int, ItemOutput] = {}
    with ThreadPoolExecutor(max_workers=plan.concurrency, thread_name_prefix="composite-map") as pool:
        futures = {
            pool.submit(contextvars.copy_context().run, invoke_checked, context, plan, ref.identity, output_type): (index, ref)
            for index, ref in enumerate(refs)
        }
        for future in as_completed(futures):
            index, ref = futures[future]
            result = future.result()
            item = ItemOutput[output_type](ref=ref, state="ok" if result.code == Code.OK else "failed",
                    data=result.data if result.code == Code.OK else None,
                    error=failure(plan.name, result, ref) if result.code != Code.OK else None, meta=result.meta)
            items[index] = item
            output.items = [items[i] for i in sorted(items)]
            output.success_count = sum(item.state == "ok" for item in items.values())
            output.failed_count = len(items) - output.success_count
            publish_step(context, output)
            context.emit(f"{plan.title}：完成 {len(items)}/{len(refs)}，成功 {output.success_count}",
                         type="step.item.done", data={"step": plan.name, "asin": ref.identity["asin"],
                         "completed": len(items), "total": len(refs), "state": item.state})
    output.finished_at = now()
    if output.success_count < plan.min_success:
        output.state = "failed"
        output.error = failure(plan.name, err(Code.ERROR_MISSING_FIELDS,
            f"{plan.title}成功商品只有 {output.success_count} 个，至少需要 {plan.min_success} 个",
            missing=[plan.capability]))
    else:
        output.state = "partial" if output.failed_count else "succeeded"
    publish_step(context, output)
    return output


def run_once(plan: StepPlan, params: dict, context: Any, output_type: Any, input_count: int) -> StepOutput:
    """Batch and Reduce share one call; the caller explicitly binds sample_refs."""
    if plan.mode not in {"reduce", "batch"}:
        raise ValueError("run_once requires batch or reduce")
    output = StepOutput[output_type](**plan.model_dump(include={"name", "title", "capability", "mode"}),
                                    state="running", input_count=input_count, started_at=now())
    publish_step(context, output)
    result = invoke_checked(context, plan, params, output_type)
    output.finished_at = now()
    if result.code == Code.OK:
        output.state = "succeeded"
        output.data = TypeAdapter(output_type).validate_python(result.data)
        output.success_count = input_count
    else:
        output.state = "failed"
        output.failed_count = input_count
        output.error = failure(plan.name, result)
    publish_step(context, output)
    return output
