"""Product Dev: fixed Entity steps, typed artifacts and a portable view contract."""
from __future__ import annotations

from typing import Annotated, Any, Literal

from pydantic import BaseModel, ConfigDict, Field, TypeAdapter, field_validator

from amz.composite.step_runner import (
    Failure, StepOutput, StepPlan, StrictModel, failure, now, publish_step, run_map, run_once, validate_plan,
)
from amz.entities.market.models import ProposalsResult
from amz.entities.product import ProductDetails
from amz.entities.product.reviews import ReviewData
from amz.envelope import Code, Result, err, ok
from amz.registry import registry
from amz.schemas.entity_ref import EntityRef, product_ref
from amz.schemas.voc import ProductVoc

WORKFLOW_ID = "composite.product-development"
VERSION = "2.0.0"


class ProductDevelopmentInput(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)
    term: str = Field(min_length=1, max_length=200, title="市场关键词", description="这批商品所属的同一细分市场")
    marketplace: Literal["US"] = Field(default="US", title="站点")
    asins: list[Annotated[str, Field(pattern=r"^[A-Z0-9]{10}$")]] = Field(
        default_factory=list, max_length=20, title="竞品 ASIN",
        description="每行一个 10 位 ASIN，填写 3–20 个不同商品；留空则按市场搜索顺序取样",
        json_schema_extra={"uniqueItems": True, "anyOf": [{"maxItems": 0}, {"minItems": 3}]},
    )
    sample_size: int = Field(default=5, ge=3, le=20, strict=True, title="自动取样数量", description="仅未填写 ASIN 时生效；不代表市场全量或头部排名")
    pages: int = Field(default=2, ge=1, le=3, strict=True, title="市场搜索页数", description="仅自动寻找商品时使用；不是评论页数")

    @field_validator("asins", mode="before")
    @classmethod
    def check_asins(cls, values: Any) -> list[str]:
        if not isinstance(values, list) or any(not isinstance(v, str) for v in values):
            raise ValueError("ASIN 必须是字符串列表")
        values = [product_ref("US", value).identity["asin"] for value in values]
        if len(set(values)) != len(values):
            raise ValueError("ASIN 必须不同")
        if values and len(values) < 3:
            raise ValueError("至少需要 3 个不同 ASIN")
        return values


PLAN = (
    StepPlan(name="details", title="商品资料", description="准备同站点样本，保存商品详情与 Listing 事实", capability="entity.product.product_details", mode="map", renderer="product-details"),
    StepPlan(name="reviews", title="评论证据", description="保存评论原文、实际样本数量和采样条件", capability="entity.product.reviews", mode="map", from_step="details", renderer="product-reviews"),
    StepPlan(name="voc", title="单品分析", description="逐商品分析 Listing 优势、评论痛点与使用洞察", capability="entity.product.voc", mode="map", from_step="reviews", renderer="product-voc"),
    StepPlan(name="proposals", title="开发建议", description="一次市场分析返回成功因子、缺口和改进提案", capability="entity.market.proposals", mode="reduce", from_step="voc", renderer="market-proposals"),
)
TYPES = {"details": ProductDetails, "reviews": ReviewData, "voc": ProductVoc, "proposals": ProposalsResult}


class Artifacts(StrictModel):
    details: StepOutput[ProductDetails]
    reviews: StepOutput[ReviewData]
    voc: StepOutput[ProductVoc]
    proposals: StepOutput[ProposalsResult]


class Coverage(StrictModel):
    requested: int = Field(ge=0, description="最初选择的商品数")
    details: int = Field(ge=0, description="详情步骤成功数")
    reviews: int = Field(ge=0, description="评论步骤成功数，不等于可分析评论充足")
    voc: int = Field(ge=0, description="单品分析成功数")
    market_used: int | None = Field(default=None, ge=0, description="Market 返回的 VOC 准备后样本数；不代表每条结论覆盖数")
    proposal_count: int = Field(default=0, ge=0)


class ProductDevelopmentOutput(StrictModel):
    schema_version: Literal["product-development.v1"] = "product-development.v1"
    workflow_version: Literal["2.0.0"] = VERSION
    run_id: str | None = Field(default=None, description="所属 Runtime；纯函数离线验证时可为空")
    status: Literal["OK", "PARTIAL", "FAILED"]
    term: str
    marketplace: Literal["US"]
    selection: Literal["explicit", "market_search"]
    requested_refs: list[EntityRef]
    coverage: Coverage
    artifacts: Artifacts
    failures: list[Failure]
    report: str = Field(description="只格式化本次结构化产物的 Markdown 报告，不再次调用模型")


OUTPUT_SCHEMA = ProductDevelopmentOutput.model_json_schema()
STEPS = [dict(id=step.name, title=step.title, description=step.description,
              capability=step.capability, mode=step.mode, depends=[step.from_step] if step.from_step else [],
              renderer=step.renderer, output_schema=StepOutput[TYPES[step.name]].model_json_schema()) for step in PLAN]
VIEW = {"version": 1, "title": "产品开发", "related_skills": ["skill.amz-product-improve"],
        "stages": [{"id": step.name, "step": step.name, "title": step.title, "renderer": step.renderer} for step in PLAN],
        "summary_fields": ["requested", "details", "reviews", "voc", "market_used", "proposal_count"]}


class _RegistryContext:
    def invoke(self, capability: str, params: dict) -> Result:
        return registry.invoke(capability, params)

    def emit(self, message: str, type: str = "progress", data: Any = None) -> None:
        pass

    def step(self, id: str, title: str, status: str, result: Any = None, error: str = "") -> None:
        from amz.infra.runtime import get_current
        from amz.composite.base import Artifact
        runtime = get_current()
        if runtime is not None:
            # Persist the typed step before announcing its completion.
            spec = next(step for step in STEPS if step["id"] == id)
            Artifact(run_id=runtime.run_id, step=id, status=status, data=result,
                     output_schema=spec["output_schema"], produced_at=now()).save()
            if status in {"succeeded", "partial", "failed", "blocked"}:
                runtime.record("artifact", id, f"runs/{runtime.run_id}/artifacts/{id}.json",
                               schema="product-development.v1")
            runtime.record_step(id, status, {"title": title, "error": error})


def register_product_development() -> None:
    if registry.get(WORKFLOW_ID) is None:
        registry.register(WORKFLOW_ID, description="商品资料 → 评论证据 → 单品分析 → 开发建议",
            category="composite", input_model=ProductDevelopmentInput, output_model=ProductDevelopmentOutput,
            requires=["entity.market.product_refs", *[step.capability for step in PLAN]])(_registered_run)


def _registered_run(**params: Any) -> Result:
    from amz.infra.runtime import Runtime, get_current, runtime_context
    inputs = ProductDevelopmentInput.model_validate(params)
    if get_current() is not None:
        return run_product_development(inputs, _RegistryContext())
    runtime = Runtime.begin(name=WORKFLOW_ID, params=inputs.model_dump(mode="json"))
    try:
        with runtime_context(runtime):
            result = run_product_development(inputs, _RegistryContext())
            runtime.save_result(WORKFLOW_ID, result, params=inputs.model_dump(mode="json"))
            runtime.finish(result.code == Code.OK, result.message if result.code != Code.OK else "")
    except Exception as exc:
        result = err(Code.ERROR_SERVER_INTERNAL, f"Product Dev 记录或执行失败：{exc}")
        try:
            runtime.finish(False, result.message)
        except OSError:
            pass
    result.meta.hint = f"run_id={runtime.run_id}"
    return result


def run_product_development(inputs: ProductDevelopmentInput, context: Any) -> Result:
    from amz.infra.runtime import get_current
    validate_plan(PLAN)
    outputs = {step.name: StepOutput[TYPES[step.name]](**step.model_dump(include={"name", "title", "capability", "mode"})) for step in PLAN}
    failures: list[Failure] = []
    requested: list[EntityRef] = []
    error: Failure | None = None
    for output in outputs.values():
        publish_step(context, output)
    try:
        if inputs.asins:
            requested = [product_ref(inputs.marketplace, asin) for asin in inputs.asins]
        else:
            outputs["details"].state = "running"
            publish_step(context, outputs["details"])
            context.emit("按市场搜索顺序准备商品样本；这不是头部商品排名")
            found = context.invoke("entity.market.product_refs", {"term": inputs.term, "marketplace": inputs.marketplace, "pages": inputs.pages})
            if found.code != Code.OK:
                error = failure("details", found)
            else:
                refs = TypeAdapter(list[EntityRef]).validate_python(found.data)
                if any(ref.entity_type != "product" or ref.identity["marketplace"] != inputs.marketplace or len(ref.identity["asin"]) != 10 for ref in refs):
                    raise ValueError("市场样本必须是同站点、10 位 ASIN 的商品引用")
                requested = list(dict.fromkeys(refs))[:inputs.sample_size]
        if not error and len(requested) < 3:
            error = failure("details", err(Code.ERROR_MISSING_FIELDS, "市场有效商品少于 3 个", missing=["product_refs"]))
        for plan in PLAN:
            if error:
                output = outputs[plan.name]
                output.state = "failed" if plan.name == error.step else "blocked"
                output.error = error
                output.finished_at = now()
                publish_step(context, output)
                continue
            refs = requested if plan.from_step is None else [item.ref for item in outputs[plan.from_step].items if item.state == "ok"]
            if plan.mode == "map":
                output = run_map(plan, refs, context, TYPES[plan.name])
            else:
                output = run_once(plan, {"term": inputs.term, "marketplace": inputs.marketplace,
                    "sample_refs": [ref.model_dump(mode="json") for ref in refs]}, context, TYPES[plan.name], len(refs))
                if output.data:
                    evidence = output.data.evidence
                    if (evidence.used_count < 3 or evidence.used_count > len(refs)
                            or evidence.market_ref.entity_type != "market"
                            or evidence.market_ref.identity["marketplace"] != inputs.marketplace
                            or not output.data.micro_renovation_proposals):
                        output.state = "failed"
                        output.error = failure(plan.name, err(Code.ERROR_MISSING_FIELDS, "市场结果缺少有效样本或具体提案", missing=["evidence/proposals"]))
                    elif evidence.used_count < len(refs) or any(source.state != "ready" for source in evidence.sources):
                        output.state = "partial"
                    output.success_count = evidence.used_count if 0 <= evidence.used_count <= len(refs) else 0
                    output.failed_count = len(refs) - output.success_count
                    publish_step(context, output)
            outputs[plan.name] = output
            failures.extend(item.error for item in output.items if item.error)
            if output.state == "failed":
                error = output.error
    except Exception as exc:
        current = next((value for value in outputs.values() if value.state in {"running", "queued"}), outputs["details"])
        error = failure(current.name, err(Code.ERROR_SERVER_INTERNAL, f"{type(exc).__name__}: {exc}"))
        current.state, current.error, current.finished_at = "failed", error, now()
        publish_step(context, current)
        for output in outputs.values():
            if output.state in {"queued", "running"}:
                output.state, output.error = "blocked", error
                publish_step(context, output)
    if error:
        failures.append(error)
    analysis = outputs["proposals"].data
    coverage = Coverage(requested=len(requested), details=outputs["details"].success_count,
        reviews=outputs["reviews"].success_count, voc=outputs["voc"].success_count,
        market_used=analysis.evidence.used_count if analysis and 0 <= analysis.evidence.used_count <= outputs["proposals"].input_count else None,
        proposal_count=len(analysis.micro_renovation_proposals) if analysis and not error else 0)
    status = "FAILED" if error else "PARTIAL" if any(value.state == "partial" for value in outputs.values()) else "OK"
    report = _report(inputs.term, coverage, analysis if not error else None, failures, status)
    runtime = get_current()
    data = ProductDevelopmentOutput(run_id=runtime.run_id if runtime else None,
        status=status, term=inputs.term, marketplace=inputs.marketplace,
        selection="explicit" if inputs.asins else "market_search", requested_refs=requested, coverage=coverage,
        artifacts=Artifacts(**outputs), failures=failures, report=report).model_dump(mode="json")
    return err(error.code, error.message, data=data, missing=error.missing) if error else ok(data)


def _report(term: str, coverage: Coverage, analysis: ProposalsResult | None, failures: list[Failure], status: str) -> str:
    lines = [f"# 产品开发：{term}", "", f"状态：{status}。选择 {coverage.requested} 个商品；单品分析成功 {coverage.voc} 个；市场有效样本 {coverage.market_used if coverage.market_used is not None else '未生成'} 个。", ""]
    if analysis:
        lines += ["## 市场总结", "", analysis.market_gap.market_summary, "", "## 成功因子", ""]
        for factor in analysis.success_factors.market_leaders_success_factors:
            lines += [f"- {factor.factor_name}：{factor.description}（ASIN：{', '.join(factor.example_asins)}）"]
        lines += ["", "## 市场缺口", ""]
        for point in analysis.market_gap.problem_points:
            lines += [f"- {point.point}：{point.description}（涉及 {point.asin_cnt} 个商品；{', '.join(point.asin_list)}）"]
        lines += ["", "## 改进提案", ""]
        for proposal in analysis.micro_renovation_proposals:
            lines += [f"### {proposal.title}", "", f"目标问题：{proposal.target_pain_point}", "", f"具体改动：{proposal.change_description}", "", f"预期收益：{proposal.expected_benefit}", "", f"难度：{proposal.difficulty}；相关 ASIN：{', '.join(proposal.related_asins)}", ""]
    else:
        lines += ["本次未完成开发建议。已完成阶段和失败样本保留在步骤产物中。", ""]
    lines += ["## 数据范围", "", "优势依据来自 Listing；痛点和使用洞察来自实际评论样本。各结论覆盖范围以自己的证据为准。", "提案尚未完成工艺、成本、合规或专利验证。"]
    for item in failures:
        lines.append(f"- {item.ref.identity['asin'] if item.ref else ''} / {item.step}：{item.message}")
    return "\n".join(lines) + "\n"
