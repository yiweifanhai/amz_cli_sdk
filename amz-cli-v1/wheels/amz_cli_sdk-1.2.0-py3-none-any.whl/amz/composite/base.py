"""
Composite 层核心基础设施：Step / Artifact / Pipeline / PipelineRunner / RunResult。

设计要点
--------
- **Step**：声明式步骤定义，支持三种执行模式（batch / map / reduce），
  ``fn``（Python 可调用）与 ``capability``（registry 能力 ID）二选一。
- **Artifact**：步骤产物，带 schema 的 JSON 文件，落盘到
  ``~/.cache/amz-cli/runs/{run_id}/artifacts/``（复用 infra.runtime 工作区）。
- **Pipeline**：流程定义基类，声明步骤列表，可导出/从 ``PipelineSpec`` 转换。
- **PipelineRunner**：执行引擎，拓扑排序 → 分层并发 → 缓存检查 → capability 解析
  → 产物落盘 + runtime 记录 + 进度事件。
- **RunResult**：执行结果汇总。

三种执行模式
------------
===== ====== ===================================================== ==========================
模式   签名                                                         Runner 行为
===== ====== ===================================================== ==========================
batch  ``fn(params, deps_data) -> dict``                           调用一次
map    ``fn(item, deps_items, params) -> dict``                    取列表 → 逐项并发 →
                                                                    自动匹配依赖 → 收集结果
reduce ``fn(all_items, deps_data, params) -> dict``                收集上游全部 item → 单次调用
===== ====== ===================================================== ==========================

capability 步骤：Runner 走 ``registry.invoke(capability, input_params)``，输入由
``inputs`` 端口绑定（或默认：map=item、batch/reduce=params）构造，``Result.meta``
的 usage/upstream 自动捕获进 Artifact meta。

缓存策略
--------
``run_id`` 为确定性指纹（pipeline + version + 规范化 params），「工作区即缓存」：
同参数复用 workspace/artifact，``force=True`` 重跑。
"""

from __future__ import annotations

import contextvars
import hashlib
import json
import os
import re
import threading
import tempfile
import time
import traceback
import warnings

# Artifact 字段名 ``schema`` 与 Pydantic BaseModel 的废弃方法同名，仅告警不影响功能。
warnings.filterwarnings(
    "ignore",
    message=r"Field name .*shadows an attribute in parent .*BaseModel.*",
)
from collections import deque
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from pydantic import BaseModel, Field

from amz.config import config
from amz.envelope import Code
from amz.registry import registry
from amz.infra.paths import MAX_COMPONENT_LENGTH, cache_path, confined_path, validate_component
from amz.infra.runtime import Runtime, runtime_context
from amz.composite.spec import PipelineSpec, StepSpec, PortBinding
from amz.composite.schema_registry import resolve_output_schema
from amz.composite.events import event as make_event


# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------

# 单个 map 步骤的 worker 上限（防多 map 同层线程爆炸的保守防线）
_MAX_STEP_WORKERS = 32


class StepError(Exception):
    """步骤执行失败（capability 返回非 OK / map 失败超阈值等）。"""


# ---------------------------------------------------------------------------
# Step
# ---------------------------------------------------------------------------

@dataclass
class Step:
    """步骤定义。

    Attributes:
        name: 步骤名（也是 artifact 名），如 ``"product_info"``
        fn: 可调用对象（签名取决于 mode）；与 ``capability`` 二选一
        capability: registry 能力 ID（如 ``"product.get"``）；与 ``fn`` 二选一
        depends: 依赖的前置步骤名列表
        optional: 失败是否阻断 pipeline
        ttl_hours: 产物缓存时间（小时）
        mode: 执行模式 — ``"batch"`` | ``"map"`` | ``"reduce"``
        item_key: map 模式下匹配 item 的字段名（如 ``"asin"``）
        map_from: map/reduce 从哪取 item 列表 — ``"params"`` | step_name | depends[0]
        list_key: map_from="params" 时显式指定列表键名
        concurrency: map 模式并发数
        description: 「说明」——这块干什么，web 平台直接展示
        inputs: 显式端口接线 ``{port_name: PortBinding}``（capability 步骤用）
        output_schema: 输出 JSON Schema（未填则从 capability.output_schema 解析）
        retry: 失败重试次数
        timeout_s: 单步超时（秒，0 = 不限制）
        fail_threshold: map 失败率阈值（> 阈值判步骤失败）
    """

    name: str
    fn: Callable | None = None
    capability: str | None = None
    depends: list[str] = field(default_factory=list)
    optional: bool = False
    ttl_hours: int = 24
    mode: str = "batch"
    item_key: str = ""
    map_from: str = ""
    list_key: str = ""
    concurrency: int = 5
    description: str = ""
    inputs: dict[str, PortBinding] = field(default_factory=dict)
    output_schema: dict | None = None
    retry: int = 0
    timeout_s: float = 0.0
    fail_threshold: float = 0.5


# ---------------------------------------------------------------------------
# Artifact
# ---------------------------------------------------------------------------

class Artifact(BaseModel):
    """步骤产物（带 schema 的 JSON 文件）。

    Attributes:
        schema: 产物 schema 标识（如 ``"product.get.output"``）
        output_schema: 本步输出 JSON Schema（可视化渲染用）
        run_id: 执行 ID
        step: 步骤名
        status: ``pending|running|ok|failed|skipped|cached``
        inputs: 本步输入快照（params + depends + 形状摘要）
        produced_at: 产出时间（ISO 8601）
        elapsed_ms: 步骤执行耗时（毫秒）
        data: 步骤产出数据
        meta: 元信息，如 ``{from_cache, upstream, usage, error}``
    """

    schema: str = ""
    output_schema: dict = Field(default_factory=dict)
    run_id: str = ""
    step: str = ""
    status: str = "ok"
    inputs: dict = Field(default_factory=dict)
    produced_at: str = ""
    elapsed_ms: float = 0.0
    data: Any = None
    meta: dict = Field(default_factory=dict)

    # ------------------------------------------------------------------
    # 序列化
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """转为可 JSON 序列化的 dict。"""
        return {
            "schema": self.schema,
            "output_schema": self.output_schema,
            "run_id": self.run_id,
            "step": self.step,
            "status": self.status,
            "inputs": self.inputs,
            "produced_at": self.produced_at,
            "elapsed_ms": self.elapsed_ms,
            "data": self.data,
            "meta": self.meta,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Artifact":
        """从 dict 反序列化。"""
        return cls(
            schema=d.get("schema", ""),
            output_schema=d.get("output_schema", {}),
            run_id=d.get("run_id", ""),
            step=d.get("step", ""),
            status=d.get("status", "ok"),
            inputs=d.get("inputs", {}),
            produced_at=d.get("produced_at", ""),
            elapsed_ms=d.get("elapsed_ms", 0.0),
            data=d.get("data"),
            meta=d.get("meta", {}),
        )

    # ------------------------------------------------------------------
    # 落盘 / 加载
    # ------------------------------------------------------------------

    def save(self) -> Path:
        """落盘到 runtime 工作区 ``runs/{run_id}/artifacts/{step}.json``。"""
        d = _artifact_dir(self.run_id)
        path = confined_path(d, f"{validate_component(self.step, label='step name')}.json")
        d.mkdir(parents=True, exist_ok=True)
        temp_path = None
        try:
            with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=d,
                                             prefix=".artifact-", suffix=".tmp", delete=False) as handle:
                temp_path = Path(handle.name)
                json.dump(self.to_dict(), handle, ensure_ascii=False, indent=2, default=str, allow_nan=False)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp_path, path)
        finally:
            if temp_path is not None:
                temp_path.unlink(missing_ok=True)
        return path

    @classmethod
    def load(cls, run_id: str, step: str) -> "Artifact | None":
        """从 runtime 工作区加载（兼容旧 ``store/{run_id}/`` 读）。"""
        filename = f"{validate_component(step, label='step name')}.json"
        path = confined_path(_artifact_dir(run_id), filename)
        if not path.exists():
            legacy = cache_path("store", validate_component(run_id, label="run_id"), filename)
            if legacy.exists():
                path = legacy
            else:
                return None
        try:
            artifact = cls.from_dict(json.loads(path.read_text(encoding="utf-8")))
        except (json.JSONDecodeError, ValueError, OSError):
            return None
        if artifact.run_id != run_id or artifact.step != step:
            return None
        return artifact

    def is_valid(self, ttl_hours: int) -> bool:
        """检查产物是否在 TTL 内。"""
        if self.status not in {"ok", "cached"} or not self.produced_at:
            return False
        try:
            produced = datetime.fromisoformat(self.produced_at.replace("Z", "+00:00"))
            now = datetime.now(timezone.utc)
            return (now - produced).total_seconds() < ttl_hours * 3600
        except (ValueError, TypeError):
            return False


def _artifact_dir(run_id: str) -> Path:
    return cache_path("runs", validate_component(run_id, label="run_id"), "artifacts")


# ---------------------------------------------------------------------------
# Pipeline 基类
# ---------------------------------------------------------------------------

class Pipeline:
    """流程定义基类。

    用法::

        class ProductAnalysisPipeline(Pipeline):
            name = "product_analysis"
            description = "一批 ASIN → 市场分析报告"
            category = "product"
            steps = [Step(...), ...]
    """

    def __init__(
        self,
        name: str = "",
        description: str = "",
        category: str = "",
        version: str = "v1",
        params_schema: dict | None = None,
        steps: list[Step] | None = None,
    ):
        self.name = name
        self.description = description
        self.category = category
        self.version = version
        self.params_schema = params_schema or {}
        self.steps = steps if steps is not None else []

    def validate(self) -> list[str]:
        """校验 DAG，返回错误列表（空 = 通过）。"""
        errors: list[str] = []
        if config.is_managed:
            try:
                validate_component(self.name, label="pipeline name")
                for step in self.steps:
                    validate_component(step.name, label="step name")
                    if step.fn is not None or not step.capability:
                        errors.append(f"step '{step.name}': managed composite requires a capability and cannot use fn")
                    elif registry.get(step.capability) is None:
                        errors.append(f"step '{step.name}': unknown capability '{step.capability}'")
            except ValueError as exc:
                errors.append(str(exc))
        step_names = {s.name for s in self.steps}

        if not self.name:
            errors.append("pipeline name is empty")
        if not self.steps:
            errors.append("no steps defined")

        for s in self.steps:
            cap = registry.get(s.capability) if s.capability else None
            if cap is not None and cap.internal:
                errors.append(f"step '{s.name}': {s.capability} is internal; use {cap.entity_entrypoint or 'its Entity entrypoint'}")
            # 依赖是否存在
            for dep in s.depends:
                if dep not in step_names:
                    errors.append(f"step '{s.name}' depends on unknown step '{dep}'")
            # fn / capability 至少其一
            if s.fn is None and not s.capability:
                errors.append(f"step '{s.name}': requires fn or capability")
            # fn 必须是可调用对象
            if s.fn is not None and not callable(s.fn):
                errors.append(f"step '{s.name}': fn is not callable")
            # capability 必须非空
            if s.capability is not None and not s.capability.strip():
                errors.append(f"step '{s.name}': capability is empty string")
            # mode 合法性
            if s.mode not in ("batch", "map", "reduce"):
                errors.append(f"step '{s.name}' has invalid mode '{s.mode}'")
            # map 模式需要 item_key
            if s.mode == "map" and not s.item_key:
                errors.append(f"step '{s.name}': mode='map' requires item_key")
            # map/reduce 需要数据源
            if s.mode in ("map", "reduce"):
                source = s.map_from or (s.depends[0] if s.depends else "")
                if not source:
                    errors.append(
                        f"step '{s.name}': mode='{s.mode}' requires map_from or depends"
                    )
                elif source != "params" and source not in step_names:
                    errors.append(
                        f"step '{s.name}': map_from '{source}' is not a step nor 'params'"
                    )
            # map_from 指向的步骤是否存在
            if s.map_from and s.map_from != "params" and s.map_from not in step_names:
                errors.append(
                    f"step '{s.name}': map_from '{s.map_from}' is not a known step"
                )
            # concurrency
            if s.concurrency < 1:
                errors.append(f"step '{s.name}': concurrency must be >= 1, got {s.concurrency}")

        # 环检测（拓扑排序）
        if step_names and not errors:
            try:
                _topo_sort_layers(self.steps)
            except ValueError as e:
                errors.append(str(e))

        return errors

    @property
    def step_names(self) -> list[str]:
        return [s.name for s in self.steps]

    # ------------------------------------------------------------------
    # 与 PipelineSpec 互转
    # ------------------------------------------------------------------

    def to_spec(self) -> PipelineSpec:
        """导出为可序列化的 PipelineSpec（fn 步骤 capability 置 None）。"""
        return PipelineSpec(
            name=self.name,
            description=self.description,
            category=self.category,
            version=self.version,
            params_schema=self.params_schema,
            steps=[_step_to_spec(s) for s in self.steps],
        )


def _step_to_spec(s: Step) -> StepSpec:
    return StepSpec(
        name=s.name,
        capability=s.capability,
        mode=s.mode,
        item_key=s.item_key,
        map_from=s.map_from,
        list_key=s.list_key,
        depends=list(s.depends),
        inputs=s.inputs,
        output_schema=s.output_schema,
        description=s.description,
        concurrency=s.concurrency,
        optional=s.optional,
        ttl_hours=s.ttl_hours,
        retry=s.retry,
        timeout_s=s.timeout_s,
    )


def spec_to_pipeline(spec: PipelineSpec) -> Pipeline:
    """从 PipelineSpec 构造运行时 Pipeline（capability 步骤，fn 为 None）。"""
    spec.validate_managed()
    steps = [
        Step(
            name=s.name,
            capability=s.capability,
            depends=list(s.depends),
            optional=s.optional,
            ttl_hours=s.ttl_hours,
            mode=s.mode,
            item_key=s.item_key,
            map_from=s.map_from,
            list_key=s.list_key,
            concurrency=s.concurrency,
            description=s.description,
            inputs=s.inputs,
            output_schema=s.output_schema,
            retry=s.retry,
            timeout_s=s.timeout_s,
        )
        for s in spec.steps
    ]
    return Pipeline(
        name=spec.name,
        description=spec.description,
        category=spec.category,
        version=spec.version,
        params_schema=spec.params_schema,
        steps=steps,
    )


# ---------------------------------------------------------------------------
# PipelineRunner
# ---------------------------------------------------------------------------

class PipelineRunner:
    """执行引擎。

    用法::

        runner = PipelineRunner(pipeline)
        result = runner.run({"asins": ["B0XXXX"], "niche": "portable_blender"})
        print(result.get("market_gap"))
    """

    def __init__(self, pipeline: Pipeline):
        self.pipeline = pipeline
        self._on_event: Callable | None = None
        self._run_id: str = ""
        self._step_meta: dict[str, dict] = {}

    # ------------------------------------------------------------------
    # run
    # ------------------------------------------------------------------

    def run(
        self,
        params: dict | None = None,
        force: bool = False,
        on_event: Callable | None = None,
    ) -> RunResult:
        """执行 pipeline。

        Args:
            params: 用户参数，如 ``{"asins": [...], "niche": "..."}``
            force: 强制重跑，忽略已有缓存
            on_event: 进度回调 ``Callable[[RunEvent], None]``

        Returns:
            RunResult
        """
        params = params or {}
        t0 = time.time()
        self._on_event = on_event

        # 校验
        errors = self.pipeline.validate()
        if errors:
            return RunResult(
                run_id="",
                pipeline_name=self.pipeline.name,
                artifacts={},
                elapsed_ms=0.0,
                success=False,
                errors={"validate": "; ".join(errors)},
            )

        run_id = _make_run_id(self.pipeline.name, self.pipeline.version, params)
        self._run_id = run_id

        rt = Runtime.begin(name=self.pipeline.name, params=params, run_id=run_id)

        self._emit("run.started", detail={"params": _truncate(params, 4096)})

        layers = _topo_sort_layers(self.pipeline.steps)
        artifacts: dict[str, Artifact] = {}
        step_errors: dict[str, str] = {}

        with runtime_context(rt):
            for layer_idx, layer in enumerate(layers):
                with ThreadPoolExecutor(max_workers=len(layer)) as ex:
                    futures = {}
                    for step in layer:
                        if step.name in step_errors:
                            rt.record_step(step.name, "skipped", {"error": step_errors[step.name]})
                            continue
                        # 每个 step 一份 context 副本（Context 不可重入/并发）
                        ctx = contextvars.copy_context()
                        futures[
                            ex.submit(
                                ctx.run,
                                self._execute_step,
                                step, run_id, artifacts, params, force, rt,
                            )
                        ] = step
                    for fut in as_completed(futures):
                        step = futures[fut]
                        try:
                            artifact = fut.result()
                            artifacts[step.name] = artifact
                            rt.record_step(
                                step.name, artifact.status,
                                {"elapsed_ms": artifact.elapsed_ms},
                            )
                        except Exception as e:
                            step_errors[step.name] = f"{type(e).__name__}: {e}"
                            rt.record_step(step.name, "failed", {"error": str(e)})
                            if not step.optional:
                                _mark_remaining_skipped(
                                    step, layers, layer_idx, artifacts, step_errors
                                )

        elapsed = (time.time() - t0) * 1000
        success = len(step_errors) == 0
        rt.finish(success, "; ".join(step_errors.values()))

        self._emit("run.done", elapsed_ms=elapsed, status="ok" if success else "failed")

        return RunResult(
            run_id=run_id,
            pipeline_name=self.pipeline.name,
            artifacts=artifacts,
            elapsed_ms=elapsed,
            success=success,
            errors=step_errors,
        )

    # ------------------------------------------------------------------
    # 内部方法
    # ------------------------------------------------------------------

    def _execute_step(
        self,
        step: Step,
        run_id: str,
        completed: dict[str, Artifact],
        params: dict,
        force: bool,
        rt: Runtime | None = None,
    ) -> Artifact:
        """执行单个步骤：检查缓存 → 按模式分发 → 包装 → 落盘。"""
        # 1. 检查缓存
        if not force:
            cached = Artifact.load(run_id, step.name)
            if cached and cached.is_valid(step.ttl_hours):
                cached.meta["from_cache"] = True
                cached.status = "cached"
                self._emit("step.done", step=step.name, status="cached")
                return cached

        self._emit("step.started", step=step.name)
        t1 = time.time()
        self._step_meta.pop(step.name, None)
        data: Any = None
        error: str = ""

        try:
            if step.mode == "map":
                data = self._execute_map(step, completed, params)
                self._check_map_threshold(step, data)
            elif step.mode == "reduce":
                data = self._execute_reduce(step, completed, params)
            else:
                data = self._execute_batch(step, completed, params)
        except Exception as e:
            traceback.print_exc()
            error = f"{type(e).__name__}: {e}"
            elapsed_ms = (time.time() - t1) * 1000
            artifact = self._make_artifact(
                step, run_id, None, elapsed_ms, rt=rt,
                step_meta=self._take_step_meta(step),
                status="failed", error=error,
            )
            self._emit("step.failed", step=step.name, error=error, elapsed_ms=elapsed_ms)
            raise

        elapsed_ms = (time.time() - t1) * 1000
        artifact = self._make_artifact(
            step, run_id, data, elapsed_ms, rt=rt,
            step_meta=self._take_step_meta(step),
            status="ok", inputs=self._inputs_snapshot(step, data, params),
        )
        self._emit("step.done", step=step.name, status="ok", elapsed_ms=elapsed_ms)
        return artifact

    def _check_map_threshold(self, step: Step, data: Any) -> None:
        """map 步骤失败率超阈值则判步骤失败。"""
        if not isinstance(data, dict):
            return
        meta = data.get("meta", {})
        if not isinstance(meta, dict):
            return
        total = meta.get("total", 0)
        failed = meta.get("failed", 0)
        if total and failed / total > step.fail_threshold:
            raise StepError(f"map step '{step.name}': {failed}/{total} items failed")

    # ------------------------------------------------------------------
    # batch 模式
    # ------------------------------------------------------------------

    def _execute_batch(
        self,
        step: Step,
        completed: dict[str, Artifact],
        params: dict,
    ) -> dict:
        """单次调用：``fn(params, deps_data) -> dict`` 或 capability。"""
        deps_data = {
            dep_name: completed[dep_name].data
            for dep_name in step.depends
            if dep_name in completed
        }
        if step.capability:
            input_params = self._build_capability_input(step, None, deps_data, params)
            data, meta = self._invoke_capability(step, input_params)
            self._stash_step_meta(step, meta)
            return data if isinstance(data, dict) else {"result": data}
        return step.fn(params, deps_data)

    # ------------------------------------------------------------------
    # map 模式
    # ------------------------------------------------------------------

    def _execute_map(
        self,
        step: Step,
        completed: dict[str, Artifact],
        params: dict,
    ) -> dict:
        """对列表中每项并发调用，收集结果。"""
        items = self._resolve_items(step, params, completed)
        if not items:
            return {"items": [], "meta": {"total": 0, "ok": 0, "failed": 0}}

        key = step.item_key
        indexes = self._build_dep_indexes(step, completed)
        results: list[dict] = []
        agg_meta: dict = {}

        with ThreadPoolExecutor(
            max_workers=min(step.concurrency, _MAX_STEP_WORKERS)
        ) as ex:
            futures = {}
            for item in items:
                deps_matched = self._match_deps(item, step, completed, indexes=indexes)
                # 每个 item 一份 context 副本（Context 不可重入/并发）
                ctx = contextvars.copy_context()
                futures[
                    ex.submit(ctx.run, self._run_map_item, step, item, deps_matched, params)
                ] = item

            for fut in as_completed(futures):
                item = futures[fut]
                key_val = (
                    item.get(key, str(item)) if isinstance(item, dict) else str(item)
                )
                try:
                    result, item_meta = fut.result()
                    self._merge_usage(agg_meta, item_meta)
                    results.append(result)
                except Exception as e:
                    results.append({
                        key: key_val,
                        "status": "failed",
                        "error": f"{type(e).__name__}: {e}",
                    })
                self._emit(
                    "step.item.done", step=step.name, item=str(key_val),
                    status=results[-1].get("status", "ok") if results else "ok",
                )

        # 按原始输入顺序排序
        order_map: dict[str, int] = {}
        for i, item in enumerate(items):
            val = item.get(key) if isinstance(item, dict) else str(item)
            order_map[str(val)] = i
        results.sort(key=lambda r: order_map.get(str(r.get(key, "")), 9999))

        ok_count = sum(1 for r in results if r.get("status") == "ok")
        fail_count = sum(1 for r in results if r.get("status") == "failed")

        meta = {
            "total": len(items),
            "ok": ok_count,
            "failed": fail_count,
            "failed_items": [
                r.get(key) for r in results if r.get("status") == "failed"
            ],
        }
        if agg_meta:
            meta.update(agg_meta)

        self._stash_step_meta(step, agg_meta)
        return {"items": results, "meta": meta}

    def _run_map_item(
        self,
        step: Step,
        item: dict,
        deps_matched: dict,
        params: dict,
    ) -> tuple[dict, dict]:
        """map 单 item 执行，返回 ``(result_dict, item_meta)``。"""
        if step.capability:
            input_params = self._build_capability_input(step, item, deps_matched, params)
            data, meta = self._invoke_capability(step, input_params)
            result = {
                step.item_key: item.get(step.item_key) if isinstance(item, dict) else None,
            }
            if isinstance(data, dict):
                result.update(data)
            result.setdefault("status", "ok")
            return result, meta

        result = step.fn(item, deps_matched, params)
        if not isinstance(result, dict):
            result = {"status": "ok", "result": result}
        return result, {}

    # ------------------------------------------------------------------
    # reduce 模式
    # ------------------------------------------------------------------

    def _execute_reduce(
        self,
        step: Step,
        completed: dict[str, Artifact],
        params: dict,
    ) -> dict:
        """收集上游全部 item，单次调用。"""
        all_items = self._resolve_items(step, params, completed)
        deps_data = {
            dep_name: completed[dep_name].data
            for dep_name in step.depends
            if dep_name in completed
        }
        if step.capability:
            input_params = self._build_capability_input(step, None, deps_data, params)
            # 附加聚合 items 供 reduce 型 capability 使用
            input_params.setdefault("items", all_items)
            data, meta = self._invoke_capability(step, input_params)
            self._stash_step_meta(step, meta)
            return data if isinstance(data, dict) else {"result": data}
        return step.fn(all_items, deps_data, params)

    # ------------------------------------------------------------------
    # capability 调用与输入构造
    # ------------------------------------------------------------------

    def _invoke_capability(self, step: Step, input_params: dict) -> tuple[Any, dict]:
        """调用 registry 能力，返回 ``(data, meta)``；非 OK 抛 StepError。"""
        r = registry.invoke(step.capability, input_params)
        meta: dict = {}
        md = getattr(r, "meta", None)
        if md is not None:
            try:
                meta = {
                    k: v
                    for k, v in md.model_dump().items()
                    if v not in (None, "", [], {})
                }
            except Exception:
                meta = {}
        if getattr(r, "code", None) != Code.OK:
            raise StepError(
                getattr(r, "message", "") or f"capability '{step.capability}' failed"
            )
        return r.data, meta

    def _build_capability_input(
        self,
        step: Step,
        item: dict | None,
        deps: dict,
        params: dict,
    ) -> dict:
        """构造 capability 输入参数：默认 base + autowire 投影 + 显式端口绑定。

        优先级：显式 ``inputs`` > autowire（input_model 投影元数据）>
        params / map item 默认值。autowire 只补缺不覆盖，显式绑定总是赢。
        """
        if step.mode == "map" and isinstance(item, dict):
            input_params = dict(item)
        else:
            input_params = dict(params or {})

        # autowire：按 input_model 投影元数据自动接线（composite 零胶水）
        autowired = self._autowire_input(step, item, params)
        for k, v in autowired.items():
            if k not in input_params:
                input_params[k] = v

        for port_name, binding in (step.inputs or {}).items():
            input_params[port_name] = self._resolve_binding(
                binding, item, deps, params
            )

        # 只保留能力 input_model 声明的键：剔掉 map item 的元数据键（asin）、
        # batch params 里的实体/非参数键（product 等），避免 extra=allow 的
        # 输入模型把杂键透传给能力函数。
        cap = registry.get(step.capability or "")
        if cap is not None and cap.input_model is not None:
            allowed = cap.input_model.model_fields
            unknown = set(step.inputs or {}) - set(allowed)
            if unknown:
                raise StepError(f"step '{step.name}': unsupported explicit inputs: {', '.join(sorted(unknown))}")
            input_params = {k: v for k, v in input_params.items() if k in allowed}
        return input_params

    def _autowire_input(
        self,
        step: Step,
        item: dict | None,
        params: dict,
    ) -> dict:
        """按 input_model 投影元数据自动构造输入（composite 零接线）。

        - map 模式：item dict（SDK 字段名空间）即投影源，直接投影。
        - batch/reduce 模式：从 params 递归找 ``entity_sources`` 声明的
          Entity 实例投影；同类型多个实例、或多个类型都能投影 → 歧义，
          抛 StepError 要求显式 ``inputs``。
        - 投影失败（必填字段取不到）→ 静默跳过，由 registry.invoke 的
          参数校验报缺字段（harness 可据此补齐依赖）。
        """
        cap = registry.get(step.capability or "")
        if cap is None or cap.input_model is None or not cap.entity_sources:
            return {}

        from amz.schemas.projection import project

        if step.mode == "map":
            src = item if isinstance(item, dict) else None
            if src is None:
                return {}
            projected = project(src, cap.input_model)
            return projected or {}

        # batch / reduce：params 中的 Entity 实例
        types = {t.lower() for t in cap.entity_sources}
        found: dict[str, list] = {}
        _collect_entities(params, types, found)
        matched: dict[str, dict] = {}
        for type_name, entities in found.items():
            for ent in entities:
                projected = project(ent, cap.input_model)
                if projected is None:
                    continue
                if type_name in matched:
                    raise StepError(
                        f"step '{step.name}': ambiguous autowire for "
                        f"'{step.capability}' — multiple {type_name} entities "
                        f"in params; bind inputs explicitly or pass a single entity"
                    )
                matched[type_name] = projected
        if len(matched) > 1:
            raise StepError(
                f"step '{step.name}': ambiguous autowire for "
                f"'{step.capability}' — inputs projectable from "
                f"{sorted(matched)}; bind inputs explicitly"
            )
        if len(matched) == 1:
            return next(iter(matched.values()))
        return {}

    def _resolve_binding(
        self,
        binding: PortBinding | dict,
        item: dict | None,
        deps: dict,
        params: dict,
    ) -> Any:
        if isinstance(binding, dict):
            binding = PortBinding(**binding)
        src = binding.source
        if src == "params":
            key = binding.key or binding.field
            return params.get(key) if key else params
        value = (deps or {}).get(src)
        if isinstance(value, dict) and binding.field:
            value = value.get(binding.field)
        return value

    def _stash_step_meta(self, step: Step, meta: dict) -> None:
        if meta:
            self._step_meta[step.name] = meta

    def _take_step_meta(self, step: Step) -> dict:
        return self._step_meta.pop(step.name, {})

    @staticmethod
    def _merge_usage(acc: dict, meta: dict) -> None:
        usage = meta.get("usage")
        if isinstance(usage, dict):
            u = acc.setdefault("usage", {})
            for k in ("input_tokens", "output_tokens", "total_tokens"):
                v = usage.get(k)
                if isinstance(v, (int, float)):
                    u[k] = u.get(k, 0) + v
        for k in ("upstream", "from_cache"):
            if meta.get(k):
                acc[k] = meta[k]

    # ------------------------------------------------------------------
    # Item 列表解析
    # ------------------------------------------------------------------

    def _resolve_items(
        self,
        step: Step,
        params: dict,
        completed: dict[str, Artifact],
    ) -> list[dict]:
        """从 map_from 解析 item 列表。"""
        source = step.map_from or (step.depends[0] if step.depends else "")

        if source == "params":
            list_key = step.list_key or (
                step.item_key + "s" if step.item_key else ""
            )
            if not list_key:
                return []
            raw = params.get(list_key, [])
            if isinstance(raw, str):
                raw = [x.strip() for x in raw.split(",") if x.strip()]
            if not raw:
                return []
            if isinstance(raw[0], str):
                return [{step.item_key: v} for v in raw]
            return list(raw)

        if source and source in completed:
            artifact = completed[source]
            if isinstance(artifact.data, dict):
                return list(artifact.data.get("items", []))
            return []

        return []

    # ------------------------------------------------------------------
    # 依赖匹配（map 模式核心）
    # ------------------------------------------------------------------

    def _build_dep_indexes(
        self,
        step: Step,
        completed: dict[str, Artifact],
    ) -> dict[str, dict]:
        """为每个依赖步骤建 ``{item_key值: item}`` 索引（O(n) 一次，O(1) 匹配）。"""
        key = step.item_key
        indexes: dict[str, dict] = {}
        for dep_name in step.depends:
            dep_artifact = completed.get(dep_name)
            if not dep_artifact:
                continue
            dep_data = dep_artifact.data
            if isinstance(dep_data, dict):
                dep_items = dep_data.get("items", [dep_data])
            else:
                dep_items = [dep_data]
            idx: dict[Any, dict] = {}
            for di in dep_items:
                if isinstance(di, dict) and key:
                    val = di.get(key)
                    if val is not None:
                        idx[val] = di
            indexes[dep_name] = idx
        return indexes

    def _match_deps(
        self,
        item: dict,
        step: Step,
        completed: dict[str, Artifact],
        indexes: dict[str, dict] | None = None,
    ) -> dict:
        """为当前 item 匹配各依赖步骤中的对应数据。"""
        key = step.item_key
        item_val = item.get(key)

        matched: dict[str, dict] = {}
        for dep_name in step.depends:
            if indexes is not None:
                idx = indexes.get(dep_name)
                found = idx.get(item_val) if idx else None
                matched[dep_name] = found or {}
                continue

            dep_artifact = completed.get(dep_name)
            if not dep_artifact:
                continue

            dep_data = dep_artifact.data
            if isinstance(dep_data, dict):
                dep_items = dep_data.get("items", [dep_data])
            else:
                dep_items = [dep_data]

            found = None
            for di in dep_items:
                if isinstance(di, dict) and di.get(key) == item_val:
                    found = di
                    break
            matched[dep_name] = found or {}

        return matched

    # ------------------------------------------------------------------
    # Artifact 构造
    # ------------------------------------------------------------------

    def _make_artifact(
        self,
        step: Step,
        run_id: str,
        data: Any,
        elapsed_ms: float,
        rt: Runtime | None = None,
        step_meta: dict | None = None,
        status: str = "ok",
        inputs: dict | None = None,
        error: str = "",
    ) -> Artifact:
        """构造并落盘 Artifact，登记进 runtime 工作区。"""
        schema_ref, output_schema = resolve_output_schema(step, self.pipeline.name)
        meta = dict(step_meta or {})
        meta["from_cache"] = False
        if error:
            meta["error"] = error

        artifact = Artifact(
            schema=schema_ref,
            output_schema=output_schema or {},
            run_id=run_id,
            step=step.name,
            status=status,
            inputs=inputs or {},
            produced_at=datetime.now(timezone.utc).isoformat(),
            elapsed_ms=elapsed_ms,
            data=data,
            meta=meta,
        )
        artifact.save()
        if rt is not None:
            rt.record(
                "artifact",
                step.name,
                f"runs/{run_id}/artifacts/{step.name}.json",
                schema=schema_ref,
                meta={"status": status, "elapsed_ms": elapsed_ms},
            )
        return artifact

    @staticmethod
    def _inputs_snapshot(step: Step, data: Any, params: dict) -> dict:
        snap: dict = {"params": _truncate(params, 4096), "depends": list(step.depends)}
        if isinstance(data, dict) and "items" in data:
            snap["item_count"] = len(data.get("items") or [])
        return snap

    # ------------------------------------------------------------------
    # 事件
    # ------------------------------------------------------------------

    def _emit(self, type_: str, **kw: Any) -> None:
        if self._on_event is None:
            return
        try:
            self._on_event(
                make_event(
                    type_,
                    run_id=self._run_id,
                    pipeline=self.pipeline.name,
                    **kw,
                )
            )
        except Exception:
            pass


# ---------------------------------------------------------------------------
# RunResult
# ---------------------------------------------------------------------------

@dataclass
class RunResult:
    """Pipeline 执行结果。"""

    run_id: str
    pipeline_name: str
    artifacts: dict[str, Artifact]
    elapsed_ms: float
    success: bool
    errors: dict[str, str] = field(default_factory=dict)

    def get(self, step: str) -> Any:
        """快捷获取 artifact data。"""
        a = self.artifacts.get(step)
        return a.data if a else None


# ---------------------------------------------------------------------------
# 内部工具
# ---------------------------------------------------------------------------

def _topo_sort_layers(steps: list[Step]) -> list[list[Step]]:
    """拓扑分层：返回按依赖排序的层列表，同层步骤无依赖关系，可并发。

    Raises:
        ValueError: 检测到循环依赖
    """
    name_to_step = {s.name: s for s in steps}
    in_degree = {s.name: len(s.depends) for s in steps}
    dependents: dict[str, list[str]] = {s.name: [] for s in steps}
    for s in steps:
        for dep in s.depends:
            if dep in dependents:
                dependents[dep].append(s.name)

    queue = deque([s.name for s in steps if in_degree[s.name] == 0])
    layers: list[list[Step]] = []
    seen: set[str] = set()

    while queue:
        layer: list[Step] = []
        for _ in range(len(queue)):
            name = queue.popleft()
            seen.add(name)
            layer.append(name_to_step[name])
        layers.append(layer)

        for step in layer:
            for dep_name in dependents[step.name]:
                in_degree[dep_name] -= 1
                if in_degree[dep_name] == 0:
                    queue.append(dep_name)

    if len(seen) != len(steps):
        unseen = [s.name for s in steps if s.name not in seen]
        raise ValueError(f"circular dependency detected involving: {unseen}")

    return layers


def _mark_remaining_skipped(
    failed_step: Step,
    layers: list[list[Step]],
    failed_layer_idx: int,
    artifacts: dict[str, Artifact],
    errors: dict[str, str],
):
    """非 optional 步骤失败后，标记后续层步骤为 skipped。"""
    for layer in layers[failed_layer_idx + 1:]:
        for step in layer:
            if step.name not in artifacts and step.name not in errors:
                errors[step.name] = f"skipped: dependency '{failed_step.name}' failed"


def _make_run_id(pipeline_name: str, version: str = "", params: dict | None = None) -> str:
    """确定性 run_id = 人类可读 slug + 参数指纹。

    同 ``(pipeline_name, version, params)`` 必得同 id（工作区即缓存）。
    """
    params = params or {}
    slug = _slugify(params.get("niche") or pipeline_name)[:MAX_COMPONENT_LENGTH - 9]
    canonical = json.dumps(
        [pipeline_name, version, params],
        sort_keys=True,
        ensure_ascii=False,
        default=str,
    )
    fp = hashlib.sha1(canonical.encode("utf-8")).hexdigest()[:8]
    return f"{slug}_{fp}"


def _slugify(text: str) -> str:
    text = (text or "").lower()
    text = re.sub(r"[^a-z0-9]+", "_", text).strip("_")
    return text if len(text.replace("_", "")) >= 3 else "run"


def _truncate(value: Any, limit: int) -> Any:
    """截断超长值，避免 inputs 快照 / 事件膨胀。"""
    if isinstance(value, dict):
        return {k: _truncate(v, limit) for k, v in list(value.items())[:64]}
    if isinstance(value, (list, tuple)):
        return [_truncate(v, limit) for v in list(value)[:64]]
    if isinstance(value, str) and len(value) > limit:
        return value[:limit] + f"...<truncated {len(value) - limit} chars>"
    return value


def _collect_entities(value: Any, types: set[str], out: dict[str, list]) -> None:
    """递归收集 ``value`` 中 ``entity_type`` 命中 ``types`` 的 Entity 实例。

    autowire 的实体发现：batch/reduce 步骤从 run params 里找到可投影的
    聚合根（如 ``{"product": Product(...)}`` 或嵌套列表）。
    """
    from amz.entities._core.base import Entity

    if isinstance(value, Entity):
        t = str(getattr(value, "entity_type", "")).lower()
        if t in types:
            out.setdefault(t, []).append(value)
        return
    if isinstance(value, dict):
        for v in value.values():
            _collect_entities(v, types, out)
        return
    if isinstance(value, (list, tuple)):
        for v in value:
            _collect_entities(v, types, out)
