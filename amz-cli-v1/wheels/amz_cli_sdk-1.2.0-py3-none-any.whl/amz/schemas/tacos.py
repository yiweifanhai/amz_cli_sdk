"""Market TACOS estimates and their internal calculation inputs."""

from __future__ import annotations

from datetime import date
from typing import Annotated, Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from amz.schemas.entity_ref import EntityRef

Positive = Annotated[float, Field(gt=0)]
NonNegative = Annotated[float, Field(ge=0)]
Ratio = Annotated[float, Field(ge=0, le=1)]
ReferralRate = Annotated[float, Field(ge=0, lt=1)]
ShippingMethod = Literal["slow", "fast", "air", "express"]


class _TacosModel(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)


class TacosProductInput(_TacosModel):
    asin: str = Field(min_length=1)
    price_usd: Positive
    weight_g: Positive
    dimensions_cm: tuple[Positive, Positive, Positive]
    fba_fee: NonNegative | None = None
    available_date: str | None = None
    ad_ratio: Ratio | None = Field(default=None, description="Ratio 0–1, converted from Product's percentage")
    missing: list[str] = Field(default_factory=list)


class CalcMarketTacosInput(_TacosModel):
    keyword: str = Field(min_length=1)
    keyword_acos: NonNegative = Field(description="Ratio: 1.18 means 118%; may exceed 1")
    products: list[TacosProductInput] = Field(min_length=1)
    current_date: date
    exchange_rate: Positive
    shipping_method: ShippingMethod = "slow"
    referral_rate: ReferralRate = 0.15

    @model_validator(mode="after")
    def distinct_products(self):
        if len({row.asin for row in self.products}) != len(self.products):
            raise ValueError("products must have distinct ASINs")
        return self


class TacosProduct(_TacosModel):
    asin: str
    price_usd: float
    m1_pct: float
    ad_ratio: float | None
    tacos_pct: float | None
    m2_pct: float | None
    months_since_available: float | None
    fba_fee: float
    fba_source: Literal["product", "calculated"]
    shipping_cost: float
    billable_weight_g: float
    missing: list[str] = Field(default_factory=list)


class TacosBucket(_TacosModel):
    product_count: int
    ad_data_count: int
    m1_median_pct: float | None
    matched_m1_median_pct: float | None = Field(description="M1 median of the same Products used for TACOS and M2")
    keyword_acos: float
    ad_ratio_median: float | None
    tacos_median_pct: float | None
    m2_pct: float | None = Field(description="Matched M1 median minus TACOS median; excludes purchase cost")
    insufficient_sample: bool = Field(description="Fewer than 3 Products with both M1 and ad data")


class TacosFailure(_TacosModel):
    ref: EntityRef
    code: str
    message: str
    missing: list[str] = Field(default_factory=list)


class MarketTacosResult(_TacosModel):
    keyword: str
    keyword_acos: float
    current_date: date
    total_products: int
    products_with_margin: int
    products_with_ad_data: int
    products_without_date: int
    products_over_12_months: int
    cumulative: dict[str, TacosBucket]
    exclusive: dict[str, TacosBucket]
    products: list[TacosProduct]
    failed: list[TacosFailure] = Field(default_factory=list)
    sources: list[dict[str, Any]] = Field(default_factory=list)
    assumptions: dict[str, Any] = Field(default_factory=dict)
    limitations: list[str] = Field(default_factory=list)
