"""Public contracts for product material, copyability and innovation comparison."""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class _InnovationModel(BaseModel):
    model_config = ConfigDict(extra="ignore")


class Barrier(_InnovationModel):
    """单一维度的复制壁垒。"""

    level: Literal["低", "中", "高"]  # 壁垒等级
    reason: str  # 判断理由


class BarrierAnalysis(_InnovationModel):
    """四维度复制壁垒分析。"""

    patent_risk: Barrier  # 专利风险壁垒
    supply_chain: Barrier  # 供应链壁垒（原料/模具/工艺可得性）
    tech_complexity: Barrier  # 技术复杂度壁垒
    brand_bindness: Barrier  # 品牌绑定壁垒（用户对品牌的忠诚度）


class CopyabilityOutput(_InnovationModel):
    """可复制性评估输出。"""

    visual_observations: str = ""  # 对产品图片/外观的视觉观察
    copy_difficulty: Literal["低", "中", "高"]  # 总体复制难度
    barrier_analysis: BarrierAnalysis  # 四维壁垒分析
    differentiation_suggestions: list[dict] = Field(default_factory=list)  # 差异化建议列表
    score: int = Field(ge=0, le=10)  # 可复制性评分 0-10（越低越难复制）
    score_reason: str  # 评分理由
    verdict: str  # 结论


class MaterialAssessmentOutput(_InnovationModel):
    """新品材质可开发性评估输出。"""

    material_reason: str  # 材质判断理由
    material_conclusion: str  # 材质结论
    easy_to_develop_reason: str  # 易开发性判断理由
    easy_to_develop_conclusion: str  # 易开发性结论
    easy_to_develop_mark: bool  # 是否易开发标记


class ComparativeInnovationOutput(_InnovationModel):
    """基准品差分创新分析输出。"""

    status: str  # 分析状态（VALID=有效 / INVALID=输入不足）
    comparison_mode: Literal["REAL_BENCHMARK"]  # 只允许真实基准商品对比
    root_product_keyword: str  # 根产品关键词
    baseline_summary: str  # 基准品总结
    innovation_analysis: str  # 创新分析文本
    primary_dimension: str  # 主创新维度
    secondary_dimensions: list[str]  # 次要创新维度列表
    innovation_score: int = Field(ge=0, le=10)  # 创新分 0-10
    one_sentence_reason: str  # 一句话理由
