"""
amz CLI：SDK 命令行入口（harness 可驱动）。

用法:
  amz capabilities [--id <capability_id>]      列出全部能力 / 单个能力 schema
  amz run <capability_id> --param key=value...  调用单个能力
      [--out FILE] [--task run_id]
  amz task new <name> [--param key=value...]    创建任务工作区
  amz task run <capability_id> --param ... [--task run_id]   在任务内调用能力
  amz task status <run_id>                      任务状态 + 调用时间线 + 文件清单
  amz task files <run_id> [--kind kind]         列出任务中间文件
  amz task list                                 最近任务
  amz task cleanup [--older-than-hours N]       清理过期已结束任务
  amz doctor                                    检查配置/缓存/token

参数约定
--------
- ``--param key=value``：值先按 JSON 解析（嵌套 dict/list），失败按字符串；
  再按能力 input_schema 做类型强制（"1"→1, "true"→True）
- ``amz run`` 为单发调用；``amz task run`` 会记录调用与中间文件

机器输出约定
------------
- 受管模式，或独立配置 ``cli.output=json`` 时，命令 stdout 输出一个完整 UTF-8 JSON 值，诊断和进度写入 stderr。
- 参数、文件、执行或业务失败返回非零退出码；``composite.validate`` 的 ``data.valid=false`` 也视为失败。
- 配置引导失败发生在 CLI 接管前，此时 stdout 为空，错误由 stderr 和非零退出码表达。
- ``run --out FILE`` 仍写入结果文件，stdout 返回同一 Result；宿主可在外层 wrapper 中限制该选项。
- ``run --task`` 记录调用但不结束已有任务；``task run`` 记录调用并按结果结束任务。查询失败任务的状态仍是成功查询。
"""

from __future__ import annotations

import json
import sys
from contextlib import nullcontext, redirect_stdout
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence


@dataclass
class CommandResponse:
    payload: Any
    exit_code: int = 0
    human_lines: list[str] | None = None


class CliError(ValueError):
    def __init__(self, message: str, code: str = "ERROR_PARAM"):
        super().__init__(message)
        self.code = code


# ---------------------------------------------------------------------------
# 参数解析
# ---------------------------------------------------------------------------


def _parse_value(raw: str) -> Any:
    """--param 值解析：先试 JSON，解析失败按字符串；拒绝非有限 JSON 数值。"""
    try:
        value = json.loads(raw)
    except json.JSONDecodeError:
        return raw
    try:
        json.dumps(value, allow_nan=False)
    except ValueError as exc:
        raise CliError("non-finite JSON number is not allowed") from exc
    return value


def _parse_params(tokens: list[str], *, strict: bool = True) -> dict:
    """解析 ``--param key=value`` 序列（可多次出现；也接受裸 ``key=value`` 和 ``--param key value``）。"""
    params: dict = {}
    index = 0
    while index < len(tokens):
        token = tokens[index]
        if token in ("--param", "-p"):
            index += 1
            if index == len(tokens) or tokens[index].startswith("--"):
                raise CliError(f"{token} requires a parameter")
            token = tokens[index]
            if "=" not in token:
                # --param key value 形式
                index += 1
                if index == len(tokens) or tokens[index].startswith("--"):
                    raise CliError(f"parameter {token!r} requires a value")
                params[token] = _parse_value(tokens[index])
                index += 1
                continue
        elif token.startswith("--param="):
            token = token[len("--param="):]
        # 裸 key=value（也支持 --param a=1 b=2）
        if "=" in token and not token.startswith("--"):
            key, _, value = token.partition("=")
            if not key.strip():
                raise CliError("parameter name must not be empty")
            params[key.strip()] = _parse_value(value)
        elif strict or token.startswith("--"):
            raise CliError(f"unexpected parameter: {token}")
        index += 1
    return params


def _options(tokens: list[str], values: tuple[str, ...] = (), flags: tuple[str, ...] = ()):
    options: dict[str, Any] = {}
    rest: list[str] = []
    index = 0
    while index < len(tokens):
        token = tokens[index]
        if token in values:
            index += 1
            if index == len(tokens) or tokens[index].startswith("--"):
                raise CliError(f"{token} requires a value")
            options[token] = tokens[index]
        elif token in flags:
            options[token] = True
        else:
            rest.append(token)
        index += 1
    return options, rest


def _required(args: list[str], usage: str) -> tuple[str, list[str]]:
    if not args or args[0].startswith("--"):
        raise CliError(f"Usage: amz {usage}")
    return args[0], args[1:]


def _no_extra(args: list[str]) -> None:
    if args:
        raise CliError(f"unexpected argument: {args[0]}")


def _load_capabilities():
    """导入全部能力并返回 registry。"""
    from amz.registry import registry
    from amz.discovery import load_builtin_capabilities

    load_builtin_capabilities()
    return registry


def _result_response(result, capability_id: str = "") -> CommandResponse:
    payload = result.model_dump()
    failed = payload["code"] != "OK"
    # Validation reports its verdict in data while preserving the SDK envelope.
    if capability_id == "composite.validate" and isinstance(payload.get("data"), dict):
        failed = failed or payload["data"].get("valid") is False
    return CommandResponse(payload, exit_code=int(failed))


def _write_out(out: str | None, payload: Any) -> None:
    if out is None:
        return
    from amz.infra.paths import resolve_workspace_path

    path = resolve_workspace_path(out)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False, default=str, allow_nan=False), encoding="utf-8")
    print(f"written: {path}", file=sys.stderr)


# ---------------------------------------------------------------------------
# capabilities 命令
# ---------------------------------------------------------------------------


def cmd_capabilities(cap_id: str | None = None) -> CommandResponse:
    registry = _load_capabilities()
    if cap_id is not None:
        cap = registry.get(cap_id)
        if cap is None:
            raise CliError(f"unknown capability: {cap_id}", "ERROR_NOT_FOUND")
        return CommandResponse({
            "id": cap.id, "category": cap.category, "description": cap.description,
            "requires": cap.requires, "requires_fields": cap.requires_fields,
            "internal": cap.internal, "entity_entrypoint": cap.entity_entrypoint,
            "input_schema": cap.input_schema, "output_schema": cap.output_schema,
        })
    caps = registry.capabilities_json()
    return CommandResponse(caps, human_lines=[
        json.dumps(caps, indent=2, ensure_ascii=False), f"\nTotal: {len(caps)} capabilities",
    ])


# ---------------------------------------------------------------------------
# run 命令
# ---------------------------------------------------------------------------


def cmd_run(capability_id: str, params: dict | None = None, out: str | None = None) -> CommandResponse:
    """调用单个能力（单发，不隐式建任务）。"""
    # Reject an invalid destination before spending time on the capability.
    if out is not None:
        from amz.infra.paths import resolve_workspace_path
        resolve_workspace_path(out)
    result = _load_capabilities().invoke(capability_id, params or {})
    response = _result_response(result, capability_id)
    _write_out(out, response.payload)
    return response


# ---------------------------------------------------------------------------
# task 命令
# ---------------------------------------------------------------------------


def cmd_task_new(name: str, params: dict | None = None) -> CommandResponse:
    from amz.infra.runtime import Runtime

    rt = Runtime.begin(name=name, params=params or {})
    return CommandResponse({"run_id": rt.run_id, "name": rt.name, "status": "running", "workspace": str(rt.dir)})


def _open_task(run_id: str):
    from amz.infra.runtime import Runtime

    rt = Runtime.open(run_id)
    if rt is None:
        raise CliError(f"unknown task: {run_id}", "ERROR_NOT_FOUND")
    return rt


def cmd_task_run(capability_id: str, params: dict | None = None, run_id: str | None = None) -> CommandResponse:
    """在任务工作区内调用能力：自动建任务（或挂到 --task），记录调用与中间文件并结束任务。"""
    from amz.config import config
    from amz.infra.runtime import Runtime, runtime_context

    registry = _load_capabilities()
    rt = _open_task(run_id) if run_id else Runtime.begin(name=f"run:{capability_id}", params=params or {})
    with runtime_context(rt):
        result = registry.invoke(capability_id, params or {})
    response = _result_response(result, capability_id)
    message = result.message or ("spec validation failed" if response.exit_code and result.code.value == "OK" else "")
    rt.finish(success=response.exit_code == 0, error=message if response.exit_code else "")
    files = rt.files(kind="result")
    result_file = str(config.cache_dir / files[-1]["path"]) if files else ""
    return CommandResponse({
        "run_id": rt.run_id, "capability": capability_id, "code": result.code.value,
        "message": message, "result_file": result_file,
        "elapsed_ms": round(result.meta.elapsed_ms, 1),
    }, exit_code=response.exit_code)


def _run_attached(capability_id: str, params: dict, run_id: str, out: str | None = None) -> CommandResponse:
    """挂到已有任务执行（记录但复用任务，不结束任务）。"""
    from amz.infra.runtime import runtime_context

    if out is not None:
        from amz.infra.paths import resolve_workspace_path
        resolve_workspace_path(out)
    registry = _load_capabilities()
    rt = _open_task(run_id)
    with runtime_context(rt):
        result = registry.invoke(capability_id, params)
    response = _result_response(result, capability_id)
    _write_out(out, response.payload)
    return response


def cmd_task_status(run_id: str) -> CommandResponse:
    manifest = _open_task(run_id).manifest()
    keys = ("run_id", "name", "status", "params", "created_at", "finished_at", "error", "files", "calls")
    return CommandResponse({key: manifest.get(key) for key in keys})


def cmd_task_files(run_id: str, kind: str | None = None) -> CommandResponse:
    from amz.config import config

    files = _open_task(run_id).files(kind)
    lines = [f"[{item.get('kind')}] {item.get('name')}  {config.cache_dir / item.get('path', '')}  ({item.get('size', 0)}B)" for item in files]
    return CommandResponse(files, human_lines=lines or [f"no files for task {run_id}"])


def cmd_task_list() -> CommandResponse:
    from amz.infra.runtime import Runtime

    runs = Runtime.list_runs()
    return CommandResponse(runs, human_lines=None if runs else ["no tasks"])


def cmd_task_cleanup(older_than_hours: int = 168) -> CommandResponse:
    from amz.infra.runtime import Runtime

    removed = Runtime.cleanup(older_than_hours=older_than_hours)
    return CommandResponse({"removed": removed}, human_lines=[f"removed {len(removed)} task workspace(s)", *[f"  {run_id}" for run_id in removed]])


# ---------------------------------------------------------------------------
# composite 命令
# ---------------------------------------------------------------------------


def cmd_composite_list() -> CommandResponse:
    from amz.composite import list_pipelines

    _load_capabilities()
    pipelines = list_pipelines()
    return CommandResponse(pipelines, human_lines=None if pipelines else ["no pipelines discovered (add to ~/.amz/composite/ or AMZ_COMPOSITE_DIR)"])


def cmd_composite_new(name: str, category: str = "", description: str = "") -> CommandResponse:
    result = _load_capabilities().invoke("composite.scaffold", {"name": name, "category": category, "description": description})
    return _result_response(result)


def cmd_composite_run(name: str, params: dict | None = None, force: bool = False) -> CommandResponse:
    from amz.composite import run_pipeline

    _load_capabilities()
    result = run_pipeline(name, params or {}, force=force)
    return CommandResponse({
        "pipeline": name, "run_id": result.run_id, "success": result.success,
        "elapsed_ms": round(result.elapsed_ms, 1), "errors": result.errors,
        "steps": {step: artifact.status for step, artifact in result.artifacts.items()},
    }, exit_code=int(not result.success))


def cmd_composite_show(run_id: str, step: str | None = None) -> CommandResponse:
    from amz.composite.base import Artifact

    manifest = _open_task(run_id).manifest()
    if step is not None:
        artifact = Artifact.load(run_id, step)
        if artifact is None:
            raise CliError(f"no artifact for step '{step}' in run {run_id}", "ERROR_NOT_FOUND")
        return CommandResponse(artifact.to_dict())
    keys = ("run_id", "name", "status", "params", "created_at", "finished_at", "error", "steps")
    return CommandResponse({
        **{key: manifest.get(key) for key in keys},
        "calls": len(manifest.get("calls", [])), "files": [item.get("path") for item in manifest.get("files", [])],
    })


def cmd_composite_spec_schema() -> CommandResponse:
    from amz.composite.spec import PipelineSpec

    return CommandResponse(PipelineSpec.model_json_schema())


def _load_spec_file(path: str) -> dict:
    from amz.infra.paths import resolve_workspace_path
    import yaml

    resolved = resolve_workspace_path(path, must_exist=True)
    text = resolved.read_text(encoding="utf-8-sig")
    try:
        spec = json.loads(text) if resolved.suffix.lower() == ".json" else yaml.safe_load(text)
    except (ValueError, yaml.YAMLError) as exc:
        raise CliError(f"invalid spec file: {resolved.name}") from exc
    if not isinstance(spec, dict):
        raise CliError("spec file must contain an object")
    try:
        json.dumps(spec, allow_nan=False)
    except (ValueError, TypeError) as exc:
        raise CliError("spec file must contain JSON-compatible values") from exc
    return spec


def cmd_composite_validate(path: str) -> CommandResponse:
    result = _load_capabilities().invoke("composite.validate", {"spec": _load_spec_file(path)})
    return _result_response(result, "composite.validate")


def cmd_composite_compile(path: str) -> CommandResponse:
    result = _load_capabilities().invoke("composite.compile", {"spec": _load_spec_file(path)})
    return _result_response(result)


def _cmd_task(args: list[str], machine: bool) -> CommandResponse:
    sub, rest = _required(args, "task new|run|status|files|list|cleanup ...")
    if sub == "new":
        if machine:
            name, rest = _required(rest, "task new <name> [--param k=v ...]")
        else:
            name = rest.pop(0) if rest and not rest[0].startswith("--") else "task"
        return cmd_task_new(name, _parse_params(rest, strict=machine))
    if sub == "run":
        cap_id, tokens = _required(rest, "task run <capability_id> [--param k=v ...] [--task run_id]")
        options, tokens = _options(tokens, ("--task",))
        return cmd_task_run(cap_id, _parse_params(tokens, strict=machine), options.get("--task"))
    if sub in ("status", "files"):
        run_id, tokens = _required(rest, f"task {sub} <run_id>")
        options, tokens = _options(tokens, ("--kind",) if sub == "files" else ())
        _no_extra(tokens)
        return cmd_task_status(run_id) if sub == "status" else cmd_task_files(run_id, options.get("--kind"))
    if sub == "list":
        _no_extra(rest)
        return cmd_task_list()
    if sub == "cleanup":
        options, tokens = _options(rest, ("--older-than-hours",))
        _no_extra(tokens)
        hours = int(options.get("--older-than-hours", 168))
        if hours < 0:
            raise CliError("--older-than-hours must be nonnegative")
        return cmd_task_cleanup(hours)
    raise CliError(f"unknown task subcommand: {sub}")


def _cmd_composite(args: list[str], machine: bool) -> CommandResponse:
    sub, rest = _required(args, "composite list|new|run|show|spec-schema|validate|compile ...")
    if sub in ("list", "spec-schema"):
        _no_extra(rest)
        return cmd_composite_list() if sub == "list" else cmd_composite_spec_schema()
    if sub == "new":
        name, rest = _required(rest, "composite new <name> [--category X] [--description Y]")
        options, rest = _options(rest, ("--category", "--description"))
        _no_extra(rest)
        return cmd_composite_new(name, options.get("--category", ""), options.get("--description", ""))
    if sub == "run":
        name, rest = _required(rest, "composite run <name> [--param k=v ...] [--force]")
        options, rest = _options(rest, flags=("--force",))
        return cmd_composite_run(name, _parse_params(rest, strict=machine), options.get("--force", False))
    if sub == "show":
        run_id, rest = _required(rest, "composite show <run_id> [--step X]")
        options, rest = _options(rest, ("--step",))
        _no_extra(rest)
        return cmd_composite_show(run_id, options.get("--step"))
    if sub in ("validate", "compile"):
        path, rest = _required(rest, f"composite {sub} <spec.json|spec.yaml>")
        _no_extra(rest)
        return cmd_composite_validate(path) if sub == "validate" else cmd_composite_compile(path)
    raise CliError(f"unknown composite subcommand: {sub}")


def _help_response() -> CommandResponse:
    from amz import __version__

    usage = [
        "amz capabilities [--id <capability_id>]", "amz run <id> [--param k=v ...] [--out FILE] [--task run_id]",
        "amz version [--json]", "amz python <script.py> [args...]",
        "amz task new <name> [--param k=v ...]", "amz task run <id> [--param k=v ...] [--task run_id]",
        "amz task status <run_id>", "amz task files <run_id> [--kind kind]", "amz task list",
        "amz task cleanup [--older-than-hours N]", "amz composite list|new|run|show|spec-schema|validate|compile ...",
        "amz doctor", "amz setup [--token X] [--base-url URL] [--no-prompt]", "amz serve web|http|mcp [options]",
    ]
    return CommandResponse({"version": __version__, "usage": usage}, human_lines=[f"amz-cli-sdk v{__version__}", "Usage:", *usage])


def _dispatch(args: list[str], machine: bool) -> CommandResponse:
    if not args and machine:
        raise CliError("command required; use amz --help")
    if not args or args == ["--help"] or args == ["-h"]:
        return _help_response()
    command, rest = args[0], args[1:]
    if command in ("version", "--version", "-V"):
        from amz import __version__
        options, rest = _options(rest, flags=("--json",))
        _no_extra(rest)
        payload = {"name": "amz-cli-sdk", "version": __version__, "python": sys.version.split()[0]}
        return CommandResponse(payload, human_lines=None if options.get("--json") else [f"amz-cli-sdk {__version__}"])
    if command == "python":
        if machine:
            raise CliError("python is not supported in JSON output mode")
        import runpy
        script, script_args = _required(rest, "python <script.py> [args...]")
        if not Path(script).is_file():
            raise FileNotFoundError(f"script not found: {script}")
        previous_args = sys.argv
        try:
            sys.argv = [script, *script_args]
            runpy.run_path(script, run_name="__main__")
        finally:
            sys.argv = previous_args
        return CommandResponse(None, human_lines=[])
    if command == "capabilities":
        options, rest = _options(rest, ("--id",))
        cap_id = options.get("--id")
        if cap_id is None and rest and not rest[0].startswith("--"):
            cap_id = rest.pop(0)
        _no_extra(rest)
        return cmd_capabilities(cap_id)
    if command == "run":
        cap_id, rest = _required(rest, "run <capability_id> [--param k=v ...] [--out FILE] [--task run_id]")
        options, rest = _options(rest, ("--out", "--task"))
        params = _parse_params(rest, strict=machine)
        if "--task" in options:
            return _run_attached(cap_id, params, options["--task"], options.get("--out"))
        return cmd_run(cap_id, params, options.get("--out"))
    if command == "task":
        return _cmd_task(rest, machine)
    if command == "composite":
        return _cmd_composite(rest, machine)
    if command in ("doctor", "setup", "serve"):
        if machine:
            raise CliError(f"{command} is not supported in JSON output mode")
        if command == "doctor":
            _no_extra(rest)
            cmd_doctor()
        elif command == "setup":
            _cmd_setup(rest)
        else:
            _cmd_serve(rest)
        return CommandResponse(None, human_lines=[])
    raise CliError(f"unknown command: {command}")


def _error_response(code: str, message: str) -> CommandResponse:
    return CommandResponse({"code": code, "message": message, "data": None, "meta": {}}, exit_code=1)


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------


def main(argv: Sequence[str] | None = None) -> int:
    """Write one native JSON value in configured machine mode and return its status."""
    from amz.config import config

    machine = config.is_managed or config.get("cli", "output", default="text") == "json"
    if machine:
        for stream in (sys.stdout, sys.stderr):
            if hasattr(stream, "reconfigure"):
                stream.reconfigure(encoding="utf-8")
    try:
        with redirect_stdout(sys.stderr) if machine else nullcontext():
            response = _dispatch(list(sys.argv[1:] if argv is None else argv), machine)
    except CliError as exc:
        response = _error_response(exc.code, str(exc))
    except FileNotFoundError as exc:
        response = _error_response("ERROR_NOT_FOUND", str(exc))
    except (ValueError, PermissionError, UnicodeError) as exc:
        response = _error_response("ERROR_PARAM", str(exc))
    except Exception as exc:
        response = _error_response("ERROR_SERVER_INTERNAL", str(exc))
    try:
        encoded = json.dumps(response.payload, ensure_ascii=False, default=str, allow_nan=False)
    except (ValueError, TypeError) as exc:
        response = _error_response("ERROR_SERVER_INTERNAL", f"cannot encode command result: {exc}")
        encoded = json.dumps(response.payload, ensure_ascii=False)
    if response.exit_code:
        detail = response.payload.get("message") or response.payload.get("errors") or "command failed"
        print(str(detail), file=sys.stderr)
    if not machine and response.human_lines is not None:
        for line in response.human_lines:
            print(line)
    else:
        print(encoded)
    return response.exit_code


# ---------------------------------------------------------------------------
# doctor
# ---------------------------------------------------------------------------


def cmd_doctor():
    """检查配置"""
    from amz.config import config

    config.load()

    issues = []
    ok_items = []

    # 检查 token
    token = config.data_api_token
    if token:
        ok_items.append("✅ data_api.token configured")
    else:
        issues.append("❌ data_api.token not set (env: AMZ_API_TOKEN)")

    # 检查 base_url
    url = config.data_api_base_url
    ok_items.append(f"✅ data_api.base_url: {url}")
    try:
        seller = config.sellersprite_token
        ok_items.append("✅ SellerSprite MCP Token: " + ("已配置，回源使用个人 MCP Token" if seller else "未配置（可选），使用服务端默认数据源"))
    except ValueError as exc:
        issues.append(f"❌ {exc}")

    # 检查缓存目录
    cache_dir = config.cache_dir
    cache_dir.mkdir(parents=True, exist_ok=True)
    ok_items.append(f"✅ cache_dir: {cache_dir}")

    # 检查 SIF token
    sif_file = config.sif_token_file
    if sif_file.exists():
        ok_items.append(f"✅ sif_token_file: {sif_file}")
    else:
        issues.append(f"⚠️  sif_token_file not found: {sif_file}")

    for item in ok_items:
        print(item)
    for item in issues:
        print(item)

    if not issues:
        print("\n✅ All checks passed")



# ---------------------------------------------------------------------------
# serve 命令（远程服务模式）
# ---------------------------------------------------------------------------


def _cmd_serve(args: list[str]):
    """amz serve web|http|mcp [--port PORT] [--host HOST]."""
    if not args or args[0] not in ("web", "http", "mcp"):
        print("Usage: amz serve web|http|mcp [--port PORT] [--host HOST] [--no-auth] [--no-open]")
        return
    kind = args[0]
    port = 8765 if kind == "web" else 8000
    host = "127.0.0.1"
    no_auth = False
    no_open = False
    rest = args[1:]
    i = 0
    while i < len(rest):
        if rest[i] == "--port" and i + 1 < len(rest):
            port = int(rest[i + 1])
            i += 2
        elif rest[i] == "--host" and i + 1 < len(rest):
            host = rest[i + 1]
            i += 2
        elif rest[i] == "--no-auth":
            no_auth = True
            i += 1
        elif rest[i] == "--no-open":
            no_open = True
            i += 1
        else:
            i += 1

    if kind == "web":
        from amz.serve.local import run_local
        run_local(port=port, host=host, open_browser=not no_open)
        return

    from amz.config import config

    config.load()
    auth_token = "" if no_auth else config.data_api_token

    if kind == "http":
        from amz.serve.http import create_app

        app = create_app(auth_token=auth_token)
        path = "/"
    else:
        from amz.serve.mcp import create_asgi_app

        app = create_asgi_app(auth_token=auth_token)
        path = "/mcp"

    auth_note = "无鉴权" if no_auth else "X-API-Token 鉴权"
    print(f"amz serve {kind} → http://{host}:{port}{path}（{auth_note}）")
    print("按 Ctrl+C 停止")
    import uvicorn

    uvicorn.run(app, host=host, port=port, log_level="info")


# ---------------------------------------------------------------------------
# setup 命令（开箱配置向导）
# ---------------------------------------------------------------------------


def _cmd_setup(args: list[str]):
    """amz setup [--web] [--status --json] [--token X] [--base-url URL] [--no-prompt]

    SellerSprite: --sellersprite-token-file PATH / --clear-sellersprite-token.

    把配置写入 ~/.amz/config.yaml（服务端部署 / 新机器上手）。
    """
    if "--status" in args:
        from amz.setup_web import saved_status

        status = saved_status()
        if "--json" in args:
            print(json.dumps(status, ensure_ascii=False))
        else:
            print("AMZ 数据 Token：" + ("已配置" if status["data_api_token"] else "未配置"))
            print("SellerSprite MCP Token：" + ("已配置" if status["sellersprite_token"] else "未配置（可选）"))
            print("COSMO 图片关键词抽取：" + ("开启" if status["cosmo_use_images"] else "关闭"))
            for provider, is_set in status["api_keys"].items():
                print(f"{provider}：" + ("已配置" if is_set else "未配置"))
        return

    if "--web" in args:
        from amz.setup_web import run_web_setup

        result = run_web_setup(open_browser="--no-open" not in args)
        if result:
            sys.exit(result)
        return

    import yaml

    from amz.config import config

    config.load()
    token_arg = None
    base_url_arg = None
    seller_file = None
    clear_seller = "--clear-sellersprite-token" in args
    no_prompt = False
    rest = args
    i = 0
    while i < len(rest):
        if rest[i] == "--token" and i + 1 < len(rest):
            token_arg = rest[i + 1]
            i += 2
        elif rest[i] == "--base-url" and i + 1 < len(rest):
            base_url_arg = rest[i + 1]
            i += 2
        elif rest[i] == "--no-prompt":
            no_prompt = True
            i += 1
        elif rest[i] == "--sellersprite-token-file" and i + 1 < len(rest):
            seller_file = rest[i + 1]
            i += 2
        else:
            i += 1

    target = Path.home() / ".amz" / "config.yaml"
    target.parent.mkdir(parents=True, exist_ok=True)

    data: dict = {}
    if target.exists():
        try:
            data = yaml.safe_load(target.read_text()) or {}
        except Exception:
            data = {}

    current_token = token_arg or config.data_api_token or ""
    current_url = base_url_arg or config.data_api_base_url or "https://amz.jxpxxzj.cn"

    def _prompt(label: str, current: str, secret: bool = False) -> str:
        if no_prompt or not sys.stdin.isatty():
            return current
        shown = "（已配置，回车保留）" if current else ""
        display = "***" if (secret and current) else current
        try:
            value = input(f"{label} [{display}]{shown}: ").strip()
        except (EOFError, KeyboardInterrupt):
            return current
        return value or current

    token = _prompt("data_api.token", current_token, secret=True)
    base_url = _prompt("data_api.base_url", current_url)

    data.setdefault("data_api", {})
    data["data_api"]["token"] = token
    data["data_api"]["base_url"] = base_url

    from amz.setup_web import save_sellersprite_token
    if seller_file:
        data.setdefault("sellersprite", {})["token_file"] = seller_file
        data["sellersprite"]["enabled"] = True
    if clear_seller:
        save_sellersprite_token({"sellersprite_action": "clear"}, data)
    elif not no_prompt and sys.stdin.isatty():
        from getpass import getpass
        try:
            seller_value = getpass("SellerSprite MCP Token（可选，回车保留）: ").strip()
        except (EOFError, KeyboardInterrupt):
            seller_value = ""
        save_sellersprite_token({"sellersprite_token": seller_value}, data)

    sif_default = str(config.sif_token_file)
    sif = _prompt("sif.token_file", sif_default)
    if sif:
        data.setdefault("sif", {})
        data["sif"]["token_file"] = sif

    # 物化 LLM API keys：从当前合并配置（项目 .env 等）写入，保证任意 cwd 可用
    llm_keys = data.setdefault("api_keys", {})
    for provider in ("doubao",):
        current = config.api_key(provider) or ""
        value = _prompt(f"api_keys.{provider}", current, secret=True)
        if value:
            llm_keys[provider] = value
    data.setdefault("llm", {})["default_backend"] = "doubao"

    from amz.setup_web import write_saved_config

    write_saved_config(data, target)

    print(f"\n✅ 配置已写入 {target}")
    cmd_doctor()



if __name__ == "__main__":
    raise SystemExit(main())
