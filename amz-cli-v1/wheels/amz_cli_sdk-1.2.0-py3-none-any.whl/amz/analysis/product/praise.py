"""Product VOC praise analysis."""

from __future__ import annotations
from pydantic import ValidationError
from amz.envelope import Result, ok
from amz.registry import capability
from amz.infra.llm import chat_json
from amz.schemas.analysis_inputs import VocInput
from amz.schemas.voc import ValuePerception, VocPraiseOutput
from amz.analysis.product._voc import _listing_snapshot, _review_snapshots, _input_error
from amz.analysis.product._voc import _llm_output, _features, _format_positive_reviews, _JSON_ONLY_SUFFIX



VOC_PRAISE_PROMPT = """你是一位资深的消费者洞察专家，擅长从用户好评中挖掘产品真正的竞争力——不是卖家声称的卖点，而是用户用钱包投票后亲口验证的优势。

任务：对下面的产品好评做深度挖掘，找出用户真正喜爱什么、什么超出了预期、产品在真实使用中表现出哪些卖家没有宣传的亮点。

## 提取维度

### 1. 被用户喜爱的功能/特性（Loved Features）
- 用户在评论中明确称赞的具体功能、设计细节或使用体验
- 区分狂热度：
  - 「狂热」：使用强烈情感词汇（love、amazing、incredible、best ever、game changer 等）
  - 「认可」：明确肯定但语气平实（good、works well、happy with、pleased 等）
  - 「提及」：顺带提及但不带强烈情感
- 排除泛泛的营销式好评（"Great product"、"Highly recommend"），只保留有具体指向的称赞

### 2. 惊喜/超出预期的点（Delight Factors）
- 用户明确表示「没想到」「超出预期」「惊喜」的功能或体验
- 分类：功能惊喜（没想到这么好用）| 质量惊喜（没想到材质/做工这么好）| 体验惊喜（没想到用起来这么方便/舒服）| 配件惊喜（没想到还送了XX/XX设计很贴心）
- 特别关注：卖家在 Listing 中没有重点宣传、但用户反复提到的点

### 3. 价值感知（Value Perception）
- 用户对性价比的评价：「超值」（worth every penny / great value / 比想象中好太多）、「物有所值」（fair price / reasonable）、「偏贵」（a bit pricey but worth it / expensive but good）
- 如果用户明确说「比 XX 品牌便宜但质量一样好」这类对比，要摘录

### 4. 耐用性/长期使用信号（Durability Signals）
- 使用了一段时间后的反馈（"after 3 months..."、"still working great"、"holding up well"）
- 如果有反面信号（"started to..."），也记录下来——这是长期可靠性的关键信号

### 5. 竞品对比（Competitive Mentions）
- 用户提到的竞品品牌/产品名称，以及对比结论
- 胜出原因：用户亲口说的为什么这个更好

### 6. 功能满意度排名（Feature Satisfaction Ranking）
- 按被提及次数对产品的核心功能做排序，标注每个功能的被称赞次数和代表性摘录

## 输入数据
产品标题：{title}

五点描述（供了解产品功能列表）：
{features}

好评（4-5星）：
{reviews}

## 输出 JSON 结构（所有 value 用中文）：
{{
  "loved_features": [
    {{"feature": "被称赞的具体功能/特性", "enthusiasm": "狂热|认可|提及", "evidence": "原文证据摘录（必须引用原文）", "mentioned_by": 提及用户数整数}}
  ],
  "delight_factors": [
    {{"delight": "超出预期的惊喜点描述", "category": "功能惊喜|质量惊喜|体验惊喜|配件惊喜", "evidence": "原文证据摘录", "mentioned_by": 提及用户数整数}}
  ],
  "value_perception": {{
    "overall_sentiment": "超值|物有所值|偏贵但不后悔|信息不足",
    "summary": "一句话概括用户对性价比的整体评价",
    "evidence": ["原文摘录1", "原文摘录2"],
    "mentioned_by": 提及用户数整数
  }},
  "durability_signals": [
    {{"observation": "耐用性相关发现（正面或负面）", "usage_duration": "用户自称的使用时长", "evidence": "原文证据摘录", "mentioned_by": 提及用户数整数}}
  ],
  "competitive_mentions": [
    {{"competitor_name": "被提及的竞品品牌/产品名", "comparison_result": "胜出|平手|落败", "win_reason": "用户认为胜出或落败的原因", "evidence": "原文证据摘录", "mentioned_by": 提及用户数整数}}
  ],
  "feature_satisfaction_ranking": [
    {{"feature": "功能名", "praise_count": 被称赞次数整数, "representative_quote": "最能代表用户态度的原文摘录"}}
  ]
}}

按 mentioned_by 从高到低排序。如果某个维度没有足够信号（如没有竞品对比或耐用性反馈），返回空数组或「信息不足」。
""" + _JSON_ONLY_SUFFIX


@capability(
    "analysis.voc.praise",
    description="从好评中挖掘用户喜爱点、惊喜点、竞品对比、价值感知",
    input_model=VocInput,
    output_model=VocPraiseOutput,
)
def voc_praise(
    product_info: dict,
    reviews: list[dict] | None = None,
) -> Result:
    return _run_voc_praise(
        product_info=product_info, reviews=reviews,
        llm_call=chat_json,
    )


def _run_voc_praise(
    product_info: dict,
    reviews: list[dict] | None = None,
    *, llm_call,
) -> Result:
    """analysis.voc.praise — 好评深度挖掘

    从 4-5 星好评中系统性提取：
    - 用户真正喜爱的功能/特性（与卖家声称的优势互补）
    - 超出预期的惊喜点
    - 价值感知（性价比评价）
    - 耐用性/长期使用信号
    - 竞品对比（用户亲口说的为什么选这个）
    - 功能满意度排名

    Args:
        product_info: {title, bullet_points}
        reviews: 评论列表
    """
    reviews = reviews or []
    if reviews:
        try:
            product_info = _listing_snapshot(product_info).model_dump()
            reviews = [item.model_dump() for item in _review_snapshots(reviews, legacy_ids=True)]
        except ValidationError as exc:
            return _input_error(exc)
    reviews_text = _format_positive_reviews(reviews)
    if not reviews_text.strip():
        return ok(data={
            **VocPraiseOutput().model_dump(),
            "value_perception": ValuePerception(summary="无好评数据").model_dump(),
        })

    prompt = VOC_PRAISE_PROMPT.format(
        title=product_info.get("title", ""),
        features="\n".join(_features(product_info)[:10]),
        reviews=reviews_text,
    )
    return _llm_output(prompt, VocPraiseOutput, llm_call=llm_call)
