"""Product VOC weaknesses analysis."""

from __future__ import annotations
from pydantic import ValidationError
from amz.envelope import Result, ok, err, Code
from amz.registry import capability
from amz.infra.llm import chat_json
from amz.schemas.analysis_inputs import VocWeaknessesInput
from amz.schemas.voc import ProductVocListing, ProductVocReview, VocSatisfactionMetrics, VocWeaknessSignalsInput, VocWeaknessSignalsOutput, VocWeaknessesOutput
from amz.analysis.product._voc import _llm_output, _format_reviews, _input_error, _listing_snapshot, _review_snapshots, _JSON_ONLY_SUFFIX



VOC_WEAKNESSES_PROMPT = """你是一位资深的亚马逊市场研究专家与产品战略顾问，擅长用 VOC（Voice of Customer）分析法，从评论中提取高价值洞察。

任务：对下面的产品评论做深度解析，产出一份实操性强的 VOC 洞察报告。

分析框架：
1. 核心痛点与缺陷：归纳导致负评的主要原因，区分"偶发质量问题"(Quality)与"结构性设计缺陷"(Structural)、"说明/使用问题"(Instructional)，按对体验的影响排序。
2. 未满足的隐性需求：捕捉 "I wish..."、"If only..."、"如果能...就好了" 这类陈述，以及用户需额外购买配件才能解决的问题。

## 满意度上下文
总评论数：{total_reviews}
好评率（4-5星）：{positive_pct}
差评率（1-2星）：{negative_pct}
产品综合评分：{product_rating}

## 辩证分析要求（重要）
这是一个{rating_label}的产品。请在分析每个痛点时遵循以下原则：
1. 频次加权：每个问题的严重程度不仅要看投诉的绝对数量，还要看它在总评论中的占比。例如，一个拥有 1000+ 条评论、好评率 92% 的产品，被 7 人投诉的某个问题很可能只是个体差异或个人偏好，不应标注为「High」严重度。
2. 好评背景对照：对于任何被识别为痛点的问题，请同时检视好评中是否有大量相反的证据。例如，若 7 条差评投诉「味道不好」，但好评区大量提及「气味宜人」或「香味很棒」，则应在 dialectical_note 中标注这一矛盾——说明该问题可能是个人敏感度差异而非产品质量缺陷。
3. 严重度校准：High 严重度应仅保留给（a）涉及安全隐患的问题，（b）在好评率 <85% 的产品中高频出现的问题，或（c）结构性/设计性缺陷（非偶发品控）。对于高满意度产品中的低频投诉，应标记为 Medium 或 Low。
4. 结论导向：请综合满意度上下文，给出一个 balanced_assessment，说明整体来看这些问题的实际影响程度。

## 输入数据
产品标题：{title}

五点描述：
{features}

星级分布：{star_dist}

用户评论：
{reviews}

## 输出规范（严格要求）
1. 每个 top_issue 和 unmet_need 必须包含 cnt（出现次数）、total_referenced（参与统计的评论总数）和 ratio（比例，例如 "7/250 (2.8%)"）。
2. 每个条目的 evidence 必须引用至少 1 条原文评论的原文摘录，不能是概括或推测。
3. issue_type 必须严格三选一：Structural（设计结构问题）、Quality（品控/材质质量问题）、Instructional（说明书/使用说明不清）。
4. cnt 必须是有明确提及该问题的评论计数，不能估算。
5. total_referenced 仅使用本次输入评论数；样本比例不得写成全量用户比例。全量星级分布未知时，不补造好评率/差评率。
6. 用户希望备用配件或其他容量，只能证明该用户的诉求，不能据此断言市场/卖家未提供该选项。

## 输出 JSON 结构（所有 value 用中文）：
{{
  "satisfaction_assessment": "综合考虑评分与评论量，客观评价该产品整体满意度水平的一句话",
  "top_issues": [
    {{"pain_point": "痛点", "severity": "High|Medium|Low", "evidence": "原文证据摘录（必须引用原文）", "cnt": 出现次数整数, "total_referenced": 参与统计的总评论数整数, "ratio": "例如 7/250 (2.8%)", "issue_type": "Structural|Quality|Instructional", "dialectical_note": "若好评中对此有相反证据或该问题因整体高满意度应降低权重，在此说明；若无矛盾则填「无」"}}
  ],
  "unmet_needs": [
    {{"unmet_need": "未满足需求", "impact": "High|Medium|Low", "description": "说明", "evidence": "原文证据（必须引用原文）", "cnt": 出现次数整数, "total_referenced": 参与统计的总评论数整数, "ratio": "例如 7/250 (2.8%)"}}
  ],
  "balanced_assessment": "综合满意度上下文，客观评估上述痛点对该产品整体竞争力的实际影响（2-3句话）"
}}
""" + _JSON_ONLY_SUFFIX


def _analyze_weakness_signals(
    listing: ProductVocListing,
    review_models: list[ProductVocReview],
    metrics: VocSatisfactionMetrics,
    star_dist_override: str | None = None,
    *, llm_call,
) -> Result:
    """执行一次弱点语义推理；不计算或合并确定性指标。"""
    if not review_models:
        return ok(data=VocWeaknessSignalsOutput(
            satisfaction_assessment="无评论数据",
            top_issues=[],
            unmet_needs=[],
            balanced_assessment="",
        ).model_dump())

    prompt = VOC_WEAKNESSES_PROMPT.format(
        title=listing.title,
        features="\n".join(listing.bullet_points[:10]),
        total_reviews=metrics.total_reviews,
        positive_pct=f"{metrics.positive_pct}%" if metrics.positive_pct is not None else "未知（未提供全量星级分布）",
        negative_pct=f"{metrics.negative_pct}%" if metrics.negative_pct is not None else "未知（未提供全量星级分布）",
        product_rating=metrics.product_rating or "未知",
        rating_label=metrics.rating_label,
        star_dist=star_dist_override or (
            f"4-5★: {metrics.positive_pct}%, 1-2★: {metrics.negative_pct}%"
            if metrics.positive_pct is not None and metrics.negative_pct is not None
            else "未知（不可用抽样评论代替全量星级分布）"
        ),
        reviews=_format_reviews([
            review.model_dump(mode="python") for review in review_models
        ]),
    )
    return _llm_output(prompt, VocWeaknessSignalsOutput, llm_call=llm_call)


@capability(
    "analysis.voc.weakness-signals",
    description="从已抽样评论中提取痛点和未满足需求",
    input_model=VocWeaknessSignalsInput,
    output_model=VocWeaknessSignalsOutput,
    requires=["product.get", "product.reviews", "calc.voc.satisfaction"],
)
def voc_weakness_signals(
    product_info: dict,
    reviews: list[dict],
    satisfaction: dict,
) -> Result:
    return _run_voc_weakness_signals(
        product_info=product_info, reviews=reviews, satisfaction=satisfaction,
        llm_call=chat_json,
    )


def _run_voc_weakness_signals(
    product_info: dict,
    reviews: list[dict],
    satisfaction: dict,
    *, llm_call,
) -> Result:
    """只做 VOC 语义判断；满意度指标由 Calc 显式传入。"""
    try:
        listing = _listing_snapshot(product_info)
        review_models = _review_snapshots(reviews)
        metrics = VocSatisfactionMetrics.model_validate(satisfaction)
    except ValidationError as exc:
        return _input_error(exc)
    return _analyze_weakness_signals(listing, review_models, metrics, llm_call=llm_call)


@capability(
    "analysis.voc.weaknesses",
    description="差评 VOC 兼容入口；新链路使用 Calc + weakness-signals",
    input_model=VocWeaknessesInput,
    output_model=VocWeaknessesOutput,
)
def voc_weaknesses(
    product_info: dict,
    reviews: list[dict] | None = None,
    star_ratios: dict | str | None = None,
) -> Result:
    return _run_voc_weaknesses(
        product_info=product_info, reviews=reviews, star_ratios=star_ratios,
        llm_call=chat_json,
    )


def _run_voc_weaknesses(
    product_info: dict,
    reviews: list[dict] | None = None,
    star_ratios: dict | str | None = None,
    *, llm_call,
) -> Result:
    """保留旧参数形状，内部委托同一个 Calc 和语义原子。"""
    from amz.calc.product.satisfaction import calculate_satisfaction, merge_weakness_signals

    try:
        listing = _listing_snapshot(product_info)
        review_models = _review_snapshots(reviews, legacy_ids=True)
        metrics = calculate_satisfaction(
            reviews=review_models,
            star_ratios=star_ratios if isinstance(star_ratios, dict) else None,
            total_reviews=listing.count_ratings,
            product_rating=listing.product_rating,
        )
    except ValidationError as exc:
        return _input_error(exc)

    if not review_models:
        return ok(data=VocWeaknessesOutput.empty(metrics).model_dump())
    signals = _analyze_weakness_signals(
        listing,
        review_models,
        metrics,
        star_ratios if isinstance(star_ratios, str) else None,
    llm_call=llm_call)
    if signals.code != Code.OK:
        return signals
    try:
        merged = merge_weakness_signals(signals.data, metrics)
    except ValidationError as exc:
        return err(Code.ERROR_LLM, str(exc))
    return ok(data=merged.model_dump(mode="python"))
