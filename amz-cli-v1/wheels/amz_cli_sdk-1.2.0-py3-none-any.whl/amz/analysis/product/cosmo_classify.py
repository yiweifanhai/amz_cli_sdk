"""Classify COSMO groups for an explicit target Listing; no Entity writeback."""

from __future__ import annotations

from amz.analysis.inputs import has_product_facts
from amz.envelope import Code, Result, err, ok
from amz.infra.llm import chat_json
from amz.registry import capability


from math import isfinite
from pydantic import ValidationError
from amz.analysis.base import AnalysisContractError, require_json
from amz.schemas.analysis_inputs import CosmoClassifyInput
from amz.schemas.cosmo import CosmoClassifyOutput, TermGroup


_SUGGESTED_POSITIONS = {
    "title+bullet", "title", "bullet", "description", "search_term", "not_recommended",
}
_POSITION_LABELS = {
    "title+bullet": "标题 + 首条五点", "title": "标题", "bullet": "五点描述",
    "description": "描述 / A+", "search_term": "后台 Search Term",
    "not_recommended": "不建议使用",
}


def _parse_suggested_position(raw: object) -> str:
    normalized = str(raw or "").lower().strip().replace(" ", "")
    aliases = {"title+bullets": "title+bullet", "bullets": "bullet", "searchterm": "search_term"}
    normalized = aliases.get(normalized, normalized)
    return normalized if normalized in _SUGGESTED_POSITIONS else "not_recommended"


def _build_classify_prompt(
    groups: list[TermGroup], total_asins: int, product_info: dict | None
) -> str:
    term_summary = "\n".join(
        f'- group_id="{group.group_id}", term="{group.representative_term}" (COSMO: {group.cosmo_category}/{group.cosmo_field}, '
        f'覆盖 {len(group.asins)}/{total_asins} ASIN, 加权分: {group.weighted_score}, '
        f'标题: {group.title_count}, 五点: {group.bullet_points_count}, A+: {group.a_plus_count})'
        for group in groups
    )
    if product_info:
        product_context = (
            f'\n# 目标产品信息:\n- 标题: {product_info.get("title", product_info.get("product_name", ""))}\n'
            + f'- 五点: {product_info.get("bullet_points", product_info.get("features", []))}\n'
            + (f'- 描述: {product_info.get("description")}\n' if product_info.get("description") else "")
        )
        irrelevant_instruction = """
## irrelevant (布尔值): 与目标产品是否完全无关
- true: 该词条描述的功能、场景、受众与目标产品毫无关系，搜索该词的用户不可能购买目标产品
- false: 有任何程度的相关性（哪怕是间接相关）都标记为 false
- 判断要基于目标产品的实际品类和用途，不要仅看字面意思
"""
        irrelevant_example = '"irrelevant": false, '
        irrelevant_note = "\n- irrelevant 字段必须明确给出 true 或 false"
    else:
        product_context = "\n# 注意: 未提供目标产品信息，请基于词条本身的 Amazon 搜索价值进行评分\n"
        irrelevant_instruction = irrelevant_example = irrelevant_note = ""

    return f"""你是 Amazon COSMO + Rufus 关键词评估专家。在 AI 时代，Listing 不再是简单的关键词堆砌，而是"Rufus 答案库"——每个词条都要判断是否值得写入 Listing、放在哪个位置、以及优先级。

请对以下词条进行多维度评分。
{product_context}
# 评分维度:

## relevanceScore (1-10): 与产品的相关性
- 10: 核心品类词/功能词，搜索该词的用户 100% 要找这类产品
- 7-9: 直接相关的功能/场景词
- 4-6: 间接相关，有一定关联
- 1-3: 弱相关或泛化词

## valueScore (1-10): 搜索价值和购买意图强度
- 10: 高搜索量+强购买意图（如品类大词 "yoga mat"）
- 7-9: 明确购买意图的精准词（如 "non-slip yoga mat"）
- 4-6: 有搜索量但意图不够明确（如 "exercise equipment"）
- 1-3: 低搜索量或纯信息词（如 "how to use"）

## listingScore (1-10): 是否值得写入 Listing
基于 Rufus RAG 框架判断：这个词能否成为 Rufus 采信的"答案素材"？
- 10: 必须写入，是 COSMO 知识图谱的核心节点连接词，缺少它产品会"隐形"
- 7-9: 强烈建议写入，能帮助 AI 理解产品属性/场景/人群
- 4-6: 可写可不写，有一定补充价值但非关键
- 1-3: 不建议写入，信息熵低或过于泛化（如 "high quality"、"best"）

## bulletScore (1-10): 五点描述适用性
判断这个词是否适合放在五点描述中，作为"痛点+解决方案+场景"的 Q&A 向量库：
- 10: 完美适合五点——直接回答用户高频问题（如安全性、耐用性、适配性）
- 7-9: 很适合五点——描述具体功能/使用场景/解决的痛点
- 4-6: 一般适合——可融入五点但不是核心卖点
- 1-3: 不适合五点——太泛化、太技术性、或适合放后台

## suggestedPosition: 建议埋词位置（同时决定是否保留）
这是最终的保留决策字段——选择具体位置代表"保留"，选 not_recommended 代表"不保留"。
必须与 listingScore 保持一致：listingScore >= 5 时应选择具体位置，< 5 时应选 not_recommended。
- "title+bullet": 核心品类词/场景词，必须在标题+首条五点中出现（S级）
- "title": 重要品类词，需要在标题中出现
- "bullet": 功能/场景/痛点词，适合写在五点描述中构建"答案库"
- "description": 长尾语义/叙事性场景词，适合产品描述或 A+ 页面
- "search_term": 补充性词汇，不适合前台但有搜索价值，放后台 Search Term
- "not_recommended": 与产品无关或价值太低，不建议使用
{irrelevant_instruction}
# 竞品总数: {total_asins}

# 待评分词条:
{term_summary}

# 输出格式 (纯 JSON):
{{
  "scores": [
    {{"group_id": "原样复制输入的 group_id", "term": "词条", "relevanceScore": 8, "valueScore": 7, "listingScore": 9, "bulletScore": 7, "suggestedPosition": "title+bullet", {irrelevant_example}"reason": "核心品类词，Rufus 必采信"}}
  ]
}}

注意:
- 必须为每个 group_id 返回且只返回一份评分；不同字段可以有相同词条，仍要分别评分
- reason 简洁（15字以内）
- 所有分数都是 1-10 的整数
- suggestedPosition 必须是 title+bullet/title/bullet/description/search_term/not_recommended 之一{irrelevant_note}"""


@capability(
    "analysis.cosmo.classify",
    description="COSMO 词组规则 30% + LLM 70% 分类与埋词位置建议",
    input_model=CosmoClassifyInput,
    output_model=CosmoClassifyOutput,
    requires=["analysis.cosmo.aggregate"],
)
def cosmo_classify(
    groups: list[dict],
    total_asins: int,
    product_info: dict | None = None,
    batch_size: int = 50,
) -> Result:
    try:
        parsed_groups = [TermGroup.model_validate(group) for group in groups]
    except ValidationError as exc:
        return err(Code.ERROR_PARAM, str(exc))
    if not parsed_groups:
        return ok(data=CosmoClassifyOutput().model_dump())
    if total_asins <= 0 or batch_size <= 0:
        return err(Code.ERROR_PARAM, "total_asins and batch_size must be positive for non-empty groups")
    if any(not group.group_id.strip() for group in parsed_groups) or len({group.group_id for group in parsed_groups}) != len(parsed_groups):
        return err(Code.ERROR_PARAM, "COSMO group IDs must be non-empty and unique")
    if not has_product_facts(product_info):
        return err(Code.ERROR_MISSING_FIELDS, "COSMO listing classification requires target product facts", missing=["product_info"])
    if any(not group.representative_term.strip() for group in parsed_groups):
        return err(Code.ERROR_MISSING_FIELDS, "COSMO groups require a representative term", missing=["groups.representative_term"])
    max_weight = max((group.weighted_score for group in parsed_groups), default=1) or 1
    output: list[TermGroup] = []
    for start in range(0, len(parsed_groups), batch_size):
        batch = parsed_groups[start : start + batch_size]
        prompt = _build_classify_prompt(batch, total_asins, product_info)
        try:
            model_call = chat_json
            raw = require_json(model_call(prompt=prompt, model="pro", temperature=0.2))
            scores = raw.get("scores") if isinstance(raw, dict) else None
            if not isinstance(scores, list):
                raise AnalysisContractError("COSMO classification requires a scores list")
            expected = {group.group_id: group for group in batch}
            by_term: dict[str, list[str]] = {}
            for group in batch:
                by_term.setdefault(group.representative_term.lower(), []).append(group.group_id)
            score_map = {}
            for item in scores:
                if not isinstance(item, dict):
                    raise AnalysisContractError("COSMO score must be an object")
                term = str(item.get("term") or "").lower()
                key = item.get("group_id")
                if key is None:
                    matches = by_term.get(term, [])
                    if len(matches) != 1:
                        raise AnalysisContractError("COSMO scores require group_id for unknown or ambiguous terms")
                    key = matches[0]
                if not isinstance(key, str):
                    raise AnalysisContractError("COSMO score group_id must be a string")
                if key not in expected or key in score_map:
                    raise AnalysisContractError("COSMO scores contain an unknown or repeated group_id")
                if term and term != expected[key].representative_term.lower():
                    raise AnalysisContractError("COSMO score term does not match its group_id")
                for name in ("relevanceScore", "valueScore", "listingScore", "bulletScore"):
                    if name not in item or isinstance(item[name], bool) or not isfinite(float(item[name])):
                        raise AnalysisContractError(f"COSMO score requires a finite {name}")
                position = item.get("suggestedPosition")
                allowed = _SUGGESTED_POSITIONS | {"title+bullets", "bullets", "searchterm"}
                if not isinstance(position, str) or position.lower().strip().replace(" ", "") not in allowed:
                    raise AnalysisContractError("COSMO score requires a valid suggestedPosition")
                if not isinstance(item.get("reason"), str):
                    raise AnalysisContractError("COSMO score requires a reason string")
                if (product_info or "irrelevant" in item) and not isinstance(item.get("irrelevant"), bool):
                    raise AnalysisContractError("COSMO score irrelevant must be a boolean")
                score_map[key] = item
            if score_map.keys() != expected.keys():
                raise AnalysisContractError("COSMO classification omitted input terms")
        except Exception as exc:
            return err(Code.ERROR_LLM, str(exc))
        for group in batch:
            rule = (
                (len(group.asins) / total_asins if total_asins else 0) * 30
                + (20 if group.title_count else 0)
                + (10 if group.bullet_points_count else 0)
                + group.weighted_score / max_weight * 40
            )
            item = score_map[group.group_id]
            relevance = min(10, max(1, float(item["relevanceScore"])))
            value = min(10, max(1, float(item["valueScore"])))
            listing_score = min(10, max(1, float(item["listingScore"])))
            bullet_score = min(10, max(1, float(item["bulletScore"])))
            llm_score = (relevance + value + listing_score) / 3 * 10
            position = _parse_suggested_position(item.get("suggestedPosition"))
            irrelevant = bool(item.get("irrelevant", False)) and bool(product_info)
            reason = str(item.get("reason") or "")
            final = rule * 0.3 + llm_score * 0.7
            if irrelevant:
                grade, position = "C", "not_recommended"
            elif final < 30 or listing_score <= 3:
                grade = "C"
            elif final >= 70 and listing_score >= 8 and bullet_score >= 7:
                grade = "S"
            elif final >= 50 and listing_score >= 6:
                grade = "A"
            else:
                grade = "B"
            display_reason = (
                f"与产品无关: {reason} [{_POSITION_LABELS[position]}]"
                if irrelevant else f"{reason} [{_POSITION_LABELS[position]}]"
            )
            scores = {
                "rule_score": round(rule, 1),
                "llm_listing_score": listing_score,
                "llm_bullet_score": bullet_score,
                "final_score": round(final, 1),
            }
            if relevance is not None:
                scores["llm_relevance_score"] = relevance
            if value is not None:
                scores["llm_value_score"] = value
            output.append(group.model_copy(update={
                "classification": grade,
                "keep_in_listing": position != "not_recommended",
                "suggested_position": position,
                "reason": display_reason,
                "scores": scores,
            }))
    return ok(data=CosmoClassifyOutput(groups=output).model_dump())
