"""classify_asin: analyze only explicit product facts and decision dimensions."""
from __future__ import annotations
import json
from amz.envelope import Code, Result, err, ok
from amz.infra.llm import chat_json
from amz.analysis.inputs import has_text
from amz.analysis.base import parse_structured, require_json
from amz.registry import capability
from amz.schemas.analysis_inputs import ClassifyAsinInput
from amz.schemas.traffic import AsinClassificationOutput


@capability(
    "analysis.asin.classify",
    description="按已发现维度为单个 ASIN 打标",
    input_model=ClassifyAsinInput,
    output_model=AsinClassificationOutput,
    requires=["analysis.asin.discover-dimensions"],
)
def classify_asin(product: dict, dimensions: list[dict]) -> Result:
    if not isinstance(product, dict) or not any(has_text(product.get(name)) for name in ("title", "description", "raw_text", "top_keywords", "keywords")):
        return err(Code.ERROR_MISSING_FIELDS, "classification requires product facts", missing=["product"])
    if not isinstance(dimensions, list) or not dimensions:
        return err(Code.ERROR_MISSING_FIELDS, "classification requires supplied dimensions", missing=["dimensions"])
    names = set()
    for dimension in dimensions:
        if not isinstance(dimension, dict) or not isinstance(dimension.get("name"), str) or not dimension["name"].strip() or not isinstance(dimension.get("values"), list) or not dimension["values"] or any(not isinstance(value, str) or not value.strip() for value in dimension["values"]):
            return err(Code.ERROR_PARAM, "each classification dimension requires a name and non-empty values")
        name = dimension["name"].strip().casefold()
        if name in names:
            return err(Code.ERROR_PARAM, "classification dimension names must be unique")
        names.add(name)
    normalized_dimensions = []
    for dimension in dimensions:
        values = [str(value) for value in dimension.get("values", [])]
        if "other" not in values:
            values.append("other")
        normalized_dimensions.append({**dimension, "values": values})
    prompt = f"""Classify ONE Amazon product using the dimensions below.

=== Dimensions ===
{json.dumps(normalized_dimensions, ensure_ascii=False)}

=== Product info ===
ASIN: {product.get('asin', '')}
Price: {product.get('price', product.get('price_usd', ''))}
Title: {product.get('title', '')}

Top reverse keywords (the actual search queries that lead users to this product;
these are strong hints for target user, use case, and product category):
{json.dumps(product.get('top_keywords', product.get('keywords', [])), ensure_ascii=False)}

Product detail text (from the product page):
{str(product.get('raw_text', product.get('description', '')))[:2000]}

=== Rules ===
- Use ALL the info above (title + keywords + detail text) when assigning values.
- Assign the best matching value for each dimension.
- Use "other" if the product clearly has a value for this dimension but it doesn't fit
  any of the listed values (e.g. dimension Material has [Leather, Fabric] and the
  product is Plastic).
- Use "unknown" ONLY if the info genuinely doesn't reveal that attribute.
- Top reverse keywords are especially useful for target-user / use-case / category dimensions.

Output JSON (no markdown):
{{
  "classification": {{"dim_name_1": "value_1", "dim_name_2": "value_2"}}
}}"""
    try:
        response = chat_json(
            prompt=prompt, json_schema=AsinClassificationOutput.model_json_schema(),
            model="pro", temperature=0.2,
        )
        raw = require_json(response)
        if not isinstance(raw, dict) or "classification" not in raw:
            return err(Code.ERROR_LLM, "model output is missing classification")
        output = parse_structured(response, AsinClassificationOutput)
        allowed = {item["name"]: set(item["values"]) | {"unknown"} for item in normalized_dimensions}
        cleaned = {}
        for name, values in allowed.items():
            value = output.classification.get(name, "unknown")
            cleaned[name] = value if value in values else "other"
        return ok(data=AsinClassificationOutput(classification=cleaned).model_dump())
    except Exception as exc:
        return err(Code.ERROR_LLM, str(exc))
