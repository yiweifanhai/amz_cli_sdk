"""Product listing part rewrite capability."""

from __future__ import annotations
from amz.envelope import Result, ok, err, Code
from amz.registry import capability
from amz.analysis.product._listing import listing_rules, validate_listing
from amz.schemas.analysis_inputs import ListingPartRewriteInput
from amz.schemas.listing import PartRewriteOutput
from amz.infra.llm import chat
from amz.analysis.inputs import has_text



LISTING_PART_REWRITE_PROMPT = """# Role: Amazon Listing 微调编辑器

你是一个精准的文本微调编辑器，不是创作者。你的任务是将指定关键词**插入**到现有文本中，做**最小幅度**的改动。

# 产品信息
- 原始标题: {product_title}

# 当前要微调的部分: {part_label}
{current_text}

# 需要插入的关键词:
{keywords_text}

# 该部分已有的关键词（按重要性排序，不要删除或移动它们）:
{existing_keywords}

# Listing 其他部分（参考）:
{other_parts}

# 硬约束（必须遵守）:
1. **只在需要插入关键词的位置做改动**，其余文本保持原样一字不差
2. **不要删除已有的关键词**，不要改变已有关键词的顺序和位置
3. **改动不超过 {max_change} 个单词**——只增加或替换必要的少量词
4. **{part_label}不超过 {max_chars} 字符**
5. **越重要的关键词放越靠前的位置**
6. **语法正确、英文流畅**

# 插入技巧:
- 融入现有句子结构，替换同义表述或在并列结构处扩展
- 优先在逗号后、并列结构处、句尾插入
- 如果原文说 "leather case"，可以改为 "leather case holder" 来插入 "holder"
- 不要重新组织句子结构，保持原文的表述框架

# 输出:
直接输出微调后的{part_label}文本，不要加任何前缀、标签或解释。只输出纯文本。"""


@capability(
    "analysis.listing.part-rewrite",
    description="Listing 局部改写（仅改写 Title 或某一条 BP，最小改动）",
    input_model=ListingPartRewriteInput,
    output_model=PartRewriteOutput,
    requires=["product.get"],
)
def listing_part_rewrite(
    product_title: str,
    part_label: str,
    current_text: str,
    keywords: list[dict],
    existing_keywords: list[str] | None = None,
    other_parts: dict | None = None,
    asin: str = "",
    price: str = "",
    brand: str = "",
    forbidden_terms: list[str] | None = None,
    media_title_limit: int | None = None,
) -> Result:
    return _run_listing_part_rewrite(
        product_title=product_title, part_label=part_label, current_text=current_text, keywords=keywords, existing_keywords=existing_keywords, other_parts=other_parts, asin=asin, price=price,
        brand=brand, forbidden_terms=forbidden_terms, media_title_limit=media_title_limit,
        llm_call=chat,
    )


def _run_listing_part_rewrite(
    product_title: str,
    part_label: str,
    current_text: str,
    keywords: list[dict],
    existing_keywords: list[str] | None = None,
    other_parts: dict | None = None,
    asin: str = "",
    price: str = "",
    brand: str = "",
    forbidden_terms: list[str] | None = None,
    media_title_limit: int | None = None,
    *, llm_call,
) -> Result:
    """analysis.listing.part-rewrite — 局部改写

    仅改写 Title 或某一条 Bullet Point，做最小改动插入指定关键词。

    Args:
        product_title: 产品原标题
        part_label: "Title" 或 "BP1" 等
        current_text: 当前该部分的文本
        keywords: [{{term, grade, score}}, ...] 要插入的关键词
        existing_keywords: 该部分已有的关键词（不要删除）
        other_parts: 其他部分的文本参考 {{title, bp1, bp2, ...}}
    """
    missing = [name for name, value in (("part_label", part_label), ("current_text", current_text)) if not has_text(value)]
    if missing:
        return err(Code.ERROR_MISSING_FIELDS, "part rewrite requires the original text and target part", missing=missing)
    if not isinstance(keywords, list) or any(not isinstance(item, dict) for item in keywords):
        return err(Code.ERROR_PARAM, "keywords must be a list of objects")
    if not keywords or any(not has_text(item.get("term") or item.get("keyword")) for item in keywords):
        return err(Code.ERROR_MISSING_FIELDS, "each rewrite keyword requires a non-empty term or keyword", missing=["keywords.term"])
    valid_parts = {"title", "item_name", "标题", "商品名称", "title_differentiation",
                   "item highlights", "highlights", "商品亮点", *(f"bp{i}" for i in range(1, 6))}
    if part_label.strip().lower() not in valid_parts:
        return err(Code.ERROR_PARAM, "part_label must identify title, highlights or bp1-bp5")
    # 格式化关键词
    kw_lines = []
    for kw in keywords:
        term = kw.get("term") or kw.get("keyword") or ""
        grade = kw.get("grade", "")
        score = kw.get("score", "")
        volume = kw.get("search_volume", kw.get("searches", ""))
        source = str(kw.get("source") or "a10").upper()
        attributes = [source]
        if grade:
            attributes.append(f"{grade}级")
        if score not in ("", None):
            try:
                attributes.append(f"分数{float(score):.1f}")
            except (TypeError, ValueError):
                attributes.append(f"分数{score}")
        if volume not in ("", None):
            attributes.append(f"月搜索{volume}")
        kw_lines.append(f"- {term} [{', '.join(attributes)}]")

    keywords_text = "\n".join(kw_lines) if kw_lines else "无"

    existing_str = ", ".join(existing_keywords) if existing_keywords else "无"

    # 构建其他部分参考
    other_lines = []
    if other_parts:
        for key, val in other_parts.items():
            if val and key != part_label.lower():
                other_lines.append(f"{key}: {val}")
    other_str = "\n".join(other_lines) if other_lines else "无"

    # 动态参数
    is_highlights = part_label.strip().lower() in {"title_differentiation", "item highlights", "highlights", "商品亮点"}
    is_title = not is_highlights and ("title" in part_label.lower() or part_label.strip().lower() in {"item_name", "标题", "商品名称"})
    base_change = 10 if is_title else 15
    max_change = base_change + (len(keywords) - 1) * 5
    max_chars = (media_title_limit or 75) if is_title else (125 if is_highlights else 250)

    prompt = LISTING_PART_REWRITE_PROMPT.format(
        product_title=product_title,
        part_label=part_label,
        current_text=current_text,
        keywords_text=keywords_text,
        existing_keywords=existing_str,
        other_parts=other_str,
        max_change=max_change,
        max_chars=max_chars,
    )
    prompt = prompt.replace(
        "# 产品信息\n- 原始标题:",
        f"# 产品信息\n- ASIN: {asin or 'N/A'}\n- 价格: {price or 'N/A'}\n- 原始标题:",
    )
    prompt = prompt.replace(
        "5. **越重要的关键词放越靠前的位置**\n6. **语法正确、英文流畅**",
        "5. **越重要（分数越高、搜索量越大）的关键词放越靠前的位置**\n"
        "6. **不要把新插入的词放在比它分数更高的已有词前面**\n"
        "7. **语法正确、英文流畅**",
    )

    prompt += listing_rules(brand, forbidden_terms, media_title_limit)

    try:
        # 局部改写返回纯文本，不是 JSON
        result = llm_call(prompt=prompt, model="pro", temperature=0.7)
        text = result.get("text", "").strip()
        if not text or len(text) > max_chars:
            raise ValueError("rewritten text is empty or exceeds the character limit")
        data = {"title": text} if is_title else ({"title": product_title, "title_differentiation": text} if is_highlights else {"text": text})
        validate_listing(data, brand, forbidden_terms, media_title_limit)
        return ok(data=PartRewriteOutput(text=text).model_dump())
    except Exception as e:
        return err(Code.ERROR_LLM, str(e))
