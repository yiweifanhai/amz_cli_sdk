"""Product listing allocate capability."""

from __future__ import annotations
from collections import Counter
from amz.envelope import Result, ok, Code, err
from amz.registry import capability
from amz.infra.llm import chat_json
from amz.schemas.analysis_inputs import ListingAllocateInput
from amz.schemas.listing import AllocationOutput
from amz.analysis.product._listing import _json_output
from amz.analysis.inputs import has_text, validate_listing_facts



LISTING_ALLOCATE_PROMPT = """# Role: Amazon Listing 关键词位置分配助手

# Task:
将以下缺失关键词分配到 Listing 的最佳位置（Title 或 BP1-5），基于语义相关性。

# 当前 Listing:
**Title**: {title}
{bullets_text}

# 待分配的缺失关键词:
{keywords}

# 分配规则:
1. 基于每条 Bullet 的主题/卖点，将关键词分配到语义最相关的位置
2. 每条 Bullet Point 最多分配 3 个关键词（避免单条过度修改）
3. Title 只分配最重要的核心词（一般 1-2 个），加入后标题不得超过 75 字符（含空格）；其他词放五点或 unassigned。禁止加入其他品牌或商标词。
4. 如果某个词无法合理分配到任何位置，放入 unassigned
5. 尽量均匀分散，不要把大量词堆到同一条
6. 只能分配到有原文的 Title 或 BP1-BP5；不存在或空白的段落必须返回空数组。
   找不到有原文的合适位置时放入 unassigned，不得为关键词创建新事实或新段落。
7. 每个输入关键词必须原样出现且恰好一次，放在一个已有位置或 unassigned。

# 输出格式 (纯 JSON):
```json
{{
  "title": ["分配到标题的词"],
  "bp1": ["分配到BP1的词"],
  "bp2": ["分配到BP2的词"],
  "bp3": ["分配到BP3的词"],
  "bp4": ["分配到BP4的词"],
  "bp5": ["分配到BP5的词"],
  "unassigned": ["无合适位置的词"]
}}
```"""


@capability(
    "analysis.listing.allocate",
    description="关键词位置分配（LLM 语义分配，Title + BP1-5）",
    input_model=ListingAllocateInput,
    output_model=AllocationOutput,
    requires=["analysis.keyword.gap"],
)
def listing_allocate(
    listing: dict,
    missing_keywords: list[str],
    use_llm: bool = True,
) -> Result:
    return _run_listing_allocate(
        listing=listing, missing_keywords=missing_keywords, use_llm=use_llm,
        llm_call=chat_json,
    )


def _run_listing_allocate(
    listing: dict,
    missing_keywords: list[str],
    use_llm: bool = True,
    *, llm_call,
) -> Result:
    """analysis.listing.allocate — 位置分配

    Args:
        listing: {{title, bullet_points: []}}
        missing_keywords: 需分配的关键词
        use_llm: True=LLM 语义分配, False=确定性规则分配
    """
    if not isinstance(listing, dict):
        return err(Code.ERROR_PARAM, "listing must be an object")
    failure = validate_listing_facts(listing.get("title", ""), listing.get("bullet_points", []))
    if failure is not None:
        return failure
    if not isinstance(missing_keywords, list) or any(not isinstance(item, str) or not item.strip() for item in missing_keywords):
        return err(Code.ERROR_PARAM, "missing_keywords must be a list of non-empty text")
    if not missing_keywords:
        return ok(data=AllocationOutput().model_dump())
    title = listing.get("title", "")
    bps = listing.get("bullet_points", [])
    # 输出协议固定为 BP1-BP5；不能把关键词分配到无法返回的 BP6+。
    n_bps = 5
    available_bps = [i for i, text in enumerate(bps[:n_bps]) if has_text(text)]

    if not use_llm:
        # 确定性规则：短词放 title，长词均匀分配到各 BP
        assigned_title = []
        assigned_bps = [[] for _ in range(n_bps)]
        unassigned = []

        for kw in missing_keywords:
            words = len(kw.split())
            if has_text(title) and words <= 3 and len(assigned_title) < 2 and len(" ".join([title, *assigned_title, kw])) <= 75:
                assigned_title.append(kw)
            elif available_bps:
                bp_idx = min(available_bps, key=lambda i: len(assigned_bps[i]))
                assigned_bps[bp_idx].append(kw)
            else:
                unassigned.append(kw)

        return ok(data={
            "title": assigned_title,
            "bp1": assigned_bps[0],
            "bp2": assigned_bps[1],
            "bp3": assigned_bps[2],
            "bp4": assigned_bps[3],
            "bp5": assigned_bps[4],
            "unassigned": unassigned,
        })

    # LLM 语义分配
    bullets_text = "\n".join(f"BP{i+1}: {bp}" for i, bp in enumerate(bps[:5]))

    prompt = LISTING_ALLOCATE_PROMPT.format(
        title=title,
        bullets_text=bullets_text,
        keywords=", ".join(missing_keywords),
    )

    available = {f"bp{i + 1}" for i in available_bps}
    if has_text(title):
        available.add("title")

    def validate_allocation(data):
        for part, terms in data.items():
            if terms and part not in available | {"unassigned"}:
                raise ValueError(f"allocation targets a part without original text: {part}")
        returned = [term for terms in data.values() for term in terms]
        if Counter(returned) != Counter(missing_keywords):
            raise ValueError("allocation must return each supplied keyword exactly once")

    return _json_output(prompt, AllocationOutput, model="lite", temperature=0.2, llm_call=llm_call,
                        validate=validate_allocation)
