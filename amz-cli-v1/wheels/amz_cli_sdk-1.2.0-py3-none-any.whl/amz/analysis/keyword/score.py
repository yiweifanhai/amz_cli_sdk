"""Keyword score analysis."""

from __future__ import annotations

from amz.envelope import Result, ok, err, Code
from amz.registry import capability
from amz.schemas.analysis_inputs import KeywordScoreInput
from amz.schemas.keyword_analysis import RelevanceOutput, KeywordScoreOutput
from .relevance import keyword_relevance, _product_text
from amz.calc.keyword.score import _normalize_keyword_row, keyword_score_missing, score_keyword_rows





@capability(
    "analysis.keyword.score",
    description="A10 四维混合评分（候选集合内百分位 + LLM 语义乘数）",
    input_model=KeywordScoreInput,
    output_model=KeywordScoreOutput,
)
def keyword_score(keywords: list[dict], product_info: dict | None = None) -> Result:
    """Score supplied candidates relative to this set and a concrete product."""
    if not isinstance(keywords, list):
        return err(Code.ERROR_PARAM, "keywords must be a list")
    if not keywords:
        return ok(data=KeywordScoreOutput(grade_distribution={"S": 0, "A": 0, "B": 0, "C": 0}).model_dump())
    if not _product_text(product_info):
        return err(Code.ERROR_MISSING_FIELDS, "product_info requires title, bullet_points or description", missing=["product_info"])
    if any(not isinstance(item, dict) for item in keywords):
        return err(Code.ERROR_PARAM, "keywords must contain objects")
    try:
        rows = [_normalize_keyword_row(item) for item in keywords]
    except (TypeError, ValueError, OverflowError) as exc:
        return err(Code.ERROR_PARAM, f"invalid keyword metrics: {exc}")
    terms = [row["keyword"].strip() for row in rows]
    if any(not term for term in terms) or len({term.casefold() for term in terms}) != len(terms):
        return err(Code.ERROR_PARAM, "keywords require unique non-empty term or keyword values")
    for row, term in zip(rows, terms):
        row["keyword"] = term

    missing = keyword_score_missing(rows)
    if missing:
        return err(Code.ERROR_MISSING_FIELDS, "each scoring dimension requires observed metrics", missing=missing)

    relevance_call = keyword_relevance
    try:
        result = relevance_call(terms, product_info)
        if result.code != Code.OK:
            return result
        output = RelevanceOutput.model_validate(result.data)
        relevance_map = {}
        for item in output.results:
            key = item.keyword.strip().casefold()
            if key in relevance_map or item.match == "unknown":
                raise ValueError("duplicate or missing semantic judgment")
            relevance_map[key] = item.model_dump()
        if relevance_map.keys() != {term.casefold() for term in terms}:
            raise ValueError("semantic judgments do not cover the candidate set")
    except Exception as exc:
        return err(Code.ERROR_LLM, f"keyword scoring requires complete semantic judgments: {exc}")
    try:
        return ok(data=score_keyword_rows(rows, relevance_map))
    except (TypeError, ValueError) as exc:
        return err(Code.ERROR_PARAM, f"invalid keyword metrics: {exc}")
