"""Keyword relevance analysis."""

from __future__ import annotations

from amz.envelope import Result, ok, err, Code
from amz.registry import capability
from amz.schemas.analysis_inputs import KeywordRelevanceInput
from amz.schemas.keyword_analysis import RelevanceItem, RelevanceOutput
from amz.infra.llm import chat_json
from amz.analysis.base import require_json



KEYWORD_RELEVANCE_SYSTEM = """你是一位资深的亚马逊运营专家。你的唯一任务是判断关键词与产品的匹配程度。

# 核心原则

判断的关键不仅是词面是否相关，更要判断：**搜索这个关键词的用户，我们的产品能否满足他的需求？**

# 匹配程度（四档）

- **perfect**: 完美匹配。核心品类词，搜这个词的用户就是要买这个产品，产品完全满足需求
- **high**: 非常匹配。直接相关的功能词/场景词，搜这个词的用户需求能被产品满足
- **partial**: 有一些不匹配。间接相关，产品只能部分满足需求，或者词义有偏差
- **low**: 很不匹配。产品不能满足该关键词对应的用户搜索需求（即使词面看起来有关联）

# 判断逻辑

对每个关键词，请思考：
1. 搜索这个词的用户，他真正想要什么？
2. 我们的产品（标题+五点描述）能否满足这个需求？
3. 如果产品不能很好满足该需求，即使词面相关，也应判为 partial 或 low

# 注意事项

- 重点评估产品与关键词的需求匹配度，不要考虑搜索量、竞争度等市场数据
- reason 限 15 字以内
- 必须为每个关键词都返回结果
- 只输出 JSON，顶层为 results 数组：{"results": [{"keyword": "输入中的原词", "match": "perfect", "reason": "简短理由"}]}。
- 返回实际判断结果，不返回 JSON Schema 定义，不输出 type/properties/items 等 schema 包装。"""


def _product_text(product_info: dict | None) -> str:
    """Use only supplied product facts; empty schema defaults are not context."""
    if not isinstance(product_info, dict):
        return ""
    parts = [value.strip() for key in ("title", "description", "full_description") if isinstance(value := product_info.get(key), str)]
    bullets = product_info.get("bullet_points") or product_info.get("bulletPoints") or []
    if isinstance(bullets, list):
        parts.extend(item.strip() for item in bullets if isinstance(item, str))
    return "\n".join(part for part in parts if part)


@capability(
    "analysis.keyword.relevance",
    description="LLM 语义相关性判断（基于搜索意图匹配）",
    input_model=KeywordRelevanceInput,
    output_model=RelevanceOutput,
)
def keyword_relevance(
    keywords: list[str],
    product_info: dict,
    batch_size: int = 20,
    max_retries: int = 2,
) -> Result:
    """Judge every explicit candidate against supplied product facts."""
    if not isinstance(keywords, list) or any(not isinstance(term, str) or not term.strip() for term in keywords):
        return err(Code.ERROR_PARAM, "keywords must contain non-empty strings")
    normalized = list(dict.fromkeys(keyword.strip() for keyword in keywords))
    if not normalized:
        return ok(data=RelevanceOutput().model_dump())
    if len({term.casefold() for term in normalized}) != len(normalized):
        return err(Code.ERROR_PARAM, "keywords must be unique ignoring case")
    context = _product_text(product_info)
    if not context:
        return err(Code.ERROR_MISSING_FIELDS, "product_info requires title, bullet_points or description", missing=["product_info"])
    if not isinstance(batch_size, int) or batch_size < 1 or not isinstance(max_retries, int) or max_retries < 0:
        return err(Code.ERROR_PARAM, "batch_size must be positive and max_retries must be non-negative")

    llm_call = chat_json
    all_results: list[RelevanceItem] = []
    for start in range(0, len(normalized), batch_size):
        batch = normalized[start:start + batch_size]
        expected = {candidate.casefold(): candidate for candidate in batch}
        user_prompt = "# 产品信息\n" + context + "\n\n# 待判断关键词\n" + "\n".join(f"- {term}" for term in batch)
        last_error = "missing semantic judgments"
        for _attempt in range(max_retries + 1):
            try:
                result = llm_call(
                    messages=[
                        {"role": "system", "content": KEYWORD_RELEVANCE_SYSTEM},
                        {"role": "user", "content": user_prompt},
                    ],
                    json_schema=RelevanceOutput.model_json_schema(),
                    model="lite", temperature=0.2,
                )
                raw = require_json(result)
                if isinstance(raw, dict):
                    # Older array prompts sometimes produce this schema-shaped envelope.
                    # Every item still passes the same coverage and judgment checks below.
                    raw = raw.get("results", raw.get("scores", raw.get("items") if raw.get("type") == "array" else None))
                if not isinstance(raw, list):
                    raise ValueError("relevance output must be an array")
                returned: dict[str, RelevanceItem] = {}
                for value in raw:
                    item = RelevanceItem.model_validate(value)
                    key = item.keyword.strip().casefold()
                    if key not in expected or key in returned:
                        raise ValueError("unexpected or duplicate keyword in relevance output")
                    if item.match == "unknown":
                        raise ValueError(f"semantic judgment missing for {item.keyword}")
                    returned[key] = item.model_copy(update={"keyword": expected[key]})
                if returned.keys() != expected.keys():
                    raise ValueError("model omitted candidate keywords")
                all_results.extend(returned[term.casefold()] for term in batch)
                break
            except Exception as exc:
                last_error = str(exc)
        else:
            return err(Code.ERROR_LLM, f"keyword relevance failed: {last_error}")
    return ok(data=RelevanceOutput(results=all_results).model_dump())
