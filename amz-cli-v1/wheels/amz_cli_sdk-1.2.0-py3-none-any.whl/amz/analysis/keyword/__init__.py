"""Keyword analysis implementations; import the specific capability module."""
