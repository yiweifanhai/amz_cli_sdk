"""Shared structured-response validation for market analyses."""
from amz.infra.llm import chat_json
from amz.analysis.base import parse_structured, require_json, AnalysisContractError
from amz.envelope import Result, Code, ok, err
from amz.schemas.market_analysis import _MarketModel


_JSON_ONLY = """
严格要求：只输出 JSON，不要任何 markdown 标题、说明文字或 ``` 围栏。"""

def _llm_output(prompt: str, output_model: type[_MarketModel], temperature: float = 0.3, *, call_model=None) -> Result:
    try:
        result = (call_model or chat_json)(
            prompt=prompt, json_schema=output_model.model_json_schema(),
            model="pro", temperature=temperature,
        )
        raw = require_json(result)
        if not isinstance(raw, dict):
            raise AnalysisContractError("market model output must be an object")
        missing = set(output_model.model_fields) - set(raw)
        if missing:
            raise AnalysisContractError("model output is missing fields: " + ", ".join(sorted(missing)))
        return ok(data=parse_structured(result, output_model).model_dump())
    except Exception as exc:
        return err(Code.ERROR_LLM, str(exc))
