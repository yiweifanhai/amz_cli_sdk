"""Compatibility demand analysis that delegates deterministic scoring to Calc."""
from __future__ import annotations
from amz.calc.market.demand import score_demand
from amz.envelope import Code, Result, err
from amz.registry import capability
from amz.schemas.analysis_inputs import DemandAssessInput
from amz.schemas.demand import DemandOutput

@capability(
    "analysis.demand.assess",
    description="基于真实 Google/Amazon 趋势输入的确定性需求评估兼容入口",
    input_model=DemandAssessInput,
    output_model=DemandOutput,
)
def demand_assess(
    keyword: str,
    asin: str = "",
    google_trends: dict | None = None,
    amazon_trend: dict | None = None,
    market_data: dict | None = None,
) -> Result:
    """评估需求；不允许 LLM 凭 keyword 编造趋势数值。"""
    if not google_trends:
        return err(
            Code.ERROR_PARAM,
            "google_trends is required; fetch real trend data in data/entities before scoring",
            data={"required": ["target_avg", "baseline_avg", "cagr_3y", "trend_direction"]},
        )
    if not isinstance(google_trends, dict):
        return err(Code.ERROR_PARAM, "google_trends must be an object")
    required = ("target_avg", "baseline_avg", "cagr_3y", "trend_direction")
    missing = [name for name in required if google_trends.get(name) is None or google_trends.get(name) == ""]
    if missing:
        return err(Code.ERROR_MISSING_FIELDS, "google_trends is incomplete: " + ", ".join(missing), missing=missing)
    try:
        result = score_demand(
            keyword=keyword,
            google_trends=google_trends,
            amazon_trend=amazon_trend,
            market_data=market_data,
        )
        if result.code != Code.OK:
            return result
        if asin:
            result.data["data"]["asin"] = asin
        result.data = DemandOutput.model_validate(result.data).model_dump()
    except (TypeError, ValueError) as exc:
        return err(Code.ERROR_PARAM, f"invalid demand inputs: {exc}")
    return result
