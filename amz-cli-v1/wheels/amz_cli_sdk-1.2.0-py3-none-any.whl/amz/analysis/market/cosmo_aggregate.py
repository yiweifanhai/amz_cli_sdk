"""Historical COSMO synonym aggregation from an explicit product sample."""

from __future__ import annotations

from amz.envelope import Code, Result, err, ok
from amz.infra.llm import chat_json
from amz.registry import capability


from amz.analysis.market.grouping import group_terms
from amz.calc.market.cosmo import merge_cosmo_results
from amz.schemas.analysis_inputs import CosmoAggregateInput
from amz.schemas.cosmo import CosmoAggregateOutput


@capability(
    "analysis.cosmo.aggregate",
    description="跨 ASIN COSMO 同义聚合（分批、跨批合并、漏词补全）",
    input_model=CosmoAggregateInput,
    output_model=CosmoAggregateOutput,
    requires=["analysis.cosmo.extract"],
)
def cosmo_aggregate(
    cosmo_outputs: list[dict],
    min_count: int = 1,
    target_product: str = "",
    model: str = "lite",
) -> Result:
    """analysis.cosmo.aggregate — 跨 ASIN COSMO 同义聚合

    流程：收集所有 term -> 按 COSMO 字段分组 -> LLM 同义聚合 -> 去重。

    Args:
        cosmo_outputs: 多个 ASIN 的 cosmo_extract 输出
        min_count: 最少出现次数阈值
        target_product: 目标产品描述，用于 representative term 选择
    """
    if cosmo_outputs and "cosmo_field" in cosmo_outputs[0]:
        merged_terms = cosmo_outputs
    else:
        merged_result = merge_cosmo_results(cosmo_outputs)
        merged_terms = merged_result.data["terms"]
    merged_terms = [term for term in merged_terms if int(term.get("count", 0)) >= max(1, min_count)]
    try:
        all_groups = group_terms(
            merged_terms, target_product, model=model,
            call_model=chat_json,
        )
        return ok(data=CosmoAggregateOutput(groups=all_groups).model_dump())
    except Exception as exc:
        return err(Code.ERROR_LLM, str(exc))
