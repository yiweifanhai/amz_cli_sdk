"""Market COSMO aggregation from explicit Product results, without Entity I/O."""

from __future__ import annotations

from pydantic import ValidationError

from amz.calc.market.cosmo import merge_cosmo_results
from amz.envelope import Code, Result, err, ok
from amz.infra.llm import chat_json
from amz.registry import capability
from amz.schemas.cosmo import (
    CosmoSource, MarketCosmo, MarketCosmoGroup, MarketCosmoInput, MarketCosmoMember,
)


@capability(
    "analysis.market.cosmo",
    description="Aggregate Product COSMO into market synonym groups and verified sample coverage",
    input_model=MarketCosmoInput,
    output_model=MarketCosmo,
    requires=["analysis.cosmo.extract"],
)
def market_cosmo(
    products: list[dict], failed_product_refs: list[dict] | None = None,
    min_success: int = 1, model: str = "lite",
) -> Result:
    """Compute only from supplied facts; no fetch, Store access, or mutation."""
    if not products:
        return err(Code.ERROR_MISSING_FIELDS, "products requires successful Product COSMO inputs", missing=["products"])
    try:
        inputs = MarketCosmoInput.model_validate({
            "products": products, "failed_product_refs": failed_product_refs or [],
            "min_success": min_success, "model": model,
        })
    except ValidationError as exc:
        return err(Code.ERROR_PARAM, str(exc))
    used = [item.ref for item in inputs.products]
    failed = inputs.failed_product_refs
    if any(ref.entity_type != "product" for ref in [*used, *failed]):
        return err(Code.ERROR_PARAM, "COSMO inputs require Product refs")
    if len(set(used)) != len(used) or len(set(failed)) != len(failed) or set(used) & set(failed):
        return err(Code.ERROR_PARAM, "Product refs must be unique and cannot be both successful and failed")
    if len({ref.key[0] for ref in [*used, *failed]}) != 1:
        return err(Code.ERROR_PARAM, "A Market COSMO sample must use one marketplace")
    if len(used) < inputs.min_success:
        return err(Code.ERROR_UPSTREAM, "Not enough successful Product COSMO inputs", data={
            "success_count": len(used), "min_success": inputs.min_success,
            "failed_product_refs": [ref.model_dump(mode="json") for ref in failed],
        })
    by_asin = {ref.key[1]: ref for ref in used}
    # The Calc implementation is shared with the historical aggregate entry.
    merged = merge_cosmo_results([
        {"asin": item.ref.key[1], "cosmo": item.cosmo.model_dump()}
        for item in inputs.products
    ])
    try:
        from amz.analysis.market.grouping import group_terms

        grouped = group_terms(
            merged.data["terms"], model=inputs.model,
            strict_members=True, call_model=chat_json,
        )
        groups = []
        for group in grouped:
            refs = [by_asin[asin] for asin in group.asins]
            groups.append(MarketCosmoGroup(
                group_id=group.group_id,
                representative_term=group.representative_term,
                representative_term_cn=group.representative_term_cn,
                cosmo_category=group.cosmo_category, cosmo_field=group.cosmo_field,
                members=[MarketCosmoMember(
                    term=member.term,
                    product_refs=[by_asin[asin] for asin in member.asins],
                ) for member in group.members],
                product_refs=refs,
                coverage_count=len(refs), coverage_ratio=len(refs) / len(used),
                mention_count=group.count,
                position_counts={
                    "title": group.title_count, "bullet_points": group.bullet_points_count,
                    "review": group.review_count, "image": group.image_description_count,
                    "description_or_a_plus": group.a_plus_count,
                },
                weighted_score=group.weighted_score,
                needs_review=group.needs_review, warnings=group.warnings,
            ))
        limitations = [
            "Only the supplied Product sample is represented; this is not a full-market estimate.",
            "Coverage uses successful Product inputs as the denominator; failed products are excluded.",
            "Unmentioned terms do not prove the product lacks a feature; unavailable sources remain unknown.",
            "Position and mention counts are distinct from unique-product coverage.",
            "The legacy aPlus location includes listing descriptions; it does not establish that an A+ page was supplied.",
        ]
        if failed:
            limitations.append("Some Product inputs failed; results cover only successful inputs.")
        if not groups:
            limitations.append("The supplied Product COSMO fields contained no terms to group.")
        output = MarketCosmo(
            groups=groups, used_product_refs=used, failed_product_refs=failed,
            success_count=len(used), sample_count=len(used) + len(failed),
            coverage_denominator=len(used),
            sources=[CosmoSource(product_ref=item.ref, updated_at=item.updated_at, source=item.source) for item in inputs.products],
            limitations=limitations,
        )
        return ok(output.model_dump(mode="json"))
    except Exception as exc:
        return err(Code.ERROR_LLM, str(exc))
