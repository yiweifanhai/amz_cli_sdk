"""Market analysis implementations and shared market helpers."""
