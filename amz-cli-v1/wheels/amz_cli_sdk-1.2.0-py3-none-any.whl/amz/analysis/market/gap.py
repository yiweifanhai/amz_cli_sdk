"""market_gap: analyze only the prepared market facts supplied by the caller."""
from __future__ import annotations
from amz.envelope import Result, Code, err
from amz.registry import capability
from amz.infra.llm import chat_json
from amz.analysis.inputs import has_text
from amz.analysis.market._inputs import validate_rows, normalize_references
from amz.analysis.market._output import _JSON_ONLY, _llm_output
from amz.schemas.market_analysis import MarketGapOutput
from amz.schemas.analysis_inputs import MarketGapInput


GAP_PROMPT = """你是一位资深的亚马逊产品战略官，擅长做市场缺口分析（Market Gap Analysis），能从多个竞品的微观数据中提取整个类目共性的痛点、未被解决的结构性缺陷以及潜在商业机会。

下面是某细分市场里多个竞品的核心痛点(top_issues)和未满足需求(unmet_needs)。请横向对比并聚合：把相似的问题归一化，识别出这个价格区间内哪些是普遍存在的红海痛点(problem_points)，哪些是尚未被巨头解决的蓝海机会(opportunity_points)。关注被多个 ASIN 共同提及的条目（asin_cnt 高）。

# 竞品痛点数据
{weaknesses}

# 消费者使用洞察（跨产品聚合）
下面是各竞品的使用场景、用户画像和购买动机。请从中提取：(1) 这个市场最主要的 3-5 个使用场景，(2) 哪些人群需求未被充分满足，(3) 哪些购买动机是该品类主要的决策驱动力。这些洞察应与上面的痛点交叉验证——某个场景下的痛点可能比日常场景下的痛点更需要解决。

{use_insights}

# 输出 JSON（所有 value 用中文，opportunity_score 为 1-10 整数表示机会大小）：
{{
  "market_summary": "1-2段总结这个细分市场的主要遗留问题和消费者未被满足的需求",
  "problem_points": [
    {{"point": "问题核心名称", "description": "在市场上的具体表现", "severity": "High|Medium|Low", "opportunity_score": 1-10, "asin_cnt": 整数, "asin_list": ["ASIN"]}}
  ],
  "opportunity_points": [
    {{"point": "未被满足的需求机会名称", "description": "具体表现", "opportunity_score": 1-10, "asin_cnt": 整数, "asin_list": ["ASIN"]}}
  ],
  "market_use_insights": {{
    "dominant_scenarios": [{{"scenario": "场景描述", "cross_product_frequency": "高|中|低", "insight": "该场景对产品设计/营销的启发"}}],
    "key_personas": [{{"persona": "用户群体名称", "need_gaps": "该人群哪些需求未被充分满足", "insight": "对该人群的差异化切入建议"}}],
    "primary_motivations": [{{"motivation": "购买动机描述", "decision_weight": "高|中|低", "insight": "如何强化该决策因子上的竞争力"}}]
  }}
}}
""" + _JSON_ONLY


@capability(
    "analysis.market.gap-analysis",
    description="市场缺口分析（规范 ID）",
    input_model=MarketGapInput,
    output_model=MarketGapOutput,
    requires=["analysis.voc.weaknesses", "analysis.voc.use-insights"],
)
@capability(
    "analysis.market.gap",
    description="市场缺口分析（兼容旧 ID）",
    input_model=MarketGapInput,
    output_model=MarketGapOutput,
    requires=["analysis.voc.weaknesses", "analysis.voc.use-insights"],
)
def market_gap(
    weaknesses: list[dict],
    use_insights: list[dict] | None = None,
) -> Result:
    """analysis.market.gap — 市场缺口分析

    横向对比多个竞品的 VOC 痛点，结合使用洞察进行交叉验证，
    识别红海痛点（普遍存在）和蓝海机会（尚未被解决）。

    Args:
        weaknesses: [{{asin, weaknesses: {{top_issues, unmet_needs, ...}}}}, ...]
        use_insights: [{{asin, use_insights: {{use_scenarios, user_personas, purchase_motivations}}}}, ...]
    """
    failure = validate_rows(weaknesses, "weaknesses")
    if failure is not None:
        return failure
    for row in weaknesses:
        for name in ("top_issues", "unmet_needs"):
            values = row["weaknesses"].get(name)
            if not isinstance(values, list) or any(not isinstance(value, dict) for value in values):
                return err(Code.ERROR_MISSING_FIELDS, f"weaknesses requires {name} as a list of objects", missing=[name])
    evidence_rows = []
    for row in weaknesses:
        prepared = {
            field: [item for item in row["weaknesses"][field]
                    if has_text(item.get(name)) and has_text(item.get("evidence"))]
            for field, name in (("top_issues", "pain_point"), ("unmet_needs", "unmet_need"))
        }
        if any(prepared.values()):
            evidence_rows.append({**row, "weaknesses": {**row["weaknesses"], **prepared}})
    if len(evidence_rows) < 3:
        return err(Code.ERROR_MISSING_FIELDS, "market gap requires at least 3 distinct products with a supported pain point or unmet need", missing=["weaknesses (3 products with evidence)"])
    weaknesses = evidence_rows
    if use_insights:
        failure = validate_rows(use_insights, "use_insights")
        if failure is not None:
            return failure
        for row in use_insights:
            for name in ("use_scenarios", "user_personas", "purchase_motivations"):
                values = row["use_insights"].get(name, [])
                if not isinstance(values, list) or any(not isinstance(value, dict) for value in values):
                    return err(Code.ERROR_PARAM, f"use_insights {name} must be a list of objects")
    # 格式化痛点
    wk_lines = []
    for item in weaknesses:
        asin = item.get("asin", "unknown")
        wk = item.get("weaknesses", {})
        issues = wk.get("top_issues", [])
        unmet = wk.get("unmet_needs", [])
        issue_lines = "\n".join(
            f"  - [{i.get('severity', '?')}] {i.get('pain_point', '')} "
            f"(cnt: {i.get('cnt', '?')}, ratio: {i.get('ratio', '?')}) — {str(i.get('evidence') or '')[:100]}"
            for i in issues[:10]
        )
        unmet_lines = "\n".join(
            f"  - [{u.get('impact', '?')}] {u.get('unmet_need', '')} "
            f"(cnt: {u.get('cnt', '?')}) — {str(u.get('evidence') or '')[:100]}"
            for u in unmet[:10]
        )
        wk_lines.append(f"## {asin}\n### 痛点\n{issue_lines}\n### 未满足需求\n{unmet_lines}\n")

    # 格式化使用洞察
    ui_lines = []
    for item in (use_insights or []):
        asin = item.get("asin", "unknown")
        ui = item.get("use_insights", {})
        scenarios = ui.get("use_scenarios", [])
        personas = ui.get("user_personas", [])
        motivations = ui.get("purchase_motivations", [])
        sc_lines = "\n".join(
            f"  - [{s.get('frequency', '?')}] {s.get('scenario', '')} (mentioned_by: {s.get('mentioned_by', '?')})"
            for s in scenarios[:5]
        )
        ps_lines = "\n".join(
            f"  - {p.get('persona', '')} — traits: {p.get('traits', '')} (mentioned_by: {p.get('mentioned_by', '?')})"
            for p in personas[:5]
        )
        mt_lines = "\n".join(
            f"  - {m.get('motivation', '')} [{m.get('decision_factor_type', '')}] (mentioned_by: {m.get('mentioned_by', '?')})"
            for m in motivations[:5]
        )
        ui_lines.append(f"## {asin}\n### 使用场景\n{sc_lines}\n### 用户画像\n{ps_lines}\n### 购买动机\n{mt_lines}\n")

    prompt = GAP_PROMPT.format(
        weaknesses="\n".join(wk_lines) if wk_lines else "无竞品痛点数据",
        use_insights="\n".join(ui_lines) if ui_lines else "无使用洞察数据",
    )

    result = _llm_output(
        prompt, MarketGapOutput,
        call_model=chat_json,
    )
    if result.code == Code.OK:
        try:
            asins = [row["asin"] for row in [*weaknesses, *(use_insights or [])]]
            for field in ("problem_points", "opportunity_points"):
                normalize_references(result.data[field], "asin_list", asins)
        except ValueError as exc:
            return err(Code.ERROR_LLM, str(exc))
    return result
