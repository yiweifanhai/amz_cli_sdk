"""market_proposals: analyze only the prepared market facts supplied by the caller."""
from __future__ import annotations
from amz.envelope import Result, Code, err
from amz.registry import capability
from amz.infra.llm import chat_json
from amz.analysis.market._inputs import normalize_references
from amz.analysis.market._output import _JSON_ONLY, _llm_output
from amz.schemas.market_analysis import ProposalsOutput
from amz.schemas.analysis_inputs import MarketProposalsInput


PROPOSALS_PROMPT = """你是一位经验丰富的产品经理，擅长在现有产品基础上做低成本、可落地的"微改造"（不是从零开发新品），用最小的改动撬动最大的差异化。

下面是某细分市场的成功因子、遗留问题、改进机会和消费者使用洞察。请提出一组具体的产品微改造提案：每条要绑定到一个明确的痛点或机会，给出具体可执行的改造动作（材质/结构/配件/包装/说明书等层面的具体改动，而不是空泛方向），预估收益和实现难度。

# 市场成功因子
{success_factors}

# 遗留问题
{problems}

# 改进机会
{opportunities}

# 消费者使用洞察
{use_insights_summary}

在生成微改造提案时，优先考虑以下方向：
1. 解决高频使用场景中的已知痛点（场景驱动创新）
2. 为未被充分服务的关键用户群做适配（人群驱动创新）
3. 强化主要购买决策因子上的竞争力（动机驱动创新）

# 事实与引用规则
- 中文描述，但 ASIN 必须逐字保留输入标识，不翻译、不填占位符。
- related_asins 只选该痛点/机会或成功因子中实际列出的 ASIN；未提供时返回 []。
- 输入未给出的现有材质、尺寸、螺纹、模具和测试结果均未知，不得补造。
- 改造参数可作为待打样验证的建议，不能写成已经存在的规格或已证明有效。
- expected_benefit 写预期方向及验证方法；没有实验数据时不写改善百分比、保证效果或销量/好评提升数字。
- 不建议宣称未经执行的检测、认证或保证，也不推断无需开模/无需验证。
- 只围绕输入问题提出方案，不补造使用工况（例如普通漏水不能假设是装热水导致）。
- 每条 change_description 先写「待核实前提：」列出实施所需但输入未确认的结构或材质，再写「建议动作：」。前提不成立时该方案不适用。
- 不把内侧凹槽、现有垫圈、瓶口毛刺、光面盖等当成已知事实；模具、认证和兼容性均需评估。

# 输出 JSON（描述用中文，difficulty 取 低|中|高）：
{{
  "micro_renovation_proposals": [
    {{"title": "简短动作短语", "target_pain_point": "针对的痛点/机会名称（对应上面的 point）", "change_description": "具体可执行的改造动作", "expected_benefit": "预期方向与验证方法", "difficulty": "低|中|高", "related_asins": []}}
  ]
}}
按 (机会大 + 难度低) 优先排序，给出 5-10 条。
""" + _JSON_ONLY


@capability(
    "analysis.market.renovation-proposal",
    description="微改造提案（规范 ID）",
    input_model=MarketProposalsInput,
    output_model=ProposalsOutput,
    requires=["analysis.market.success-factors", "analysis.market.gap-analysis"],
)
@capability(
    "analysis.market.proposals",
    description="微改造提案（兼容旧 ID）",
    input_model=MarketProposalsInput,
    output_model=ProposalsOutput,
    requires=["analysis.market.success-factors", "analysis.market.gap-analysis"],
)
def market_proposals(
    success_factors: list[dict] | None = None,
    problem_points: list[dict] | None = None,
    opportunity_points: list[dict] | None = None,
    use_insights: dict | None = None,
) -> Result:
    """analysis.market.proposals — 微改造提案

    综合市场成功因子、遗留问题和改进机会，生成 5-10 条具体的微改造方案。

    Args:
        success_factors: [{{factor_name, description, example_asins, why_it_works}}, ...]
        problem_points: [{{point, description, severity, opportunity_score, asin_cnt, asin_list}}, ...]
        opportunity_points: [{{point, description, opportunity_score, asin_cnt, asin_list}}, ...]
        use_insights: {{dominant_scenarios, key_personas, primary_motivations}}
    """
    for name, values in (("success_factors", success_factors), ("problem_points", problem_points), ("opportunity_points", opportunity_points)):
        if values is not None and (not isinstance(values, list) or any(not isinstance(value, dict) for value in values)):
            return err(Code.ERROR_PARAM, f"{name} must be a list of objects")
    if not any(str(item.get("point") or "").strip() for item in [*(problem_points or []), *(opportunity_points or [])]):
        return err(Code.ERROR_MISSING_FIELDS, "proposals require a supplied problem or opportunity", missing=["problem_points or opportunity_points"])
    if use_insights is not None and not isinstance(use_insights, dict):
        return err(Code.ERROR_PARAM, "use_insights must be an object")
    for row in success_factors or []:
        if not isinstance(row.get("example_asins", []), list) or any(not isinstance(value, str) for value in row.get("example_asins", [])):
            return err(Code.ERROR_PARAM, "success factor example_asins must be a list of strings")
    for row in [*(problem_points or []), *(opportunity_points or [])]:
        if not isinstance(row.get("asin_list", []), list) or any(not isinstance(value, str) for value in row.get("asin_list", [])):
            return err(Code.ERROR_PARAM, "point asin_list must be a list of strings")
    for name in ("dominant_scenarios", "key_personas", "primary_motivations"):
        values = (use_insights or {}).get(name, [])
        if not isinstance(values, list) or any(not isinstance(value, dict) for value in values):
            return err(Code.ERROR_PARAM, f"use_insights {name} must be a list of objects")
    # 格式化成功因子
    sf_text = "无"
    if success_factors:
        sf_lines = []
        for f in success_factors[:10]:
            sf_lines.append(
                f"- {f.get('factor_name', '')}: {f.get('description', '')} "
                f"(example: {', '.join(f.get('example_asins', []))})"
            )
        sf_text = "\n".join(sf_lines)

    # 格式化遗留问题
    prob_text = "无"
    if problem_points:
        prob_lines = []
        for p in problem_points[:10]:
            prob_lines.append(
                f"- [{p.get('severity', '?')}] {p.get('point', '')}: {p.get('description', '')} "
                f"(机会分: {p.get('opportunity_score', '?')}, 涉及 {p.get('asin_cnt', '?')} 个 ASIN；"
                f"asin_list: {', '.join(p.get('asin_list', [])) or '[]'})"
            )
        prob_text = "\n".join(prob_lines)

    # 格式化改进机会
    opp_text = "无"
    if opportunity_points:
        opp_lines = []
        for o in opportunity_points[:10]:
            opp_lines.append(
                f"- {o.get('point', '')}: {o.get('description', '')} "
                f"(机会分: {o.get('opportunity_score', '?')}, 涉及 {o.get('asin_cnt', '?')} 个 ASIN；"
                f"asin_list: {', '.join(o.get('asin_list', [])) or '[]'})"
            )
        opp_text = "\n".join(opp_lines)

    # 格式化使用洞察摘要
    ui_text = "无"
    if use_insights:
        parts = []
        for s in use_insights.get("dominant_scenarios", [])[:3]:
            parts.append(f"场景: {s.get('scenario', '')} ({s.get('cross_product_frequency', '?')}) → {s.get('insight', '')}")
        for p in use_insights.get("key_personas", [])[:3]:
            parts.append(f"人群: {p.get('persona', '')} (缺口: {p.get('need_gaps', '')}) → {p.get('insight', '')}")
        for m in use_insights.get("primary_motivations", [])[:3]:
            parts.append(f"动机: {m.get('motivation', '')} (权重: {m.get('decision_weight', '?')}) → {m.get('insight', '')}")
        ui_text = "\n".join(parts)

    prompt = PROPOSALS_PROMPT.format(
        success_factors=sf_text,
        problems=prob_text,
        opportunities=opp_text,
        use_insights_summary=ui_text,
    )

    result = _llm_output(
        prompt, ProposalsOutput, temperature=0.4,
        call_model=chat_json,
    )
    if result.code == Code.OK:
        asins = [asin for row in success_factors or [] for asin in row.get("example_asins", [])]
        asins.extend(asin for row in [*(problem_points or []), *(opportunity_points or [])] for asin in row.get("asin_list", []))
        try:
            normalize_references(result.data["micro_renovation_proposals"], "related_asins", asins)
        except ValueError as exc:
            return err(Code.ERROR_LLM, str(exc))
    return result
