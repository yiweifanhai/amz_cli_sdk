"""discover_asin_dimensions: analyze only explicit product facts and decision dimensions."""
from __future__ import annotations
import json
from amz.envelope import Code, Result, err, ok
from amz.infra.llm import chat_json
from amz.analysis.base import parse_structured, require_json
from amz.registry import capability
from amz.schemas.analysis_inputs import TrafficAnalysisInput
from amz.schemas.traffic import DimensionsOutput
from amz.analysis.market.traffic_inputs import _product_lines, _format_price_bands, _format_keyword_clusters, validate_market_inputs


@capability(
    "analysis.asin.discover-dimensions",
    description="发现与主定价维度正交的 2-4 个购买决策维度",
    input_model=TrafficAnalysisInput,
    output_model=DimensionsOutput,
    requires=["analysis.asin.primary-pricing-dimension"],
)
def discover_asin_dimensions(
    main_keyword: str,
    primary_dimension: dict,
    price_bands: list[dict],
    refinement_dimensions: dict,
    keyword_clusters: list[dict] | dict,
    products: list[dict],
) -> Result:
    failure = validate_market_inputs(main_keyword, price_bands, refinement_dimensions, keyword_clusters, products)
    if failure is not None:
        return failure
    if not isinstance(primary_dimension, dict) or not str(primary_dimension.get("name") or "").strip() or not isinstance(primary_dimension.get("values"), list) or not primary_dimension["values"] or any(not isinstance(value, str) or not value.strip() for value in primary_dimension["values"]):
        return err(Code.ERROR_MISSING_FIELDS, "primary_dimension requires a name and values", missing=["primary_dimension"])
    prompt = f"""You are analyzing the "{main_keyword}" Amazon market.

=== Input 1: Supplied sample price bands ===
{_format_price_bands(price_bands)}

=== Input 2: Supplied Amazon refinement dimensions (optional) ===
{json.dumps(refinement_dimensions, ensure_ascii=False) if refinement_dimensions else "none"}

A missing refinement dimension means no filter evidence was supplied; do not invent storefront filters.

=== Input 3: Keyword clusters (user search intent groups) ===
{_format_keyword_clusters(keyword_clusters)}

=== Input 4: Sample products ===
{_product_lines(products)}

=== Already-decided primary pricing dimension ===
{json.dumps(primary_dimension, ensure_ascii=False)}

=== Note ===
Three other dimensions (price_band, rating_band, brand_origin) will be added
automatically downstream. You do NOT need to propose them.

=== Task ===
Identify 2-4 ADDITIONAL discriminative dimensions, ORTHOGONAL to the primary pricing
dimension and to the auto-injected ones. They should:
1. Be highly relevant to purchase decisions
2. Have enumerable, finite distinct values
3. Be visible from product listings / refinement / search behavior
4. Capture variation NOT already captured by the primary or price_band / rating_band / brand_origin
5. Reflect real signals — if keyword clusters show a clear split (e.g. "for women" vs
   "for men", or "leather" vs "quilted"), extract that as a dimension. DO NOT just
   copy keyword cluster names as values; extract the underlying attribute.

Output JSON (no markdown):
{{
  "dimensions": [
    {{"name": "Dimension Name", "values": ["v1", "v2", "v3"]}}
  ]
}}"""
    try:
        response = chat_json(
            prompt=prompt, json_schema=DimensionsOutput.model_json_schema(),
            model="pro", temperature=0.2,
        )
        raw = require_json(response)
        if not isinstance(raw, dict) or "dimensions" not in raw:
            return err(Code.ERROR_LLM, "model output is missing dimensions")
        output = parse_structured(response, DimensionsOutput)
        if not output.dimensions or any(not item.name.strip() or not item.values for item in output.dimensions):
            return err(Code.ERROR_LLM, "discovered dimensions require names and values")
        if len({item.name.strip().casefold() for item in output.dimensions}) != len(output.dimensions):
            return err(Code.ERROR_LLM, "model returned duplicate dimension names")
        output.dimensions = output.dimensions[:4]
        for dimension in output.dimensions:
            dimension.role = "discriminative"
        return ok(data=output.model_dump())
    except Exception as exc:
        return err(Code.ERROR_LLM, str(exc))
