"""discover_primary_pricing_dimension: analyze only explicit product facts and decision dimensions."""
from __future__ import annotations
import json
from amz.envelope import Code, Result, err, ok
from amz.infra.llm import chat_json
from amz.analysis.base import parse_structured
from amz.registry import capability
from amz.schemas.analysis_inputs import PriceDimensionInput
from amz.schemas.traffic import PrimaryDimensionOutput
from amz.analysis.market.traffic_inputs import _product_lines, _format_price_bands, _format_keyword_clusters, validate_market_inputs


@capability(
    "analysis.asin.primary-pricing-dimension",
    description="选择解释市场价格分层的单一主规格维度",
    input_model=PriceDimensionInput,
    output_model=PrimaryDimensionOutput,
    requires=["analysis.cluster.keywords"],
)
def discover_primary_pricing_dimension(
    main_keyword: str,
    price_bands: list[dict],
    refinement_dimensions: dict,
    keyword_clusters: list[dict] | dict,
    products: list[dict],
) -> Result:
    failure = validate_market_inputs(main_keyword, price_bands, refinement_dimensions, keyword_clusters, products)
    if failure is not None:
        return failure
    import math
    try:
        prices = [float(item.get("price", item.get("price_usd"))) for item in products if item.get("price", item.get("price_usd")) is not None]
    except (TypeError, ValueError):
        return err(Code.ERROR_PARAM, "sample product prices must be numbers")
    if not prices or not all(math.isfinite(value) and value >= 0 for value in prices):
        return err(Code.ERROR_MISSING_FIELDS, "at least one finite sample product price is required", missing=["products.price or price_usd"])
    prompt = f"""You are analyzing the "{main_keyword}" Amazon market.

=== Input 1: Supplied sample price bands ===
{_format_price_bands(price_bands)}

=== Input 2: Supplied Amazon refinement dimensions (optional) ===
{json.dumps(refinement_dimensions, ensure_ascii=False) if refinement_dimensions else "none"}

A missing refinement dimension means no filter evidence was supplied; do not invent storefront filters.

=== Input 3: Keyword clusters (user search intent groups) ===
{_format_keyword_clusters(keyword_clusters)}

=== Input 4: Sample products (ASIN | price | title | top reverse keywords) ===
{_product_lines(products)}

=== Pricing Theory ===
In most product categories, ONE primary spec drives the price tiers. Consumers anchor
on a single number/attribute when comparing prices. Examples:
  - MP3 player → storage capacity (GB)
  - Mattress → thickness (inch) or size
  - Power bank → battery capacity (mAh)
  - Bedding → thread count or size
  - Watch → movement type (quartz vs automatic)
  - Camera → sensor size or megapixels
This is the dimension whose different values map to clearly different price tiers.

=== Task ===
Identify the ONE primary pricing dimension for this market.
- It must be a SINGLE concrete attribute (NOT a vague concept like "quality" or "intent").
- Its values must be enumerable and clearly distinguishable.
- It should explain price variation across the sample products above.
- If Amazon's refinement has a dimension that obviously plays this role, use it.

Output JSON (no markdown):
{{
  "primary_pricing_dimension": {{
    "name": "Dimension Name",
    "values": ["val_low", "val_mid", "val_high"],
    "rationale": "1-2 sentences on why this is the primary price driver in this market"
  }}
}}"""
    try:
        response = chat_json(
            prompt=prompt, json_schema=PrimaryDimensionOutput.model_json_schema(),
            model="pro", temperature=0.2,
        )
        output = parse_structured(response, PrimaryDimensionOutput)
        if not output.primary_pricing_dimension.name.strip() or not output.primary_pricing_dimension.values:
            return err(Code.ERROR_LLM, "primary pricing dimension requires a name and values")
        output.primary_pricing_dimension.role = "primary_pricing"
        return ok(data=output.model_dump())
    except Exception as exc:
        return err(Code.ERROR_LLM, str(exc))
