"""Internal implementations of Entity analysis capabilities.

Entity prepares dependencies, checks required evidence and manages results.
Analysis receives explicit inputs, validates them and runs model analysis;
it does not fetch business data or manage Entity state. Skill and Composite
call Entity business methods rather than invoking Analysis directly.

Implementations are grouped in product/, market/, keyword/ and taobao_market/.
Old Python facade modules have been removed; capability IDs remain internal.
Shared helpers such as base.py and inputs.py remain part of the current code.
"""
