"""Input evidence checks shared by Entity projections and Analysis implementations.

Schema defaults and non-empty containers do not prove that usable facts exist.
These checks run before the model through the canonical Analysis functions.
"""
from __future__ import annotations

from amz.envelope import Code, Result, err


def has_text(value: object) -> bool:
    """Accept actual text, not identifiers, numbers, or empty nested containers."""
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, (list, tuple)):
        return any(has_text(item) for item in value)
    return False


def has_product_facts(product: object) -> bool:
    if not isinstance(product, dict):
        return False
    return any(has_text(product.get(name)) for name in (
        "title", "product_name", "description", "productDescription",
        "full_description", "bullet_points", "features", "raw_text",
    ))


def validate_listing_facts(title: object, bullet_points: object) -> Result | None:
    if not isinstance(title, str) or not isinstance(bullet_points, list) or any(
        not isinstance(value, str) for value in bullet_points
    ):
        return err(Code.ERROR_PARAM, "title must be text and bullet_points must be a list of text")
    if not has_text(title) and not has_text(bullet_points):
        return err(
            Code.ERROR_MISSING_FIELDS,
            "listing requires a non-empty title or bullet point; keywords are not product facts",
            missing=["title or bullet_points"],
        )
    return None
