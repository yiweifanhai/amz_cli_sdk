"""
FastAPI 接入层：REST 远程服务 + 可视化平台（SSE + 零依赖静态 viewer）。

远程服务端点（消费者不装 SDK 直连，X-API-Token 鉴权）：:

    GET    /health                     健康检查
    GET    /capabilities               能力目录（含 I/O schema）
    GET    /capabilities/{id}          单个能力 schema
    POST   /capabilities/{id}          调用能力（body = 参数 dict 或 {"params": {...}}）
    POST   /composite/{name}/run       固定 SOP 同步执行（body = params dict）

可视化平台端点（静态 viewer 消费）：:

    GET    /api/pipelines              pipeline 列表 + spec
    GET    /api/pipelines/{name}       DAG 图（节点 + 边 + 端口 schema）
    POST   /api/pipelines/{name}/spec  保存/编辑后的 spec（写盘 + 注册）
    GET    /api/capabilities           积木目录
    POST   /api/capability-tests/{id}  单个能力测试（持久化 input + output）
    GET    /api/capability-tests       原子能力测试记录
    GET    /api/entities               Entity 缓存总览
    GET    /api/entities/{type}/{key}  Entity 原始字段 + lazy TTL 状态
    GET    /api/entity-chains          Entity 级联测试场景
    POST   /api/entity-chains/{id}/run 运行 Entity 级联并返回逐步 Result
    POST   /api/runs                   启动 run（后台线程），返回 run_id
    GET    /api/runs                   run 清单
    GET    /api/runs/{run_id}          run manifest（step 状态 + calls + files）
    GET    /api/runs/{run_id}/steps/{step}  某步 artifact（inputs+output+meta + renderer）
    GET    /api/runs/{run_id}/events   SSE 实时进度（token 可走 ?token= 查询参数）

鉴权：请求头 ``X-API-Token``（SSE 另支持 ``?token=``）与 ``data_api.token`` 一致；
``--no-auth`` 关闭（仅限内网/本地开发）。
"""

from __future__ import annotations

import asyncio
import json
import threading
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter
from typing import Any

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

from amz import __version__, config, registry
from amz.composite import get_pipeline
from amz.composite.base import Artifact, PipelineRunner, _make_run_id
from amz.composite.loader import get_pipeline_spec
from amz.composite.schema_registry import infer_renderer
from amz.discovery import load_builtin_capabilities
from amz.envelope import Code
from amz.infra.runtime import Runtime, runtime_context
from amz.serve.entity_inspector import entity_catalog, entity_detail
from amz.serve.entity_chains import entity_chain_catalog, run_entity_chain

_STATIC_DIR = Path(__file__).parent / "static"
_CAPABILITY_TEST_PREFIX = "capability-test:"
_ENTITY_CHAIN_PREFIX = "entity-chain:"


class _NoCacheStaticFiles(StaticFiles):
    """静态 viewer 走 no-store：前端改动即时生效，避免浏览器缓存旧 JS。"""

    def file_response(self, *args, **kwargs):
        resp = super().file_response(*args, **kwargs)
        resp.headers["Cache-Control"] = "no-store"
        return resp


# ---------------------------------------------------------------------------
# 鉴权
# ---------------------------------------------------------------------------

def _auth_dependency(auth_token: str):
    """请求头 X-API-Token == auth_token（空 token 不校验）。"""

    async def check(request: Request) -> None:
        if not auth_token:
            return
        if request.headers.get("X-API-Token", "") != auth_token:
            raise HTTPException(status_code=401, detail="invalid or missing X-API-Token")

    return check


def _verify_token(request: Request, query_token: str, auth_token: str) -> None:
    """SSE 用：header 或 ?token= 查询参数之一匹配即可。"""
    if not auth_token:
        return
    if request.headers.get("X-API-Token", "") == auth_token:
        return
    if query_token == auth_token:
        return
    raise HTTPException(status_code=401, detail="invalid or missing X-API-Token")


# ---------------------------------------------------------------------------
# RunBroker — 后台运行 + 事件缓冲（供 SSE）
# ---------------------------------------------------------------------------

class RunHandle:
    def __init__(self, run_id: str):
        self.run_id = run_id
        self.events: list[dict] = []
        self.done = False
        self.success = False
        self.error = ""
        self._lock = threading.Lock()
        self._cond = threading.Condition(self._lock)

    def push(self, ev: dict) -> None:
        with self._cond:
            self.events.append(ev)
            self._cond.notify_all()

    def finish(self, success: bool, error: str = "") -> None:
        with self._cond:
            self.done = True
            self.success = success
            self.error = error
            self._cond.notify_all()


class RunBroker:
    def __init__(self):
        self._runs: dict[str, RunHandle] = {}
        self._lock = threading.Lock()

    def start(self, pipeline_name: str, params: dict, force: bool = False) -> str:
        spec = get_pipeline_spec(pipeline_name)
        run_id = _make_run_id(spec.name, spec.version, params)
        with self._lock:
            handle = self._runs.get(run_id)
            if handle is not None and not handle.done:
                return run_id
            handle = RunHandle(run_id)
            self._runs[run_id] = handle

        def _run() -> None:
            try:
                pipeline = get_pipeline(pipeline_name)
                result = PipelineRunner(pipeline).run(
                    params, force=force,
                    on_event=lambda ev: handle.push(ev.model_dump()),
                )
                handle.finish(result.success, "; ".join(result.errors.values()))
            except Exception as e:  # pragma: no cover - 兜底
                handle.finish(False, f"{type(e).__name__}: {e}")

        threading.Thread(target=_run, daemon=True).start()
        return run_id

    def get(self, run_id: str) -> RunHandle | None:
        return self._runs.get(run_id)


broker = RunBroker()


# ---------------------------------------------------------------------------
# 工具
# ---------------------------------------------------------------------------

def _sse(ev: dict) -> str:
    return f"data: {json.dumps(ev, ensure_ascii=False, default=str)}\n\n"


def _spec_or_404(name: str):
    try:
        return get_pipeline_spec(name)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


def _dag(spec) -> dict:
    nodes = [s.model_dump() for s in spec.steps]
    edges = []
    for s in spec.steps:
        for dep in s.depends:
            edges.append({"from": dep, "to": s.name})
    return {
        "name": spec.name,
        "description": spec.description,
        "category": spec.category,
        "version": spec.version,
        "params_schema": spec.params_schema,
        "nodes": nodes,
        "edges": edges,
    }


async def _live_events(handle: RunHandle):
    idx = 0
    while True:
        with handle._cond:
            while idx < len(handle.events):
                yield _sse(handle.events[idx])
                idx += 1
            done = handle.done
        if done and idx >= len(handle.events):
            break
        await asyncio.sleep(0.1)


async def _static_events(run_id: str):
    manifest = Runtime.status(run_id)
    if manifest is None:
        yield _sse({"type": "run.done", "run_id": run_id, "status": "unknown", "error": "run not found"})
        return
    for step, meta in (manifest.get("steps") or {}).items():
        yield _sse({"type": "step.done", "run_id": run_id, "step": step, "status": meta.get("status", "ok")})
    yield _sse({
        "type": "run.done", "run_id": run_id,
        "status": manifest.get("status", "finished"),
        "error": manifest.get("error", ""),
    })


def _capability_layer(item: dict[str, Any]) -> str:
    """Map historical capability categories to the SDK architecture layer."""
    category = str(item.get("category") or "")
    if category in {"entity", "calc", "analysis", "composite"}:
        return category
    # data capabilities intentionally use domain ids such as product.get and
    # keyword.reverse instead of a data.* prefix.
    return "data"


def _viewer_capabilities() -> list[dict[str, Any]]:
    rows = []
    for raw in registry.capabilities_json():
        item = dict(raw)
        item["layer"] = _capability_layer(item)
        item["atomic"] = item["layer"] != "composite"
        rows.append(item)
    return rows


def _result_file(rel_path: str) -> dict[str, Any] | None:
    """Load a Runtime result while refusing paths outside the configured cache."""
    if not rel_path:
        return None
    base = config.cache_dir.resolve()
    path = (base / rel_path).resolve()
    try:
        path.relative_to(base)
    except ValueError:
        return None
    if not path.is_file() or path.is_symlink():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError, TypeError, ValueError):
        return None
    return payload if isinstance(payload, dict) else None


def _capability_test_record(manifest: dict[str, Any], *, include_output: bool) -> dict[str, Any]:
    calls = manifest.get("calls") or []
    call = calls[-1] if calls else {}
    name = str(manifest.get("name") or "")
    capability = name.removeprefix(_CAPABILITY_TEST_PREFIX)
    code = str(call.get("code") or "")
    record: dict[str, Any] = {
        "test_id": str(manifest.get("run_id") or ""),
        "capability": capability,
        "status": "passed" if code == Code.OK.value else "failed",
        "code": code,
        "elapsed_ms": float(call.get("elapsed_ms") or 0),
        "created_at": str(manifest.get("created_at") or ""),
        "finished_at": str(manifest.get("finished_at") or ""),
        "input": manifest.get("params") or {},
    }
    if include_output:
        record["output"] = _result_file(str(call.get("result_file") or ""))
    return record


def _capability_test_manifest(test_id: str) -> dict[str, Any] | None:
    try:
        manifest = Runtime.status(test_id)
    except OSError:
        return None
    if manifest is None:
        return None
    if not str(manifest.get("name") or "").startswith(_CAPABILITY_TEST_PREFIX):
        return None
    return manifest


# ---------------------------------------------------------------------------
# 应用
# ---------------------------------------------------------------------------

def create_app(auth_token: str = "") -> FastAPI:
    load_builtin_capabilities()

    app = FastAPI(
        title="amz-cli-sdk",
        version=__version__,
        description="Amazon 数据 SDK 远程服务 + composite 可视化平台",
    )
    auth = _auth_dependency(auth_token)

    # ------------------------------------------------------------------
    # 远程服务：健康检查 / 能力目录 / 调用 / 固定 SOP
    # ------------------------------------------------------------------

    @app.get("/health", dependencies=[Depends(auth)])
    def health():
        return {"status": "ok", "version": __version__, "capabilities": len(registry.capabilities_json())}

    @app.get("/capabilities", dependencies=[Depends(auth)])
    def list_capabilities():
        return registry.capabilities_json()

    @app.get("/capabilities/{cap_id}", dependencies=[Depends(auth)])
    def get_capability(cap_id: str):
        cap = registry.get(cap_id)
        if cap is None:
            raise HTTPException(status_code=404, detail=f"unknown capability: {cap_id}")
        return {
            "id": cap.id, "category": cap.category, "description": cap.description,
            "requires": cap.requires, "requires_fields": cap.requires_fields,
            "internal": cap.internal, "entity_entrypoint": cap.entity_entrypoint,
            "input_schema": cap.input_schema, "output_schema": cap.output_schema,
        }

    @app.post("/capabilities/{cap_id}", dependencies=[Depends(auth)])
    def invoke_capability(cap_id: str, params: dict | None = None):
        if params is None:
            params = {}
        if isinstance(params, dict) and "params" in params and len(params) == 1:
            params = params["params"]
        result = registry.invoke(cap_id, params)
        return JSONResponse(content=result.model_dump(mode="json"))

    @app.post("/composite/{name}/run", dependencies=[Depends(auth)])
    def run_composite(name: str, params: dict | None = None):
        try:
            pipeline = get_pipeline(name)
        except ValueError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        run_result = PipelineRunner(pipeline).run(params or {})
        return JSONResponse(content={
            "run_id": run_result.run_id,
            "pipeline": run_result.pipeline_name,
            "success": run_result.success,
            "elapsed_ms": run_result.elapsed_ms,
            "errors": run_result.errors,
            "artifacts": {step: a.to_dict() for step, a in run_result.artifacts.items()},
        })

    # ------------------------------------------------------------------
    # 可视化平台
    # ------------------------------------------------------------------

    @app.get("/api/pipelines", dependencies=[Depends(auth)])
    def api_pipelines():
        from amz.composite import list_pipelines

        return list_pipelines()

    @app.get("/api/pipelines/{name}", dependencies=[Depends(auth)])
    def api_pipeline(name: str):
        return _dag(_spec_or_404(name))

    @app.post("/api/pipelines/{name}/spec", dependencies=[Depends(auth)])
    def api_save_spec(name: str, payload: dict):
        spec = dict(payload or {})
        spec.setdefault("name", name)
        r = registry.invoke("composite.compile", {"spec": spec})
        if r.code.value != "OK":
            raise HTTPException(status_code=400, detail=r.model_dump())
        return r.data

    @app.get("/api/capabilities", dependencies=[Depends(auth)])
    def api_capabilities():
        return _viewer_capabilities()

    @app.post("/api/capability-tests/{cap_id}", dependencies=[Depends(auth)])
    def api_run_capability_test(cap_id: str, payload: dict | None = None):
        """Run one capability and persist the exact test input/output via Runtime."""
        if registry.get(cap_id) is None:
            raise HTTPException(status_code=404, detail=f"unknown capability: {cap_id}")
        params = dict(payload or {})
        if "params" in params and len(params) == 1 and isinstance(params["params"], dict):
            params = dict(params["params"])

        started = perf_counter()
        runtime: Runtime | None = None
        try:
            try:
                runtime = Runtime.begin(name=f"{_CAPABILITY_TEST_PREFIX}{cap_id}", params=params)
            except OSError:
                # Read-only deployments can still use the tester; only history is unavailable.
                runtime = None
            if runtime is not None:
                with runtime_context(runtime):
                    result = registry.invoke(cap_id, params)
            else:
                result = registry.invoke(cap_id, params)
            if runtime is not None:
                runtime.finish(result.code == Code.OK, result.message if result.code != Code.OK else "")
        except Exception as exc:  # pragma: no cover - Runtime/serialization safety net
            if runtime is not None:
                try:
                    runtime.finish(False, f"{type(exc).__name__}: {exc}")
                except OSError:
                    pass
            raise HTTPException(status_code=500, detail=f"capability test failed: {exc}") from exc

        if runtime is not None:
            record = _capability_test_record(runtime.manifest(), include_output=False)
        else:
            record = {
                "test_id": "",
                "capability": cap_id,
                "status": "passed" if result.code == Code.OK else "failed",
                "code": result.code.value,
                "elapsed_ms": result.meta.elapsed_ms,
                "created_at": datetime.now(timezone.utc).isoformat(),
                "finished_at": datetime.now(timezone.utc).isoformat(),
                "input": params,
            }
        record["output"] = result.model_dump(mode="json")
        record["wall_elapsed_ms"] = round((perf_counter() - started) * 1000, 1)
        record["persisted"] = runtime is not None
        return record

    @app.get("/api/capability-tests", dependencies=[Depends(auth)])
    def api_capability_tests(limit: int = 50):
        limit = min(200, max(1, limit))
        rows: list[dict[str, Any]] = []
        try:
            runs = Runtime.list_runs()
        except OSError:
            return rows
        for run in runs:
            if not str(run.get("name") or "").startswith(_CAPABILITY_TEST_PREFIX):
                continue
            manifest = Runtime.status(str(run.get("run_id") or ""))
            if manifest is not None:
                rows.append(_capability_test_record(manifest, include_output=False))
            if len(rows) >= limit:
                break
        return rows

    @app.get("/api/capability-tests/{test_id}", dependencies=[Depends(auth)])
    def api_capability_test(test_id: str):
        manifest = _capability_test_manifest(test_id)
        if manifest is None:
            raise HTTPException(status_code=404, detail=f"unknown capability test: {test_id}")
        return _capability_test_record(manifest, include_output=True)

    @app.get("/api/entities", dependencies=[Depends(auth)])
    def api_entities(entity_type: str = "", q: str = "", limit: int = 200, offset: int = 0):
        try:
            return entity_catalog(
                entity_type=entity_type,
                query=q,
                limit=limit,
                offset=offset,
            )
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

    @app.get("/api/entities/{entity_type}/{cache_key}", dependencies=[Depends(auth)])
    def api_entity(entity_type: str, cache_key: str):
        try:
            detail = entity_detail(entity_type, cache_key)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        if detail is None:
            raise HTTPException(
                status_code=404,
                detail=f"entity cache record not found: {entity_type}/{cache_key}",
            )
        return detail

    @app.get("/api/entity-chains", dependencies=[Depends(auth)])
    def api_entity_chains(entity_type: str = ""):
        return entity_chain_catalog(entity_type=entity_type)

    @app.post("/api/entity-chains/{chain_id}/run", dependencies=[Depends(auth)])
    def api_run_entity_chain(chain_id: str, payload: dict | None = None):
        """Run a multi-Entity scenario and preserve all calls in one Runtime."""
        params = dict(payload or {})
        started = perf_counter()
        runtime: Runtime | None = None
        try:
            try:
                runtime = Runtime.begin(name=f"{_ENTITY_CHAIN_PREFIX}{chain_id}", params=params)
            except OSError:
                runtime = None
            if runtime is not None:
                with runtime_context(runtime):
                    outcome = run_entity_chain(chain_id, params)
            else:
                outcome = run_entity_chain(chain_id, params)
            if runtime is not None:
                runtime.finish(outcome["success"], "" if outcome["success"] else "entity chain failed")
        except KeyError as exc:
            if runtime is not None:
                runtime.finish(False, str(exc))
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except Exception as exc:  # pragma: no cover - runtime safety net
            if runtime is not None:
                try:
                    runtime.finish(False, f"{type(exc).__name__}: {exc}")
                except OSError:
                    pass
            raise HTTPException(status_code=500, detail=f"entity chain failed: {exc}") from exc

        outcome["run_id"] = runtime.run_id if runtime is not None else ""
        outcome["persisted"] = runtime is not None
        outcome["wall_elapsed_ms"] = round((perf_counter() - started) * 1000, 1)
        return outcome

    @app.post("/api/runs", dependencies=[Depends(auth)])
    def api_start_run(payload: dict):
        name = (payload or {}).get("pipeline")
        if not name:
            raise HTTPException(status_code=400, detail="'pipeline' is required")
        params = (payload or {}).get("params", {}) or {}
        force = bool((payload or {}).get("force", False))
        try:
            run_id = broker.start(name, params, force)
        except ValueError as e:
            raise HTTPException(status_code=404, detail=str(e))
        return {"run_id": run_id, "pipeline": name}

    @app.get("/api/runs", dependencies=[Depends(auth)])
    def api_runs():
        return Runtime.list_runs()

    @app.get("/api/runs/{run_id}", dependencies=[Depends(auth)])
    def api_run(run_id: str):
        manifest = Runtime.status(run_id)
        if manifest is not None:
            return manifest
        handle = broker.get(run_id)
        if handle is not None:
            return {
                "run_id": run_id,
                "status": "running" if not handle.done else ("finished" if handle.success else "failed"),
                "steps": {},
                "error": handle.error,
                "live": True,
            }
        raise HTTPException(status_code=404, detail=f"unknown run: {run_id}")

    @app.get("/api/runs/{run_id}/steps/{step}", dependencies=[Depends(auth)])
    def api_step(run_id: str, step: str):
        artifact = Artifact.load(run_id, step)
        if artifact is None:
            raise HTTPException(status_code=404, detail=f"no artifact for step '{step}'")
        d = artifact.to_dict()
        d["renderer"] = infer_renderer(artifact.data, artifact.output_schema)
        return d

    @app.get("/api/runs/{run_id}/events")
    async def api_events(run_id: str, request: Request, token: str = ""):
        _verify_token(request, token, auth_token)
        handle = broker.get(run_id)
        gen = _live_events(handle) if handle is not None else _static_events(run_id)
        return StreamingResponse(gen, media_type="text/event-stream")

    @app.get("/api/health", dependencies=[Depends(auth)])
    def api_health():
        capabilities = _viewer_capabilities()
        return {
            "ok": True,
            "capabilities": len(capabilities),
            "atomic_capabilities": sum(1 for item in capabilities if item["atomic"]),
            "entity_capabilities": sum(1 for item in capabilities if item["layer"] == "entity"),
        }

    # ------------------------------------------------------------------
    # 静态 viewer（最后挂载，避免吞掉 API 路由）
    # ------------------------------------------------------------------
    if _STATIC_DIR.exists():
        app.mount("/", _NoCacheStaticFiles(directory=str(_STATIC_DIR), html=True), name="static")

    return app


app = create_app()
