"""Bounded, persistent, single-user jobs for the local workbench.

The job file owns the lifecycle. Runtime owns SDK calls and result files.
A restarted server marks unfinished jobs interrupted instead of repeating an
upstream request. This deliberately does not claim to be a distributed queue.
"""

from __future__ import annotations

import hashlib
import ipaddress
import json
import os
import tempfile
import threading
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urlsplit
from uuid import uuid4

from pydantic import ValidationError

from amz import registry
from amz.envelope import Code, Result, err, ok
from amz.infra.paths import cache_path, confined_path, validate_component
from amz.infra.runtime import Runtime, runtime_context
from amz.serve.tool_catalog import get_catalog
from amz.serve.tool_policy import capability_allowed, execution_allowed, path_fields


TERMINAL = {"succeeded", "partial", "failed", "interrupted"}


class JobConflict(ValueError):
    """A request id was already used with different input."""


class JobUnavailable(ValueError):
    """The selected tool is known but unavailable in this workbench."""


class QueueFull(ValueError):
    """The local runner has reached its bounded queue size."""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _json(value: Any) -> Any:
    if isinstance(value, Result):
        return value.model_dump(mode="json")
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    raise TypeError(f"unsupported JSON value: {type(value).__name__}")


def _json_value(value: Any) -> Any:
    """Validate and detach values before they enter a persistent job record."""
    return json.loads(json.dumps(value, ensure_ascii=False, allow_nan=False, default=_json))


def _check_urls(params: dict[str, Any]) -> None:
    """Reject local file and private-network URLs in explicit URL fields."""
    for name, value in params.items():
        if isinstance(value, dict):
            _check_urls(value)
        elif isinstance(value, list):
            for item in value:
                if isinstance(item, dict):
                    _check_urls(item)
        if not isinstance(value, str) or not (name == "url" or name.endswith("_url")) or not value:
            continue
        try:
            parsed = urlsplit(value)
            host = (parsed.hostname or "").lower().rstrip(".")
            if parsed.scheme not in {"https", "http"} or not host or parsed.username or parsed.password:
                raise ValueError
            if host == "localhost" or host.endswith((".localhost", ".local")):
                raise ValueError
            try:
                address = ipaddress.ip_address(host)
            except ValueError:
                address = None
            if address is not None and not address.is_global:
                raise ValueError
        except ValueError:
            raise ValueError(f"{name} 必须是公开 http(s) URL，不能使用本地文件或内网地址。") from None


def validate_tool_params(tool: dict[str, Any], params: dict[str, Any]) -> None:
    if not isinstance(params, dict):
        raise ValueError("params 必须是 JSON 对象。")
    schema = tool.get("input_schema") or {}
    names = set((schema.get("properties") or {}).keys())
    unknown = set(params) - names
    if unknown:
        raise ValueError("未知参数：" + "、".join(sorted(unknown)))
    missing = set(schema.get("required") or []) - set(params)
    if missing:
        raise ValueError("缺少参数：" + "、".join(sorted(missing)))
    if path_fields(schema):
        raise JobUnavailable("当前工作台不接受服务器文件路径，请使用支持受控上传的工具。")
    _check_urls(params)
    if tool["kind"] == "composite" and tool["id"] == "composite.product-development":
        from amz.composite.product_development import ProductDevelopmentInput
        try:
            ProductDevelopmentInput.model_validate(params)
        except ValidationError as exc:
            raise ValueError("参数不符合要求：" + str(exc)) from None
    if tool["kind"] == "capability":
        cap = registry.get(tool["id"])
        if cap is None or not capability_allowed(cap.id):
            raise JobUnavailable("该能力不在本地工作台的业务白名单中。")
        if cap.input_model is not None:
            try:
                cap.input_model.model_validate(params)
            except ValidationError as exc:
                errors = [".".join(map(str, item["loc"])) + ": " + item["msg"] for item in exc.errors()]
                raise ValueError("参数不符合要求：" + "; ".join(errors)) from None


def execute_tool(tool: dict[str, Any], params: dict[str, Any], context: "JobContext") -> Any:
    if not execution_allowed(tool["id"], tool["kind"]):
        raise JobUnavailable("该入口不在本地执行策略允许范围内。")
    if tool["kind"] == "capability":
        context.step("execute", tool["title"], "running")
        result = context.invoke(tool["id"], params)
        context.step("execute", tool["title"], "succeeded" if result.code == Code.OK else "failed", result, result.message)
        return result
    if tool["kind"] == "composite":
        from amz.serve.workflows import execute
    elif tool["kind"] == "skill":
        from amz.serve.skill_runner import execute
    else:
        raise JobUnavailable("不支持的工具类型。")
    return execute(tool["id"], params, context)


class JobContext:
    def __init__(self, manager: "JobManager", run_id: str, runtime: Runtime, kind: str = "capability"):
        self.manager = manager
        self.run_id = run_id
        self.runtime = runtime
        self.kind = kind
        self._tools = {tool["id"]: tool for tool in manager.catalog()["tools"]}

    def emit(self, message: str, type: str = "progress", data: Any = None) -> None:
        self.manager._event(self.run_id, message, type, data)

    def step(self, id: str, title: str, status: str, result: Any = None, error: str = "") -> None:
        if status not in {"queued", "running", "succeeded", "partial", "failed", "skipped", "blocked", "interrupted"}:
            raise ValueError(f"unknown step status: {status}")
        validate_component(id, label="step id")
        self.manager._step(self.run_id, id, title, status, result, error)
        self.runtime.record_step(id, status, {"title": title, "error": error})

    def invoke(self, capability_id: str, params: dict[str, Any]) -> Result:
        tool = self._tools.get(capability_id)
        fixed_workflow = capability_id == "composite.product-development" and tool is not None and tool["kind"] == "composite"
        if tool is None or (tool["kind"] != "capability" and not fixed_workflow) or not tool.get("available"):
            return err(Code.ERROR_PARAM, "该能力不在本地工作台的可执行业务目录中。", capability=capability_id)
        if self.kind == "skill" and not capability_id.startswith(("entity.", "composite.")):
            return err(Code.ERROR_PARAM, "Skill 只能调用 Entity 或已发布的固定工作流。", capability=capability_id)
        try:
            validate_tool_params(tool, params)
        except (ValueError, TypeError) as exc:
            return err(Code.ERROR_PARAM, str(exc), capability=capability_id)
        self.emit("开始：" + tool["title"], "capability.started", {"capability": capability_id})
        with runtime_context(self.runtime):
            if fixed_workflow:
                from amz.serve.workflows import execute
                outcome = execute(capability_id, params, self)
                result = outcome.get("result") if isinstance(outcome, dict) and "result" in outcome else outcome
                result = result if isinstance(result, Result) else Result.model_validate(result)
                self.runtime.save_result(capability_id, result, params=params)
            else:
                result = registry.invoke(capability_id, params)
        self.emit("完成：" + tool["title"] if result.code == Code.OK else "失败：" + tool["title"],
                  "capability.finished", {"capability": capability_id, "code": result.code.value,
                                          "elapsed_ms": result.meta.elapsed_ms, "from_cache": result.meta.from_cache})
        return result


class JobManager:
    """One local workspace, a bounded executor, and atomic JSON job records."""

    def __init__(self, directory: Path | str | None = None, *, max_workers: int = 1,
                 max_pending: int = 32, catalog_provider: Callable[[], dict] | None = None,
                 executor: Callable[[dict, dict, JobContext], Any] | None = None):
        self.directory = Path(directory) if directory is not None else cache_path("workbench")
        self.directory.mkdir(parents=True, exist_ok=True)
        self.directory = self.directory.resolve()
        self._lock = threading.RLock()
        self._runs: dict[str, dict[str, Any]] = {}
        self._requests: dict[str, str] = {}
        self._catalog = catalog_provider or get_catalog
        self._execute = executor or execute_tool
        self.max_pending = max(1, max_pending)
        self._closed = False
        self._restore()
        self._pool = ThreadPoolExecutor(max_workers=max(1, min(max_workers, 4)), thread_name_prefix="amz-workbench")

    def catalog(self) -> dict[str, Any]:
        return self._catalog()

    def _path(self, run_id: str) -> Path:
        validate_component(run_id, label="run id")
        return confined_path(self.directory, run_id + ".json")

    def _save(self, run: dict[str, Any]) -> None:
        path = self._path(run["id"])
        temp_path = None
        try:
            with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=self.directory,
                                             prefix=".job-", suffix=".tmp", delete=False) as handle:
                temp_path = Path(handle.name)
                json.dump(run, handle, ensure_ascii=False, allow_nan=False, default=_json)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp_path, path)
        finally:
            if temp_path is not None:
                temp_path.unlink(missing_ok=True)

    def _restore(self) -> None:
        for path in sorted(self.directory.glob("*.json")):
            if path.is_symlink():
                continue
            try:
                run = json.loads(path.read_text(encoding="utf-8"))
                if not isinstance(run, dict) or path.name != run["id"] + ".json":
                    continue
                self._path(run["id"])
                if run.get("status") not in TERMINAL | {"running", "queued"}:
                    continue
                if run["status"] in {"running", "queued"}:
                    run.update(status="interrupted", error="服务已重启，原任务未继续执行。请核对结果后重新运行。",
                               updated_at=_now(), finished_at=_now())
                    for step in run.get("steps", []):
                        if step.get("status") in {"running", "queued"}:
                            step["status"] = "interrupted"
                    events = run.setdefault("events", [])
                    events.append({"id": len(events) + 1, "time": _now(), "type": "run.interrupted", "message": run["error"]})
                    self._save(run)
                self._runs[run["id"]] = run
                if run.get("request_id"):
                    self._requests[run["request_id"]] = run["id"]
            except (OSError, ValueError, KeyError, TypeError):
                # One corrupt file must not hide unrelated completed runs.
                continue

    def submit(self, tool_id: str, params: dict[str, Any], request_id: str) -> dict[str, Any]:
        if not isinstance(request_id, str) or not request_id.strip() or len(request_id) > 128:
            raise ValueError("request_id 必须为 1–128 个字符。")
        encoded = json.dumps([tool_id, params], ensure_ascii=False, sort_keys=True, allow_nan=False, separators=(",", ":"))
        fingerprint = hashlib.sha256(encoded.encode()).hexdigest()
        with self._lock:
            existing_id = self._requests.get(request_id)
            if existing_id:
                existing = self._runs[existing_id]
                if existing["fingerprint"] != fingerprint:
                    raise JobConflict("同一个 request_id 已用于不同参数，请使用新的 request_id。")
                return deepcopy(existing)
            if self._closed:
                raise JobUnavailable("本地工作台正在关闭。")
            tool = next((item for item in self.catalog()["tools"] if item["id"] == tool_id), None)
            if tool is None:
                raise KeyError(tool_id)
            if self._execute is execute_tool and not execution_allowed(tool_id, tool["kind"]):
                raise JobUnavailable("该入口不在本地执行策略允许范围内。")
            if not tool.get("available"):
                raise JobUnavailable(tool.get("unavailable_reason") or "工具暂不可用。")
            validate_tool_params(tool, params)
            if sum(run["status"] not in TERMINAL for run in self._runs.values()) >= self.max_pending:
                raise QueueFull("本地任务队列已满，请等待现有任务完成。")
            now = _now()
            run_id = "web_" + uuid4().hex
            steps = [{**deepcopy(step), "status": "queued", "result": None, "error": ""}
                     for step in tool.get("steps", [])]
            if tool["kind"] == "capability":
                steps = [{"id": "execute", "title": tool["title"], "status": "queued", "result": None, "error": ""}]
            run = {
                "id": run_id, "tool_id": tool_id, "title": tool["title"], "kind": tool["kind"],
                "renderer": tool.get("renderer", "generic"), "status": "queued", "params": deepcopy(params),
                "request_id": request_id, "fingerprint": fingerprint, "created_at": now, "updated_at": now,
                "finished_at": None, "result": None, "error": "", "report": "", "calls": [],
                "events": [{"id": 1, "time": now, "type": "run.queued", "message": "已加入本地任务队列。"}],
                "steps": steps,
                "tool_snapshot": deepcopy(tool),
            }
            self._save(run)
            self._runs[run_id] = run
            self._requests[request_id] = run_id
            self._pool.submit(self._run, run_id, deepcopy(tool))
            return deepcopy(run)

    def _event(self, run_id: str, message: str, type: str = "progress", data: Any = None) -> None:
        data = _json_value(data)
        with self._lock:
            run = self._runs[run_id]
            event = {"id": len(run["events"]) + 1, "time": _now(), "type": type, "message": message}
            if data is not None:
                event["data"] = data
            run["events"].append(event)
            run["updated_at"] = event["time"]
            self._save(run)

    def _step(self, run_id: str, id: str, title: str, status: str, result: Any, error: str) -> None:
        result = _json_value(result)
        with self._lock:
            run = self._runs[run_id]
            step = next((item for item in run["steps"] if item["id"] == id), None)
            if step is None:
                step = {"id": id}
                run["steps"].append(step)
            step.update(title=title, status=status, result=result, error=error, updated_at=_now())
            self._event(run_id, title, "step." + status, {"step_id": id, "status": status})

    def _run(self, run_id: str, tool: dict[str, Any]) -> None:
        runtime = None
        try:
            with self._lock:
                run = self._runs[run_id]
                run["status"] = "running"
                self._event(run_id, "开始执行：" + run["title"], "run.started")
                params = deepcopy(run["params"])
            runtime = Runtime.begin(name="workbench:" + tool["id"], params=params, run_id=run_id)
            context = JobContext(self, run_id, runtime, kind=tool["kind"])
            with runtime_context(runtime):
                outcome = self._execute(tool, params, context)
            report = ""
            if isinstance(outcome, dict) and "result" in outcome:
                report = str(outcome.get("report") or "")
                outcome = outcome["result"]
            if isinstance(outcome, Result):
                result = outcome
            elif isinstance(outcome, dict) and "code" in outcome:
                result = Result.model_validate(outcome)
            else:
                result = ok(outcome)
            succeeded = result.code == Code.OK
            partial = succeeded and tool["kind"] == "composite" and isinstance(result.data, dict) and result.data.get("status") == "PARTIAL"
            if tool["kind"] != "capability":
                runtime.save_result(tool["id"], result, params=params)
            runtime.finish(succeeded, "" if succeeded else result.message)
            with self._lock:
                run = self._runs[run_id]
                run.update(status="partial" if partial else "succeeded" if succeeded else "failed", result=result.model_dump(mode="json"),
                           error="" if succeeded else result.message, report=report, finished_at=_now(),
                           calls=runtime.manifest().get("calls", []))
                for step in run["steps"]:
                    if step["status"] in {"queued", "running"}:
                        step["status"] = "skipped" if step["status"] == "queued" else ("succeeded" if succeeded else "failed")
                self._event(run_id, "任务部分完成，请查看缺失样本。" if partial else "任务完成。" if succeeded else "任务失败：" + result.message,
                            "run.partial" if partial else "run.succeeded" if succeeded else "run.failed")
        except Exception as exc:
            message = f"{type(exc).__name__}: {exc}"
            if runtime is not None:
                try:
                    runtime.finish(False, message)
                except OSError:
                    pass
            with self._lock:
                run = self._runs[run_id]
                run.update(status="failed", error=message, finished_at=_now(),
                           result=err(Code.ERROR_SERVER_INTERNAL, message).model_dump(mode="json"))
                if runtime is not None:
                    run["calls"] = runtime.manifest().get("calls", [])
                for step in run["steps"]:
                    if step["status"] == "running":
                        step.update(status="failed", error=message)
                    elif step["status"] == "queued":
                        step["status"] = "skipped"
                self._event(run_id, "任务失败：" + message, "run.failed")

    def get(self, run_id: str) -> dict[str, Any] | None:
        with self._lock:
            run = self._runs.get(run_id)
            if run is None:
                return None
            result = deepcopy(run)
        if result["status"] == "running":
            manifest = Runtime.status(run_id)
            if manifest is not None:
                result["calls"] = manifest.get("calls", [])
        result.pop("fingerprint", None)
        return result

    def list(self, limit: int = 100) -> list[dict[str, Any]]:
        with self._lock:
            rows = sorted(self._runs.values(), key=lambda run: run["created_at"], reverse=True)[:max(1, min(limit, 200))]
            return [{key: deepcopy(value) for key, value in run.items()
                     if key not in {"fingerprint", "events", "calls", "steps", "result", "report"}} for run in rows]

    def shutdown(self, wait: bool = True) -> None:
        with self._lock:
            self._closed = True
        self._pool.shutdown(wait=wait)
