"""Workbench projection of the shared catalog plus local execution status."""
from __future__ import annotations

from importlib import import_module
from typing import Any

from amz.catalog import build_catalog
from amz.catalog.resources import load_resource
from amz.serve.tool_policy import path_fields, runtime_status


# Compatibility exports are read-only display data. Execution must use policy.
_METADATA = load_resource("metadata")
GROUPS = _METADATA["groups"]
TOOL_LABELS = {item["id"]: (item["title"], item["group"], item["renderer"]) for item in _METADATA["tools"]}
TOOL_DESCRIPTIONS = {item["id"]: item["description"] for item in _METADATA["tools"]}


def list_capability_tools() -> list[dict[str, Any]]:
    return [{**tool, **runtime_status(tool)} for tool in build_catalog()["tools"]]


def _extra_tools(module_name: str, function_name: str) -> list[dict[str, Any]]:
    try:
        module = import_module(module_name)
    except ModuleNotFoundError as exc:
        if exc.name == module_name:
            return []
        raise
    return getattr(module, function_name)()


def get_catalog() -> dict[str, Any]:
    extras = [*_extra_tools("amz.serve.workflows", "list_workflows"), *_extra_tools("amz.serve.skill_runner", "list_skills")]
    catalog = build_catalog(extra_tools=extras)
    original = {tool["id"]: tool for tool in extras}
    catalog["tools"] = [{**tool, **runtime_status({**original.get(tool["id"], {}), **tool})} for tool in catalog["tools"]]
    catalog["counts"]["available"] = sum(bool(tool["available"]) for tool in catalog["tools"])
    return catalog


def get_tool(tool_id: str) -> dict[str, Any] | None:
    return next((tool for tool in get_catalog()["tools"] if tool["id"] == tool_id), None)
