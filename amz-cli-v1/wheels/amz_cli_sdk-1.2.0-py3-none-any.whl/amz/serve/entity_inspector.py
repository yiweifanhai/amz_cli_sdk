"""Read-only Entity cache inspection for the local web viewer.

The Entity cache is the source of truth for aggregate state.  This module keeps
the HTTP layer small and, importantly, never constructs or enriches an Entity
while inspecting it: opening the viewer must not trigger upstream requests or
mutate TTL state.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from amz.config import config
from amz.entities import entity_registry
from amz.entities._core.base import ENTITY_CACHE_SCHEMA, Entity, EnrichSpec


def entity_catalog(
    *,
    entity_type: str = "",
    query: str = "",
    limit: int = 200,
    offset: int = 0,
) -> dict[str, Any]:
    """Return registered Entity types plus persisted cache-record summaries."""
    classes = _registered_classes()
    if entity_type and entity_type not in classes:
        raise KeyError(f"unknown entity type: {entity_type}")

    selected = (
        {entity_type: classes[entity_type]}
        if entity_type
        else classes
    )
    type_rows: list[dict[str, Any]] = []
    records: list[dict[str, Any]] = []
    totals = _empty_counts()

    for type_name, entity_cls in selected.items():
        type_counts = _empty_counts()
        type_records: list[dict[str, Any]] = []
        for path in _cache_files(type_name):
            try:
                payload = _inspection_payload(entity_cls, _read_payload(path))
                row = _record_summary(entity_cls, path, payload)
            except (OSError, json.JSONDecodeError, TypeError, ValueError) as exc:
                row = {
                    "entity_type": type_name,
                    "cache_key": path.stem,
                    "cache_id": "",
                    "identity": {},
                    "identity_label": path.stem,
                    "saved_at": "",
                    "size_bytes": _file_size(path),
                    "status": "invalid",
                    "field_counts": {"populated": 0, "total": len(entity_cls.model_fields)},
                    "lazy_counts": {"fresh": 0, "stale": 0, "missing": 0, "unknown": 0},
                    "error": f"{type(exc).__name__}: {exc}",
                }
            _accumulate(type_counts, row)
            type_records.append(row)

        type_rows.append(_type_summary(entity_cls, type_records, type_counts))
        records.extend(type_records)
        _merge_counts(totals, type_counts)

    q = query.strip().lower()
    if q:
        records = [
            row for row in records
            if q in _search_text(row)
        ]
    records.sort(key=lambda row: row.get("saved_at", ""), reverse=True)

    offset = max(0, int(offset))
    limit = min(500, max(1, int(limit)))
    total_matches = len(records)
    return {
        "schema": ENTITY_CACHE_SCHEMA,
        "summary": {
            "registered_types": len(selected),
            **totals,
            "matching_records": total_matches,
        },
        "types": type_rows,
        "records": records[offset:offset + limit],
        "offset": offset,
        "limit": limit,
        "has_more": offset + limit < total_matches,
    }


def entity_detail(entity_type: str, cache_key: str) -> dict[str, Any] | None:
    """Return one raw cache payload enriched with model/lazy-field metadata."""
    classes = _registered_classes()
    entity_cls = classes.get(entity_type)
    if entity_cls is None:
        raise KeyError(f"unknown entity type: {entity_type}")

    path = _cache_path(entity_type, cache_key)
    if path is None or not path.is_file() or path.is_symlink():
        return None
    try:
        payload = _inspection_payload(entity_cls, _read_payload(path))
    except (OSError, json.JSONDecodeError, TypeError, ValueError):
        return None

    summary = _record_summary(entity_cls, path, payload)
    fields = payload.get("fields") if isinstance(payload.get("fields"), dict) else {}
    lazy = _lazy_statuses(entity_cls, payload)
    return {
        **summary,
        "schema": payload.get("schema", ""),
        "identity_fields": list(entity_cls.identity_fields),
        "model_fields": list(entity_cls.model_fields),
        "model_schema": entity_cls.model_json_schema(),
        "lazy_fields": lazy,
        "fields": fields,
        "result_data": payload.get("result_data") or {},
        "fetched_at": payload.get("fetched_at") or {},
        "fetch_keys": payload.get("fetch_keys") or {},
    }


def _registered_classes() -> dict[str, type[Entity]]:
    return {
        entity_cls.entity_type: entity_cls
        for entity_cls in sorted(entity_registry.classes(), key=lambda cls: cls.entity_type)
    }


def _cache_files(entity_type: str) -> list[Path]:
    directory = config.cache_dir / "entities" / entity_type
    if not directory.is_dir():
        return []
    return sorted(
        (path for path in directory.glob("*.json") if path.is_file() and not path.is_symlink()),
        key=lambda path: path.stat().st_mtime,
        reverse=True,
    )


def _cache_path(entity_type: str, cache_key: str) -> Path | None:
    # Current cache keys are sha256 digests; safe legacy names are also readable.
    if (
        not cache_key
        or cache_key in {".", ".."}
        or Path(cache_key).name != cache_key
        or "/" in cache_key
        or "\\" in cache_key
    ):
        return None
    return config.cache_dir / "entities" / entity_type / f"{cache_key}.json"


def _read_payload(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise TypeError("entity cache root must be an object")
    return payload


def _inspection_payload(entity_cls: type[Entity], payload: dict[str, Any]) -> dict[str, Any]:
    """Project field-cache records to the existing viewer response, without I/O."""
    if payload.get("schema") != "amz.entity.v3":
        return payload
    entries = payload.get("fields")
    if not isinstance(entries, dict) or any(not isinstance(entry, dict) for entry in entries.values()):
        raise TypeError("v3 entity fields must contain field-cache objects")
    return {
        **payload,
        "fields": {
            name: entry.get("value") for name, entry in entries.items()
            if name in entity_cls.model_fields
        },
        "result_data": {
            name: entry.get("value") for name, entry in entries.items()
            if name in entity_cls.lazy_fields and name not in entity_cls.model_fields
        },
        "fetched_at": {
            name: entry["updated_at"] for name, entry in entries.items()
            if entry.get("updated_at") is not None
        },
        "fetch_keys": {
            name: entry["fetch_key"] for name, entry in entries.items()
            if entry.get("fetch_key") is not None
        },
        "_field_entries": entries,
    }


def _type_summary(
    entity_cls: type[Entity],
    records: list[dict[str, Any]],
    counts: dict[str, int],
) -> dict[str, Any]:
    return {
        "entity_type": entity_cls.entity_type,
        "model": entity_cls.__name__,
        "identity_fields": list(entity_cls.identity_fields),
        "model_fields": list(entity_cls.model_fields),
        "lazy_fields": [
            _lazy_definition(entity_cls.entity_type, field, spec)
            for field, spec in entity_cls.lazy_fields.items()
        ],
        "record_count": len(records),
        **counts,
    }


def _record_summary(
    entity_cls: type[Entity],
    path: Path,
    payload: dict[str, Any],
) -> dict[str, Any]:
    fields = payload.get("fields") if isinstance(payload.get("fields"), dict) else {}
    identity = {name: fields.get(name) for name in entity_cls.identity_fields}
    identity_values = [str(value) for value in identity.values() if value not in (None, "")]
    lazy = _lazy_statuses(entity_cls, payload)
    lazy_counts = {"fresh": 0, "stale": 0, "missing": 0, "unknown": 0}
    for item in lazy:
        lazy_counts[item["status"]] += 1

    if lazy_counts["stale"] or lazy_counts["unknown"]:
        status = "stale"
    elif lazy_counts["missing"] and lazy_counts["fresh"]:
        status = "partial"
    elif lazy_counts["missing"]:
        # Core fields may already be populated; only the lazy aggregate is empty.
        status = "core"
    else:
        status = "fresh"

    populated = sum(1 for value in fields.values() if _has_value(value))
    return {
        "entity_type": entity_cls.entity_type,
        "cache_key": path.stem,
        "cache_id": str(payload.get("cache_id") or ""),
        "identity": identity,
        "identity_label": " · ".join(identity_values) or str(payload.get("cache_id") or path.stem),
        "saved_at": str(payload.get("saved_at") or ""),
        "size_bytes": _file_size(path),
        "status": status,
        "field_counts": {"populated": populated, "total": len(entity_cls.model_fields)},
        "lazy_counts": lazy_counts,
    }


def _lazy_statuses(entity_cls: type[Entity], payload: dict[str, Any]) -> list[dict[str, Any]]:
    fields = payload.get("fields") if isinstance(payload.get("fields"), dict) else {}
    fetched_at = payload.get("fetched_at") if isinstance(payload.get("fetched_at"), dict) else {}
    fetch_keys = payload.get("fetch_keys") if isinstance(payload.get("fetch_keys"), dict) else {}
    entries = payload.get("_field_entries")
    now = datetime.now(timezone.utc)
    rows: list[dict[str, Any]] = []

    for field, spec in entity_cls.lazy_fields.items():
        entry = entries.get(field, {}) if entries is not None else None
        fetched_raw = fetched_at.get(field)
        declared = field in entity_cls.model_fields
        has_value = (not declared) or fields.get(field) is not None
        fetched = _parse_datetime(fetched_raw)
        expires = fetched + timedelta(hours=spec.ttl_hours) if fetched else None
        if entry is not None and entry.get("state", "missing") == "missing":
            status = "missing"
        elif entry is not None and entry.get("state") != "ready":
            status = "unknown"
        elif not fetched_raw or not has_value:
            status = "missing"
        elif fetched is None:
            status = "unknown"
        elif expires is not None and expires <= now:
            status = "stale"
        elif entry is not None and entry.get("version") != spec.version:
            status = "stale"
        else:
            status = "fresh"

        rows.append({
            **_lazy_definition(entity_cls.entity_type, field, spec),
            "status": status,
            "fetched_at": str(fetched_raw or ""),
            "expires_at": expires.isoformat() if expires else "",
            "age_hours": round((now - fetched).total_seconds() / 3600, 1) if fetched else None,
            "fetch_key": str(fetch_keys.get(field) or ""),
            "has_value": has_value,
            **({
                "state": entry.get("state", "missing"),
                "last_params": entry.get("last_params") or {},
                "stored_version": entry.get("version"),
                "error": entry.get("error"),
            } if entry is not None else {}),
        })
    return rows


def _lazy_definition(entity_type: str, field: str, spec: EnrichSpec) -> dict[str, Any]:
    return {
        "field": field,
        "source": spec.source,
        "depends": list(spec.depends),
        "optional_depends": list(spec.optional_depends),
        "invalidates_on": list(spec.invalidates_on),
        "dependency_params": {
            dependency: list(names)
            for dependency, names in spec.dependency_params.items()
        },
        "ttl_hours": spec.ttl_hours,
        "version": spec.version,
        "capability": f"entity.{entity_type}.{field}",
    }


def _parse_datetime(value: Any) -> datetime | None:
    if not value or not isinstance(value, str):
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone.utc)
    except ValueError:
        return None


def _has_value(value: Any) -> bool:
    return value not in (None, "", [], {})


def _file_size(path: Path) -> int:
    try:
        return path.stat().st_size
    except OSError:
        return 0


def _empty_counts() -> dict[str, int]:
    return {
        "records": 0,
        "invalid_records": 0,
        "fresh_fields": 0,
        "stale_fields": 0,
        "missing_fields": 0,
        "unknown_fields": 0,
    }


def _accumulate(counts: dict[str, int], row: dict[str, Any]) -> None:
    counts["records"] += 1
    if row.get("status") == "invalid":
        counts["invalid_records"] += 1
    lazy = row.get("lazy_counts") or {}
    counts["fresh_fields"] += int(lazy.get("fresh", 0))
    counts["stale_fields"] += int(lazy.get("stale", 0))
    counts["missing_fields"] += int(lazy.get("missing", 0))
    counts["unknown_fields"] += int(lazy.get("unknown", 0))


def _merge_counts(target: dict[str, int], source: dict[str, int]) -> None:
    for key in target:
        target[key] += source[key]


def _search_text(row: dict[str, Any]) -> str:
    return " ".join([
        str(row.get("entity_type") or ""),
        str(row.get("cache_id") or ""),
        str(row.get("cache_key") or ""),
        str(row.get("identity_label") or ""),
        json.dumps(row.get("identity") or {}, ensure_ascii=False, default=str),
    ]).lower()
