"""HTTP contract for the local workbench; mounted by the local-only app."""

from __future__ import annotations

from typing import Any
import json

from fastapi import APIRouter, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel, ConfigDict, Field

from amz import __version__, config
from amz.serve.local_jobs import JobConflict, JobManager, JobUnavailable, QueueFull


class RunRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    tool_id: str = Field(min_length=1, max_length=180)
    params: dict[str, Any] = Field(default_factory=dict)
    request_id: str = Field(min_length=1, max_length=128)


def create_workbench_router(manager: JobManager | None = None) -> APIRouter:
    jobs = manager or JobManager()
    router = APIRouter(prefix="/api/workbench", tags=["local-workbench"])

    @router.get("/catalog")
    def catalog():
        return jobs.catalog()

    @router.get("/health")
    def health():
        catalog = jobs.catalog()
        return {
            "version": __version__, "capabilities": catalog["counts"],
            "config": {
                "data_api": bool(config.data_api_token),
                "llm": bool(config.api_key(config.llm_default_backend)),
                "local_only": True,
            },
        }

    @router.get("/runs")
    def runs(limit: int = 100):
        return {"runs": jobs.list(limit=limit)}

    @router.post("/runs", status_code=202)
    def submit(body: RunRequest):
        try:
            result = jobs.submit(body.tool_id, body.params, body.request_id)
            result.pop("fingerprint", None)
            return result
        except KeyError:
            raise HTTPException(404, "没有找到该工具。") from None
        except JobConflict as exc:
            raise HTTPException(409, str(exc)) from exc
        except JobUnavailable as exc:
            raise HTTPException(409, str(exc)) from exc
        except QueueFull as exc:
            raise HTTPException(429, str(exc)) from exc
        except (ValueError, TypeError) as exc:
            raise HTTPException(422, str(exc)) from exc

    @router.get("/runs/{run_id}")
    def run(run_id: str):
        result = jobs.get(run_id)
        if result is None:
            raise HTTPException(404, "没有找到该运行记录。")
        return result

    @router.get("/runs/{run_id}/export")
    def export(run_id: str, format: str = "json"):
        result = jobs.get(run_id)
        if result is None:
            raise HTTPException(404, "没有找到该运行记录。")
        if format == "json":
            content = json.dumps(result, ensure_ascii=False, indent=2)
            media_type, suffix = "application/json", "json"
        elif format == "md":
            if not result.get("report"):
                raise HTTPException(409, "本次运行没有 Markdown 报告，可下载 JSON 结果。")
            content = result["report"]
            media_type, suffix = "text/markdown", "md"
        else:
            raise HTTPException(422, "导出格式只能是 json 或 md。")
        return Response(content, media_type=media_type,
                        headers={"Content-Disposition": f'attachment; filename="{result["id"]}.{suffix}"'})

    return router
