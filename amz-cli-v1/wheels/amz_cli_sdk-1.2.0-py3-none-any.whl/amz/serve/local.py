"""Single-user, loopback-only web workbench; no upstream keys reach the browser."""

from __future__ import annotations

import argparse
import threading
import time
import webbrowser
from contextlib import asynccontextmanager
from pathlib import Path
from urllib.parse import urlsplit

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from amz import __version__, config


LOCAL_HOSTS = {"localhost", "127.0.0.1", "::1"}


def create_local_app(web_dir: Path | None = None, manager=None) -> FastAPI:
    from amz.discovery import load_builtin_capabilities
    from amz.serve.local_jobs import JobManager
    from amz.serve.workbench import create_workbench_router

    load_builtin_capabilities()
    owned_manager = manager is None
    manager = manager or JobManager()

    @asynccontextmanager
    async def lifespan(app):
        yield
        if owned_manager:
            close = getattr(manager, "close", None) or getattr(manager, "shutdown", None)
            if close:
                close()

    app = FastAPI(title="AMZ 本地工作台", version=__version__, lifespan=lifespan)
    app.state.job_manager = manager

    @app.middleware("http")
    async def local_boundary(request: Request, call_next):
        try:
            host = urlsplit("http://" + request.headers.get("host", "")).hostname
        except ValueError:
            host = None
        if host not in LOCAL_HOSTS:
            return JSONResponse({"detail": "工作台仅接受本机地址"}, status_code=403)
        if request.method not in {"GET", "HEAD", "OPTIONS"}:
            origin = request.headers.get("origin")
            expected = f"{request.url.scheme}://{request.headers['host']}"
            if origin is not None and origin != expected:
                return JSONResponse({"detail": "不接受其他网站提交运行请求"}, status_code=403)
            if request.headers.get("x-amz-local") != "1":
                return JSONResponse({"detail": "缺少本机请求标记"}, status_code=403)
            if request.headers.get("sec-fetch-site") == "cross-site":
                return JSONResponse({"detail": "不接受跨站请求"}, status_code=403)
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        if request.url.path.startswith("/api/") or request.url.path in {"/", "/index.html"}:
            response.headers["Cache-Control"] = "no-store"
        return response

    app.include_router(create_workbench_router(manager))
    built = web_dir or Path(__file__).resolve().parents[2] / "apps" / "web" / "dist"
    if built.is_dir() and (built / "index.html").is_file():
        app.mount("/", StaticFiles(directory=built, html=True), name="workbench")
    else:
        @app.get("/")
        def not_built():
            return JSONResponse(
                {"detail": "网页尚未构建，请运行项目根目录的 start-web.command"},
                status_code=503,
            )
    return app


def run_local(*, port: int = 8765, host: str = "127.0.0.1", open_browser: bool = True) -> None:
    if host not in LOCAL_HOSTS:
        raise ValueError("本地工作台只允许 localhost、127.0.0.1 或 ::1")
    if not 1 <= port <= 65535:
        raise ValueError("port must be between 1 and 65535")
    config.load()
    address = f"[{host}]" if host == "::1" else host
    url = f"http://{address}:{port}"
    app = create_local_app()
    print(f"AMZ 本地工作台 → {url}", flush=True)
    print("按 Ctrl+C 停止；历史与结果会保留。", flush=True)
    if open_browser:
        def open_when_ready():
            from urllib.request import urlopen
            for _ in range(50):
                try:
                    with urlopen(url + "/api/workbench/health", timeout=1):
                        webbrowser.open(url)
                        return
                except OSError:
                    time.sleep(0.2)
        threading.Thread(target=open_when_ready, daemon=True).start()
    import uvicorn
    uvicorn.run(app, host=host, port=port, log_level="info")


def main():
    parser = argparse.ArgumentParser(description="AMZ local workbench")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--no-open", action="store_true")
    args = parser.parse_args()
    run_local(port=args.port, host=args.host, open_browser=not args.no_open)


if __name__ == "__main__":
    main()
