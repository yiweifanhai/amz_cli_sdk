"""Server-owned local execution policy, independent from product visibility."""
from __future__ import annotations

from typing import Any

from amz import registry

# Explicitly reviewed browser entrypoints. Adding a product card cannot authorize
# execution. Expand this set only with the corresponding execution review.
ALLOWED_CAPABILITIES = frozenset({
    'ads.keyword-funnel',
    'category.search',
    'category.tree',
    'data.fx.rate',
    'data.taobao.search',
    'entity.keyword.aba_series',
    'entity.keyword.cluster',
    'entity.keyword.market',
    'entity.keyword.market_opportunity',
    'entity.keyword.market_profile',
    'entity.keyword.market_stats',
    'entity.keyword.metrics',
    'entity.keyword.products',
    'entity.keyword.score',
    'entity.keyword.trends',
    'entity.market.cosmo',
    'entity.market.cosmo_aggregate',
    'entity.market.cosmo_merge',
    'entity.market.demand',
    'entity.market.discover_dimensions',
    'entity.market.gap',
    'entity.market.opportunity',
    'entity.market.primary_pricing_dimension',
    'entity.market.product_refs',
    'entity.market.products',
    'entity.market.profile',
    'entity.market.proposals',
    'entity.market.stats',
    'entity.market.success_factors',
    'entity.market.summary',
    'entity.market.timing',
    'entity.market.tacos',
    'entity.product.classify',
    'entity.product.compare',
    'entity.product.competitors',
    'entity.product.copyability',
    'entity.product.core',
    'entity.product.cosmo',
    'entity.product.cosmo_classify',
    'entity.product.fba_fee',
    'entity.product.finance',
    'entity.product.innovation',
    'entity.product.keyword_gap',
    'entity.product.keyword_relevance',
    'entity.product.listing_allocate',
    'entity.product.listing_diff',
    'entity.product.listing_micro_insert',
    'entity.product.listing_part_rewrite',
    'entity.product.listing_rewrite',
    'entity.product.margin',
    'entity.product.market',
    'entity.product.market_opportunity',
    'entity.product.market_profile',
    'entity.product.market_stats',
    'entity.product.material',
    'entity.product.material_eligibility',
    'entity.product.praise',
    'entity.product.primary_keyword_ref',
    'entity.product.primary_keywords',
    'entity.product.product_details',
    'entity.product.return_on_capital',
    'entity.product.reverse_keywords',
    'entity.product.reviews',
    'entity.product.rufus_qa',
    'entity.product.satisfaction',
    'entity.product.strengths',
    'entity.product.traffic_dimensions',
    'entity.product.unmet_needs',
    'entity.product.use_insights',
    'entity.product.voc',
    'entity.product.weaknesses',
    'entity.product.wishlist',
    'entity.product_draft.classify',
    'entity.product_draft.compare',
    'entity.product_draft.cosmo_classify',
    'entity.product_draft.keyword_gap',
    'entity.product_draft.keyword_relevance',
    'entity.product_draft.listing_allocate',
    'entity.product_draft.listing_diff',
    'entity.product_draft.listing_micro_insert',
    'entity.product_draft.listing_part_rewrite',
    'entity.product_draft.listing_rewrite',
    'entity.product_draft.set_facts',
    'entity.review.items',
    'entity.taobao_market.sample',
    'entity.taobao_market.summary',
    'entity.taobao_product.get',
    'keyword.miner',
    'keyword.reverse',
    'keyword.trends',
    'market.competitors',
    'market.snapshot',
    'product.get',
    'product.nr-page',
    'product.refinements',
    'product.reviews',
    'product.rufus',
    'product.search',
    'search.web',
    'supply.search-1688',
})
PATH_FIELDS = {"csv_path", "path", "file_path", "file", "filename", "target_dir", "output_dir", "output_path"}


def path_fields(schema: dict[str, Any]) -> set[str]:
    found: set[str] = set()
    for name, value in schema.items():
        if name == "properties" and isinstance(value, dict):
            found.update(key for key in value if key in PATH_FIELDS or key.endswith(("_path", "_dir")))
        if isinstance(value, dict):
            found.update(path_fields(value))
        elif isinstance(value, list):
            for item in value:
                if isinstance(item, dict):
                    found.update(path_fields(item))
    return found


def capability_allowed(capability_id: str) -> bool:
    cap = registry.get(capability_id)
    return cap is not None and not cap.internal and capability_id in ALLOWED_CAPABILITIES


def execution_allowed(tool_id: str, kind: str) -> bool:
    if kind == "capability":
        return capability_allowed(tool_id)
    if kind == "composite":
        from amz.serve.workflows import WORKFLOW_ID
        return tool_id == WORKFLOW_ID
    if kind == "skill":
        from amz.serve.skill_runner import ALLOWED_TOOLS
        return tool_id.removeprefix("skill.") in ALLOWED_TOOLS and tool_id.startswith("skill.")
    return False


def runtime_status(tool: dict[str, Any]) -> dict[str, Any]:
    allowed = execution_allowed(tool["id"], tool["kind"])
    supported = allowed
    ready: bool | None = None
    reason = ""
    readiness = "数据源与模型配置将按参数和缓存检查。"
    schema = tool.get("input_schema", {})
    if tool["kind"] == "capability":
        cap = registry.get(tool["id"])
        schema = cap.input_schema if cap is not None else {}
    blocked = path_fields(schema)
    if blocked:
        supported = False
        ready = False
        reason = "需要受控文件上传；当前不接受服务器文件路径（" + "、".join(sorted(blocked)) + "）。"
        readiness = reason
    elif not allowed:
        reason = tool.get("unavailable_reason") or "尚未接入本地执行器，或不在当前执行策略允许范围。"
    return {"supported": supported, "ready": ready, "can_run": allowed,
            "readiness_reason": readiness, "available": supported and allowed and ready is not False,
            "unavailable_reason": reason}
