"""Local web catalog and adapters for published Composite workflows."""

from typing import Any

from pydantic import ValidationError

from amz.composite.product_development import (
    OUTPUT_SCHEMA, STEPS, VIEW, VERSION, PLAN, WORKFLOW_ID, ProductDevelopmentInput,
    register_product_development, run_product_development,
)
from amz.envelope import Code, err


def register_workflows() -> None:
    register_product_development()


def list_workflow_tools() -> list[dict]:
    register_workflows()
    return [{
        "id": WORKFLOW_ID, "title": "产品开发", "description": "固定四步，从真实竞品评论得到市场缺口、改进提案与报告。",
        "group": "workflows", "kind": "composite", "input_schema": ProductDevelopmentInput.model_json_schema(),
        "output_schema": OUTPUT_SCHEMA, "renderer": "product-development", "steps": [dict(step) for step in STEPS],
        "version": VERSION, "view": VIEW, "plan": [step.model_dump(mode="json") for step in PLAN],
        "available": True,
    }]


def execute_workflow(tool_id: str, params: dict, context: Any) -> dict:
    if tool_id != WORKFLOW_ID:
        result = err(Code.ERROR_NOT_FOUND, "未知的本地工作流")
    else:
        try:
            inputs = ProductDevelopmentInput.model_validate(params)
        except ValidationError as exc:
            result = err(Code.ERROR_PARAM, str(exc))
        else:
            result = run_product_development(inputs, context)
    return {"result": result, "report": (result.data or {}).get("report", "") if isinstance(result.data, dict) else ""}

list_workflows = list_workflow_tools
execute = execute_workflow
